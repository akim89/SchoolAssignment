<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - Shareholder Roles Used in Forms");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
					
			<!-- Skin the dropdown menus -->

			$('.dropdown').multiselect({
				multiple: false,
				header: "Select an option",
				noneSelectedText: "Select an option",
				selectedList: 1,
				minWidth: 170
			});
			
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});
			
			<!-- Change the report when the user selects a new option -->
			
			$('.dropdown').change(function(){
				window.location = "<?php echo $_SERVER['PHP_SELF'] ?>?" + $(this).attr('name') + '=' +$(this).val();
			});
			
			
		});

	</script>	
	
<?php
	
	body_start();	
	navigation_start("report");	
	
		$ShareholderID = validate("int", @$_GET['shareholder'], 'shareholder', 0);
		$RoleID        = validate("int", @$_GET['role'], 'role', 0);
	
		echo "<div align='center'>";				
			
			echo "<table align='center'>";
				echo "<tr class='bold'>";
					echo "<td align='center'>Shareholders</td>";
					echo "<td align='center'>Roles</td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_SHAREHOLDERS, "items" => lookup_dropdown_menu(DB_TABLE_SHAREHOLDERS), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE, "value" => $ShareholderID)); echo "</td>";
					echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_ROLES, "items" => lookup_dropdown_menu(DB_TABLE_ROLES), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE, "value" => $RoleID)); echo "</td>";
				echo "</tr>";
			echo "</table>";
			
			if(check_messages()){
			
				if($ShareholderID || $RoleID){
				
					if($ShareholderID){
						$Query = "SELECT COUNT(role_name) AS count, r.role_name FROM " . DB_TABLE_FORM_ROLES . " fr LEFT JOIN " . DB_TABLE_ROLES . " r ON r.role_id=fr.role_id LEFT JOIN " . DB_TABLE_SHAREHOLDERS . " s ON s.shareholder_id=fr.shareholder_id WHERE s.shareholder_id='" . $ShareholderID . "' GROUP BY s.shareholder_id, r.role_id ORDER BY COUNT(role_name) DESC, r.role_name";
					}elseif($RoleID){
						$Query = "SELECT COUNT(role_name) AS count, s.shareholder_name FROM " . DB_TABLE_FORM_ROLES . " fr LEFT JOIN " . DB_TABLE_ROLES . " r ON r.role_id=fr.role_id LEFT JOIN " . DB_TABLE_SHAREHOLDERS . " s ON s.shareholder_id=fr.shareholder_id WHERE r.role_id='" . $RoleID . "' GROUP BY r.role_id, s.shareholder_id ORDER BY COUNT(role_name) DESC, s.shareholder_name";
					}				
							
					// Display the report
							
					echo "<div class='boxed_group'>\n";
						echo "<h3>Shareholder Roles Used in Forms</h3>";	
						echo "<div class='boxed_group_inner clearfix'>\n";
							
							$Result = db_query($Query);
							$Count  = row_count($Result);
							
							if($Count > 0){
							
								echo "<table class='report_table'>\n";
									echo "<thead>\n";
										echo "<tr>\n";
											echo "<th>Count</th>\n";
											echo "<th>" . ($ShareholderID ? "Role" : "Shareholder") . "</th>\n";
										echo "</tr>\n";
									echo "</thead>\n";
									echo "<tbody>\n";
					
										while($Info = row_fetch($Result)){
											echo "<tr>\n";
												echo "<td>" . $Info[0] . "</td>\n";
												echo "<td>" . $Info[1] . "</td>\n";										
											echo "</tr>\n";
										}
									
									echo "</tbody>\n";						
								echo "</table>\n";
							
							}else{
								add_message('info', $GLOBALS['infoMessage']['no_records']);
								print_messages();
							}						
				
						echo "</div>\n";						
					echo "</div>\n";
					
				}
				
			}else{
				print_messages();
			}
			
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>