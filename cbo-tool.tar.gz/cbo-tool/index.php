<?php 

	ob_start();
	include("includes.php");
	redirect(DEFAULT_PAGE);
		
?>