<?php

	// CBO Fiscal Year Reset Date: Dec 1st
	
	require_once("includes.php");
	db_connect();

	// Change to the directory (needed for the PHP CLI to work correctly with Cron)
	
	chdir(PATH_ROOT_DIR . "/" . PATH_WWW);		
	
	echo "BEGIN reset audit dates\n";
		echo "\tStart Time: " . date('Y-m-d H:i:s', time()) . "\n";	
		
			// Set the update values
			
			$_COOKIE['user_id']         = $UserID = 1;	// For dblog
			$_SERVER['REMOTE_ADDR']     = '127.0.0.1';	// For dblog
			$_SERVER['SCRIPT_FILENAME'] = getcwd() . "/" . $_SERVER['SCRIPT_FILENAME'];	// For dblog
			
			$Info['last_audit_date'] = NULL;
			$Info['date_updated']    = "NOW()";
			$Info['updated_by']      = $UserID;

			// Start the DB transaction
			
			if(begin_db_transaction()){
				
					$Success    = TRUE;
					$BoxCount   = 0;
					$ShareCount = 0;
					
					// Reset each box
					
					$Query = "SELECT box_id FROM " . DB_TABLE_BOXES . " WHERE deleted=0 AND last_audit_date IS NOT NULL";
					$Result = db_query($Query);
					
					while($Box = row_fetch_assoc($Result)){
						if(!db_query(create_sql_update($Info, array('box_id' => $Box['box_id']), DB_TABLE_BOXES))){ $Success = FALSE; }
						if(!create_audit_entry(DB_TABLE_BOXES, $Box['box_id'], $UserID)){ $Success = FALSE; }
						$BoxCount++;
					}
					
					// Reset each share
					
					$Query = "SELECT share_id FROM " . DB_TABLE_SHARES . " WHERE deleted=0 AND last_audit_date IS NOT NULL";
					$Result = db_query($Query);
										
					while($Share = row_fetch_assoc($Result)){
						if(!db_query(create_sql_update($Info, array('share_id' => $Share['share_id']), DB_TABLE_SHARES))){ $Success = FALSE; }
						if(!create_audit_entry(DB_TABLE_SHARES, $Share['share_id'], $UserID)){ $Success = FALSE; }
						$ShareCount++;
					}
					
					// Display an error and rollback the changes if there was a problem with any of the queries, otherwise commit them
								
					if($Success){
						commit_db_transaction();	
						echo "\t\tSUCCESS: " . $GLOBALS['successMessage']['changes_saved'] . " There were $BoxCount box(es) reset and $ShareCount share(s) reset.\n";
					}else{
						rollback_db_transaction();
						echo "\t\tERROR: " . $GLOBALS['errorMessage']['db_write_failure_multiple'] . "\n";			
					}
					
			}else{
				echo "\t\tERROR: " . $GLOBALS['errorMessage']['db_unable_to_begin_transaction'] . "\n";
			}

		echo "\tEnd Time: " . date('Y-m-d H:i:s', time()) . "\n";
	echo "END reset audit dates\n";
	
	db_close();
	
?>