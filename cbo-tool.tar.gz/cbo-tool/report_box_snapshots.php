<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - Safe Deposit Box Snapshots");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
					
			<!-- Skin the dropdown menus -->

			$('.dropdown').multiselect({
				multiple: false,
				header: "Select an option",
				noneSelectedText: "Select an option",
				selectedList: 1,
				minWidth: 170
			});
			
			<!-- Format the datepickers -->
						
			$(".datepicker" ).datepicker({
				changeMonth: true,
				changeYear: true,
				dateFormat: 'yy-mm-dd'
			});
			
			<!-- Change the report when the user selects a new option -->
			
			$('.dropdown, .datepicker').change(function(){
				if(!!$('#date').val() && !!$('#box').val()){
					window.location = "<?php echo $_SERVER['PHP_SELF'] ?>?box=" + $('#box').val() + "&date=" + $('#date').val();
				}
			});
			
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});
			
			<!-- Make the backgournd color for the first cell in each row white -->
			
			$('tr').each(function(){
				$(this).find('td:first, th:first').css('background', 'white');
			});
			
		});

	</script>	
	
<?php
	
	body_start();	
	navigation_start("report");	
	
		$BoxID = validate("int", @$_GET['box'], 'box', 0);
		$Date  = validate("regex", @$_GET['date'], 'date', 0, "date");
	
		echo "<div align='center'>";				
			
			echo "<div style='margin-bottom: 30px'>";
				
				echo "<table>";
						echo "<tr style='text-align: center; font-weight: bold;'>";
								echo "<td>Box</td>";
								echo "<td>Date</td>";
						echo "</tr>";
						echo "<tr>";
								echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_BOXES, "items" => lookup_dropdown_menu(DB_TABLE_BOXES), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE, "value" => $BoxID)); echo "</td>";
								echo "<td>"; form_date_time(array("use_table" => FALSE, "name" => "date", "value" => $Date, "date_only" => TRUE, "css" => "autocomplete='off' class='datepicker'")); echo "</td>";
						echo "</tr>";
				echo "</table>";
								
			echo "</div>";
			
			if(check_messages()){
			
				if($BoxID && $Date){
				
					$Query = "SELECT s.box_snapshot_id, GROUP_CONCAT(share_id) AS shares, s.date_created, IF(form_name IS NOT NULL, form_name, 'Admin Panel') AS form_name, s.form_id, execution_id FROM box_snapshot s LEFT JOIN box_snapshot_contents c ON s.box_snapshot_id=c.box_snapshot_id LEFT JOIN form f ON f.form_id=s.form_id WHERE box_id=$BoxID AND s.deleted=0 AND c.deleted=0 AND DATE_FORMAT(s.date_created, '%Y-%m-%d')=(SELECT DATE_FORMAT(date_created, '%Y-%m-%d') FROM box_snapshot WHERE box_id=$BoxID AND date_created <= '$Date 23:59:59' AND deleted=0 ORDER BY date_created DESC LIMIT 1) GROUP BY s.box_snapshot_id";
					$Result = db_query($Query);
					$Count  = row_count($Result);
					
					if($Count > 0){
					
						while($Current = row_fetch_assoc($Result)){
					
							echo "<div class='boxed_group'>\n";
								echo "<h3>Safe Deposit Box Snapshot as of " . $Current['date_created'] . "</h3>";	
								echo "<div class='boxed_group_inner clearfix'>\n";
						
									echo "<div class='margin_bottom_15px margin_top_10px' align='left'>\n";
										echo "<span class='bold'>Snapshot Created By:</span> " . ($Current['form_name'] == "Admin Panel" ? $Current['form_name'] : "<a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . lookup_filename_for_form_execution($Current['form_id'], $Current['execution_id']) . "'>" . $Current['form_name'] . "</a>");
									echo "</div>\n";
																		
									echo "<table class='report_table'>\n";
										echo "<thead>\n";
											echo "<tr>\n";
												echo "<th width='20'></th>\n";
												echo "<th>Label</th>\n";
												echo "<th>Media Type</th>\n";
												echo "<th>Key Type</th>\n";
												echo "<th>Date Distributed</th>\n";
											echo "</tr>\n";
										echo "</thead>\n";
										echo "<tbody>\n";
											
											$Count = 0;
											
											foreach(explode(',', $Current['shares']) as $ShareID){
												$Query  = "SELECT share_label, media_type_name, key_type_name, original_distribution_date FROM " . DB_TABLE_SHARES . " s LEFT JOIN " . DB_TABLE_MEDIA_TYPES . " m ON m.media_type_id=s.media_type_id LEFT JOIN " . DB_TABLE_KEY_TYPES . " k ON k.key_type_id=s.key_type_id WHERE share_id=" . $ShareID . " ORDER BY share_label";																							
												$Result2 = db_query($Query);
												$Info = row_fetch_assoc($Result2);
												
												echo "<tr>\n";
													echo "<td>" . ++$Count . ".</td>\n";
													echo "<td>" . $Info['share_label'] . "</td>\n";
													echo "<td>" . $Info['media_type_name'] . "</td>\n";
													echo "<td>" . $Info['key_type_name'] . "</td>\n";
													echo "<td>" . $Info['original_distribution_date'] . "</td>\n";
												echo "</tr>\n";
											}
										
										echo "</tbody>\n";						
									echo "</table>\n";						
						
								echo "</div>\n";						
							echo "</div>\n";
						}
						
					}else{
						add_message('info', $GLOBALS['infoMessage']['no_records']);
						print_messages();
					}									
				}
					
			}else{
				print_messages();
			}
			
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>