<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - Shareholders Used for Events");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
					
			<!-- Skin the dropdown menus -->

			$('.dropdown').multiselect({
				multiple: false,
				header: "Select an option",
				noneSelectedText: "Select an option",
				selectedList: 1,
				minWidth: 170
			});
			
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});
			
			<!-- Change the report when the user selects a new option -->
			
			$('.datepicker').change(function(){
				window.location = "<?php echo $_SERVER['PHP_SELF'] ?>?" + $(this).attr('name') + '=' + $(this).val();
			});
			
			<!-- Create the datepicker -->
			
			$(".datepicker" ).datepicker({
				changeMonth: true,
				changeYear: true,
				dateFormat: 'yy-mm-dd'
			});
			
		});

	</script>	
	
<?php
	
	body_start();	
	navigation_start("report");	
	
		$Date = validate("regex", @$_GET['date'], 'date', 0, 'date');
	
		echo "<div align='center'>";				
			
			echo "<div style='margin-bottom: 30px'>";
				echo "<div class='bold' style='margin-bottom: 5px;'>Used Since</div>";
				form_date_time(array("title" => "", "delimiter" => "", "name" => "date", "value" => $Date, "css" => "autocomplete='off' class='datepicker'"));
			echo "</div>";
			
			if(check_messages()){
			
				$SubQuery = ($Date ? " AND start_date >= '" . $Date . "' " : NULL);
			
				$Query = "SELECT COUNT(e.event_id) AS times_used, shareholder_name, IF(MAX(e.start_date), MAX(e.start_date), 'Never Used') AS last_used FROM " . DB_TABLE_SHAREHOLDERS . " s LEFT JOIN " . DB_TABLE_EVENT_SHAREHOLDERS . " es ON s.shareholder_id=es.shareholder_id AND es.deleted=0 LEFT JOIN " . DB_TABLE_EVENTS . " e ON es.event_id=e.event_id AND e.deleted=0 AND e.cancelled=0 WHERE s.deleted=0 " . $SubQuery . " GROUP BY s.shareholder_id ORDER BY COUNT(es.shareholder_id) DESC";
			
				// Display the report
						
				echo "<div class='boxed_group'>\n";
					echo "<h3>Shareholders Used for Events</h3>";	
					echo "<div class='boxed_group_inner clearfix'>\n";
						
						$Result = db_query($Query);
						$Count  = row_count($Result);
						
						if($Count > 0){
						
							echo "<table class='report_table'>\n";
								echo "<thead>\n";
									echo "<tr>\n";
										echo "<th>Count</th>\n";
										echo "<th>Shareholder</th>\n";
										echo "<th>Last Used</th>\n";
									echo "</tr>\n";
								echo "</thead>\n";
								echo "<tbody>\n";
				
									while($Info = row_fetch($Result)){
										echo "<tr>\n";
											echo "<td>" . $Info[0] . "</td>\n";
											echo "<td>" . $Info[1] . "</td>\n";	
											echo "<td>" . $Info[2] . "</td>\n";
										echo "</tr>\n";
									}
								
								echo "</tbody>\n";						
							echo "</table>\n";
						
						}else{
							add_message('info', $GLOBALS['infoMessage']['no_records']);
							print_messages();
						}						
			
					echo "</div>\n";						
				echo "</div>\n";

			}else{
				print_messages();
			}
			
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>
