<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - Equipment Model Types");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
						
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});
			
			<!-- Change the report when the user selects a new option -->
			
			$('.dropdown').change(function(){
				window.location = "<?php echo $_SERVER['PHP_SELF'] ?>?<?php echo DB_TABLE_MODEL_TYPES; ?>=" + $('#<?php echo DB_TABLE_MODEL_TYPES; ?>').val() + "&<?php echo DB_TABLE_EQUIP_VERSIONS; ?>=" + $('#<?php echo DB_TABLE_EQUIP_VERSIONS; ?>').val();
			});		
			
		});

	</script>

	<style>
	
		select.dropdown{
		   background: #EDEDED;
		   border: solid 1px #D3D3D3;
		   border-radius: 4px;
		   color: #555555;
		   padding: 3px;
		   font-size: 10px;
		   font-family: Verdana,Arial,sans-serif;
		   height: 24px;
		   width: 175px;
		   margin: 0 5px;		   
		}
		   
		select.dropdown > option{
			padding: 5px 5px;
			background-color: white;
		}
		
		select:hover, option:hover{
			background-color: lightgray;
		}	
		
	</style>	
	
<?php
	
	body_start();	
	navigation_start("report");	
	
		$ModelType = validate("int", @$_GET[DB_TABLE_MODEL_TYPES], 'model type', 0);
		$Version   = validate("int", @$_GET[DB_TABLE_EQUIP_VERSIONS], 'version', 0);
	
		echo "<div align='center'>";				
			
			echo "<table align='center'>";
				echo "<tr class='bold'>";
					echo "<td align='center'>Model Types</td>";
					echo "<td align='center'>Versions</td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_MODEL_TYPES, "items" => lookup_dropdown_menu(DB_TABLE_MODEL_TYPES), "css" => "class='dropdown'", "select_opt_text" => "Select an option", "value" => @$ModelType)); echo "</td>";
					echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_EQUIP_VERSIONS, "items" => lookup_dropdown_menu(DB_TABLE_EQUIP_VERSIONS), "css" => "class='dropdown'", "select_opt_text" => "Select an option", "value" => @$Version)); echo "</td>";
				echo "</tr>";
			echo "</table>";
			
			if(check_messages()){
			
				if($ModelType || $Version){
				
					if($Version && $ModelType){
						$Query = "SELECT COUNT(equipment_id) AS count, model_type_name AS model, equipment_version_name AS version FROM " . DB_TABLE_EQUIP . " e LEFT JOIN " . DB_TABLE_MODEL_TYPES . " m ON m.model_type_id=e.model_type_id LEFT JOIN " . DB_TABLE_EQUIP_VERSIONS . " v ON v.equipment_version_id=e.equipment_version_id WHERE e.deleted=0 AND e.model_type_id=" . $ModelType . " AND e.equipment_version_id=" . $Version . " HAVING count > 0";
					}elseif($ModelType){
						$Query = "SELECT COUNT(equipment_id) AS count, model_type_name AS model, GROUP_CONCAT(DISTINCT equipment_version_name SEPARATOR ', ') AS version FROM " . DB_TABLE_EQUIP . " e LEFT JOIN " . DB_TABLE_MODEL_TYPES . " m ON m.model_type_id=e.model_type_id LEFT JOIN " . DB_TABLE_EQUIP_VERSIONS . " v ON v.equipment_version_id=e.equipment_version_id WHERE e.deleted=0 AND e.model_type_id=" . $ModelType . " HAVING count > 0";
					}elseif($Version){
						$Query = "SELECT COUNT(equipment_id) AS count, GROUP_CONCAT(DISTINCT model_type_name SEPARATOR ', ') AS model, equipment_version_name AS version FROM " . DB_TABLE_EQUIP . " e LEFT JOIN " . DB_TABLE_MODEL_TYPES . " m ON m.model_type_id=e.model_type_id LEFT JOIN " . DB_TABLE_EQUIP_VERSIONS . " v ON v.equipment_version_id=e.equipment_version_id WHERE e.deleted=0 AND e.equipment_version_id=" . $Version . " HAVING count > 0";
					}		
					
					// Display the report
							
					echo "<div class='boxed_group'>\n";
						echo "<h3>Equipment Model/Version Inventory</h3>";	
						echo "<div class='boxed_group_inner clearfix'>\n";
							
							$Result = db_query($Query);
							$Count  = row_count($Result);
							
							if($Count > 0){
							
								echo "<table class='report_table'>\n";
									echo "<thead>\n";
										echo "<tr>\n";
											echo "<th>Count</th>\n";
											echo "<th>Model Type</th>\n";
											echo "<th>Version</th>\n";
										echo "</tr>\n";
									echo "</thead>\n";
									echo "<tbody>\n";
					
										while($Info = row_fetch($Result)){
											echo "<tr>\n";
												echo "<td>" . $Info[0] . "</td>\n";
												echo "<td>" . $Info[1] . "</td>\n";										
												echo "<td>" . $Info[2] . "</td>\n";										
											echo "</tr>\n";
										}
									
									echo "</tbody>\n";						
								echo "</table>\n";
							
							}else{
								add_message('info', $GLOBALS['infoMessage']['no_records']);
								print_messages();
							}						
				
						echo "</div>\n";						
					echo "</div>\n";
					
				}
				
			}else{
				print_messages();
			}
			
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>