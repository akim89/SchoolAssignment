<?php

	require_once("includes.php");
	db_connect();

	// Change to the directory (needed for the PHP CLI to work correctly with Cron)

	chdir(PATH_ROOT_DIR . "/" . PATH_WWW);

	echo "BEGIN update user info\n";
		echo "\tStart Time: " . date('Y-m-d H:i:s', time()) . "\n";

			// Set some logging values

			$_COOKIE['user_id']         = $UserID = 1;	// For dblog
			$_SERVER['REMOTE_ADDR']     = '127.0.0.1';	// For dblog
			$_SERVER['SCRIPT_FILENAME'] = getcwd() . "/" . $_SERVER['SCRIPT_FILENAME'];	// For dblog

			// Start the DB transaction

			if(begin_db_transaction()){

					$Success = TRUE;
					$Count   = 0;

					// Connect to the LDAP server

					$AD = ldap_connect(LDAP_SERVER);
					ldap_set_option($AD, LDAP_OPT_PROTOCOL_VERSION, 3);
					ldap_set_option($AD, LDAP_OPT_REFERRALS, 0);
					$Bind = @ldap_bind($AD, LDAP_USER . "@" . LDAP_DOMAIN, LDAP_PASS);

					if($Bind){

						// Find all users

						$Query = "SELECT user_id, username, title FROM " . DB_TABLE_USERS . " WHERE disabled=0 AND username IS NOT NULL";
						$Result = db_query($Query);

						// Lookup each user in AD

						while($User = row_fetch_assoc($Result)){

							$LDAPResult = ldap_search($AD, LDAP_BASEDN, "sAMAccountName=" . $User['username']);
							$LDAPData   = ldap_get_entries($AD, $LDAPResult);

							// AD data was found

							if($LDAPResult){
								$JobTitle = @$LDAPData[0]['title'][0];

								// Update the users title if it has changed

								if($User['title'] != $JobTitle){
									if(!db_query(create_sql_update(array('title' => $JobTitle), array('user_id' => $User['user_id']), DB_TABLE_USERS))){ $Success = FALSE; }
									$Count++;
								}
							}
						}

						// Display an error and rollback the changes if there was a problem with any of the queries, otherwise commit them

						if($Success){
							commit_db_transaction();
							echo "\t\tSUCCESS: " . $GLOBALS['successMessage']['changes_saved'] . " There were $Count user(s) updated.\n";
						}else{
							rollback_db_transaction();
							echo "\t\tERROR: " . $GLOBALS['errorMessage']['db_write_failure_multiple'] . "\n";
						}

					}else{
						echo "\t\tERROR: " . $GLOBALS['errorMessage']['unable_bind_ldap'] . "\n";
					}

			}else{
				echo "\t\tERROR: " . $GLOBALS['errorMessage']['db_unable_to_begin_transaction'] . "\n";
			}

		echo "\tEnd Time: " . date('Y-m-d H:i:s', time()) . "\n";
	echo "END update user info\n";

	db_close();

?>
