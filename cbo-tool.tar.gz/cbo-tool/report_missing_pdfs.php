<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - Forms Missing PDFs");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
				
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});
			
			$('.report_table > tbody > tr').each(function(){			
				$(this).find('td:first').css('padding-left', '8px');
			});
			
		});

	</script>	
	
<?php
	
	body_start();	
	navigation_start("report");	
	
		echo "<div align='center'>";	

			// Display the report
					
			echo "<div class='boxed_group'>\n";
				echo "<h3>Forms Missing PDF Scans</h3>";	
				echo "<div class='boxed_group_inner clearfix'>\n";
					
					$FormTables = generate_db_array("form_table", "form_name", DB_TABLE_FORMS, array('deleted' => 0));
					
					foreach($FormTables as $Table => $Name){
						$Queries[] = "(SELECT '" . $Name . "' AS form_name, id AS row_id, activity_date, filename FROM " . $Table . " WHERE deleted=0 AND filename_signed IS NULL AND status_id!=3)";
					}
					
					if(@$Queries){
					
						$Query = implode(" UNION ", $Queries);
						$Query .= " ORDER BY activity_date";
						
						$Result = db_query($Query);
						$Count = row_count($Result);						
					}
								
					if(@$Count > 0){
					
						echo "<table class='report_table'>\n";
							echo "<thead>\n";
								echo "<tr>\n";
									echo "<th>Form Name</th>\n";
									echo "<th>Activity Date</th>\n";
									echo "<th>DOCX File</th>\n";
								echo "</tr>\n";
							echo "</thead>\n";
							echo "<tbody>\n";
			
								while($Info = row_fetch($Result)){
									echo "<tr>\n";
										echo "<td style='text-align: left;'>" . $Info[0] . "</td>\n";
										echo "<td>" . $Info[2] . "</td>\n";										
										echo "<td><a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . $Info[3] . "'>" . $Info[3] . "</a></td>\n";										
									echo "</tr>\n";
								}
							
							echo "</tbody>\n";						
						echo "</table>\n";
					
					}else{
						add_message('info', $GLOBALS['infoMessage']['no_records']);
						print_messages();
					}						
		
				echo "</div>\n";						
			echo "</div>\n";
			
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>