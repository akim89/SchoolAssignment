#!/usr/bin/perl -w
use SOAP::Lite;
use Data::Dumper;
use strict;

# USER INPUT
my $sysId = $ARGV[0];

# ENVIRONMENT VARIABLES
our $USERNAME = 'username';
our $PASSWORD = 'password';
our $INSTANCE = 'https://verisigndev.service-now.com';
our $WSDL     = 'cmdb_ci_server.do?SOAP';

# SOAP CONNECTION SETUP
sub SOAP::Transport::HTTP::Client::get_basic_credentials {  return "$USERNAME" => "$PASSWORD";  }
my $soap   = SOAP::Lite->proxy($INSTANCE.'/'.$WSDL);
my $method = SOAP::Data->name('getRecords')->attr({xmlns => 'http://www.service-now.com/'});

# GRAB RACK LOCATION
my @params;
push(@params, SOAP::Data->name(sys_id => $sysId) );
my $result;
$result = $soap->call($method => @params); 


if ($@) {
	# print "$@";  # some kind of error
	print "error";
} else {
	# print Dumper($result);
	print $result->valueof('//getRecordsResponse/getRecordsResult/u_location_label');
}
