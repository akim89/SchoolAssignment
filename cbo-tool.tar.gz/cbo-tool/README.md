cbo
===

Tool for tracking components of CBO ceremonies and generating the necessary forms

User
===========================

```bash
groupadd -g 555 webadmin
useradd -u 555 -g 555 -m -d /home/webadmin -p '*' webadmin
usermod -a -G apache webadmin
chage -I -1 -m 0 -M 99999 -E -1 webadmin
```

Config
===========================

Configuration items can be found in `includes/config.php`.

Passwords
===========================

Passwords should be stored in `includes/.secrets.php`. The current authentication vairables are:

	$GLOBAL_DB_USERNAME   = 'username';
	$GLOBAL_DB_PASSWORD   = 'password';
	$GLOBAL_LDAP_USERNAME = 'username';
	$GLOBAL_LDAP_PASSWORD = 'password';

This file will need to be manually created when deploying.

The `lookupRackLocation.pl` script will also need to be updated with the appropriate ServiceNow username and password.

Database
===========================

The tool utilizes the local `cbo` database.

The `cbo` database schema can be created by importing the `db_install.sql` file.

```bash
mysql -u [username] -p cbo < db_install.sql
```

Note: The above command should only be run if creating a new instance of the tool, as all existing data will be erased.

Connectivity
===========================

* LDAPS connectivity to AD servers
* Connectivity to ServiceNow is required

Permissions
===========================

The `webadmin` and `apache` users should have read/write access to the `forms`, `forms/completed`, `forms/deleted`, `forms/signed`, `forms/signed/unmapped`, `forms/temp`, `logs`, `templates` and `uploads` directories.

Cron Entries
===========================

The cron jobs located in the `crontab` file should be added to the `webadmin` crontab.

The `/usr/local/sysadmin/bglinker/logs` directory should have read/write access for the `webadmin` user.

Admin User
===========================

The initial admin user will need to be configured directly in the database (from the `user` table set `is_admin=1`). That user will then be able to grant/revoke admin priviliges to other users via the `Admin Panel` in the web interface.

Sample Data
===========================

The `templates` directory contains a few of the existing CBO templates. The `forms` directory contains all of the existing tokenized .docx forms as of 2015-10-21.

Apahce Rewrite Rule
===========================

In order to secure login credentials and other sensitive data the following rewrite rule should be appended to `/etc/httpd/conf.d/rewrite.conf`. This will force a redirect from HTTP to HTTPS.

	RewriteCond %{HTTPS} !=on
	RewriteRule ^/cbo(.*)$ https://%{SERVER_NAME}/cbo$1 [R,L]
