<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - HSM Restarts");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
					
			<!-- Skin the dropdown menus -->

			$('.dropdown').multiselect({
				multiple: false,
				header: "Select an option",
				noneSelectedText: "Select an option",
				selectedList: 1,
				minWidth: 170
			});
			
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});
			
			<!-- Change the report when the user selects a new option -->
			
			$('.dropdown').change(function(){
				window.location = "<?php echo $_SERVER['PHP_SELF'] ?>?" + $(this).attr('name') + '=' + $(this).val();
			});
			
			
		});

	</script>	
	
<?php
	
	body_start();	
	navigation_start("report");	
	
		$HSMID = validate("int", @$_GET['hsm'], 'HSM', 0);
	
		echo "<div align='center'>";				
			
			echo "<table align='center'>";
				echo "<tr class='bold'>";
					echo "<td align='center'>HSM</td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => "hsm", "items" => lookup_dropdown_menu(DB_TABLE_EQUIP . "_hsm"), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE, "value" => $HSMID)); echo "</td>";
				echo "</tr>";
			echo "</table>";
			
			if(check_messages()){
			
				if($HSMID){
				
					$Query = "SELECT date_restarted, execution_id, r.form_id, form_name FROM " . DB_TABLE_EQUIP_RESTARTS . " r LEFT JOIN " . DB_TABLE_EQUIP . " e ON e.equipment_id=r.equipment_id LEFT JOIN " . DB_TABLE_FORMS . " f ON f.form_id=r.form_id WHERE e.equipment_id='" . $HSMID . "' ORDER BY date_restarted";	
							
					// Display the report
							
					echo "<div class='boxed_group'>\n";
						echo "<h3>HSM Restart Dates</h3>";	
						echo "<div class='boxed_group_inner clearfix'>\n";
							
							$Result = db_query($Query);
							$Count  = row_count($Result);
							
							if($Count > 0){
							
								echo "<table class='report_table'>\n";
									echo "<thead>\n";
										echo "<tr>\n";
											echo "<th width='150'>Count</th>\n";
											echo "<th width='300'>Source</th>\n";
											echo "<th>Date</th>\n";
										echo "</tr>\n";
									echo "</thead>\n";
									echo "<tbody>\n";
					
										$Count = 1;
										while($Info = row_fetch_assoc($Result)){
											echo "<tr>\n";
												echo "<td>" . $Count . "</td>\n";
												echo "<td><a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . lookup_filename_for_form_execution($Info['form_id'], $Info['execution_id']) . "'>" . $Info['form_name'] . "</a></td>\n";
												echo "<td>" . $Info['date_restarted'] . "</td>\n";										
											echo "</tr>\n";
											$Count++;
										}
									
									echo "</tbody>\n";						
								echo "</table>\n";
							
							}else{
								add_message('info', $GLOBALS['infoMessage']['no_records']);
								print_messages();
							}						
				
						echo "</div>\n";						
					echo "</div>\n";
					
				}
				
			}else{
				print_messages();
			}
			
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>