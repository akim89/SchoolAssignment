<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - Shareholders that Backed Out of an Event");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
			
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});	
			
		});

	</script>	
	
<?php
	
	body_start();	
	navigation_start("report");	
		
		echo "<div align='center'>";
			
			$Query = "SELECT COUNT(e.event_id) AS times_backed_out, shareholder_name FROM " . DB_TABLE_EVENT_SHAREHOLDERS . " es LEFT JOIN " . DB_TABLE_SHAREHOLDERS . " s ON s.shareholder_id=es.shareholder_id LEFT JOIN " . DB_TABLE_EVENTS . " e ON e.event_id=es.event_id AND e.cancelled=0 AND e.deleted=0 WHERE es.deleted=1 GROUP BY es.shareholder_id ORDER BY times_backed_out DESC";
			
			// Display the report
					
			echo "<div class='boxed_group'>\n";
				echo "<h3>Shareholders that Backed Out of an Event</h3>";	
				echo "<div class='boxed_group_inner clearfix'>\n";
					
					$Result = db_query($Query);
					$Count  = row_count($Result);
					
					if($Count > 0){
					
						echo "<table class='report_table'>\n";
							echo "<thead>\n";
								echo "<tr>\n";
									echo "<th>Count</th>\n";
									echo "<th>Shareholder</th>\n";
								echo "</tr>\n";
							echo "</thead>\n";
							echo "<tbody>\n";
			
								while($Info = row_fetch($Result)){
									echo "<tr>\n";
										echo "<td>" . $Info[0] . "</td>\n";
										echo "<td>" . $Info[1] . "</td>\n";	
									echo "</tr>\n";
								}
							
							echo "</tbody>\n";						
						echo "</table>\n";
					
					}else{
						add_message('info', $GLOBALS['infoMessage']['no_records']);
						print_messages();
					}						
		
				echo "</div>\n";						
			echo "</div>\n";
				
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>
