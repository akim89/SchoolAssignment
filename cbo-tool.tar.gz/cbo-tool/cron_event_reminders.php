<?php

	require_once("includes.php");

	// Change to the directory (needed for the PHP CLI to work correctly with Cron)
	
	chdir(PATH_ROOT_DIR . "/" . PATH_WWW);		

	require_once(PATH_FRAMEWORK_LANGUAGE . '/en/messages.php');	
	autoload_classes();	
	db_connect();
	
	echo "BEGIN email event reminder\n";
		echo "\tStart Time: " . date('Y-m-d H:i:s', time()) . "\n";	
				
			$Reminders = todays_event_email_reminders();
			
			if(count($Reminders)){
				
				if(begin_db_transaction()){
				
					// Loop through each reminder
					
					foreach($Reminders as $Reminder){

						$Success = TRUE;
					
						// Lookup recipients
						
						$Recipients = list_event_recipients($Reminder['event_id']);
						
						// Generate the iCal file
						
						// $meeting = new iCalendarEvent;
						// $meeting->setSubject($Reminder['start_date'] . " - " . $Reminder['site_name'] . " - CBO - " . $Reminder['event_name'])
						// ->setDescription("This is reminder of your participation in a CBO Event. Please remember to bring your badge.\n\nThank you,\nCBO team")
						// ->setLocation($Reminder['site_name'])
						// ->setOrganizerEmail(ICAL_FROM)
						// ->setStartTimestamp(gmdate('Y-m-d H:i:s', (strtotime($Reminder['start_date'] . " " . $Reminder['start_time']))))
						// ->setEndTimestamp(gmdate('Y-m-d H:i:s', (strtotime($Reminder['start_date'] . " " . $Reminder['end_time']))));
						
						// if($Reminder['ical_uid']){
							// $meeting->setUID($Reminder['ical_uid']);
						// }
					 
						// foreach($Recipients as $Email){
							// if($Email){
								// $attendee = new iCalendarAttendee;
								// $attendee->setEmail($Email)->setRSVP(TRUE);
								// $meeting->addAttendee($attendee);
							// }
						// }
						
						// if(count($meeting->getErrors())){
							// echo "\t\tERROR: Unable to successfully create iCal file.";
							// foreach($meeting->getErrors() as $Error){
								// echo "\t\tERROR: " . $Error;
							// }
						// }else{
							// $iCalString = $meeting->returnString()->create();
							
							// // Update the database with iCal UID
							
							// if(!$Reminder['ical_uid']){
								// $EventInfo['ical_uid'] = $meeting->getUID();
								// $EventWhere['event_id'] = $Reminder['event_id'];
							
								// if(!db_query(create_sql_update($EventInfo, $EventWhere, DB_TABLE_EVENTS))){ $Success = FALSE; }	
							// }							
						// }
						
						// Load and replace the template tokens

						$Subject = $Reminder['subject'];
						$Body    = nl2br($Reminder['body']);
								
						if($Reminder['days_notice'] > 0){
							if($Reminder['days_notice'] % 7 == 0){
								$Notice = ($Reminder['days_notice'] / 7) . " Week";
							}else{
								$Notice = $Reminder['days_notice'] . " Day";
							}
						}else{
							$Notice = "";
						}		
						
						$Subject = str_replace("%date%", $Reminder['start_date'], $Subject);		
						$Subject = str_replace("%reminder_type%", $Notice, $Subject);
						$Subject = str_replace("%site%", $Reminder['site_name'], $Subject);
						$Subject = str_replace("%event_name%", $Reminder['event_name'], $Subject);
						
						$Body = str_replace("%reminder_type%", strtolower($Notice), $Body);	
						$Body = str_replace("%date%", $Reminder['start_date'], $Body);			

						// Send the email
						
						$Mail = new Rmail();
						$Mail->setFrom(EMAIL_FROM);
						$Mail->setBcc(EMAIL_BCC);
						$Mail->setHeadCharset('utf-8');
						$Mail->setTextCharset('utf-8');
						$Mail->setHTMLCharset('utf-8');
						
						if(get_magic_quotes_gpc()){
							$Mail->setSubject(stripslashes($Subject));
							$Mail->setHTML(stripslashes($Body));
						}else{
							$Mail->setSubject($Subject);
							$Mail->setHTML($Body);
						}
						
						// if(count($meeting->getErrors()) == 0){
							// $Mail->addAttachment(new StringAttachment($iCalString, "cbo_event_reminder.ics", 'text/Calendar'));
						// }
						
						$MailResult = $Mail->send($Recipients);
						
						// Update the event scheulde
						
						$ScheduleInfo['sent'] = 1;
						$ScheduleInfo['sent_time'] = "NOW()";
						$ScheduleWhere['event_schedule_id'] = $Reminder['event_schedule_id'];
						
						if(!db_query(create_sql_update($ScheduleInfo, $ScheduleWhere, DB_TABLE_EVENT_SCHEDULE))){ $Success = FALSE; }	
						
						if($Success && $MailResult){
							commit_db_transaction();
							echo "\t\tSUCCESS: (Event Schedule ID " . $Reminder['event_schedule_id'] . ") Email has been successfully sent and the datbase has been updated.\n";
						}else{
							rollback_db_transaction();
							if(!$Success){ echo "\t\tERROR: There was an error writing to the database.\n"; }
							if(!$MailResult){ echo "\t\tERROR: There was an error sending the email.\n"; }
						}
			
					}
					
				}else{
					echo "\t\tERROR: Unable to start database transaction.\n";
				}
				
			}else{
				echo "\t\tINFO: No event email reminders to send.\n";
			}
		
		echo "\tEnd Time: " . date('Y-m-d H:i:s', time()) . "\n";
	echo "END email event reminder\n";
	
	db_close();
	
?>
