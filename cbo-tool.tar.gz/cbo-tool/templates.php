<?php 

	require_once("includes.php");
	db_connect();	
	header_start("CBO Templates");
	uploadify_headers();	
	
?>

	<script>
	
		$(document).ready(function(){
			
			// Display the uploader

			$('#uploadify_filename').uploadify({
				'uploader'        : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify.swf',
				// 'script'          : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify.php',
				'script'          : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify_templates.php',
				'cancelImg'       : '<?php echo PATH_JS_UPLOADIFY; ?>/cancel.png',
				'folder'          : '<?php echo PATH_TEMPLATES; ?>',
				'removeCompleted' : false,
				'sizeLimit'       : <?php echo UPLOADIFY_FILESIZE; ?>,								
				'expressInstall'  : '<?php echo PATH_JS_UPLOADIFY; ?>/expressInstall.swf',
				'auto'            : true,
				'onComplete'      : function(event, queueID, fileObj, response, data){
										loadFiles();
									}
			});
			
			// Display all the files in the "templates" directory
			 
			function loadFiles(allFiles){
				if(!allFiles){
					allFiles = false;
				}

				$.get('<?php echo PATH_AJAX; ?>/ajax_list_templates.php?all_files=' + (allFiles ? 1 : 0), function(data){
					$('#files').html(data);
				});				
			}
			
			// Show or hide all revisions
			
			$('#all_templates').on('click', function(){
				var value = $(this).attr('data-show-all-files');
				loadFiles((value == 1 ? true : false));	// Reload the file list				
				$(this).text((value == 1 ? 'View Latest Versions' : 'View All Versions'));	// Change the text
				$(this).attr('data-show-all-files', (value == 1 ? 0 : 1));	// Flip the bit
				
			});
			
			// Display the files on page load
			
			loadFiles();		
		
		});		
		
	</script>
	
<?php
		
	body_start();	
	navigation_start("templates");
	
		echo "<div align='center'>\n";
		
			// Display the uploader
			
			echo "<div class='boxed_group'>\n";
				echo "<h3>Upload a New Template</h3>";			
				echo "<div class='boxed_group_inner clearfix'>\n";
				
					echo "Select the file you would like to upload.<br /><br />\n";		
					echo "<input id='uploadify_filename' name='uploadify_filename' type='file' />\n";
			
				echo "</div>\n";
			echo "</div>\n";			
			
			// Container for the list of files
			
			echo "<div class='boxed_group'>\n";
				echo "<h3>Existing Templates</h3>";			
				echo "<div class='boxed_group_inner clearfix'>\n";
				
					echo "<div id='files' class='columns margin_top_10px' style='padding: 0 10px;'></div>";						
			
				echo "</div>\n";
			echo "</div>\n";
			
			echo "<div id='all_templates' data-show-all-files='1'>View All Versions</div>";
			
		echo "</div>\n";
		
	footer_start();		
	db_close();
	
?>
