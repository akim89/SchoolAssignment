<?php

	require_once("includes.php");
	db_connect();

	// Change to the directory (needed for the PHP CLI to work correctly with Cron)

	chdir(PATH_ROOT_DIR . "/" . PATH_WWW);

	echo "BEGIN update shareholder info\n";
		echo "\tStart Time: " . date('Y-m-d H:i:s', time()) . "\n";

			// Set some logging values

			$_COOKIE['user_id']         = $UserID = 1;	// For dblog
			$_SERVER['REMOTE_ADDR']     = '127.0.0.1';	// For dblog
			$_SERVER['SCRIPT_FILENAME'] = getcwd() . "/" . $_SERVER['SCRIPT_FILENAME'];	// For dblog

			// Start the DB transaction

			if(begin_db_transaction()){

					$Success = TRUE;
					$Count   = 0;

					// Connect to the LDAP server

					$AD = ldap_connect(LDAP_SERVER);
					ldap_set_option($AD, LDAP_OPT_PROTOCOL_VERSION, 3);
					ldap_set_option($AD, LDAP_OPT_REFERRALS, 0);
					$Bind = @ldap_bind($AD, LDAP_USER . "@" . LDAP_DOMAIN, LDAP_PASS);

					if($Bind){

						// Find all shareholders

						$Query = "SELECT shareholder_id, username, manager_name, desk_location, phone_number, shareholder_name, job_title FROM " . DB_TABLE_SHAREHOLDERS . " WHERE deleted=0 AND username IS NOT NULL";
						$Result = db_query($Query);

						// Lookup each shareholder in AD

						while($Shareholder = row_fetch_assoc($Result)){

							$LDAPResult = ldap_search($AD, LDAP_BASEDN, "sAMAccountName=" . $Shareholder['username']);
							$LDAPData   = ldap_get_entries($AD, $LDAPResult);

							// AD data was found

							if($LDAPResult) {

								// Find the shareholder's managers name

								preg_match('/(?<=CN=)(.*?)(?=,OU)/', @$LDAPData[0]['manager'][0], $Matches);

								if(@$Matches[0]){
									list($ManagerLast, $ManagerFirst) = array_map('trim', explode(',', str_replace('\\', '', $Matches[0])));
									$ManagersName = $ManagerFirst . " " . $ManagerLast;
								}else{
									$ManagersName = NULL;
								}

								// Find the shareholders phone number and desk location

								$TelephoneNumber = @$LDAPData[0]['telephonenumber'][0];
								$DeskLocation    = @$LDAPData[0]['roomnumber'][0];
								$JobTitle        = @$LDAPData[0]['title'][0];
							}

							// Check if any data has changed

							if($Shareholder['manager_name'] != $ManagersName || $Shareholder['desk_location'] != $DeskLocation || $Shareholder['phone_number'] != $TelephoneNumber || $Shareholder['job_title'] != $JobTitle){

								$Info['manager_name']  = $ManagersName;
								$Info['desk_location'] = $DeskLocation;
								$Info['phone_number']  = $TelephoneNumber;
								$Info['job_title']     = $JobTitle;
								$Info['updated_by']    = 1;
								$Info['date_updated']  = "NOW()";

								if(!db_query(create_sql_update($Info, array('shareholder_id' => $Shareholder['shareholder_id']), DB_TABLE_SHAREHOLDERS))){ $Success = FALSE; }
								if(!create_audit_entry(DB_TABLE_SHAREHOLDERS, $Shareholder['shareholder_id'], $UserID)){ $Success = FALSE; }
								$Count++;

								// If the manager changed send out an email

								if($Shareholder['manager_name'] != $ManagersName){
									$Body = $Shareholder['shareholder_name'] . "'s manager changed from " . ($Shareholder['manager_name'] ? $Shareholder['manager_name'] : "NULL") . " to " . $ManagersName;
									echo (mail(EMAIL_MANAGER_CHANGE_TO, EMAIL_MANAGER_CHANGE_SUBJECT, $Body) ? "\t\tSUCCESS: Manager change email successfully sent for " . $Shareholder['shareholder_name'] . ".\n" : "\t\tERROR: Email delivery failed.\n");
								}

								// If the desk location changed send out an email

								if($Shareholder['desk_location'] != $DeskLocation){
									$Body = $Shareholder['shareholder_name'] . "'s desk location changed from " . ($Shareholder['desk_location'] ? $Shareholder['desk_location'] : "NULL") . " to " . $DeskLocation;
									echo (mail(EMAIL_DESK_CHANGE_TO, EMAIL_DESK_CHANGE_SUBJECT, $Body) ? "\t\tSUCCESS: Desk location change email successfully sent for " . $Shareholder['shareholder_name'] . ".\n" : "\t\tERROR: Email delivery failed.\n");
								}

								// If the job title changed send out an email

								if($Shareholder['job_title'] != $JobTitle){
									$Body = $Shareholder['shareholder_name'] . "'s job title changed from " . ($Shareholder['job_title'] ? $Shareholder['job_title'] : "NULL") . " to " . $JobTitle;
									echo (mail(EMAIL_TITLE_CHANGE_TO, EMAIL_TITLE_CHANGE_SUBJECT, $Body) ? "\t\tSUCCESS: Job title change email successfully sent for " . $Shareholder['shareholder_name'] . ".\n" : "\t\tERROR: Email delivery failed.\n");
								}
							}
						}
					}

					// Display an error and rollback the changes if there was a problem with any of the queries, otherwise commit them

					if($Success){
						commit_db_transaction();
						echo "\t\tSUCCESS: " . $GLOBALS['successMessage']['changes_saved'] . " There were $Count shareholder(s) updated.\n";
					}else{
						rollback_db_transaction();
						echo "\t\tERROR: " . $GLOBALS['errorMessage']['db_write_failure_multiple'] . "\n";
					}

			}else{
				echo "\t\tERROR: " . $GLOBALS['errorMessage']['db_unable_to_begin_transaction'] . "\n";
			}

		echo "\tEnd Time: " . date('Y-m-d H:i:s', time()) . "\n";
	echo "END update shareholder info\n";

	db_close();

?>
