<?php

	include("includes.php");
	db_connect();
	header_start("Send A Security Notification");
	multiselect_headers();

?>

	<script>

		$(document).ready(function(){

			<!-- Remove site options that do not apply -->

			$('#site_id option').each(function(){
				if($(this).val() != 3 && $(this).val() != 2 && $(this).val() != 5){
					$(this).remove();
				}
			});

			<!-- Style the single-select dropdown menus -->

			$('#site_id, #work_location_id, #notification_id, select#type_id').multiselect({
				multiple: false,
				header: "Select an option",
				noneSelectedText: "Select an option",
				selectedList: 1
			});

			<!-- Disable work locations if FRI is selected (only applicable with type 1 notifications) -->

			$('#site_id').on('change', function(){
				if($(this).val() == 3){
					$('#work_location_id option').filter('[value=2], [value=3]').attr('disabled', true);
					$('#work_location_id').val(1).multiselect("refresh");
				}else{
					$('#work_location_id option').attr('disabled', false);
					$('#work_location_id').multiselect("refresh");
				}
			});

			<!-- Submit the form -->

			$('form').on('submit', function(e){
				e.preventDefault();
				var form = $(this);

				$.ajax({
					type: "POST",
					url: "<?php echo PATH_AJAX; ?>/ajax_send_security_notification.php?action=" + form.attr('name'),
					data: form.serialize(),
					success: function(response){
						form.prev('.messages').html(response);

						if(/success/.test(response)){
							if(form.attr('name') == "end"){
								$('#notification_id').find('option:selected').remove().end().multiselect("refresh");
							}
							form.find('select').val('').multiselect("uncheckAll").multiselect("refresh");
						}
					}
				});
			});

			<!-- Change fields based on the notification type -->

			$('#work_location_id').parents('tr').hide();

			$('#type_id').on('change', function(){
				if($(this).val() == 1){
					$('#work_location_id').parents('tr').show();
				}else{
					$('#work_location_id').parents('tr').hide();
				}
			});

			<!-- Ignore client-side validation -->

			$('form[name=start]').attr('novalidate', 'novalidate');

		});

	</script>

<?php

	body_start();
	navigation_start("security");

?>

		<div class='margin_right_10px'>

			<div class='boxed_group'>
				<h3>Send Start Notice</h3>
				<div class='boxed_group_inner clearfix'>
					<div align='center'>
						<div class='messages'></div>

						<?php

							// Display the form

							form_start(array("action" => $_SERVER['SCRIPT_NAME'], 'name' => 'start'));
								form_dropdown(array("title" => "Notification Type", "name" => "type_id", "items" => list_security_notification_types(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
								form_dropdown(array("title" => "Site", "name" => "site_id", "items" => list_sites(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
								form_dropdown(array("title" => "Work Location", "name" => "work_location_id", "items" => list_work_locations(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
								form_break();
								form_submit(array("value" => "Send"));
							form_end();

						?>

					</div>
				</div>
			</div>

			<div class='boxed_group'>
				<h3>Send End Notice</h3>
				<div class='boxed_group_inner clearfix'>
					<div align='center'>
						<div class='messages'>

							<?php

								if(count($OpenNotifications = list_access_security_notifications(1)) == 0){
									add_message('info', $GLOBALS['infoMessage']['no_security_notifications']);
									print_messages();
								}

							?>

						</div>

						<?php

							// Display the form

							if(count($OpenNotifications)){
								form_start(array("action" => $_SERVER['SCRIPT_NAME'], 'name' => 'end'));
									form_dropdown(array("title" => "Open Notifications", "name" => "notification_id", "items" => $OpenNotifications, "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
									form_hidden(array("name" => "type_id", "value" => 1));
									form_break();
									form_submit(array("value" => "Send"));
								form_end();
							}

						?>

					</div>
				</div>
			</div>

		</div>

<?php

	footer_start();
	db_close();

?>
