<?php

	require_once("../includes.php");
	db_connect();
	
	//Add HSM Model to form_layout
	
	$Query1 = "INSERT INTO form_layout (form_id, field_name, token_name, field_type, dropdown_option, table_column_name, auto_populate_trigger, auto_populate_value) 
	VALUES (48, HSM Model, {{MODEL}}, dropdown, model_type, model_type_id, SERIAL, model_type_name)";
	$Result1 = db_query($Query1);

	//Add HSM Version to form_layout
	
	$Query2 = "INSERT INTO form_layout (form_id, field_name, token_name, field_type, dropdown_option, table_column_name, auto_populate_trigger, auto_populate_value) 
	VALUES (48, HSM Version, {{HSM_VERSION}}, dropdown, equipment_version, equipment_version_id, SERIAL, equipment_version_name)";
	$Result2 = db_query($Query2);

	//Add Firmware to form_layout
	
	$Query3 = "INSERT INTO form_layout (form_id, field_name, token_name, field_type, table_column_name) 
	VALUES (48, HSM Firmware, {{FIRMWARE_VERSION}}, text, firmware_version)";
	$Result3 = db_query($Query3);

	//Add Escrow Location to form_layout
	
	$Query4 = "INSERT INTO form_layout (form_id, field_name, token_name, field_type, dropdown_option, table_column_name, auto_populate_trigger, auto_populate_value) 
	VALUES (48, HSM Location, {{LOCATION}}, dropdown, escrow_location, escrow_location_id, SERIAL, escrow_location)"; 
	$Result4 = db_query($Query4);

	//Add Product to form_layout
	
	$Query5 = "INSERT INTO form_layout (form_id, field_name, token_name, field_type, dropdown_option, table_column_name, auto_populate_trigger, auto_populate_value) 
	VALUES (48, Product, {{PRODUCT}}, dropdown, product, product_id, SERIAL, product_name)";
	$Result5 = db_query($Query5);

	//Add Environment to form_layout
	
	$Query6 = "INSERT INTO form_layout (form_id, field_name, token_name, field_type, dropdown_option, table_column_name, auto_populate_trigger, auto_populate_value) 
	VALUES (48, Environment, {{ENVIRONMENT}}, dropdown, environment, environment_id, SERIAL, environment_name)";
	$Result6 = db_query($Query6);

	//Delete extraneous form_layout entries
	
	$Query7 = "DELETE FROM form_layout WHERE form_layout_id BETWEEN 3150 AND 3161";
	$Result7 = db_query($Query7);

	$Query8 = "DELETE FROM form_layout WHERE form_layout_id BETWEEN 3129 AND 3134";
	$Result8 = db_query($Query8);

	//Add new columns to HSM Out-Of-Band Attestation to capture additional fields in form_layout
	
	$Query9 = "ALTER TABLE form_hsm_out_of_band_verification_attestation
	ADD COLUMN model_type_id INT(3) NULL,
	ADD COLUMN equipment_version_id INT(10) NULL,
	ADD COLUMN escrow_location_id INT(2) NULL,
	ADD COLUMN environment_id INT(2) NULL,
	ADD COLUMN product_id INT(2) NULL";
	$Result9 = db_query($Query9);

	$Query10 = "ALTER TABLE form_hsm_out_of_band_verification_attestation
	ADD COLUMN firmware_version varchar(32) NULL";
	$Result10 = db_query($Query10);

?>