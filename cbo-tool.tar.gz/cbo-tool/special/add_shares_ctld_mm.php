<?php

 // This script is created to add the CTLD shares for the Max Memory HSMs to the cbo tool
 // This script could be used for other similary situations with careful modifications
 // We are updating two tables: share and audit_share
 // Steps: 
 // Steps 1. create the share in the share table. Then use the share_id to insert into the
 // audit_share table
 // This is not a fancy script. you must know what you are doing here
 // You have to edit that values as per the names and other values
######### 

// Load the Includes Module
  require_once('../includes.php');

 // Connect to the Database
  db_connect();

 // date when the shares are created by the ceremony
 $share_create_date='2016-08-30';

 // WE need to edit the values of the insert statements depending on the product sharetype etc

  // Starting serial number. Working from BRN1
  // The box_id for BRN starts from 1  which is same as the counter(1 to 16)
  $serial_number=101051;

  for ($counter=1; $counter <17; $counter++) {

       $sh_label="PROD-CTLD-ZSK-User-" . $counter . "of16a";
       //define Value set for (share_type_id,product_id,environment_id,key_type_id,media_type_id,mofn_threshold,created_by,share_set,)
       $value_set="12,3,4,3,1,'3of16',26,'a',";
       // insert into share table using the value set above
       //insert_share($sh_label, $serial_number, $counter, $share_create_date, $value_set);

       //echo '<pre>' . print_r($insert_share, true) . '</pre>';
       // once the share is inserted we need to collect the share_id created 
       $this_share_id=get_share_id($serial_number);

       // Use the share_id and insert it along with other data into the audit_share
       insert_audit_share($this_share_id, $sh_label, $serial_number,$share_create_date, $value_set, $counter);  

       $serial_number=$serial_number + 1;
  }


  // do the same for ILG ILG box_id starts from 33
  $ilg_box_id=33;

  for ($counter=1; $counter <17; $counter++) {

       $sh_label="PROD-CTLD-ZSK-User-" . $counter . "of16b";
       //define Value set for (share_type_id,product_id,environment_id,key_type_id,media_type_id,mofn_threshold,created_by,share_set,)
       $value_set="12,3,4,3,1,'3of16',26,'b',";
       // insert into share table using the value set above
       //insert_share($sh_label, $serial_number, $ilg_box_id, $share_create_date, $value_set); 

       // once the share is inserted we need to collect the share_id created
       $this_share_id=get_share_id($serial_number);
       
       // Use the share_id and insert it along with other data into the audit_share
       insert_audit_share($this_share_id, $sh_label, $serial_number,$share_create_date, $value_set, $ilg_box_id);
       $serial_number=$serial_number + 1;
       $ilg_box_id=$ilg_box_id +1;
  }

 //add the SO shares  
 // BRN

  $serial_number=101087;
  $brn_dso_box_id=17;
  for ($counter=1; $counter <7; $counter++) {

       $sh_label="PROD-CTLD-ZSK-SO-" . $counter . "of6e";
       $value_set="10,3,4,3,1,'2of6',26,'e',";
       // insert into share table using the value set above
       //insert_share($sh_label, $serial_number, $brn_dso_box_id, $share_create_date, $value_set); 

       //echo '<pre>' . print_r($insert_share, true) . '</pre>';
       // once the share is inserted we need to collect the share_id created
       $this_share_id=get_share_id($serial_number);
       // insert the share info to the audit_share using this share id
       insert_audit_share($this_share_id, $sh_label, $serial_number,$share_create_date, $value_set, $brn_dso_box_id);
       $serial_number=$serial_number + 1;
       $brn_dso_box_id= $brn_dso_box_id + 1;
  }

  // ILG starting number for the ILG DSO box is 49
  $ilg_dso_box_id=49;

  for ($counter=1; $counter <7; $counter++) {

       $sh_label="PROD-CTLD-ZSK-SO-" . $counter . "of6f";

       $value_set="10,3,4,3,1,'2of6',26,'f',";
       // insert into share table using the value set above
       //insert_share($sh_label, $serial_number, $ilg_dso_box_id, $share_create_date, $value_set);

       // once the share is inserted we need to collect the share_id created
       $this_share_id=get_share_id($serial_number);
       // insert the share info to the audit_share using this share id
       insert_audit_share($this_share_id, $sh_label, $serial_number,$share_create_date, $value_set, $ilg_dso_box_id);
       $serial_number=$serial_number + 1;
        $ilg_dso_box_id= $ilg_dso_box_id + 1;
   }

// START of FUNCTIONS

function get_share_id($serial_number) {
   $get_share_id_qry="SELECT share_id from share where serial_number=" . $serial_number;
       $share_id_data=db_query($get_share_id_qry);
       $data_row = row_fetch_assoc($share_id_data);
       $share_id=$data_row['share_id'];
    return $share_id;
}
function insert_audit_share($this_share_id, $sh_label, $serial_number,$share_create_date, $value_set, $box_id) {

         $insert_audit_share_data="INSERT INTO audit_share (`audit_share_id`,`share_id`,`share_label`, `serial_number`, `share_type_id`, `product_id`, `environment_id`, `key_type_id`,`media_type_id`,`mofn_threshold`,`created_by`,`share_set`,`box_id`, `share_creation_date`)
                         VALUES (NULL," . $this_share_id . ",'" . $sh_label ."','" . $serial_number ."'," . $value_set . $box_id. ",'" . $share_create_date .  "')";
         //echo '<pre>' . print_r($insert_audit_share_data, true) . '</pre>';

          db_query($insert_audit_share_data);
}

function insert_share($sh_label, $serial_number, $box_id, $share_create_date, $val_set) {

       $insert_share="INSERT INTO share (share_id,share_label, serial_number, share_type_id, product_id, environment_id,key_type_id,media_type_id,mofn_threshold,created_by,share_set,`box_id`,`share_creation_date`)
                       Values (NULL,'" . $sh_label ."','" . $serial_number . "'," .  $val_set . $box_id . ",'" .$share_create_date ."')";

       //echo '<pre>' . print_r($insert_share, true) . '</pre>';
       db_query($insert_share);
}


db_close();
?>
