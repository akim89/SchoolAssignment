<?php
// Load the Includes Module
  require_once('../includes.php');

 // Connect to the Database
  db_connect();


  $serial_number=101051;
   
  for ($counter=1; $counter <17; $counter++) {

       //update the share table with boxID and create date 
       $update_data="UPDATE share SET box_id=" . $counter . ", share_creation_date='2016-08-30'  where serial_number=" . $serial_number;
          db_query($update_data);

       $serial_number=$serial_number + 1;
  }

  // do the same for ILG
  $ilg_box_id=33;
  
  for ($counter=1; $counter <17; $counter++) {

       $sh_label="PROD-CTLD-ZSK-User-" . $counter . "of16b";
       //update the share table with boxID and create date 
       $update_boxid="update share set `box_id`=" .$ilg_box_id . ", `share_creation_date`='2016-08-30'  where serial_number=" . $serial_number;
       db_query($update_boxid);
       $serial_number=$serial_number + 1;
       $ilg_box_id= $ilg_box_id + 1;
  }

 //add the SO shares

  $serial_number=101087;
  $brn_dso_box_id=17;
  for ($counter=1; $counter <7; $counter++) {

       $update_boxid="update share set box_id=" . $brn_dso_box_id . ", share_creation_date='2016-08-30'  where serial_number=" . $serial_number;
        
       db_query($update_boxid);
       $serial_number=$serial_number + 1;
       $brn_dso_box_id= $brn_dso_box_id + 1;
  }

  $ilg_dso_box_id=49;
  for ($counter=1; $counter <7; $counter++) {

       $update_boxid="update share set box_id=" . $ilg_dso_box_id . ", share_creation_date='2016-08-30'  where serial_number=" . $serial_number;

       db_query($update_boxid);
       $serial_number=$serial_number + 1;
       $ilg_dso_box_id= $ilg_dso_box_id + 1;
   }


db_close();
?>
