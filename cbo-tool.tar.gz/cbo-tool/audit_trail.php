<?php

	require_once("includes.php");
	db_connect();
	header_start("Audit Tracker");
	multiselect_headers();
	
?>

	<script>

	
		$(document).ready(function(){
		
			<!-- Style the single-select dropdown menus -->
				
			$('.dropdown').multiselect({
				multiple: false,
				selectedList: 1,
				minWidth: 200
			}).multiselectfilter();			
		
			<!-- Highlight changes in the table (except for the last column, which is the timestamp) -->
			
			function highlight_diff(tableID){
				var lastColumn = $(tableID + ' > tbody > tr:first > td').length - 1;
				var $rows = $(tableID + " > tbody > tr");
				
				for (oldIndex = 0; oldIndex < $rows.length-1; oldIndex++) {
					var newIndex = oldIndex + 1;
					var $oldCols = $("td", $rows[oldIndex]);
					var $newCols = $("td", $rows[newIndex]);
					
					for (col = 0; col < $oldCols.length; col++) {
					   var $newCol = $($newCols[col]);
					   if(col != lastColumn && col != 0){
							if ($($oldCols[col]).text() != $newCol.text()) {	// Don't highlight the last column
								if($newCol.find('.highlight_audit_change').length == 0){	// Don't re-highlight a cell
									$newCol.wrapInner("<span class='highlight_audit_change'>");
								}
							}
						}
					}
				}									
			}
			
			<!-- Load physical key audit information -->
			
			$('.dropdown').on('change', function(){
				var type = $(this).attr('id');
			
				$.ajax({
					type: "GET",  
					url: "<?php echo PATH_AJAX; ?>/ajax_audit_" + type + ".php",  
					data: "id=" + $(this).multiselect("getChecked").val(),  
					success: function(response){
						$('#' + type + '_container').slideDown(0500).html(response);	// Display the data
						highlight_diff('#' + type + '_table');	// Highlight row differences			
						$('.audit_table > tbody > tr').removeClass('zebra').filter(":odd").addClass('zebra');	// Zebra stripe the rows
						
						// Set a maximum height of 400px for the audit table
						
						if($('#' + type + '_table').height() > 400){
							$('#' + type + '_table').parent('div').css({'height' : '400px', 'overflow-y' : "auto"});
						}						
					} 
				});			
			});
			
			<!-- Highlight the current row -->
					
			$('.audit_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});	
			
			<!-- Mark or unmark a row if it's double clicked -->
			
			$('.audit_table > tbody > tr').live('dblclick', function(){
				if($(this).hasClass('selected_row')){
					$(this).removeClass('selected_row');
				}else{
					$(this).addClass('selected_row');
				}
			});	
			
		});

	</script>	
	
<?php

	body_start();	
	navigation_start("audit");
	
		echo "<table align='center'>";
			echo "<tr class='bold'>";
				echo "<td align='center'>Physical Keys</td>";
				echo "<td align='center'>Equipment</td>";
				echo "<td align='center'>Shares</td>";
				echo "<td align='center'>Boxes</td>";
				echo "<td align='center'>Personnel</td>";
			echo "</tr>";
			echo "<tr>";
				echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_KEYS, "items" => lookup_dropdown_menu(DB_TABLE_KEYS), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE)); echo "</td>";
				echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_EQUIP, "items" => array_filter((array)lookup_dropdown_menu(DB_TABLE_EQUIP) + (array)lookup_dropdown_menu(DB_TABLE_EQUIP . "_hsm")), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE)); echo "</td>";
				echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_SHARES, "items" => array_filter((array)lookup_dropdown_menu(DB_TABLE_SHARES) + (array)list_passwords()), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE)); echo "</td>";
				echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_BOXES, "items" => lookup_dropdown_menu(DB_TABLE_BOXES), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE)); echo "</td>";
				echo "<td>"; form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_SHAREHOLDERS, "items" => lookup_dropdown_menu(DB_TABLE_SHAREHOLDERS, TRUE), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE)); echo "</td>";
			echo "</tr>";
		echo "</table>";
		
		echo "<div id='" . DB_TABLE_KEYS . "_container' class='audit_container scroll_x'></div>";
		echo "<div id='" . DB_TABLE_EQUIP . "_container' class='audit_container scroll_x'></div>";
		echo "<div id='" . DB_TABLE_SHARES . "_container' class='audit_container scroll_x'></div>";
		echo "<div id='" . DB_TABLE_BOXES . "_container' class='audit_container scroll_x'></div>";
		echo "<div id='" . DB_TABLE_SHAREHOLDERS . "_container' class='audit_container scroll_x'></div>";
		
	footer_start();		
	db_close();
	
?>