<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting - Safe Deposit Box Contents");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
					
			<!-- Skin the dropdown menus -->

			$('.dropdown').multiselect({
				multiple: false,
				header: "Select an option",
				noneSelectedText: "Select an option",
				selectedList: 1,
				minWidth: 170
			});
			
			<!-- Zebra stripe the rows -->
			
			$('.report_table > tbody > tr:odd').addClass('zebra');
			
			<!-- Highlight the current row -->
					
			$('.report_table > tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});
			
			<!-- Change the report when the user selects a new option -->
			
			$('.dropdown').change(function(){
				window.location = "<?php echo $_SERVER['PHP_SELF'] ?>?" + $(this).attr('name') + '=' +$(this).val();
			});
			
			<!-- Make the backgournd color for the first cell in each row white -->
			
			$('tr').each(function(){
				$(this).find('td:first, th:first').css('background', 'white');
			});
			
		});

	</script>	
	
<?php
	
	body_start();	
	navigation_start("report");	
	
		$BoxID = validate("int", @$_GET['box'], 'box', 0);
	
		echo "<div align='center'>";				
			
			echo "<div style='margin-bottom: 30px'>";
				form_dropdown(array("use_table" => FALSE, "name" => DB_TABLE_BOXES, "items" => lookup_dropdown_menu(DB_TABLE_BOXES), "multiselect" => TRUE, "css" => "class='dropdown'", "select_opt" => FALSE, "value" => $BoxID)); 
			echo "</div>";
			
			if(check_messages()){
			
				if($BoxID){
				
					$Query  = "SELECT share_label, media_type_name, key_type_name, original_distribution_date FROM " . DB_TABLE_SHARES . " s LEFT JOIN " . DB_TABLE_MEDIA_TYPES . " m ON m.media_type_id=s.media_type_id LEFT JOIN " . DB_TABLE_KEY_TYPES . " k ON k.key_type_id=s.key_type_id WHERE box_id=" . $BoxID . " ORDER BY share_label";

					// Display the report
							
					echo "<div class='boxed_group'>\n";
						echo "<h3>Safe Deposit Box Contents</h3>";	
						echo "<div class='boxed_group_inner clearfix'>\n";
							
							$Result = db_query($Query);
							$Count  = row_count($Result);
							
							if($Count > 0){
							
								echo "<table class='report_table'>\n";
									echo "<thead>\n";
										echo "<tr>\n";
											echo "<th width='20'></th>\n";
											echo "<th>Label</th>\n";
											echo "<th>Media Type</th>\n";
											echo "<th>Key Type</th>\n";
											echo "<th>Date Distributed</th>\n";
										echo "</tr>\n";
									echo "</thead>\n";
									echo "<tbody>\n";
					
										$Count = 0;
										
										while($Info = row_fetch($Result)){
											echo "<tr>\n";
												echo "<td>" . ++$Count . ".</td>\n";
												echo "<td>" . $Info[0] . "</td>\n";
												echo "<td>" . $Info[1] . "</td>\n";										
												echo "<td>" . $Info[2] . "</td>\n";										
												echo "<td>" . $Info[3] . "</td>\n";										
											echo "</tr>\n";
										}
									
									echo "</tbody>\n";						
								echo "</table>\n";
							
							}else{
								add_message('info', $GLOBALS['infoMessage']['no_records']);
								print_messages();
							}						
				
						echo "</div>\n";						
					echo "</div>\n";
					
				}
				
			}else{
				print_messages();
			}
			
		echo "</div>\n";
		
	footer_start();	
	db_close();
	
?>