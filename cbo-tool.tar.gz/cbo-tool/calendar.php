<?php

	include("includes.php");
	autoload_classes();
	db_connect();	
	header_start("Calendar");

?>
	
	<link href='<?php echo PATH_FRAMEWORK_CALENDAR_CSS; ?>/calendar.css' type="text/css" rel="stylesheet"></link>
	<link href='<?php echo PATH_FRAMEWORK_CALENDAR_CSS; ?>/calendar_monthly.css' type="text/css" rel="stylesheet"></link>
	<link href='<?php echo PATH_FRAMEWORK_CALENDAR_CSS; ?>/calendar_events.css' type="text/css" rel="stylesheet"></link>

<?php

	body_start();	
	navigation_start("calendar");
	
		echo "<div class='margin_right_10px'>\n";
			
			echo "<div align='center' class='margin_bottom_15px'>\n";
				echo "<a class='font_size_13px' href='manage_event.php'><img class='valign_middle small_icon' src='" . PATH_IMAGES . "/calendar.png'> Manage Events</a>\n";
			echo "</div>\n";
				
			// Create a new calendar object
			
			$cal = new CalendarMonthly();
			$cal->setNavigationYearsVariance(8)
			->setMinYear(2014)
			->setMonth(@$_GET['month'])
			->setYear(@$_GET['year'])
			->showNavigation();
			
			// Lookup all events for the month
			
			$Query  = "(SELECT * FROM " . DB_TABLE_EVENTS . " WHERE start_date LIKE '" . $cal->getPreviousYear() . "-" . $cal->getPreviousMonth() ."%' AND deleted=0 AND cancelled=0)";
			$Query .= "UNION(SELECT * FROM " . DB_TABLE_EVENTS . " WHERE start_date LIKE '" . $cal->getYear() . "-" . $cal->getMonth() ."%' AND deleted=0 AND cancelled=0)";
			$Query .= "UNION(SELECT * FROM " . DB_TABLE_EVENTS . " WHERE start_date LIKE '" . $cal->getNextYear() . "-" . $cal->getNextMonth() ."%' AND deleted=0 AND cancelled=0)";
			$Result = db_query($Query);
			
			// Add each event to the calendar
			
			while($EventInfo = row_fetch_assoc($Result)){
				$event = new CalendarEvent;
                $event->setDate($EventInfo['start_date'])->setTime($EventInfo['start_time'])->addWrapperClass(($EventInfo['confirmed'] == 1 ? 'calendar_event_green' : 'calendar_event_yellow'))->setInnerHTML($EventInfo['event_name'] . " @ " . date('H:i', strtotime($EventInfo['start_time'])));
                $cal->addEvent($event);
			}
						
			$cal->compile();
			
		echo "</div>\n";
		
	footer_start();		
	db_close();
	
?>
