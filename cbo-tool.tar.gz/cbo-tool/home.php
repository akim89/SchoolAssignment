<?php

	require_once("includes.php");
	db_connect();
	header_start("Home");
	multiselect_headers();
	custom_jquery_alert_boxes();
	uploadify_headers();
	special_symbol_replacement_headers();

?>

	<script>

		$(document).ready(function(){

			// Forms Automatic/Manual Button
			$('#forms_button').click(function(){
				var button = $(this).find('span.ui-button-text');
        button.toggleClass('active');
				if(button.hasClass('active')) button.text("Manual Mode");
				else button.text("Automatic Mode");
    	});

			<!-- Replace Microsoft special characters -->

			$('textarea, :text').live('blur', function(){
				$(this).val(removeMSWordChars($(this).val()));
			});

			<!-- Function to style the single-select dropdown menus -->

			function style_dropdown(selector){
				$(selector).multiselect({
					multiple: false,
					header: "Select a form",
					noneSelectedText: "Select a form",
					selectedList: 1,
					minWidth: 400
				}).multiselectfilter();
			}

			<!-- Function to load a list of forms pending approval/rejection -->

			function get_pending_forms(message){

				// Destory any existing dropdowns

				$('#pending_forms').multiselect("destroy");

				$.get('<?php echo PATH_AJAX; ?>/ajax_load_pending_forms.php', function(response){

					// Display the dropdown (or remove it if empty)

					if(!!response){
						$('#pending_forms_container').html(response);
						if(!!message){
							$('#messages2').html(message);	// Dispaly any success messages if there are still items in the dropdown menu
						}
					}else{
						$('#decision_buttons, #pending_forms').remove();	// This will show a success message when the last form in the dropdown is processed
					}

					// If a dropdown was returned manipulate the options and format it

					if(!!response){
						check_for_couriers();	// Check for pending courier forms
					}

				});
			}

			<!-- Load the form information via AJAX -->

			$('#forms').on('change', function(){
				$.ajax({
					type: "GET",
					url: "<?php echo PATH_AJAX; ?>/ajax_form_new.php",
					data: "form_id=" + $('#forms > option:selected').val(),
					success: function(response){

						// Destroy any datepickers that may already exist

						$(".datepicker").datepicker("destroy");

						// Display the repsonse

						$('#results').slideDown(0500).html(response);

						// Skin the dropdown menus

						$('.dropdown').multiselect({
							multiple: false,
							header: "Select an option",
							noneSelectedText: "Select an option",
							selectedList: 1,
							minWidth: 260
						}).multiselectfilter();

						// Format the datepickers

						$(".datepicker" ).datepicker({
							changeMonth: true,
							changeYear: true,
							dateFormat: 'yy-mm-dd'
						});

						// Skin the button

						$('input:submit, input:button').button();

						// Clear out any messages

						$('#messages').html("");

						// Form customizations

						if($('#forms').val() == 32 || $('#forms').val() == 29){	// Combo distribution & Combo change
							$('#FUNCTION').find('option[value="4"]').remove().end().multiselect("refresh");	// Remove the "unassigned" option
						}else if($('#forms').val() == 34){	// Function change
							$('#SITE').find('option:not([value="1"],[value=""],[value="2"],[value="3"],[value="5"])').remove().end().multiselect("refresh");	// Remove options that are not ALL, BRN1, FRI2, ILG1
						}else if($('#forms').val() == 36){	// Role change
							$('#NEW_ROLE, #EXISTING_ROLE').find('option[value="3"],option[value="4"]').remove().end().multiselect("refresh");	// Remove the "Both" and "Sysadmin" options
						}

					}
				});
			});

			// Setup a trigger for looking up an items properties

			$('[data-lookup-values-for]').live('change', function(){
				var targetField = $(this).attr('id');

				var data = new Object();
				data.id = $(this).multiselect("getChecked").val();
				data.dataType = $(this).data('lookup-values-for');

				$.ajax({
					type: "GET",
					dataType: "json",
					url: "<?php echo PATH_AJAX; ?>/ajax_lookup_values.php",
					data: data,
					success: function(response){

						// JSON data was returned

						if(!!response){

							// Find all fields that need to be auto-populated

							$('[my_trigger_is="'+targetField+'"]').each(function(){

								var key = $(this).data('auto-populate-value');
								var errorMsg = 'We attempted to autopopulate the <strong>"' + $(this).parent().siblings().text().slice(0, -1) + '"</strong> but no value was returend from the server. Please verify that the object you are updating is in the correct state.';

								// Auto-filling a text box

								if($(this).prop('type') == "text"){

									// Value is not null/undefined, fill in the value and disable the field

									if(!!response[key]){

										$(this).val(response[key]).prop('disabled', true);

									// Value is null/undefined, enable the field for user input

									}else{
										$(this).val('').prop('disabled', false);
										jAlert(errorMsg);
									}

								// Auto-filling a dropdown menu

								}else if($(this).prop('type') == "select-multiple"){

									// Enable all options for this dropdown menu

									$(this).find('option').prop("disabled", false);

									// Value is not null/undefined, fill in the value and disable the field

									if(!!response[key]){

										// The server returned only one value

										if(/^\d+$/.exec(response[key])){

											$(this).val(response[key]).multiselect("refresh").multiselect("disable").trigger('change');	// The trigger('change') is used to make an additional change to another field if needed (ex: "Safe Cabinet Combo Change" :: Access Personnel -> Function [looked up] -> Pool Type [triggered by 'change'])

										// The server returned multiple values (comma seperated)

										}else if(/^(\d+,?)+$/.exec(response[key])){

											// Create an array out of the comma seperated string

											var values = response[key].split(",");
											var status;

											// Disable all options that are not one of the values returned from the server

											$(this).find('option').filter(function(){

												var optionValue = $(this).val();
												status = 1;

												$.each(values, function(index, value){

													if(value == optionValue){
														status = 0;	// We don't want matches to be included
													}

												});

												return status;

											}).prop("disabled", true);

											// Refresh and enable the dropdown menu

											if($(this).find('option:enabled').length == 1){

												// If only one option remains enabled, go ahead and select it for the user and lock it in

												$(this).val($(this).find('option:enabled').val()).multiselect("refresh").multiselect("disable").trigger('change');	// The trigger('change') is used to make an additional change to another field if needed (ex: "Safe Cabinet Combo Change" :: Access Personnel -> Function [looked up] -> Pool Type [triggered by 'change'])
											}else{

												// If multiple options are enabled, give the user the ability to select the correct one

												$(this).val('').multiselect("uncheckAll").multiselect("refresh").multiselect("enable");
											}
										}

									// Value is null/undefined, enable the target field for user input

									}else{
										$(this).multiselect("uncheckAll").multiselect("refresh").multiselect("enable");
										jAlert(errorMsg);
									}

								}

							});

						}else{
							jAlert('We attempted to autopopulate some values but no JSON was returned from the server. Please verify that the form is configured properly. You may need to contact the system administrator.');
						}

					}
				});

			});

			<!-- Intercept the form submission and send the data via AJAX -->

			var canSubmit = true;

			$('#new_form').find(':submit').live('click', function(e){

				// If the form has been submitted and is still processing don't accept another submission

				if(!canSubmit){
					return
				}

				canSubmit = false;

				// Disable the submit button

				var button = $(this);
				button.hide();

				// Find all disabled form fields

				var disabledFields = $('form').find(':disabled');

				// Enable all disabled form fields so they will be send to the server

				disabledFields.each(function(){
					$(this).prop('disabled', false);
				});

				// Submit the form

				$.ajax({
					type: "POST",
					url: "<?php echo PATH_AJAX; ?>/ajax_form_new.php",
					data: $('form').serializeArray(),
					success: function(response){
						$('#messages').html(response);

						// Reload the pending forms

						get_pending_forms();

						// Re-enable the submit button

						button.show();
						canSubmit = true;
					},
					complete: function(jqXHR){

						// Present the file as a download

						if(/success/.exec(jqXHR.responseText)){
							// window.location = $('.download').attr('href');	// Interupted get_pending_forms() ajax call
							downloadURL($('.download').attr('href'));
						}

					}
				});

				// Re-disable the form fields that the user should not be able to change

				disabledFields.each(function(){
					$(this).prop('disabled', true);
				});

				return false;
			});

			<!-- Function for forcing file download -->

			function downloadURL(url){
				var hiddenIFrameID = 'hiddenDownloader';
				var iframe = document.getElementById(hiddenIFrameID);

				if(iframe === null){
					iframe = document.createElement('iframe');
					iframe.id = hiddenIFrameID;
					iframe.style.display = 'none';
					document.body.appendChild(iframe);
				}
				iframe.src = url;
			};

			<!-- Display the "Approve" and "Reject" buttons when a pending form is selected -->

			$('#pending_forms').live('change', function(){
			 $('#decision_buttons').find('input[type=submit]').show();	// Make all buttons visible

			 										// Determine the Form Mode (i.e. Automatic or Manual on Button)
			 										var isManual = $('#forms_button').find('span.ui-button-text').hasClass('active');

                          //CBO-Tool2.0  CODE for the Dynamic Pending forms for signature Begin
                                var selected_data_str = $(this).val();
                                var selected_data = String(selected_data_str).split("--");
                                var selected_form_info={};
                                var form_name = selected_form_info.form_name = selected_data[0];
                                var execution_id = selected_form_info.execution_id = selected_data[1];
                                //Path to the generic front end
                                var redirect_path = "<?php echo PATH_AUTOFORMS ?>/" + "gen_front_end_form.php";
                                // Manual signature forms
                                // Load Excluded Forms List from form_manual_list
                               var manual_forms_list;
                               $.ajax({
                                url: './autoforms/json/form_manual_list.json',
                                async: false,
                                dataType: 'json',
                                success: function (response) {
                                manual_forms_list = response['manual_forms'];
                                }
                                });
                                // Check if the Current Form is in the List of Excluded Forms, if it is, Set the Redirect
                                // Path to Null so that the Approve/Reject Buttons will Appear. Otherwise, Keep the Redirect
                                // Path as is (gen_front_end_form.php)
                                redirect_path = (manual_forms_list.indexOf(form_name) > -1) ? null : redirect_path;
                                // Only the first item in the list can be viewed/approved/rejected. Commented out for the  CBO 2.0
                                //if ($(this)[0].selectedIndex == 0) {
                                                        //'<input type="text" name="data_file" value="' + data_file + '" />' +
																			// If Manual Mode is Not Enabled, Do the Normal Procedure
																			if(!isManual){
                                        $.ajax({
                                                type: 'HEAD',
                                                url: redirect_path,
                                                success: function(){
                                                     // Create Local Storage Variables
                                                     localStorage.setItem("selected_data_string", selected_data_str[0]);
                                                     localStorage.setItem("execution_id", execution_id);
                                                     //localStorage.setItem("data_file", data_file);
                                       // Pass in the Data File Name and Form ID to the File Handling the Unique Form
                                            	     var form = $('<form action="' + redirect_path + '" method="post">' +
                                                        '<input type="text" name="selected_data_string" value="' + selected_data_str[0] + '" />' +
                                                        '<input type="text" name="execution_id" value="' + execution_id + '" />' +

                                                        '</form>');
                                                    $('body').append(form);
                                                    form.submit();
                                              },
                                                error: function(){
                                                        $('#decision_buttons').show();
                                                        $('input:submit, input:button').button();
                                                }
                                        });
																			}
																			// If Manual Mode is Enabled, Show the Manual Upload Buttons
																			else{
																				$('#decision_buttons').show();
																				$('input:submit, input:button').button();
																			}

                                 //}
                                 /**
                                 else{  // All other options can only be viewed
                                        $('#decision_buttons').show().find('input[type=submit]:gt(0)').hide(); // Hide approve/reject buttons
                                       }
                                  **/

			 });
                     // CBO-TOOL2.0: the code changes for the pending forms End.
			<!-- Intercept the approval/rejection form submission and send the data via AJAX -->

			$('#decision_buttons').find(':submit').live('click', function(e){

				if($(this).attr('value') == "View"){

					// Download the form

					window.location.href = $(this).data('href');

				}else{

					// Submit the form

					$.ajax({
						type: "POST",
						url: "<?php echo PATH_AJAX; ?>/ajax_form_approve_reject.php",
						data: 'submit=' + $(this).val() + '&id=' + $('#pending_forms > option:selected').val(),
						success: function(response) {

							// Reload the pending forms if success

							if(/success/.exec(response)){
								get_pending_forms(response);
							}

							// Display any error messages

							$('#messages2').html(response);
						}
					});

				}

				return false;
			});
                          // CBO-TOOL2.0: Do we need this code End
			<!-- Do not permit back-dating on box audit forms -->

			$('.datepicker').live('change', function(){
				if($('#form_id').val() == 10){
					var now = new Date();
					now.setHours(0);
					now.setMinutes(0);
					now.setSeconds(0);
					now.setMilliseconds(0);

					if($(this).datepicker('getDate') < now){
						$(this).val('');
						jAlert('Back-dating the audit date is not permitted.', 'Value Not Permitted');
					}
				}
			});

			<!-- Initialize the uploadify plugin -->

			$(".uploader").uploadify({
				'expressInstall'  : '<?php echo PATH_JS_UPLOADIFY; ?>/expressInstall.swf',
				'uploader'        : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify.swf',
				'script'          : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify_signed_form.php',
				'cancelImg'       : '<?php echo PATH_JS_UPLOADIFY; ?>/cancel.png',
				'checkScript'     : '<?php echo PATH_JS_UPLOADIFY; ?>/check.php',
				'folder'          : '<?php echo PATH_FORMS_SIGNED; ?>',
				'removeCompleted' : false,
				'sizeLimit'       : <?php echo UPLOADIFY_FILESIZE; ?>,
				'auto'            : true,
				'fileExt'         : '*.pdf',
				'fileDesc'        : '.pdf',
				'multi'           : true
			});

			<!-- On page load run "get_pending_forms()" -->

			get_pending_forms();

			<!-- Style the dropdowns on page load -->

			style_dropdown('#forms');

			<!-- Check to see if any courier forms are pending approval, if so enable all of them plus the first form that is not one -->

			function check_for_couriers(){
				var showInfoMsg = false;
				var count = 0;
				var firstCourier = false;
				var firstNonCourier = true;

				$('#pending_forms').find('option').each(function(){
					count++;

					if(/.*_courier_.*/.test($(this).val())){	// Test if the current option is a courier form
						showInfoMsg = true;						// Display the "info" message that at least one courier forms exist
						$(this).prop('disabled', false);		// Enable all courier forms

						if(firstCourier == false){				// If this is the first courier form found, flip the bit
							firstCourier = true;
						}
					}else{

						// This will enable the first form that comes after a courier form that is not another courier form

						if(firstNonCourier == true && firstCourier == true){
							$(this).prop('disabled', false);	// Enable the form
							firstNonCourier = false;			// Flip the bit so we don't enable any addiational non-courier forms
						}
					}

				});

				// Show or hide the "info" message

				if(showInfoMsg == true){
					$('#info').slideDown();
				}else{
					$('#info').slideUp();
				}

				// Style the dropdown

				style_dropdown('#pending_forms');
			}

		});

	</script>

<?php

	body_start();
	navigation_start("home");

		echo "<div align='center'>";

			// Display a courier message if needed

			echo "<div id='info' style='font-size: 13px;' class='hidden'>";
				add_message('tip', $GLOBALS['tipMessage']['item_in_courrier']);
				print_messages();
			echo "</div>";

			// Display a list of avaliable forms

			echo "<div class='boxed_group'>\n";
				echo "<h3>New Form</h3>";
				echo "<div class='boxed_group_inner clearfix'>\n";

					echo "<div class='vertical_margin_10px'>";
						form_dropdown(array("use_table" => FALSE, "name" => "forms", "multiselect" => TRUE, "items" => list_forms(), "select_opt" => FALSE));
					echo "</div>";

					// Containers to hold the AJAX responses

					echo "<div id='messages'></div>";
					echo "<div id='results'></div>";

				echo "</div>\n";
			echo "</div>\n";

			// Display a list of forms that need approved/rejected

			echo "<div id='pending_forms_container'></div>\n";

			// Switch to Determine if Forms Should be Manually Uploaded or the Default Process Should be Used
			echo "<button id='forms_button' style='margin-top: 20px'>Automatic Mode</button>";

			// Display a list of forms that need a signed document uploaded

			echo "<div class='boxed_group'>\n";
				echo "<h3>Upload Signed Forms</h3>";
				echo "<div class='boxed_group_inner clearfix'>\n";

					echo "<div id='uploader_container' class='margin_bottom_15px'>";
						echo "<input type='file' class='uploader' id='uploader' name='filename'>";
						echo "<input type='hidden' name='filename_hidden' id='filename_hidden' value=''>";	// This input will be sent back to the server when the row is submitted
					echo "</div>";

					echo "<span class='small_font'><i>Note: The uploaded file should have the same name as the original DOCX file and be in PDF format.</i></span>";

				echo "</div>\n";
			echo "</div>\n";

		echo "</div>";

	footer_start();
	db_close();

?>
