<?php

	require_once("includes.php");
	db_connect();

	// Change to the directory (needed for the PHP CLI to work correctly with Cron)

	chdir(PATH_ROOT_DIR . "/" . PATH_WWW);

	echo "BEGIN end-of-life check\n";
		echo "\tStart Time: " . date('Y-m-d H:i:s', time()) . "\n";

			$MonthsWarning = array(1, 6);

			foreach($MonthsWarning as $MonthsBack){

				echo "\t\tBEGIN: End-of-life in  " . $MonthsBack . " " . ($MonthsBack > 1 ? "months" : "month") . ".\n";

					$Query = "SELECT label_name, serial_number FROM " . DB_TABLE_EQUIP . " WHERE CURDATE()=(DATE_ADD(date_shipped, INTERVAL 4 YEAR) - INTERVAL " . $MonthsBack . " MONTH) AND deleted=0 AND status!='Destroyed'";
					$Result = db_query($Query);
					$Count = row_count($Result);

					if($Count > 0){

						while($Eqiupment = row_fetch_assoc($Result)){
							$Body = $Eqiupment['label_name'] . " (" . $Eqiupment['serial_number'] . ") will be end-of-life in " . $MonthsBack . " " . ($MonthsBack > 1 ? "months" : "month") . ".";
							if(mail(EMAIL_END_OF_LIFE_TO, EMAIL_END_OF_LIFE_SUBJECT, $Body)){
								echo "\t\t\tSUCCESS: Email for " . $Eqiupment['label_name'] . " successfully sent.\n" ;
							}else{
								echo "\t\t\tERROR: Email delivery for " . $Eqiupment['label_name'] . " failed.\n";
							}
						}

					}else{
						echo "\t\t\tINFO: There are no end-of-life devices within " . $MonthsBack . " " . ($MonthsBack > 1 ? "months" : "month") . ".\n";
					}

				echo "\t\tEND: End-of-life in  " . $MonthsBack . " " . ($MonthsBack > 1 ? "months" : "month") . ".\n";

			}

		echo "\tEnd Time: " . date('Y-m-d H:i:s', time()) . "\n";
	echo "END end-of-life check\n";

	db_close();

?>