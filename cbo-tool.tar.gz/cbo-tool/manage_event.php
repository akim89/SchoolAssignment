<?php

	require_once("includes.php");
	db_connect();
	header_start("Manage Events");
	multiselect_headers();
	custom_jquery_alert_boxes();

?>

	<script>

	// Populate the Shareholder's Container DIV With the List of Filtered Shareholders
	function getEditShareholders(){
		// Remove Any Previous List of Shareholders
		$('.wipe_shareholder').remove();
		// Load the JSON Shareholder Data From the Data Attribute of the shareholder_container
		var shareholder_data = JSON.parse($('#shareholder_container_edit').attr('data'));
		// Load the Key Data
		var shareholder_key_data = JSON.parse($('#shareholder_container_edit').attr('keydata'));
		// Originally Selected Shareholders
		var shareholder_originals = JSON.parse($('#shareholder_container_edit').attr('eventData'));
		// Get the Site ID that was Selected
		var site_id = $('select#site_id_update').val();

		// Div Construction For the Shareholders List
		div_construction = '';

		// For Each Shareholder Retrieved Fron the Database
		for(var counter = 0; counter < shareholder_data.length; counter++){
			// Define the Current Shareholder
			var current_shareholder = shareholder_data[counter];
			// Filter the Shareholders Based on Site and Deleted Status
			if(site_id == current_shareholder.site && current_shareholder.deleted != "1"){

				// Determine the Last Used Date and Initilize the Color
				var shareholder_status = (current_shareholder.last_used == "0") ? "Never" :  current_shareholder.last_used;
				var shareholder_color = '';

				// If the Shareholder was Never Used, Use the Color Gray
				if(shareholder_status == "Never") shareholder_color = "gray";
				// If the Shareholder has Been Used Before, Do the Frequency Analysis
				else{
					// Get the Current Date
					var current_date = new Date();
					// Get Date the Shareholder was Last Used
					var last_used_date = new Date(current_shareholder.last_used);
					// Calculate the Days Since the Shareholder was Last Used
					var days_since_last_used = Math.floor((current_date - last_used_date) / (1000 * 60 * 60 * 24));
					// Determine the Color of the Date Based on the Days Since Last Used
					if(days_since_last_used <= 30) shareholder_color = "red";
					else if(days_since_last_used <= 90) shareholder_color = "orange";
					else shareholder_color = "green";
				}

				// Get the Current Shareholder's Keys
				var users_keys = shareholder_key_data[current_shareholder.id];

				// Determine if the Current Shareholder is an Original Shareholder
				var checked = ($.inArray(current_shareholder.id, shareholder_originals) !== -1) ? 'checked' : null;

				// If the User Does Not Have a Key Assigned, Don't Create a Box For Them
				// if(users_keys != false){
					// Construct the Option for Each of the Valid Shareholders
					div_construction += '<tr class="wipe_shareholder">';
					div_construction += '<td></td>';
					div_construction += '<td align="left">';
					div_construction += '<input type="checkbox" site="' + current_shareholder.site + '" class="shareholder" value="' + current_shareholder.id + '" name="shareholder_id[]" ' + checked + '>' + current_shareholder.name + '</input>';
					div_construction += '<td class="last_used" style="color: ' + shareholder_color + ';"> (' + shareholder_status + ')</td>';
					div_construction += '<td style="padding-left: 100px">';
					div_construction += '<select class="phsyical_keys" id="' + Math.random().toString(36).substring(7) + '" name="physical_key_id[]" multiselect="multiselect" style="min-width: 100px">';
					// For Each of the Shareholder's Keys, Create an Option
					if(users_keys != false){
						$.each(users_keys, function(value, label){
							div_construction += '<option value="' + value + '">' + label + '</option>';
						});
					}
					else div_construction += '<option value="none">Not Assigned</option>';
					div_construction += '</select>';
					div_construction += '</td>';
					div_construction += '</td>';
					div_construction += '</tr>';
				//}

				$( ".phsyical_keys" ).multiselect({});

			}
		}

		// Insert the Generated Shareholder List After the Shareholder Container
		$(div_construction).insertAfter($('#shareholder_container_edit'));

	}

	// Populate the Shareholder's Container DIV With the List of Filtered Shareholders
	function getShareholders(){
		// Remove Any Previous List of Shareholders
		$('.wipe_shareholder').remove();
		// Load the JSON Shareholder Data From the Data Attribute of the shareholder_container
		var shareholder_data = JSON.parse($('#shareholder_container').attr('data'));
		// Load the Key Data
		var shareholder_key_data = JSON.parse($('#shareholder_container').attr('keydata'));
		// Get the Site ID that was Selected
		var site_id = $('select#site_id').val();

		// Div Construction For the Shareholders List
		div_construction = '';

		// For Each Shareholder Retrieved Fron the Database
		for(var counter = 0; counter < shareholder_data.length; counter++){
			// Define the Current Shareholder
			var current_shareholder = shareholder_data[counter];
			// Filter the Shareholders Based on Site and Deleted Status
			if(site_id == current_shareholder.site && current_shareholder.deleted != "1"){

				// Determine the Last Used Date and Initilize the Color
				var shareholder_status = (current_shareholder.last_used == "0") ? "Never" :  current_shareholder.last_used;
				var shareholder_color = '';

				// If the Shareholder was Never Used, Use the Color Gray
				if(shareholder_status == "Never") shareholder_color = "gray";
				// If the Shareholder has Been Used Before, Do the Frequency Analysis
				else{
					// Get the Current Date
					var current_date = new Date();
					// Get Date the Shareholder was Last Used
					var last_used_date = new Date(current_shareholder.last_used);
					// Calculate the Days Since the Shareholder was Last Used
					var days_since_last_used = Math.floor((current_date - last_used_date) / (1000 * 60 * 60 * 24));
					// Determine the Color of the Date Based on the Days Since Last Used
					if(days_since_last_used <= 30) shareholder_color = "red";
					else if(days_since_last_used <= 90) shareholder_color = "orange";
					else shareholder_color = "green";
				}

				// Get the Current Shareholder's Keys
				var users_keys = shareholder_key_data[current_shareholder.id];

				// If the User Does Not Have a Key Assigned, Don't Create a Box For Them
				// if(users_keys != false){
					// Construct the Option for Each of the Valid Shareholders
					div_construction += '<tr class="wipe_shareholder">';
					div_construction += '<td></td>';
					div_construction += '<td align="left">';
					div_construction += '<input type="checkbox" site="' + current_shareholder.site + '" class="shareholder" value="' + current_shareholder.id + '" name="shareholder_id[]">' + current_shareholder.name + '</input>';
					div_construction += '<td class="last_used" style="color: ' + shareholder_color + ';"> (' + shareholder_status + ')</td>';
					div_construction += '<td style="padding-left: 100px">';
					div_construction += '<select class="phsyical_keys" id="' + Math.random().toString(36).substring(7) + '" name="physical_key_id[]" multiselect="multiselect" style="min-width: 100px">';
					// For Each of the Shareholder's Keys, Create an Option
					if(users_keys != false){
						$.each(users_keys, function(value, label){
							div_construction += '<option value="' + value + '">' + label + '</option>';
						});
					}
					else div_construction += '<option value="none">Not Assigned</option>';
					div_construction += '</select>';
					div_construction += '</td>';
					div_construction += '</td>';
					div_construction += '</tr>';
				//}

				$( ".phsyical_keys" ).multiselect({});

			}
		}

		// Insert the Generated Shareholder List After the Shareholder Container
		$(div_construction).insertAfter($('#shareholder_container'));

	}

		$(document).ready(function(){

			<!-- Remove site options that do not apply -->

			function removeSites(element){
				element.each(function(){
					if($(this).val() != 2 && $(this).val() != 5 && $(this).val() != 3){
						$(this).remove();
					}
				});
			}

			removeSites($('#site_id option'));

			<!-- Style the single-select dropdown menus -->

			function styleSingleDropdowns(element){
				element.multiselect({
					multiple: false,
					header: "Select an option",
					noneSelectedText: "Select an option",
					selectedList: 1
				});

				$('.phsyical_keys').multiselect({
					minWidth: 120
				});

				$('#cancel_event_id, #update_event_id, #confirm_event_id').multiselect({
					minWidth: 300
				});
			}

			styleSingleDropdowns($('select').not('#product_id'));

			<!-- Style the multi-select dropdown menus -->

			function styleProducts(element){
				element.multiselect({
					header: "Select an option",
					noneSelectedText: "Select an option"
				});
			}

			styleProducts($('#product_id'));

			<!-- Disable users who currently possess no keys -->

			/**
			$('.phsyical_keys').each(function(){
				if($(this).find('option').length == 0){
					var parent = $(this).parents('tr');
					parent.find('input').attr('disabled', true);
					parent.find('select').multiselect('disable');
				}
			});
			**/

			<!-- Create the datepicker -->

			function styleDatepicker(element){
				element.datepicker({
					changeMonth: true,
					changeYear: true,
					dateFormat: 'yy-mm-dd'
				});
			}

			styleDatepicker($(".datepicker" ));

			<!-- Submit the form -->

			$('form#schedule_event #submit').on('click', function(e){
				e.preventDefault();

				// Storage for the Form Data
				var form_data = {
					shareholder_id: [],
					physical_key_id: []
				};

				// Manual Form to JSON
				var form_inputs = $('#schedule_event *').filter(':input')
				// Add the Checkbox Information
				form_inputs.each(function(index){
					// Get the Current Class of the Element
					var current_class = $(this).attr('class');
					// Determine if the Current Element is Part of Choosing the Shareholders
					if(current_class == 'shareholder' || 'phsyical_keys'){
						// If the Element is a Shareholder Checkbox
						if(current_class == 'shareholder'){
							// Determine if the Checkbox is Checked
							if($(this).prop('checked')){
								// Get the Value of the Next Indexed Element (The Key Select Dropdown)
								var dropdown = form_inputs[index + 1];
								var dropdown_value = ($(dropdown).val() == 'none') ? null : $(dropdown).val();
								// Get the Shareholder
								var shareholderID = $(this).val();
								// Add to JSON
								form_data.shareholder_id.push(shareholderID);
								form_data.physical_key_id.push(dropdown_value);
							}
						}
					}
				});

				// Add the Event Details to the JSON
				var email_template_id = form_data.email_template_id = $('#email_template_id').val();
				var event_name = form_data.event_name = $('#event_name').val();
				var site_id = form_data.site_id = $('#site_id').val();
				var start_date = form_data.start_date = $('#start_date').val();
				var start_time = form_data.start_time = $('#start_time').val();
				var end_time = form_data.end_time = $('#end_time').val();
				var product_id = form_data.product_id = $('#product_id').val();
				var cc_recipients = form_data.cc_recipients = $('#cc_recipients').val();

				$.ajax({
					type: "POST",
					url: "<?php echo PATH_AJAX; ?>/ajax2.0/ajax_schedule_event.php",
					data: form_data,
					success: function(response){
						$('#messages').html(response);

						if(/success/.test(response)){
							$('form#schedule_event input:text').val('');
							$('form#schedule_event select').val('').multiselect("uncheckAll");
							$('form#schedule_event input:checkbox').attr('checked', false);
						}
					}
				});
			});

			<!-- Cacnel an event -->

			var allEventMenus = $('#cancel_event_id, #update_event_id, #confirm_event_id');

			$('#cancel_event_id').on('change', function(e){
				var selectedID = $(this).find('option:selected').val();

				$.alerts.okButton = "Yes";
				$.alerts.cancelButton = "No";

				if(!!selectedID){
					jConfirm('Are you sure you want to cancel this event?', 'Event Cancellation Confirmation', function(r){
						if(r){
							$.ajax({
								type: "POST",
								url: "<?php echo PATH_AJAX; ?>/ajax_event_cancel.php",
								data: { 'event_id' : selectedID },
								success: function(response){
									$('#messages2').html(response);

									// Remove itme from dropdown

									if(/success/.test(response)){
										allEventMenus.find('option[value="' + selectedID + '"]').remove();
										allEventMenus.multiselect("uncheckAll").multiselect("refresh");
									}
								}
							});
						}else{
							return false;
						}
					});
				}

			});

			<!-- Load event shareholder information -->

			$('#update_event_id, #confirm_event_id').on('change', function(e){
				var element = $(this);
				var elementID = element.attr('id');
				var selectedID = element.find('option:selected').val();
				var parent = element.parents('.boxed_group_inner');

				if(!!selectedID){
					$.ajax({
						type: "GET",
						url: "<?php echo PATH_AJAX; ?>/ajax2.0/ajax_load_event_shareholders.php",
						data: { 'event_id' : selectedID, 'type' : (/update/.test(elementID) ? "update" : "confirm") },
						success: function(response){
							parent.find('.form_container').html(response);
							parent.find('.form_container').find('input:submit, input:button, button').button();

							if(/update/.test(elementID)){
								styleProducts(parent.find('.form_container').find('#product_id_update'));
								styleDatepicker(parent.find('.form_container').find('.datepicker'));
								removeSites($('#site_id_update option'));
							}

							styleSingleDropdowns(parent.find('.form_container').find('select').not('#product_id_update'));

							/**
							parent.find('.form_container').find('.phsyical_keys').each(function(){
								if($(this).find('option').length == 0){
									var parent = $(this).parent();
									if(!parent.find('input').is(':checked')){
										parent.find('input').attr('disabled', true);
										parent.find('select').multiselect('disable');
									}
								}
							});
							**/

						}
					});
				}

			});

			<!-- Deselect a physical key if the shareholder is unchecked -->

			$('input.shareholder').live('click', function(e){
				if(!$(this).is(":checked")){
					$(this).next('.phsyical_keys').multiselect("uncheckAll");
				}
			});

			<!-- Update the shareholders/keys -->

			$('#update, #confirm').live('click', function(e){

				e.preventDefault();

				// Storage for the Form Data
				var form_data = {
					shareholder_id: [],
					physical_key_id: [],
					update_event_id: $('#shareholder_container_edit').attr('eventID')
				};

				// Manual Form to JSON
				var form_inputs = $('.form_container *').filter(':input')
				// Add the Checkbox Information
				form_inputs.each(function(index){
					// Get the Current Class of the Element
					var current_class = $(this).attr('class');
					// Determine if the Current Element is Part of Choosing the Shareholders
					if(current_class == 'shareholder' || 'phsyical_keys'){
						// If the Element is a Shareholder Checkbox
						if(current_class == 'shareholder'){
							// Determine if the Checkbox is Checked
							if($(this).prop('checked')){
								// Get the Value of the Next Indexed Element (The Key Select Dropdown)
								var dropdown = form_inputs[index + 1];
								var dropdown_value = ($(dropdown).val() == 'none') ? null : $(dropdown).val();
								// Get the Shareholder
								var shareholderID = $(this).val();
								// Add to JSON
								form_data.shareholder_id.push(shareholderID);
								form_data.physical_key_id.push(dropdown_value);
							}
						}
					}
				});

				// Add the Event Details to the JSON
				var email_template_id = form_data.email_template_id = $('#template_id_update').val();
				var event_name = form_data.event_name = $('#event_name_update').val();
				var site_id = form_data.site_id = $('#site_id_update').val();
				var start_date = form_data.start_date = $('#start_date_update').val();
				var start_time = form_data.start_time = $('#start_time_update').val();
				var end_time = form_data.end_time = $('#end_time_update').val();
				var product_id = form_data.product_id = $('#product_id_update').val();
				var cc_recipients = form_data.cc_recipients = $('#cc_recipients_update').val();

				var button = $(this);
				var buttonID = button.attr('id');
				var parent = button.parents('.boxed_group_inner');
				var select = parent.find('select');

				if(!!select.val()){
					$.ajax({
						type: "POST",
						url: "<?php echo PATH_AJAX; ?>/ajax2.0/ajax_update_event_confirm.php",
						data: form_data,
						success: function(response){
							parent.find("[id^='messages']").html(response);

							if(/success/.test(response)){
								parent.find('.form_container').empty();

								if(buttonID == "confirm"){
									select.find('option:selected').remove();
									select.multiselect("uncheckAll").multiselect("refresh");
								}else{
									select.multiselect("uncheckAll");
								}
							}
						}
					});
				}

			});


		});

	</script>

<?php

	body_start();
	navigation_start("calendar");

		echo "<div align='center'>";

			echo "<div class='boxed_group'>\n";
				echo "<h3>Schedule an Event</h3>";
				echo "<div class='boxed_group_inner clearfix'>\n";

					// Containers to hold the AJAX responses

					echo "<div id='messages'></div>";

					// Display the form

					echo "<div class='vertical_margin_10px'>";
						form_start(array("action" => $_SERVER['SCRIPT_NAME'], 'name' => 'schedule_event'));
							form_dropdown(array("title" => "Template", "name" => "email_template_id", "items" => list_email_templates(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
							form_text_field(array("title" => "Event Name", "name" => "event_name", "required" => TRUE));
							form_dropdown(array("title" => "Site", "name" => "site_id", "items" => list_sites(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
							// Create a Get Shareholders Button
							echo '<tr><td></td><td><button type="button" onclick="getShareholders()">Get Shareholders</button></td></tr>';
							form_date_time(array("title" => "Date", "name" => "start_date", "value" => NULL, "css" => "autocomplete='off' class='datepicker'", "required" => TRUE));
							form_dropdown(array("title" => "Start Time", "name" => "start_time", "items" => time_range(0, 60*60*24, 60*15), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
							form_dropdown(array("title" => "End Time", "name" => "end_time", "items" => time_range(0, 60*60*24, 60*15), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
							form_dropdown(array("title" => "Products", "name" => "product_id[]", "id" => "product_id", "items" => list_products(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE));
							form_text_field(array("title" => "Add'l Recipients (CSV)", "name" => "cc_recipients", "required" => FALSE));

							// Shareholder Query
							$Shareholder_Query = list_event_shareholder_usage();
							$Shareholder_Key_Array = array();

							// Retrieve the Shareholder List From Backend and JSON Encode it
							$ShareholderData = json_encode($Shareholder_Query);
							$ShareholderKeyData = '';

							// Get the Shareholder Key Information as Well
							foreach($Shareholder_Query as $Info){
								$KeyData = shareholder_physical_keys($Info['id']);
								$Shareholder_Key_Array[$Info['id']] = $KeyData;
							}

							// Encode the Key Data
							$ShareholderKeyData = json_encode($Shareholder_Key_Array);

							// Embed the Retrieved Data into the Data Attribute of the shareholder_container
							echo "<tr id='shareholder_container' data='" . $ShareholderData . "' keyData='". $ShareholderKeyData . "'><td align='right'>Shareholders:</td></tr>";

							form_break();
							form_submit(array("value" => "Submit"));
						form_end();

					echo "</div>";

				echo "</div>\n";
			echo "</div>\n";

			// Cancel an event

			echo "<div class='boxed_group'>\n";
				echo "<h3>Cancel An Event</h3>";
				echo "<div class='boxed_group_inner clearfix'>\n";

					echo "<div id='messages2'></div>";

					$UpcomingEvents = list_upcoming_events();

					if($UpcomingEvents){
						echo "<div class='vertical_margin_10px'>";
							form_dropdown(array("use_table" => FALSE, "name" => "cancel_event_id", "items" => $UpcomingEvents, "select_opt" => FALSE, "multiselect" => TRUE));
						echo "</div>\n";
					}else{
						add_message('info', $GLOBALS['infoMessage']['no_scheduled_events']);
						print_messages();
					}

				echo "</div>\n";
			echo "</div>\n";

			// Change event details

			echo "<div class='boxed_group'>\n";
				echo "<h3>Edit Event Details</h3>";
				echo "<div class='boxed_group_inner clearfix'>\n";

					echo "<div id='messages3'></div>";

					if($UpcomingEvents){
						echo "<div class='vertical_margin_10px margin_bottom_15px'>";
							form_dropdown(array("use_table" => FALSE, "name" => "update_event_id", "items" => $UpcomingEvents, "select_opt" => FALSE, "multiselect" => TRUE));
						echo "</div>\n";

						echo "<div class='form_container vertical_margin_10px margin_bottom_15px'></div>";
					}else{
						add_message('info', $GLOBALS['infoMessage']['no_scheduled_events']);
						print_messages();
					}

				echo "</div>\n";
			echo "</div>\n";

			// Confirm event shareholders

			echo "<div class='boxed_group'>\n";
				echo "<h3>Confirm Event Shareholders</h3>";
				echo "<div class='boxed_group_inner clearfix'>\n";

					echo "<div id='messages4'></div>";

					$PendingEvents = list_events_needing_confirmed();

					if($PendingEvents){
						echo "<div class='vertical_margin_10px margin_bottom_15px'>";
							form_dropdown(array("use_table" => FALSE, "name" => "confirm_event_id", "items" => $PendingEvents, "select_opt" => FALSE, "multiselect" => TRUE));
						echo "</div>\n";

						echo "<div class='form_container margin_bottom_15px'></div>";
					}else{
						add_message('info', $GLOBALS['infoMessage']['no_events_to_confirm']);
						print_messages();
					}

				echo "</div>\n";
			echo "</div>\n";

		echo "</div>";

	footer_start();
	db_close();

?>
