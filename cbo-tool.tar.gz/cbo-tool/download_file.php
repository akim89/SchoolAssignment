<?php   

	include("includes.php");
	
	// Present the file as a download to the user
	
	if(isset($_GET['file'])) { 
		
		
		$File = PATH_TEMPLATES . "/" . $_GET['file'];
	
		// File exists and is readable
		
		if(file_exists($File) && is_readable($File)){ 
			header('Content-type: ' . returnMIMEType($_GET['file']));  
			header("Content-Disposition: attachment; filename=\"" . $_GET['file'] . "\"");   
			readfile($File); 
			
		// File specified but not found
			
		}else{
			header("HTTP/1.0 404 Not Found"); 
			echo "<h2>Error 404: File Not Found: <em>$File</em></h2>"; 
		}
		
	// No file specified
	
	}else{ 
		header("HTTP/1.0 404 Not Found"); 
		echo "<h2>Error 404: File Not Found</h2>"; 
	} 

?>