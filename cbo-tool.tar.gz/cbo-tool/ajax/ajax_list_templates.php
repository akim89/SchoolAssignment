<?php

	include("../includes.php");

	// Generate an array of avaliable icons
				
	$IconFiles = scandir('../' . PATH_FILE_TYPE_ICONS);
	
	// Drop the file extension off of each filename, we only what the base name of the icon
	
	foreach($IconFiles as $Icon){
		$FileParts = pathinfo($Icon);
		$FileTypeIcons[] = strtolower(@$FileParts['filename']);			
	}
	
	// Generate an array of uploaded files
	
	$IgnoreFiles = array('.', '..');
	$AllFiles = array_diff(scandir('../' . PATH_TEMPLATES), $IgnoreFiles);
	
	sort($AllFiles);
	
	if($_GET['all_files'] == 1){
		$Templates = $AllFiles;
	}else{
	
		// Find just the lastest versions of the file
		
		foreach($AllFiles as $File){
			$BaseFilename = preg_replace('/_v\d+/', '', $File);		
			preg_match('/_v\d+(?!=\..+$)/', $File, $Matches);
			if($Matches){
				preg_match('/\d+/', $Matches[0], $CurrentVersion);
			}
			
			$Templates[$BaseFilename] = $File;
		}
		
	}
	
	// Display each uploaded file				

	foreach($Templates as $File){
		 
		$File = trim($File);
		
		// Determine what type of file we are working with
		
		$FileParts = pathinfo($File);
		$Extension = strtolower(@$FileParts['extension']);
		
		// Display the appropriate icon and link
		
		echo "<div style='margin-bottom: 5px;' class='filename'>\n";
			echo "<a href='download_file.php?file=" . $File . "'><img width='24' class='valign_middle' src='" . PATH_FILE_TYPE_ICONS . "/" . (in_array($Extension, $FileTypeIcons) ? $Extension : "settings") . ".png' ></a> \n";
			echo "<a href='download_file.php?file=" . $File . "'>" . preg_replace('/\.[a-zA-Z]{3,4}$/', '', str_replace('_', ' ', $File)) . "</a>\n";						
			echo "(" . date("Y-m-d H:i:s", filemtime('../' . PATH_TEMPLATES . '/' . $File)) . ")";
		echo "</div>\n";
	}

?>