<?php

	require_once("../includes.php");
	db_connect();	
		
	$Table = @$_GET['table'];
	
	if($Table){
				
		// Set the query and table headers (do not include the row ID in the header list)
		
		if($Table == DB_TABLE_BOXES){
			$Query = "SELECT box_id, box_number, site_id FROM " . DB_TABLE_BOXES . " WHERE deleted=0 ORDER BY box_number";
			$Headers[1] = array("name" => "Box Number", "field_name" => "box_number", "field_type" => "text");
			$Headers[2] = array("name" => "Site", "width" => 155, "field_name" => "site_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_SITES);
		}elseif($Table == DB_TABLE_CABINETS){
			$Query = "SELECT cabinet_id, cabinet_name FROM " . DB_TABLE_CABINETS . " WHERE deleted=0 OR deleted IS NULL ORDER BY cabinet_name";
			$Headers[1] = array("name" => "Cabinet", "field_name" => "cabinet_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_DESTRUCTION_METHODS){
			$Query = "SELECT destruction_method_id, destruction_method_name FROM " . DB_TABLE_DESTRUCTION_METHODS . " WHERE deleted=0 OR deleted IS NULL ORDER BY destruction_method_name";
			$Headers[1] = array("name" => "Destruction Method", "field_name" => "destruction_method_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_EMAIL_TEMPLATES){
			$Query = "SELECT email_template_id, email_template_name, subject, body, default_recipients FROM " . DB_TABLE_EMAIL_TEMPLATES . " WHERE deleted=0 OR deleted IS NULL ORDER BY email_template_name";
			$Headers[1] = array("name" => "Template Name", "field_name" => "email_template_name", "field_type" => "text");	
			$Headers[2] = array("name" => "Subject", "field_name" => "subject", "field_type" => "text");	
			$Headers[3] = array("name" => "Body", "field_name" => "body", "field_type" => "textarea");	
			$Headers[4] = array("name" => "Default Recipients (CSV)", "field_name" => "default_recipients", "field_type" => "text");	
		}elseif($Table == DB_TABLE_ENVIRONMENTS){
			$Query = "SELECT environment_id, environment_name FROM " . DB_TABLE_ENVIRONMENTS . " WHERE deleted=0 OR deleted IS NULL ORDER BY environment_name";
			$Headers[1] = array("name" => "Environment", "field_name" => "environment_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_EQUIP_TYPES){
			$Query = "SELECT equipment_type_id, equipment_type_name FROM " . DB_TABLE_EQUIP_TYPES . " WHERE deleted=0 OR deleted IS NULL ORDER BY equipment_type_name";
			$Headers[1] = array("name" => "Equipment Type", "field_name" => "equipment_type_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_EQUIP){
			$TableWidth = 5200;			
			$Query = "SELECT equipment_id, label_name, equipment_type_id, vendor_id, serial_number, asset_tag_number, server_name, description, model_number, model_type_id, equipment_version_id, firmware_version, part_number, purchase_order_number, tamper_seal_number, bag_id, servicenow_id, escrow_location_id, product_id, environment_id, status, date_online, date_offline, date_destroyed, rack_location, support_contract_id, date_shipped, notes, is_production_capable, is_acceptance_tested, date_acceptance_tested, date_last_verified, 0 AS update_rack  FROM " . DB_TABLE_EQUIP . " WHERE deleted=0 ORDER BY label_name";
			$Headers[1] = array("name" => "Label", "field_name" => "label_name", "field_type" => "text", "width" => 200);
			$Headers[2] = array("name" => "Equipment Type", "field_name" => "equipment_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_EQUIP_TYPES, "width" => 150);
			$Headers[3] = array("name" => "Vendor", "field_name" => "vendor_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_VENDORS, "width" => 140);
			$Headers[4] = array("name" => "Serial", "field_name" => "serial_number", "field_type" => "text", "width" => 200);
			$Headers[5] = array("name" => "Asset Tag", "field_name" => "asset_tag_number", "field_type" => "text", "width" => 200);
			$Headers[6] = array("name" => "Server Name", "field_name" => "server_name", "field_type" => "text", "width" => 200);
			$Headers[7] = array("name" => "Description", "field_name" => "description", "field_type" => "text", "width" => 200);
			$Headers[8] = array("name" => "Model Number", "field_name" => "model_number", "field_type" => "text", "width" => 200);
			$Headers[9] = array("name" => "Model Type", "field_name" => "model_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_MODEL_TYPES, "width" => 150);
			$Headers[10] = array("name" => "Version", "field_name" => "equipment_version_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_EQUIP_VERSIONS, "width" => 150);
			$Headers[11] = array("name" => "Firmware Version", "field_name" => "firmware_version", "field_type" => "text", "width" => 200);
			$Headers[12] = array("name" => "Part Number", "field_name" => "part_number", "field_type" => "text", "width" => 200);
			$Headers[13] = array("name" => "PO Number", "field_name" => "purchase_order_number", "field_type" => "text", "width" => 200);
			$Headers[14] = array("name" => "Tamper Seal Number", "field_name" => "tamper_seal_number", "field_type" => "text", "width" => 200);
			$Headers[15] = array("name" => "Tamper Bag Number", "field_name" => "bag_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_TAMPER_EVIDENT_BAGS, "width" => 150);
			$Headers[16] = array("name" => "ServiceNow ID", "field_name" => "servicenow_id", "field_type" => "text", "width" => 200);
			$Headers[17] = array("name" => "Escrow Location", "field_name" => "escrow_location_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_ESCROW_LOCATIONS, "width" => 150);
			$Headers[18] = array("name" => "Product", "field_name" => "product_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_PRODUCTS, "width" => 150);
			$Headers[19] = array("name" => "Environment", "field_name" => "environment_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_ENVIRONMENTS, "width" => 150);
			$Headers[20] = array("name" => "Status", "field_name" => "status", "field_type" => "dropdown", "dropdown_option" => "equipment_status", "width" => 150);
			$Headers[21] = array("name" => "Date Online", "field_name" => "date_online", "field_type" => "date", "width" => 100);
			$Headers[22] = array("name" => "Date Offline", "field_name" => "date_offline", "field_type" => "date", "width" => 100);		
			$Headers[23] = array("name" => "Date Destroyed", "field_name" => "date_destroyed", "field_type" => "date", "width" => 120);		
			$Headers[24] = array("name" => "Location", "field_name" => "rack_location", "field_type" => "text", "width" => 200);			
			$Headers[25] = array("name" => "Support Contract", "field_name" => "support_contract_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_SUPPORT_CONTRACTS, "width" => 150);
			$Headers[26] = array("name" => "Date Shipped", "field_name" => "date_shipped", "field_type" => "date", "width" => 120);
			$Headers[27] = array("name" => "Notes", "field_name" => "notes", "field_type" => "text", "width" => 200);			
			$Headers[28] = array("name" => "Production Capable", "field_name" => "is_production_capable", "field_type" => "checkbox", "width" => 70);
			$Headers[29] = array("name" => "Acceptance Tested", "field_name" => "is_acceptance_tested", "field_type" => "checkbox", "width" => 70);			
			$Headers[30] = array("name" => "Date Acceptance Tested", "field_name" => "date_acceptance_tested", "field_type" => "date", "width" => 100);
			$Headers[31] = array("name" => "Date Last Verified", "field_name" => "date_last_verified", "field_type" => "date", "width" => 100);	
			$Headers[32] = array("name" => "Update Rack", "field_name" => "update_rack", "field_type" => "checkbox", "width" => 100);			
		}elseif($Table == DB_TABLE_ESCROW_LOCATIONS){
			$Query = "SELECT escrow_location_id, escrow_location_name, escrow_location_type_id, site_id FROM " . DB_TABLE_ESCROW_LOCATIONS . " WHERE deleted=0 ORDER BY escrow_location_name";
			$Headers[1] = array("name" => "Escrow Location Name", "field_name" => "escrow_location_name", "field_type" => "text");
			$Headers[2] = array("name" => "Type", "width" => 155, "field_name" => "escrow_location_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_ESCROW_LOCATION_TYPES);	
			$Headers[3] = array("name" => "Site", "width" => 155, "field_name" => "site_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_SITES);	
		}elseif($Table == DB_TABLE_ESCROW_LOCATION_TYPES){
			$Query = "SELECT escrow_location_type_id, escrow_location_type_name FROM " . DB_TABLE_ESCROW_LOCATION_TYPES . " WHERE deleted=0 ORDER BY escrow_location_type_name";
			$Headers[1] = array("name" => "Escrow Location Type", "field_name" => "escrow_location_type_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_EQUIP_ATTACHMENTS){
			$Query = "SELECT a.attachment_id, attachment_name, attachment_name AS filename, attachment_description, equipment_id FROM " . DB_TABLE_ATTACHMENTS . " a, " . DB_TABLE_EQUIP_ATTACHMENTS . " v WHERE a.attachment_id=v.attachment_id";			
			$Headers[1] = array("name" => "Upload", "field_name" => "attachment_name", "field_type" => "file", "width" => 150);
			$Headers[2] = array("name" => "Filename", "field_name" => "filename", "field_type" => "text", "disabled" => TRUE);		// This input will simply display the filename that has been uploaded, it will not be sent to the server
			$Headers[3] = array("name" => "Description", "field_name" => "attachment_description", "field_type" => "text");
			$Headers[4] = array("name" => "Equipment", "field_name" => "equipment_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_EQUIP, "width" => 140);
		}elseif($Table == DB_TABLE_EQUIP_VERSIONS){
			$Query = "SELECT equipment_version_id, equipment_version_name FROM " . DB_TABLE_EQUIP_VERSIONS . " WHERE deleted=0 ORDER BY equipment_version_name";
			$Headers[1] = array("name" => "Equipment Version", "field_name" => "equipment_version_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_FORMS){
			$Query = "SELECT form_id, form_name, instructions FROM " . DB_TABLE_FORMS . " WHERE deleted=0";			
			$Headers[1] = array("name" => "Form Name", "field_name" => "form_name", "field_type" => "text", "width" => 250, "disabled" => TRUE);
			$Headers[2] = array("name" => "Instructions", "field_name" => "instructions", "field_type" => "textarea");
		}elseif($Table == DB_TABLE_FUNCTIONS){
			$Query = "SELECT function_id, function_name, function_type_id FROM " . DB_TABLE_FUNCTIONS . " WHERE deleted=0 OR deleted IS NULL ORDER BY function_name";
			$Headers[1] = array("name" => "Function", "field_name" => "function_name", "field_type" => "text");
			$Headers[2] = array("name" => "Function Type", "field_name" => "function_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_FUNCTION_TYPES, "width" => 140);
		}elseif($Table == DB_TABLE_KEY_TYPES){
			$Query = "SELECT key_type_id, key_type_name FROM " . DB_TABLE_KEY_TYPES . " WHERE deleted=0 ORDER BY key_type_name";
			$Headers[1] = array("name" => "Key Type", "field_name" => "key_type_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_MEDIA_TYPES){
			$Query = "SELECT media_type_id, media_type_name FROM " . DB_TABLE_MEDIA_TYPES . " WHERE deleted=0 ORDER BY media_type_name";
			$Headers[1] = array("name" => "Media Type", "field_name" => "media_type_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_MODEL_TYPES){
			$Query = "SELECT model_type_id, model_type_name, equipment_type_id FROM " . DB_TABLE_MODEL_TYPES . " WHERE deleted=0 ORDER BY model_type_name";
			$Headers[1] = array("name" => "Model Type", "field_name" => "model_type_name", "field_type" => "text");
			$Headers[2] = array("name" => "Equipment Type", "field_name" => "equipment_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_EQUIP_TYPES, "width" => 150);
		}elseif($Table == DB_TABLE_KEYS){
			$TableWidth = 1400;
			$Query = "SELECT physical_key_id, label, box_id, serial_number, physical_key_type_id, shareholder_id, bag_id, escrow_location_id, servicenow_sys_id FROM " . DB_TABLE_KEYS . " WHERE deleted=0 ORDER BY label";
			$Headers[1] = array("name" => "Label", "field_name" => "label", "field_type" => "text");
			$Headers[2] = array("name" => "Box", "field_name" => "box_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_BOXES);
			$Headers[3] = array("name" => "Serial", "field_name" => "serial_number", "field_type" => "text", "width" => 90);
			$Headers[4] = array("name" => "Key Type", "field_name" => "physical_key_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_PHYSICAL_KEY_TYPES);
			$Headers[5] = array("name" => "Shareholder", "field_name" => "shareholder_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_SHAREHOLDERS . "_physical_key");
			$Headers[6] = array("name" => "Tamper Bag Number", "field_name" => "bag_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_TAMPER_EVIDENT_BAGS);
			$Headers[7] = array("name" => "Escrow Location", "field_name" => "escrow_location_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_ESCROW_LOCATIONS, "width" => 150);
			$Headers[8] = array("name" => "ServiceNow SysID", "field_name" => "servicenow_sys_id", "field_type" => "text", "width" => 150);
		}elseif($Table == DB_TABLE_PHYSICAL_KEY_TYPES){
			$Query = "SELECT physical_key_type_id, physical_key_type_name FROM " . DB_TABLE_PHYSICAL_KEY_TYPES . " WHERE deleted=0 ORDER BY physical_key_type_name";
			$Headers[1] = array("name" => "Physical Key Type", "field_name" => "physical_key_type_name", "field_type" => "text");	
		}elseif($Table == DB_TABLE_PRODUCTS){
			$Query = "SELECT product_id, product_name FROM " . DB_TABLE_PRODUCTS . " WHERE deleted=0 ORDER BY product_name";
			$Headers[1] = array("name" => "Product", "field_name" => "product_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_ROLES){
			$Query = "SELECT role_id, role_name FROM " . DB_TABLE_ROLES . " WHERE deleted=0 ORDER BY role_name";
			$Headers[1] = array("name" => "Role", "field_name" => "role_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_SHARE_TYPES){
			$Query = "SELECT share_type_id, share_type_name FROM " . DB_TABLE_SHARE_TYPES . " WHERE deleted=0 ORDER BY share_type_name";
			$Headers[1] = array("name" => "Share Type", "field_name" => "share_type_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_SHARES){
			$TableWidth = 2800;
			$Query = "SELECT share_id, share_label, serial_number, share_type_id, box_id, escrow_location_id, bag_id, always_bagged, product_id, environment_id, key_type_id, media_type_id, mofn_threshold, share_creation_date, original_distribution_date, date_destroyed, share_set, notes FROM " . DB_TABLE_SHARES . " WHERE deleted=0 ORDER BY share_label";
			$Headers[1] = array("name" => "Label", "field_name" => "share_label", "field_type" => "text", "width" => 200);
			$Headers[2] = array("name" => "Serial", "field_name" => "serial_number", "field_type" => "text", "width" => 90);
			$Headers[3] = array("name" => "Type", "field_name" => "share_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_SHARE_TYPES, "width" => 150);
			$Headers[4] = array("name" => "Box", "field_name" => "box_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_BOXES, "width" => 150);
			$Headers[5] = array("name" => "Escrow Location", "field_name" => "escrow_location_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_ESCROW_LOCATIONS, "width" => 150);
			$Headers[6] = array("name" => "Bag", "field_name" => "bag_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_TAMPER_EVIDENT_BAGS, "width" => 150);
			$Headers[7] = array("name" => "Always Bagged", "field_name" => "always_bagged", "field_type" => "checkbox", "width" => 100);
			$Headers[8] = array("name" => "Product", "field_name" => "product_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_PRODUCTS, "width" => 150);
			$Headers[9] = array("name" => "Environment", "field_name" => "environment_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_ENVIRONMENTS, "width" => 150);
			$Headers[10] = array("name" => "Key Type", "field_name" => "key_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_KEY_TYPES, "width" => 150);
			$Headers[11] = array("name" => "Media Type", "field_name" => "media_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_MEDIA_TYPES, "width" => 150);
			$Headers[12] = array("name" => "MofN Threshold", "field_name" => "mofn_threshold", "field_type" => "text", "width" => 200);
			$Headers[13] = array("name" => "Creation Date", "field_name" => "share_creation_date", "field_type" => "date", "width" => 100);
			$Headers[14] = array("name" => "Distribution Date", "field_name" => "original_distribution_date", "field_type" => "date", "width" => 100);
			$Headers[15] = array("name" => "Destruction Date", "field_name" => "date_destroyed", "field_type" => "date", "width" => 100);
			$Headers[16] = array("name" => "Share Set", "field_name" => "share_set", "field_type" => "text", "width" => 200);
			$Headers[17] = array("name" => "Notes", "field_name" => "notes", "field_type" => "text", "width" => 200);			
		}elseif($Table == DB_TABLE_SHAREHOLDERS){
			$TableWidth = 2000;
			$Query = "SELECT shareholder_id, shareholder_name, username, function_type_id, cbo_user, has_data_center_access, manager_name, function_id, function_id_secondary, site_id, phone_number, desk_location, notes FROM " . DB_TABLE_SHAREHOLDERS . " WHERE deleted=0 ORDER BY shareholder_name";
			$Headers[1] = array("name" => "Name", "field_name" => "shareholder_name", "field_type" => "text");
			$Headers[2] = array("name" => "Username", "field_name" => "username", "field_type" => "text");
			$Headers[3] = array("name" => "Function Type", "field_name" => "function_type_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_FUNCTION_TYPES);
			$Headers[4] = array("name" => "CBO", "field_name" => "cbo_user", "field_type" => "checkbox", "width" => 50);
			$Headers[5] = array("name" => "DCA", "field_name" => "has_data_center_access", "field_type" => "checkbox", "width" => 50);
			$Headers[6] = array("name" => "Manager", "field_name" => "manager_name", "field_type" => "text");
			$Headers[7] = array("name" => "Primary Function", "field_name" => "function_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_FUNCTIONS);			
			$Headers[8] = array("name" => "Secondary Function", "field_name" => "function_id_secondary", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_FUNCTIONS);			
			$Headers[9] = array("name" => "Site", "field_name" => "site_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_SITES);
			$Headers[10] = array("name" => "Phone Number", "field_name" => "phone_number", "field_type" => "text", "width" => 150);
			$Headers[11] = array("name" => "Desk", "field_name" => "desk_location", "field_type" => "text", "width" => 100);
			$Headers[12] = array("name" => "Notes", "field_name" => "notes", "field_type" => "text");		
		}elseif($Table == DB_TABLE_SHAREHOLDER_BLACKLIST){
			$Query = "SELECT shareholder_blacklist_id, username FROM " . DB_TABLE_SHAREHOLDER_BLACKLIST . " WHERE deleted=0 ORDER BY username";
			$Headers[1] = array("name" => "Username", "field_name" => "username", "field_type" => "text");		
		}elseif($Table == DB_TABLE_SITES){
			$Query = "SELECT site_id, site_name FROM " . DB_TABLE_SITES . " WHERE deleted=0 ORDER BY site_name";
			$Headers[1] = array("name" => "Site", "field_name" => "site_name", "field_type" => "text");
		}elseif($Table == DB_TABLE_TAMPER_EVIDENT_BAGS){	
			$Query = "SELECT bag_id, bag_serial, used FROM " . DB_TABLE_TAMPER_EVIDENT_BAGS . " WHERE deleted=0 AND used IN (0, 1) ORDER BY bag_serial";	// Do not show "opened" bags (2's)
			$Headers[1] = array("name" => "Bag Serial", "field_name" => "bag_serial", "field_type" => "text");
			$Headers[2] = array("name" => "Sealed", "field_name" => "used", "field_type" => "checkbox", "width" => 70);
		}elseif($Table == DB_TABLE_USERS){
			$Query = "SELECT user_id, name, username, email, office_phone, cell_phone, title, reporting_manager, is_admin, disabled FROM " . DB_TABLE_USERS . " ORDER BY name";
			$Headers[1] = array("name" => "Name", "field_name" => "name", "field_type" => "text");
			$Headers[2] = array("name" => "Username", "field_name" => "username", "field_type" => "text", "disabled" => TRUE, "width" => 130);
			$Headers[3] = array("name" => "Email", "field_name" => "email", "field_type" => "text");
			$Headers[4] = array("name" => "Office", "field_name" => "office_phone", "field_type" => "text", "width" => 110);
			$Headers[5] = array("name" => "Cell", "field_name" => "cell_phone", "field_type" => "text", "width" => 110);
			// $Headers[5] = array("name" => "Employee Number", "field_name" => "employee_number", "field_type" => "text");
			$Headers[6] = array("name" => "Title", "field_name" => "title", "field_type" => "text");
			$Headers[7] = array("name" => "Manager", "field_name" => "reporting_manager", "field_type" => "text");
			// $Headers[5] = array("name" => "Notes", "field_name" => "notes", "field_type" => "text");
			$Headers[8] = array("name" => "Admin", "field_name" => "is_admin", "field_type" => "checkbox", "width" => 60);
			$Headers[9] = array("name" => "Disabled", "field_name" => "disabled", "field_type" => "checkbox", "width" => 70);
		}elseif($Table == DB_TABLE_USER_ACL){
			$Query = "SELECT user_acl_id, username FROM " . DB_TABLE_USER_ACL . " WHERE deleted=0 ORDER BY username";
			$Headers[1] = array("name" => "Username", "field_name" => "username", "field_type" => "text");			
		}elseif($Table == DB_TABLE_VENDORS){
			$TableWidth = 2000;
			$Query = "SELECT vendor_id, vendor_name, vendor_website, vendor_address_street, vendor_address_city, vendor_address_state, vendor_address_zip, vendor_address_country, vendor_support_email, vendor_support_phone, vendor_account_number, notes FROM " . DB_TABLE_VENDORS . " WHERE deleted=0 OR deleted IS NULL ORDER BY vendor_name";
			$Headers[1] = array("name" => "Vendor", "field_name" => "vendor_name", "field_type" => "text");
			$Headers[2] = array("name" => "Website", "field_name" => "vendor_website", "field_type" => "text");
			$Headers[3] = array("name" => "Street", "field_name" => "vendor_address_street", "field_type" => "text");
			$Headers[4] = array("name" => "City", "field_name" => "vendor_address_city", "field_type" => "text");
			$Headers[5] = array("name" => "State", "field_name" => "vendor_address_state", "field_type" => "text", "width" => 150);
			$Headers[6] = array("name" => "Zip", "field_name" => "vendor_address_zip", "field_type" => "text", "width" => 100);
			$Headers[7] = array("name" => "Country", "field_name" => "vendor_address_country", "field_type" => "text", "width" => 150);
			$Headers[8] = array("name" => "Email", "field_name" => "vendor_support_email", "field_type" => "text");
			$Headers[9] = array("name" => "Phone", "field_name" => "vendor_support_phone", "field_type" => "text");
			$Headers[10] = array("name" => "Account Number", "field_name" => "vendor_account_number", "field_type" => "text");
			$Headers[11] = array("name" => "Notes", "field_name" => "notes", "field_type" => "text");
			// $Headers[12] = array("name" => "Comments", "field_name" => "comments", "field_type" => "text");
		}elseif($Table == DB_TABLE_VENDOR_ATTACHMENTS){
			$Query = "SELECT a.attachment_id, attachment_name, attachment_name AS filename, attachment_description, vendor_id FROM " . DB_TABLE_ATTACHMENTS . " a, " . DB_TABLE_VENDOR_ATTACHMENTS . " v WHERE a.attachment_id=v.attachment_id";			
			$Headers[1] = array("name" => "Upload", "field_name" => "attachment_name", "field_type" => "file", "width" => 150);
			$Headers[2] = array("name" => "Filename", "field_name" => "filename", "field_type" => "text", "disabled" => TRUE);		// This input will simply display the filename that has been uploaded, it will not be sent to the server
			$Headers[3] = array("name" => "Description", "field_name" => "attachment_description", "field_type" => "text");
			$Headers[4] = array("name" => "Vendor", "field_name" => "vendor_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_VENDORS, "width" => 140);
		}elseif($Table == DB_TABLE_VENDOR_CONTACTS){
			$Query = "SELECT vendor_contact_id, vendor_contact_name, vendor_contact_title, vendor_contact_office_phone, vendor_contact_cell_phone, vendor_contact_email, vendor_id, priority_rank FROM " . DB_TABLE_VENDOR_CONTACTS . " WHERE deleted=0 ORDER BY vendor_contact_name";
			$Headers[1] = array("name" => "Contact Name", "field_name" => "vendor_contact_name", "field_type" => "text");
			$Headers[2] = array("name" => "Title", "field_name" => "vendor_contact_title", "field_type" => "text");
			$Headers[3] = array("name" => "Office Phone", "field_name" => "vendor_contact_office_phone", "field_type" => "text");
			$Headers[4] = array("name" => "Cell Phone", "field_name" => "vendor_contact_cell_phone", "field_type" => "text");
			$Headers[5] = array("name" => "Email", "field_name" => "vendor_contact_email", "field_type" => "text");
			$Headers[6] = array("name" => "Vendor", "field_name" => "vendor_id", "field_type" => "dropdown", "dropdown_option" => DB_TABLE_VENDORS);
			$Headers[7] = array("name" => "Priority Rank", "field_name" => "priority_rank", "field_type" => "text");
		}elseif($Table == DB_TABLE_SUPPORT_CONTRACTS){
			$Query = "SELECT support_contract_id, purchase_order_number, contract_number, date_start, date_end, maintenance_plan_type FROM " . DB_TABLE_SUPPORT_CONTRACTS . " WHERE deleted=0 ORDER BY contract_number";
			$Headers[1] = array("name" => "Purchase Order Number", "field_name" => "purchase_order_number", "field_type" => "text");			
			$Headers[2] = array("name" => "Contract Number", "field_name" => "contract_number", "field_type" => "text");
			$Headers[3] = array("name" => "Start Date", "field_name" => "date_start", "field_type" => "date", "width" => 100);
			$Headers[4] = array("name" => "End Date", "field_name" => "date_end", "field_type" => "date", "width" => 100);			
			$Headers[5] = array("name" => "Maintenance Plan Type", "field_name" => "maintenance_plan_type", "field_type" => "text");
		}else{
			add_message('error', $GLOBALS['errorMessage']['unknown_table']);
		}
		
		if($Table != DB_TABLE_FORMS){	// Don't allow admin users delete forms
			$Headers[99]  = array("name" => "Delete");
		}
		$Headers[100] = array("name" => "Save");
		
		if(check_messages()){
		
			// Generate the table
			
			$Result = db_query($Query);
			$Count = row_count($Result);
							
			echo "<div class='ajax_container'>";
				echo "<div class='boxed_group_inner clearfix " . (@$TableWidth ? "scroll_x" : NULL) . "'>\n";	// Add a horizontal scroll bar for large panels
					
					// Containers to hold the AJAX responses
					
					echo "<div id='messages' " . (@$TableWidth ? "style='width: " . ($TableWidth - 10) . "px; margin-right: 10px;'" : NULL) . "></div>\n";	// For large panels make sure the error/success messages scroll the entire width
			
					// Add a hidden message so the JavaScript knows if it should duplicate the last row or now
					
					if($Count == 0){
						echo "<span data_msg='no_records_found'></span>\n";	
					}
					
					// Table headers
					
					echo "<table id='admin_manager' " . (@$TableWidth ? "style='width: ". $TableWidth . "px; padding-right: 10px;'" : NULL) . ">\n";	// For panels with lots of fields, enlarge the table		
						echo "<thead>\n";		
						
							echo "<tr class='header-row'>\n";	

								foreach($Headers as $Current){
									
									if($Current['name'] == "Delete" || $Current['name'] == "Save"){					
										echo "<th width='70'>" . ($Table == DB_TABLE_USERS && $Current['name'] == "Delete" ? "Disabled" : $Current['name']) . "</th>\n";
									}else{
										if($Current['field_name'] != "disabled"){										
											echo "<th " . (@$Current['width'] ? "style='width: " . $Current['width'] . "px;'" : NULL) . ">" . $Current['name'] . "</th>\n";
										}
									}

								}
								
							echo "</tr>\n";	
							
						echo "</thead>\n";				
						echo "<tbody>\n";					
						
							// If the table contains data then load it
							
							if($Count > 0){
							
								while($Row = row_fetch($Result)){
									$Total = count($Row) - 1;
								
									echo "<tr class='data-row' id='" . $Row[0] . "'>\n";
									
										$Count = 1;
										while($Count <= $Total){
										
											if($Table == DB_TABLE_USERS && $Headers[$Count]['field_name'] == "disabled"){
												$DisabledValue = $Row[$Count];
											}else{
											
												echo "<td align='center'>";
												
													if($Headers[$Count]['field_type'] == "date"){
										
														form_text_field(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "value" => @$Row[$Count], "css" => "class='datepicker'"));

													}elseif($Headers[$Count]['field_type'] == "text"){
													
														form_text_field(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "value" => @$Row[$Count], "disabled" => (@$Headers[$Count]['disabled'] ? TRUE : FALSE)));
												
													}elseif($Headers[$Count]['field_type'] == "textarea"){
													
														form_text_area(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "value" => @$Row[$Count], "css" => "style='width: 98%;'", "disabled" => (@$Headers[$Count]['disabled'] ? TRUE : FALSE)));
														
													}elseif($Headers[$Count]['field_type'] == "dropdown"){
													
														// Cache each dropdown list (except for the tamper evedint bags menu as it will be different for each row)
														
														if($Headers[$Count]['dropdown_option'] != DB_TABLE_TAMPER_EVIDENT_BAGS){
															if(!@${$Headers[$Count]['field_name']}){	// Check if cache exists
																${$Headers[$Count]['field_name']} = lookup_dropdown_menu($Headers[$Count]['dropdown_option']);	// Create one-time cache
															}
														}else{
															${$Headers[$Count]['field_name']} = lookup_dropdown_menu($Headers[$Count]['dropdown_option']);	// Refresh cache on every loop
														}
														
														$Value = @$Row[$Count];														
												
														// If loading a tamper evident bag dropdown, the actual value will be missing because the bag is marked as used
														// we need to add it back into the array so that the bag is selected and visible in GUI
														
														if($Headers[$Count]['dropdown_option'] == DB_TABLE_TAMPER_EVIDENT_BAGS){
															if($Value){
																${$Headers[$Count]['field_name']}[$Value] = lookup_tamper_evident_bag($Value);
																asort(${$Headers[$Count]['field_name']});
															}
														}
														
														form_dropdown(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "value" => $Value, "multiselect" => FALSE, "items" => ${$Headers[$Count]['field_name']}, "css" => "class='dropdown'", "select_opt" => TRUE, "select_opt_text" => "Select an option"));

													}elseif($Headers[$Count]['field_type'] == "checkbox"){
													
														$DisabledValue = NULL;
														form_boolean(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "value" => @$Row[$Count]));
														
													}elseif($Headers[$Count]['field_type'] == "file"){
												
														echo "<input type='file' class='uploader' id='uploader_" . rand() . "' name='" . $Headers[$Count]['field_name'] . "'>";
														echo "<input type='hidden' name='filename_hidden' value='" . $Headers[$Count]['field_name'] . "'>";	// This input will be sent back to the server when the row is submitted
													
													}
												
												echo "</td>\n";
											
											}
												
											$Count++;
										}
										
										if(@$Headers[99]){
											echo "<td align='center'>";
												form_boolean(array("use_table" => FALSE, "name" => "deleted", "value" => (@$DisabledValue === NULL ? NULL : $DisabledValue), "css" => (@$DisabledValue === NULL ? NULL : "class='disabled_option'")));
											echo "</td>";	
										}
										
										echo "<td align='center'>";					
											form_submit(array("use_table" => FALSE, "value" => "Update", "css" => "class='regular_button' style='width: 60px;'"));
										echo "</td>";
										
									echo "</tr>\n";
								}
							
							// The table has no data, present a blank row
							
							}else{
							
								$Total = count($Headers) - 2;	// -2 for delete and save
								$Count = 1;
								
								echo "<tr class='data-row' id='temp_id'>\n";
									
									while($Count <= $Total){
										
											echo "<td align='center'>";
											
												if($Headers[$Count]['field_type'] == "date"){
									
													form_text_field(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "css" => "class='datepicker'"));
													
												}elseif($Headers[$Count]['field_type'] == "text"){
												
													form_text_field(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "disabled" => (@$Headers[$Count]['disabled'] ? TRUE : FALSE)));
											
												}elseif($Headers[$Count]['field_type'] == "textarea"){
													
													form_text_area(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "value" => @$Row[$Count], "css" => "style='width: 98%;'", "disabled" => (@$Headers[$Count]['disabled'] ? TRUE : FALSE)));

												}elseif($Headers[$Count]['field_type'] == "dropdown"){
												
													if(!@${$Headers[$Count]['field_name']}){
														${$Headers[$Count]['field_name']} = lookup_dropdown_menu($Headers[$Count]['dropdown_option']);
													}
												
													form_dropdown(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name'], "multiselect" => FALSE, "items" => ${$Headers[$Count]['field_name']}, "css" => "class='dropdown'", "select_opt" => TRUE, "select_opt_text" => "Select an option"));

												}elseif($Headers[$Count]['field_type'] == "checkbox"){
												
													$DisabledValue = NULL;
													form_boolean(array("use_table" => FALSE, "id" => "", "name" => $Headers[$Count]['field_name']));
													
												}elseif($Headers[$Count]['field_type'] == "file"){
												
													echo "<input type='file' class='uploader' id='uploader_" . rand() . "' name='" . $Headers[$Count]['field_name'] . "'>";
													echo "<input type='hidden' name='filename_hidden'>";	// This input will be sent back to the server when the row is submitted
												
												}
											
											echo "</td>\n";
									
										$Count++;
									}
									
									if(@$Headers[99]){
										echo "<td align='center'>";
											form_boolean(array("use_table" => FALSE, "name" => "deleted", "css" => "class='disabled_option'", "disabled" => TRUE));
										echo "</td>";		
									}
									
									echo "<td align='center'>";					
										form_submit(array("use_table" => FALSE, "value" => "Add", "css" => "class='regular_button' style='width: 60px;'"));
									echo "</td>";
									
								echo "</tr>\n";
							
							}
							
						echo "</tbody>\n";			
					echo "</table>\n";
					
				echo "</div>\n";				
			echo "</div>\n";	
					
		}

	}else{
		add_message('error', $GLOBALS['errorMessage']['cant_detect_table']);
	}
	
	// Display any messages
	
	if(!check_messages()){
		echo "<div class='ajax_container'>";
			echo "<div class='boxed_group_inner clearfix'>\n";
				echo "<div class='inner_messages'>\n";
					print_messages();
				echo "</div>\n";	
			echo "</div>\n";				
		echo "</div>\n";	
	}
	
	db_close();
		
?>
