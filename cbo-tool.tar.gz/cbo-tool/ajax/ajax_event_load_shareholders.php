<?php

	include("../includes.php");
	db_connect();

	$ID = validate("int", @$_GET['event_id'], "event", 1);
	$Type = strtolower($_GET['type']);

	if(check_messages()){
	
		echo "<table>";

			$Query = "SELECT * FROM " . DB_TABLE_EVENTS . " WHERE event_id=" . $ID;
			$Result = db_query($Query);
			$Event = row_fetch_assoc($Result);

			if($Type == 'update'){
				$Query = "SELECT product_id FROM " . DB_TABLE_EVENT_PRODUCTS . " WHERE event_id=" . $ID;
				$Result = db_query($Query);
				while($Product = row_fetch_assoc($Result)){
					$Products[] = $Product['product_id'];
				}

				form_dropdown(array("title" => "Template", "name" => "email_template_id", "value" => $Event['email_template_id'], "items" => list_email_templates(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE, "id" => "template_id_" . $Type));
				form_text_field(array("title" => "Event Name", "name" => "event_name", "value" => $Event['event_name'], "required" => TRUE, "id" => "event_name_" . $Type));
				form_dropdown(array("title" => "Site", "name" => "site_id", "value" => $Event['site_id'], "items" => list_sites(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE, "id" => "site_id_" . $Type));
				form_date_time(array("title" => "Date", "name" => "start_date", "value" => $Event['start_date'], "css" => "autocomplete='off' class='datepicker'", "required" => TRUE, "id" => "start_date_" . $Type, "disabled" => TRUE));	// Events don't move, they get cancelled and rescheduled
				form_dropdown(array("title" => "Start Time", "name" => "start_time", "value" => $Event['start_time'], "items" => time_range(0, 60*60*24, 60*15), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE, "id" => "start_time_" . $Type));
				form_dropdown(array("title" => "End Time", "name" => "end_time", "value" => $Event['end_time'], "items" => time_range(0, 60*60*24, 60*15), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE, "id" => "end_time_" . $Type));
				form_dropdown(array("title" => "Products", "name" => "product_id[]", "value" => $Products, "items" => list_products(), "select_opt" => FALSE, "required" => TRUE, "multiselect" => TRUE, "id" => "product_id_" . $Type));
				form_text_field(array("title" => "Add'l Recipients (CSV)", "value" => $Event['cc_recipients'], "name" => "cc_recipients", "required" => FALSE, "id" => "cc_recipients_" . $Type));
			}

			$Query = "SELECT * FROM " . DB_TABLE_EVENT_SHAREHOLDERS . " WHERE deleted=0 AND event_id=" . $ID;
			$Result = db_query($Query);

			$Shareholders = array();
			while($Row = row_fetch_assoc($Result)){
				$Shareholders[] = $Row['shareholder_id'];
				$Keys[$Row['shareholder_id']] = $Row['physical_key_id'];
			}

			$Count = 0;
			foreach(list_event_shareholder_usage() as $Info){
				echo "<tr>";

					if($Type == 'update'){
						if($Count == 0){
							echo "<td align='right'>Shareholders:</td>";
							$Count++;
						}else{
							echo "<td></td>";
						}
					}

					echo "<td align='left'>";
						echo "<input " . (in_array($Info['id'], $Shareholders) ? "checked='checked'" : NULL) . "type='checkbox' class='shareholder' value='" . $Info['id'] . "' name='shareholder_id[]'> " . $Info['name'] . " ";

						form_dropdown(array("use_table" => FALSE, "value" => (isset($Keys[$Info['id']]) ? $Keys[$Info['id']] : NULL), "id" => uniqid(), "name" => "physical_key_id[]", "items" => shareholder_past_physical_keys($Info['id'], $Event['start_date']), "select_opt" => FALSE, "multiselect" => TRUE, "css" => "class='phsyical_keys'"));

						if($Info['last_used'] == 0){
							$Color = "gray";	// Never used before
						}elseif(((time() - strtotime($Info['last_used'])) / (60*60*24)) <= 30){		// Used in last month
							$Color = "red";
						}elseif(((time() - strtotime($Info['last_used'])) / (60*60*24)) <= 90){		// Used in last 3 months
							$Color = "orange";
						}else{		// Last used over 3 months ago
							$Color = "green";
						}

						echo " <span class='last_used' style='color: " . $Color . ";'>(" . ($Info['last_used'] == 0 ? "Never Used" : $Info['last_used']) . ")</span>";
					echo "</td>";
				echo "</tr>";
			}

			form_break();
			form_submit(array("value" => ucfirst($Type), "id" => strtolower($Type), "name" => strtolower($Type)));
		echo "</table>";
	}

	print_messages();

?>
