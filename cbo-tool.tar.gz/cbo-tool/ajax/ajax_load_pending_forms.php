<?php

	require_once("../includes.php");
	db_connect();

		if($PendingForms = pending_forms()){
			echo "<div class='boxed_group'>\n";
				echo "<h3>Form Approval</h3>";			
				echo "<div class='boxed_group_inner clearfix'>\n";
					
					// Containers to hold the AJAX responses
					
					echo "<div id='messages2'></div>";			
					echo "<div id='results2'></div>";
					
					// Display the dropdown
					
					echo "<div class='vertical_margin_10px'>";
					
						echo "<select id='pending_forms' name='pending_forms' class='dropdown' multiple='multiple'>\n";
							
							// Add each option, disabeling all but the first option (forms need to be approved/rejected in order)
							
							$Count = 1;							
							foreach($PendingForms as $Key => $Value){
							
								// Find the filename for the first form
								
								if($Count == 1){
									$DataParts = explode('--', $Key);	
									
									$Query = "SELECT filename FROM " . $DataParts[0] . " WHERE id=" . $DataParts[1];
									$Result = db_query($Query);
									$Row = row_fetch($Result);
									
									$Filename = $Row[0];
								}
							
								// echo "<option " . ($Count > 1 ? "disabled='disabled'" : NULL) . " value='" . $Key . "'>" . $Value . "</option>\n";
								echo "<option value='" . $Key . "'>" . $Value . "</option>\n";
								$Count++;
							}
							
						echo "</select>\n";
					
					echo "</div>";

					// Display the buttons
					
					echo "<div id='decision_buttons' style='display: none;'>";
						echo "<input type='submit' id='view' name='view' value='View' data-href='" . PATH_FORMS_COMPLETED . "/" . $Filename . "'> &nbsp;";
						echo "<input type='submit' id='submit1' name='submit1' value='Approve'> &nbsp;";
						echo "<input type='submit' id='submit2' name='submit2' value='Reject'>";	
					echo "</div>";
					
				echo "</div>\n";
			echo "</div>\n";
			
		}
			
	db_close();
		
?>
