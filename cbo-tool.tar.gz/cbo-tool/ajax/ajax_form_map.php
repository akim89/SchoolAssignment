<?php

	require_once("../includes.php");
	db_connect();	
	
	############################
	##    PROCESS THE FORM    ##
	############################
	
	$UserID = validate("int", $_COOKIE['user_id'], "user ID", 1, NULL, $GLOBALS['errorMessage']['cookie_no_detect_user']);	

	if(!empty($_POST)){
	
		// Validate the data
		
		$Filename  = validate("regex", @$_POST['filename'],   "filename",  1, "basic");
		$FormName  = validate("regex", @$_POST['form_name'],  "form name", 1, "text");
		$TableName = validate("regex", @$_POST['form_table'], "maps to",   1, "basic");
	
		if(check_messages()){
			$Info['form_name']    = $FormName;
			$Info['form_table']   = $TableName;
			$Info['filename']     = $Filename;
			$Info['created_by']   = $UserID;
			$Info['date_created'] = "NOW()";

			$Result = db_query(create_sql_insert($Info, DB_TABLE_FORMS));
			$Result ? add_message('success', $GLOBALS['successMessage']['changes_saved']) : add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
		}
	
	############################
	##    DISPLAY THE FORM    ##
	############################
	
	}else{

		if($FormTables = list_form_tables()){

			$Filename = $_GET['filename'];
		
			// Display the form
			
			form_start(array("action" => $_SERVER['PHP_SELF'], 'name' => 'unmapped_form', "css" => "style='margin-bottom: 0;'"));
				form_text_field(array("title" => "Form Name", "name" => "form_name", "value" => ucwords(str_replace("_", " ", basename($Filename, FROMS_FILE_EXTENSION))), "size" => 40));
				form_dropdown(array("title" => "Maps To", "name" => "form_table", "value" => NULL, "multiselect" => TRUE, "items" => $FormTables, "select_opt" => FALSE));
				form_break();
				form_hidden(array("name" => "filename", "value" => $Filename));
				form_submit(array("value" => "Submit", "id" => "map_it"));
			form_end();
			
		}else{
			add_message('error', $GLOBALS['errorMessage']['no_avaliable_tables']);
		}
			
	}
	
	// Display any messages
	
	if(!check_messages()){
		echo "<div class='inner_messages'>\n";
			print_messages();
		echo "</div>\n";		
	}
	
	db_close();
		
?>