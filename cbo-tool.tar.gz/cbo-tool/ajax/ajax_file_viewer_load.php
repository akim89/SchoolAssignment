<?php

	require_once("../includes.php");
	db_connect();

		$resultsPerPage = 15;

		if(preg_match('/[0-9]+/', @$_GET['page'], $matches)){
			(int) $startPageNum = $_GET['page'];
			(int) $recordStart = ($resultsPerPage * ($startPageNum - 1));	// Page > 1
		}else{
			(int) $recordStart = 0;	// 1st page
		}
	
		$FormID = $_GET['form_id'];
		
		if($FormID){
		
			// Find all the forms

			$Query = "SELECT form_id, form_name, form_table FROM " . DB_TABLE_FORMS . " WHERE deleted=0 ORDER BY form_name";
			$Result = db_query($Query);
			$Count = row_count($Result);			
					
			if($Count > 0){
			
				$Forms = row_fetch_all($Result);
				
				if($FormID != "all"){
					foreach($Forms as $FormInfo){
						if($FormInfo['form_id'] == $FormID){
							$Forms = array();
							$Forms[] = $FormInfo;
							break;
						}
					}
				}
				
				// Display file information
					
				foreach($Forms as $FormInfo){
					
					$Query = "SELECT SQL_CALC_FOUND_ROWS filename, filename_signed, u1.name AS created_by, s.status_name, f.status_id, IF(u2.name IS NOT NULL, u2.name, IF(u3.name IS NOT NULL, u3.name, 'N/A')) AS decision_by, IF(decision_date IS NOT NULL, decision_date, 'N/A') AS decision_date, f.date_created, f.date_updated  FROM " . clean_sql_value($FormInfo['form_table']) . " f LEFT JOIN " . DB_TABLE_FORM_STATUSES . " s ON s.status_id=f.status_id LEFT JOIN " . DB_TABLE_USERS . " u1 ON u1.user_id=f.created_by LEFT JOIN " . DB_TABLE_USERS . " u2 ON u2.user_id=f.approved_by LEFT JOIN " . DB_TABLE_USERS . " u3 ON u3.user_id=f.rejected_by WHERE f.deleted=0 ORDER BY f.date_created DESC LIMIT " . $recordStart . ", " . $resultsPerPage;
					$Result = db_query($Query);
					$Count = row_count($Result);		
					
					if($Count > 0){
						echo "<div class='boxed_group' data-form-id='" . $FormInfo['form_id'] . "'>\n";
							echo "<h3><img src='" . PATH_IMAGES . "/up.png' class='top'>" . $FormInfo['form_name'] . " Files</h3>";	
							echo "<div class='boxed_group_inner clearfix'>\n";
				
								echo "<table class='file_table'>\n";
									echo "<thead>\n";
										echo "<tr>\n";
											echo "<th width='70'>Unsigned</th>\n";
											echo "<th width='60'>Signed</th>\n";
											echo "<th width='150'>Date Created</th>\n";
											echo "<th>Created By</th>\n";									
											echo "<th width='100'>Status</th>\n";
											echo "<th>Decision Made By</th>\n";
											echo "<th width='150'>Decision Date</th>\n";									
										echo "</tr>\n";
									echo "</thead>\n";
									echo "<tbody>\n";
					
										while($FileInfo = row_fetch_assoc($Result)){
											echo "<tr>\n";
												echo "<td><a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . $FileInfo['filename'] . "'><img class='valign_middle' src='" . PATH_IMAGES . "/document.png' alt='" . $FileInfo['filename'] . "' title='" . $FileInfo['filename'] . "'></a></td>\n";
												echo "<td>" . ($FileInfo['filename_signed'] ? "<a target='_blank' href='" . PATH_FORMS_SIGNED . "/" . $FileInfo['filename_signed'] . "'><img class='valign_middle' src='" . PATH_IMAGES . "/document.png' alt='" . $FileInfo['filename_signed'] . "' title='" . $FileInfo['filename_signed'] . "'></a>" : "&nbsp;") . "</td>\n";
												echo "<td>" . $FileInfo['date_created'] . "</td>\n";
												echo "<td>" . $FileInfo['created_by'] . "</td>\n";										
												echo "<td><span class='" . ($FileInfo['status_id'] == 1 ? "pending" : ($FileInfo['status_id'] == 2 ? "approved" : "rejected")) . "'>" . $FileInfo['status_name'] . "</span></td>\n";
												echo "<td>" . $FileInfo['decision_by'] . "</td>\n";
												echo "<td>" . $FileInfo['decision_date'] . "</td>\n";										
											echo "</tr>\n";
										}
									
									echo "</tbody>\n";						
								echo "</table>\n";
	
								// Calculate the total number of pages of results

								$Query = "SELECT FOUND_ROWS() AS count";
								$Result = db_query($Query);							
								$FoundRows = row_fetch_assoc($Result);
								
								$totalPages = ceil($FoundRows['count'] / $resultsPerPage);

								// Display a list of page numbers

								echo "<div class='page'>\n";
									$pages = range(($startPageNum - 4 < 1 ? 1 : $startPageNum - 4), ($startPageNum + 4 > $totalPages ? $totalPages : $startPageNum + 4));	// Calculate +/- 4 pages from current page

									// "First" button

									if($startPageNum != 1 && $totalPages > 1){
										echo "<span data-page-num='1' class='page_number ui-corner-all'>&laquo; First</span>\n";
									}

									// Page number buttons

									foreach($pages as $currentPage){
										echo "<span data-page-num='" . $currentPage . "' class='page_number ui-corner-all " . ($startPageNum == $currentPage ? "current_page" : NULL) . "'>" . $currentPage . "</span>\n";
									}

									// "Last" button

									if($startPageNum < $totalPages && $totalPages > 1){
										echo "<span data-page-num='" . $totalPages . "' class='page_number ui-corner-all'>Last &raquo;</span>\n";
									}

								echo "</div>\n";
								
							echo "</div>\n";						
						echo "</div>\n";
						
					}
					
				}				
			}
		}
		
	db_close();
	
?>
