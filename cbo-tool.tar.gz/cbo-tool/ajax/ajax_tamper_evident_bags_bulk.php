<?php

	require_once('../includes.php');
	db_connect();

	// Process the data
	
	if(@$_POST['submit'] == "Add"){
	
		// Validate the data
		
		$SerialStart = validate("regex", $_POST['serial_start'], "start serial number", 1, "alphanum");
		$SerialEnd   = validate("regex", $_POST['serial_end'], "end serial number", 1, "alphanum");		
		
		if((int)$SerialEnd < (int)$SerialStart){
			add_message('error', $GLOBALS['errorMessage']['non_sequential_serials']);
		}
		
		// Save the data
		
		if(check_messages()){
		
			// Break apart the serails so we can seperate the characters from the numbers (we allow a set of characters at the beginning)
			
			preg_match('/^([a-zA-Z]*)(\d+)$/', $SerialStart, $StartMatches);
			preg_match('/^([a-zA-Z]*)(\d+)$/', $SerialEnd, $EndMatches);
		
			// Generate an array of serial numbers, zero padded, according to the length of the start serial number
			
			$SerialRange = array_map("pad_serial", range($StartMatches[2], $EndMatches[2]), array_fill(0, count(range($StartMatches[2], $EndMatches[2])), strlen($StartMatches[2])));
		
			// Add the serial numbers to the database
			
			foreach($SerialRange as $Serial){
				$Values[] = "('" . $StartMatches[1] . clean_sql_value($Serial) . "')";
			}
			
			$Query = "INSERT IGNORE INTO " . DB_TABLE_TAMPER_EVIDENT_BAGS . " (bag_serial) VALUES " . implode(", ", $Values);
			$Result = db_query($Query);
			
			// Add an error or success message
			
			$Result ? add_message('success', $GLOBALS['successMessage']['changes_saved']) : add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
		}
		
		// Display any messages
		
		if(!check_messages()){
			echo "<div class='inner_messages'>\n";
				print_messages();
			echo "</div>\n";		
		}
	
	// Display the inital form when the panel is first clicked
	
	}else{	
	
		echo "<div class='ajax_container'>";
			echo "<div class='boxed_group_inner clearfix'>\n";
			
				// Containers to hold the AJAX responses
					
				echo "<div id='messages'></div>\n";						
				
				// Display the input fields
				
				echo "Serial Start: <input type='text' name='serial_start' id='serial_start' size='20'> ";
				echo "Serial End: <input type='text' name='serial_end' id='serial_end' size='20'> ";
				echo "<input type='submit' name='submit' value='Add' class='special_button'>";
			
			echo "</div>\n";
		echo "</div>\n";	
	
	}	
	
	db_close();

?>