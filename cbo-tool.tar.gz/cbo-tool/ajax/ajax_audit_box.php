<?php

	require_once("../includes.php");
	db_connect();

		$ID = clean_sql_value($_GET['id']);
		
		if($ID){
		
			$Query  = "SELECT IF(f.form_name IS NOT NULL, f.form_name, 'Admin Panel') AS form_name, a.form_id, a.execution_id, a.box_id, a.box_number, s.site_name, a.last_audit_date, a.deleted, u.name, a.audit_date_created FROM " . DB_TABLE_AUDIT_BOXES . " a LEFT JOIN " . DB_TABLE_USERS . " u ON u.user_id=a.audit_created_by LEFT JOIN " . DB_TABLE_FORMS . " f ON f.form_id=a.form_id LEFT JOIN " . DB_TABLE_SITES . " s ON s.site_id=a.site_id WHERE box_id=" . $ID . " ORDER BY audit_date_created";
			$Result = db_query($Query);		
			$Count  = row_count($Result);

			if($Count > 0){
				
				// Display a header
				
				echo "<div class='boxed_group' >\n";
					echo "<h3>Box</h3>\n";
					echo "<div class='boxed_group_inner clearfix'>\n";
						
						// Display the table
						
						echo "<table id='" . DB_TABLE_BOXES . "_table' class='audit_table'>\n";
							echo "<thead>\n";
								echo "<tr>\n";
									echo "<td width='25'>&nbsp;</td>\n";
									echo "<th>Source</th>\n";
									echo "<th>Box Number</th>\n";
									echo "<th>Site</th>\n";
									echo "<th>Last Audit</th>\n";
									echo "<th>Deleted</th>\n";							
									echo "<th>Changed By</th>\n";
									echo "<th>Change Date</th>\n";
								echo "</tr>\n";
							echo "</thead>\n";
							echo "<tbody>\n";
							
								$Count = 1;
								
								while($Row = row_fetch_assoc($Result)){
								
									foreach($Row as $ID => $Value){
										$Row[$ID] = ($Value ? $Value : "----");
									}
									
									echo "<tr>\n";
										echo "<td>" . $Count . ".</td>\n";
										echo "<td>" . ($Row['form_name'] == "Admin Panel" ? $Row['form_name'] : "<a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . lookup_filename_for_form_execution($Row['form_id'], $Row['execution_id']) . "'>" . $Row['form_name'] . "</a>") . "</td>\n";
										echo "<td>" . $Row['box_number'] . "</td>\n";								
										echo "<td>" . $Row['site_name'] . "</td>\n";								
										echo "<td>" . $Row['last_audit_date'] . "</td>\n";						
										echo "<td>" . ($Row['deleted'] == 0 ? "No" : "Yes") . "</td>\n";
										echo "<td>" . $Row['name'] . "</td>\n";
										echo "<td>" . $Row['audit_date_created'] . "</td>\n";		
									echo "</tr>\n";
									
									$Count++;
								}
							
							echo "</tbody>\n";	
						echo "</table>\n";	
					
					echo "</div>";
				echo "<div>";
				
			}else{
				add_message('info', $GLOBALS['infoMessage']['no_audit_information']);
				print_messages();
			}
		}
		
	db_close();
	
?>