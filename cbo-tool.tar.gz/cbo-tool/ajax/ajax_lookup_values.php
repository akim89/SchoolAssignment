<?php

	require_once('../includes.php');
	db_connect();

	// Process the data
	
	if(@$_GET['id'] && @$_GET['dataType']){
		
		// Validate the data
		
		$ID       = clean_sql_value(@$_GET['id']);
		$DataType = clean_sql_value(@$_GET['dataType']);		
		
		// Map the query to a table

		if(preg_match('/^(equipment|equipment_.+)$/', $DataType)){
			$Table = DB_TABLE_EQUIP;
			$Query = "SELECT e.bag_id AS used_bag, e.label_name AS label, l.site_id AS site, e.vendor_id AS vendor, e.model_number AS model_number, e.escrow_location_id AS escrow_location, e.rack_location AS rack_location FROM " . $Table . " e LEFT JOIN " . DB_TABLE_ESCROW_LOCATIONS . " l ON l.escrow_location_id=e.escrow_location_id WHERE equipment_id=" . $ID;
		}elseif(preg_match('/^(share|share_.+)$/', $DataType)){
			$Table = DB_TABLE_SHARES;
			$Query = "SELECT s.bag_id AS used_bag, s.share_label AS label, IF(b.site_id IS NULL, l.site_id, b.site_id) AS site, k.shareholder_id AS shareholder, s.serial_number AS serial, s.escrow_location_id AS escrow_location FROM " . $Table . " s LEFT JOIN " . DB_TABLE_BOXES . " b ON b.box_id=s.box_id LEFT JOIN " . DB_TABLE_KEYS . " pk ON pk.box_id=b.box_id AND pk.shareholder_id IS NOT NULL LEFT JOIN " . DB_TABLE_SHAREHOLDERS . " k ON k.shareholder_id=pk.shareholder_id AND pk.shareholder_id IS NOT NULL LEFT JOIN " . DB_TABLE_ESCROW_LOCATIONS . " l ON l.escrow_location_id=s.escrow_location_id WHERE  s.share_id=" . $ID;
		}elseif(preg_match('/^(physical_key|physical_key_.+)$/', $DataType)){
			$Table = DB_TABLE_KEYS;
			$Query = "SELECT bag_id AS used_bag, label, shareholder_id AS shareholder, serial_number AS serial FROM " . $Table . " WHERE physical_key_id=" . $ID;
		}elseif($DataType == "box"){
			$Table = DB_TABLE_BOXES;
			$Query = "SELECT site_id AS site FROM " . $Table . " WHERE box_id=" . $ID;
		}elseif(preg_match('/^(shareholder_*.*)$/', $DataType)){	
			$Table = DB_TABLE_SHAREHOLDERS;
			// $Query = "SELECT CONCAT(IF(function_id=4, '', function_id), IF(function_id_secondary IS NULL, '', IF(function_id_secondary=4, '', CONCAT(',', function_id_secondary)))) AS function, GROUP_CONCAT(DISTINCT box_id) AS box FROM " . $Table . " s LEFT JOIN " . DB_TABLE_KEYS . " p ON p.shareholder_id=s.shareholder_id WHERE s.shareholder_id=" . $ID . " AND p.deleted=0";	// "Unassigned" function is not returned
			$Query = "SELECT CONCAT(function_id, IF(function_id_secondary IS NULL, '', CONCAT(',', function_id_secondary))) AS function, GROUP_CONCAT(DISTINCT box_id) AS box, function_type_id AS function_type FROM " . $Table . " s LEFT JOIN " . DB_TABLE_KEYS . " p ON p.shareholder_id=s.shareholder_id WHERE s.shareholder_id=" . $ID . " AND p.deleted=0";
		}
		
		// Lookup the value
		
		if(@$Table){
			
			$Result = db_query($Query);
			$Count = row_count($Result);
			
			if($Count > 0){
				$Row = row_fetch_assoc($Result);
				echo json_encode(array_map('trim', $Row));
			}else{
				echo json_encode(array());	// Required so that it will re-enable dropdowns that may have already been disabled
			}
	
		}
		
	}	
	
	db_close();

?>
