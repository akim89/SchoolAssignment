<?php

	require_once("../includes.php");
        require_once('ajax_construct_pendingform_name.php');
	db_connect();	
    
        // #########
        // Load the pending form docx format file
        // #########
        $docx_name_formats_raw = file_get_contents('./docx_format.json');
        $docx_name_formats = json_decode($docx_name_formats_raw, true);
	
	############################
	##    PROCESS THE FORM    ##
	############################
	
	$UserID = validate("int", $_COOKIE['user_id'], "user ID", 1, NULL, $GLOBALS['errorMessage']['cookie_no_detect_user']);	

	if(!empty($_POST)){
	
		// Set some file and directory variables
		
		$TempDirectory = PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_TEMP;
		$XMLFile = $TempDirectory . "/word/document.xml";		
		$FormID = validate("int", $_POST['form_id'], "form ID", 1);		
		$FormName = lookup_form_name($FormID);
		$Filename = lookup_form_filename($FormID);
		$Timestamp = date('YmdHis');
                // Get the formatted output filename
                $OutputFilename = get_docx_filename($FormID, $_POST, $docx_name_formats);
                // if the format is not defined for the form - give the default
                if ( $OutputFilename == "NA") {
		    $OutputFilename = basename($Filename, ".docx") . "_" . $Timestamp . FROMS_FILE_EXTENSION;		
                }
					
		unset($_POST['form_id']);	// So we don't add it to the "$TokensSubmitted" variable below
		
		// Unzip the file
		
		if(unzip_docx($Filename)){
		
			// Find all possible tokens in the XML file

			preg_match_all("/\{\{([^\}]+)\}\}/", file_get_contents($XMLFile), $Matches);	
			
			$Items = array_filter($Matches[0], create_function('$Value', 'if(preg_match("/\{\{ITEM[0-9]{1,2}.*\}\}/", $Value)){ return $Value; }'));	// Determine if there are "item" tokens (only 1 item is required)
			$Matches = array_filter($Matches[0], create_function('$Value', 'if(!preg_match("/\{\{IGNORE_.*|\{\{ITEM[0-9]{1,2}.*\}\}/", $Value)){ return $Value; }'));	// Remove "ignoreable" tokens
			
			$TotalTokens = count(array_unique(array_filter($Matches))) + (count($Items) == 0 ? 0 : 1);	// All non-ignore tokens + 1 if there are any "item" tokens
			$TokensSubmitted = count(array_filter($_POST));
			
			// If the total tokens in the file is the same as the number of tokens submitted then continue
			
			if($TokensSubmitted >= $TotalTokens){	// Most forms will be "=", only "courier" and "HSM out-of-band verification" forms will be ">"		
					
				// Validate the data
				
				$Query = "SELECT token_name, field_type, field_name, dropdown_option, auto_populate_value FROM " . DB_TABLE_FORM_LAYOUT . " WHERE form_id='" . $FormID . "' AND deleted=0";
				$Result = db_query($Query);
				
				while($CurrentField = row_fetch_assoc($Result)){
				
					$Token = str_replace("}}", "", str_replace("{{", "", $CurrentField['token_name']));
				
					// Preform form specific checks
		
					if($FormID == 13 && ($CurrentField['dropdown_option'] == "physical_key" || $Token == "RECEIVING_KEY_HOLDER")){		// Physical Key Distribution Attestation	
						
						if($Token == "RECEIVING_KEY_HOLDER"){
							$TempShareholderID = @$_POST[$Token];
						}
						
						if($CurrentField['dropdown_option'] == "physical_key"){
							$TempKeyID = @$_POST[$Token];
						}
						
						if(@$TempKeyID && @$TempShareholderID){
						
							// Verify that one or both keys for a given box are being distributed to the same shareholder
							
							if(!can_key_be_distributed_to_shareholder($TempKeyID, $TempShareholderID)){
								add_message('error', $GLOBALS['errorMessage']['both_keys_same_shareholder']);
							}
							
							// Verify that the key can be assigned accordingly
							
							check_key_movement($TempShareholderID, $TempKeyID);
						}						
						
					}elseif($FormID == 34 && preg_match('/^(SHAREHOLDER|NEW_FUNCTION|SITE)$/', $Token)){	// Shareholder Function Change Attestation 
					
						if($Token == "SHAREHOLDER"){
							$TempShareholderID = @$_POST[$Token];
						}
						
						if($Token == "NEW_FUNCTION"){
							$TempFunctionID = @$_POST[$Token];
						}
						
						if($Token == "SITE"){
							$TempSiteID = @$_POST[$Token];
						}
					
						// Verify the shareholder can take on the new "physical key" function
						
						if(@$TempShareholderID && @$TempFunctionID){
							can_shareholder_take_on_physical_key_function($TempShareholderID, $TempFunctionID);
						}
						
						// Verify the shareholder can be assigned to the selected "site"
						
						if(@$TempShareholderID && @$TempSiteID){
							can_shareholder_be_assigned_to_site($TempShareholderID, $TempSiteID);
						}
						
					}elseif($FormID == 29 && preg_match('/^ACCESS_PERSONNEL$/', $Token)){	// Combo Change Attestation
					
						// Verify the shareholder is assigned to the "access" function type
						
						if(lookup_shareholder_function_type($_POST[$Token]) == 1){
							add_message('error', $GLOBALS['errorMessage']['not_access_function_type']);
						}
					
					}elseif($FormID == 32 && preg_match('/^(RECEIVING_SHARE_HOLDER|FUNCTION)$/', $Token)){	// Combo Distribution Attestation
						
						if($Token == "RECEIVING_SHARE_HOLDER"){
							$TempShareholderID = @$_POST[$Token];
						}
						
						if($Token == "FUNCTION"){
							$TempFunctionID = @$_POST[$Token];
						}
					
						// Verify the shareholder can take on the new "access" function

						$ShareholderFunctions = lookup_shareholder_functions($TempShareholderID, TRUE);
						
						if(!in_array($TempFunctionID, $ShareholderFunctions)){	// Ignore the check if the user alredy is assigned to that function						
							if(@$TempShareholderID && @$TempFunctionID){
								can_shareholder_take_on_access_function($TempShareholderID, $TempFunctionID);
							}
						}
						
					}elseif($FormID == 36 && preg_match('/^SHAREHOLDER$/', $Token)){	// Role Change Attestation
											
						// Verify the shareholder does not possess any keys (if currently a Physical Key user)
						
						$CurrentFunctionType = lookup_shareholder_function_type($_POST[$Token]);
						
						if($CurrentFunctionType == 1){
							if(shareholder_box_count($_POST[$Token]) > 0){
								add_message('error', $GLOBALS['errorMessage']['shareholder_still_possesses_key']);
							}
							
						// Verify the shareholder does not know any combos (if currently an Access user)
						
						}elseif($CurrentFunctionType == 2){
							if(count(lookup_shareholder_functions($_POST[$Token], TRUE)) > 0){
								add_message('error', $GLOBALS['errorMessage']['shareholder_knows_combo']);
							}
						}
						
					}elseif($FormID == 48 && preg_match('/^ITEM[0-9]{1,2}.*$/', $Token)){	// HSM Out-of-Band Verification
					
						if($_POST[$Token]){
						
							// Grab the base "item"
							
							preg_match('/^ITEM[0-9]{1,2}/', $Token, $Item);	
							preg_match('/[0-9]{1,2}/', $Token, $ItemNumber);	
							
							// If an item, bag or serial is entered make sure the corresponding values exist
							
							if(preg_match('/^ITEM[0-9]{1,2}$/', $Token)){
								if(!$_POST[$Token . '_SERIAL'] && !@$AlreadyErrored[$Token]['serial']){								
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_serial'], $ItemNumber[0]);
									$AlreadyErrored[$Item[0]]['serial'] = TRUE;		// Prevents duplicate errors for the same item
								}
								if(!$_POST[$Token . '_BAG'] && !@$AlreadyErrored[$Token]['bag']){
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_bag'], $ItemNumber[0]);
									$AlreadyErrored[$Item[0]]['bag'] = TRUE;
								}
							}
							
							if(preg_match('/^ITEM[0-9]{1,2}_SERIAL$/', $Token)){								
								if(!$_POST[$Item[0]] && !@$AlreadyErrored[$Token]['desc']){
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_description'], $ItemNumber[0]);
									$AlreadyErrored[$Item[0]]['desc'] = TRUE;
								}
								if(!$_POST[$Item[0] . '_BAG'] && !@$AlreadyErrored[$Token]['bag']){
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_bag'], $ItemNumber[0]);
									$AlreadyErrored[$Item[0]]['bag'] = TRUE;
								}
							}
							
							if(preg_match('/^ITEM[0-9]{1,2}_BAG$/', $Token)){							
								if(!$_POST[$Item[0]] && !@$AlreadyErrored[$Token]['desc']){
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_description'], $ItemNumber[0]);
									$AlreadyErrored[$Item[0]]['desc'] = TRUE;
								}
								if(!$_POST[$Item[0] . '_SERIAL'] && !@$AlreadyErrored[$Token]['serial']){
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_serial'], $ItemNumber[0]);
									$AlreadyErrored[$Item[0]]['serial'] = TRUE;
								}
							}					
						
						}
					
					}elseif($FormID == 7 && preg_match('/^(ESCROW_SHARE|TAMPER_BAG_SERIAL)$/', $Token)){	// Share Escrow
					
						if($Token == "ESCROW_SHARE"){
							$TempShareID = @$_POST[$Token];
						}
						
						if($Token == "TAMPER_BAG_SERIAL"){
							$TempBagID = @$_POST[$Token];
						}
					
						// Verify that the correct bag was chosen
						
						if(@$TempShareID && @$TempBagID){
							
							$ShareInfo = lookup_share_info($TempShareID);
							
							// If the share is "always bagged" make sure the original bag was selected
							
							if($ShareInfo['always_bagged'] == 1){
								if($ShareInfo['bag_id'] != $TempBagID){
									add_message('error', $GLOBALS['errorMessage']['share_same_bag']);
								}
								
							// If the share is NOT "always bagged" make sure the selected bag is a new bag
							
							}else{							
								if(!can_bag_be_used($TempBagID)){
									add_message('error', $GLOBALS['errorMessage']['bag_already_used']);
								}							
							}
						}
					
					}elseif(preg_match('/^(18|35)$/', $FormID) && preg_match('/^ITEM[0-9]{1,2}.*$/', $Token)){	// HSM Acitvation && HSM Reactivation
					
						if(isset($_POST[$Token])){
						
							// Grab the base "item"
							
							preg_match('/^ITEM[0-9]{1,2}/', $Token, $Item);	
							preg_match('/[0-9]{1,2}/', $Token, $ItemNumber);	
							
							// If an item, bag or serial is entered make sure the corresponding values exist
													
							if(preg_match('/^ITEM[0-9]{1,2}_SHARE_OWNER$/', $Token)){								
								if(!isset($_POST[$Item[0] . '_SHARE_USED'])){
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_share'], $ItemNumber[0]);
								}
							}
							
							if(preg_match('/^ITEM[0-9]{1,2}_SHARE_USED$/', $Token)){							
								if(!isset($_POST[$Item[0] . '_SHARE_OWNER'])){
									message_substitution('error', $GLOBALS['errorMessage']['item_missing_owner'], $ItemNumber[0]);
								}
							}					
						
						}
					}
					
					// Field is a dropdown
					
					if($CurrentField['field_type'] == 'dropdown'){
						${$Token} = validate("int", @$_POST[$Token], strtolower($CurrentField['field_name']), (preg_match('/^ITEM[0-9]{1,2}.*$/', @$Token) ? 0 : 1));	// Not all "item" tokens are required

						// Create a large array of all shareholders that are used for the given form
						
						if(preg_match('/^(shareholder_*.*)$/', strtolower($CurrentField['dropdown_option']))){
							$AllShareholders[] = ${$Token};
							$AllShareholders = array_filter($AllShareholders);	// Remove NULL shareholders; Used with the HSM Activation and Reactivation forms when not all 4 shares are required
						}
						
						// If the form is using a bag, make sure it is usable
						
						if(strtolower($CurrentField['dropdown_option']) == DB_TABLE_TAMPER_EVIDENT_BAGS){	
							
							// Verify that a value is present
							
							if(${$Token}){
							
								// If this is an original used bag ignore it, otherwise, verify that it can be used
							
								if($CurrentField['auto_populate_value'] != "used_bag"){
									if(!can_bag_be_used(${$Token})){
										add_message('error', $GLOBALS['errorMessage']['bag_already_used']);
									}
								}
								
								$UsedBags[] = ${$Token};								
							}
						
						// With this type of bag it does not matter if the bag is used or new, either are valid possibilities
						
						}elseif(strtolower($CurrentField['dropdown_option']) == DB_TABLE_TAMPER_EVIDENT_BAGS . '_all'){
							$UsedBags[] = ${$Token};
						}
					
					// Field is a text box or date
					
					}elseif(preg_match('/^(text|date)$/', $CurrentField['field_type'])){
						${$Token} = validate("regex", @$_POST[$Token], strtolower($CurrentField['field_name']), (preg_match('/^ITEM[0-9]{1,2}.*$/', @$Token) ? 0 : 1), $CurrentField['field_type']);		// Not all "item" tokens are required				
					
					// Field is a text area
					
					}elseif(preg_match('/text_area/', $CurrentField['field_type'])){
						${$Token} = validate("regex", @$_POST[$Token], strtolower($CurrentField['field_name']), 1, "alltext");						
					}								
				}
				
				// Verify shareholder uniqueness				
				
				if(preg_match('/^(18|35)$/', $FormID)){	// HSM Acitvation && HSM Reactivation
				
					// These 2 forms are allowed to have 1 user used twice (the same user can be assigned to an "MofN Share" and a "User Share")
				
					if(count($AllShareholders) != count(array_unique($AllShareholders)) && count($AllShareholders) - 1 != count(array_unique($AllShareholders))){
						add_message('error', $GLOBALS['errorMessage']['unique_shareholders']);
					}					
				
				}else{
				
					// Verify that each shareholder is a unique user
					
					if(count($AllShareholders) != count(array_unique($AllShareholders))){
						add_message('error', $GLOBALS['errorMessage']['unique_shareholders']);
					}
					
				}

				// Some forms have an inner bag and an outer bag, in these cases we have to make sure that the same bag is not selected for both 

				if(@$UsedBags){
				
					if(count($UsedBags) != count(array_unique($UsedBags))){
					
						// Technically the bag has not been used yet, but if it were allowed to continue the bag would be marked as used twice
						
						add_message('error', $GLOBALS['errorMessage']['bag_already_used']);
					}
				}

				// Lookup the "table" used for the given form
						
				$Query = "SELECT form_table FROM " . DB_TABLE_FORMS . " WHERE form_id=" . $FormID;
				$Results = db_query($Query);
				$Row = row_fetch($Results);
				$Table = $Row[0];
					
				// Check for a duplicate filename					
				
				$Query = "SELECT filename FROM " . $Table . " WHERE filename='" . $OutputFilename . "'";
				$Result = db_query($Query);					
				$RowCount = row_count($Result);
		
				if($RowCount > 0){
					add_message('error', $GLOBALS['errorMessage']['duplicate_filename_detected']);
				}	
		
				// If no errors occurred write to the database and generate the .docx
		
				if(check_messages()){
				
					###################################
					##       WRITE TO DATABASE       ##
					###################################
				
					if(begin_db_transaction()){
				
						$Success = TRUE;
					
						// Find each table "field" name for the given form
						
						$Query = "SELECT token_name, dropdown_option, role_id, table_column_name FROM " . DB_TABLE_FORM_LAYOUT . " WHERE form_id=" . $FormID . " AND deleted=0";
						$Result = db_query($Query);					
						$RowCount = row_count($Result);
						
						// The KSR Receipt Attestation form no longer has an activity date field (as of 2015-04-13) so we are going to add one

						if($FormID == 12){
							$FormInfo['activity_date'] = date('Y-m-d');
						}

						// Generate an array of "table_column" => "value"
						
						if($RowCount > 0){
							while($Current = row_fetch_assoc($Result)){
								$Token = str_replace("}}", "", str_replace("{{", "", $Current['token_name']));
								
								if($Current['table_column_name']){								
									$FormInfo[$Current['table_column_name']] = $$Token;
								}elseif(preg_match('/^shareholder_?.*$/', $Current['dropdown_option'])){
									if($$Token){	// Do not insert entires without a shareholder ID; Condition should only exist with HSM Activation and Reactivation forms when not all shares are being used
										$RoleInfo[] = array("role_id" => $Current['role_id'], "shareholder_id" => $$Token);
									}
								}elseif(preg_match('/^ITEM[0-9]{1,2}.*$/', $Token)){
									$AllItems[$Token] = $$Token;
								}
							}
														
							$FormInfo['filename']     = $OutputFilename;
							$FormInfo['status_id']    = 1;
							$FormInfo['date_created'] = "NOW()";
							$FormInfo['date_updated'] = "NOW()";
							$FormInfo['created_by']   = $UserID;
							$FormInfo['deleted']      = 0;						
						}

						// Write FormInfo to the appropriate form table
						
						if(!db_query(create_sql_insert($FormInfo, $Table))){ $Success = FALSE; }
						$InsertID = last_query_id();					
							
						// Write RoleInfo to the "form_roles"
						
						foreach($RoleInfo as $Roles){
						
							// Append a few values to the Roles array
							
							$Roles['form_id']      = $FormID;
							$Roles['execution_id'] = $InsertID;
							
							if(!db_query(create_sql_insert($Roles, DB_TABLE_FORM_ROLES))){ $Success = FALSE; }
						}						
						
						###################################
						##        DOCX GENERATION        ##
						###################################

						if($Success){
						
							// Find all fields that are dropdown menus
						
							$Query = "SELECT * FROM " . DB_TABLE_FORM_LAYOUT . " WHERE form_id='" . $FormID . "' AND field_type='dropdown' AND deleted=0";
							$Result = db_query($Query);
							$RowCount = row_count($Result);
							
							if($RowCount > 0){
								while($Current = row_fetch_assoc($Result)){
									$Values[$Current['token_name']] = $Current['dropdown_option'];
								}
							}	
											
							// Load the XML file into a variable
											
							$Contents = file_get_contents($XMLFile);

                                                        // CBO-TOO2 2.0 Remove the Digital Signature tokens when the new form is downloaded
                                                        $Contents = preg_replace('/\{\{IGNORE_SIG(.*?)\}\}/', '', $Contents);
							
							// Replace form tokens with submitted values
							
							foreach($_POST as $Token => $Value){	

								// If the token is based off of a dropdown menu, then lookup the actual value
								
								if(@$Values["{{" . $Token . "}}"]){
									$Value = find_dropdown_value($Values["{{" . $Token . "}}"], $Value);
								}
							
								// Perfrom the token replacement
								
								if(!preg_match('/^ITEM[0-9]{1,2}.*$/', $Token) || (preg_match('/^ITEM[0-9]{1,2}.*$/', $Token) && preg_match('/^(18|35)$/', $FormID))){	// "ITEM" tokens will be replaced below unless it is an HSM Activation or Reactivation form, then we will do it here
									$Contents = str_replace("{{" . $Token . "}}", htmlspecialchars($Value), $Contents);								
								}
							}													
							
							// Form specific token replacements 
							
							if($FormID == 10){	// "Safe Deposit Box Audit"
								$Query  = "SELECT share_label, media_type_name, s.share_id FROM " . DB_TABLE_SHARES . " s LEFT JOIN " . DB_TABLE_MEDIA_TYPES . " m ON m.media_type_id=s.media_type_id WHERE box_id=" . clean_sql_value($_POST[preg_replace('/\{|\}/', '', array_search('box', $Values))]) . " ORDER BY media_type_name, share_label";
								$Result = db_query($Query);
								
								// Insert each of the shares into the audit section within the docx form
								
								$Count = 1;
								
								while($Current = row_fetch_assoc($Result)){
									$Contents = str_replace("{{IGNORE_NAME" . $Count . "}}", htmlspecialchars($Current['share_label']), $Contents);
									$Contents = str_replace("{{IGNORE_MEDIA" . $Count . "}}", htmlspecialchars($Current['media_type_name']), $Contents);
									
									// Insert records into the database
									
									if(!db_query(create_sql_insert(array("execution_id" => $InsertID, "share_id" => $Current['share_id']), DB_TABLE_FORM_SAFE_DEPOSIT_BOX_AUDIT_CONTENTS))){ $Success = FALSE; }
									
									$Count++;
								}
								
								// Remove the remaining "IGNORE" tokens
								
								$Contents = preg_replace("/\{\{([^\}]+)\}\}/", "", $Contents);
								
							}elseif($FormID == 37 || $FormID == 19){	// "HSM Courier" & "Equipment Courier"
							
								// Write each item to the database and replace the token in the DOCX
								
								$Count = 1;
								
								foreach(array_unique(array_filter($AllItems)) as $Item){

									// Lookup HSM info
									
									if($Info = lookup_equipment_info($Item)){									
										$ItemInfo['execution_id']  = $InsertID;
										$ItemInfo['equipment_id']  = $Item;
										$ItemInfo['label_name']    = $Info['label_name'];
										$ItemInfo['tamper_bag_id'] = $Info['bag_id'];
								
										// Insert record into the database
									
										if(!db_query(create_sql_insert($ItemInfo, ($FormID == 37 ? DB_TABLE_FORM_HSM_COURIER_ITEMS : DB_TABLE_FORM_EQUIP_COURIER_ITEMS)))){ $Success = FALSE; }

										// Replace the tokens
										
										$Contents = str_replace("{{IGNORE_LABEL" . $Count . "}}", htmlspecialchars($Info['label_name']), $Contents);
										$Contents = str_replace("{{ITEM" . $Count . "}}", htmlspecialchars($Info['serial_number']), $Contents);
										$Contents = str_replace("{{IGNORE_BAG" . $Count . "}}", htmlspecialchars(lookup_tamper_evident_bag($Info['bag_id'])), $Contents);										
									
										$Count++;									
									}
							
								}
								
								// Remove the remaining "ITEM" tokens
								
								$Contents = preg_replace("/\{\{([^\}]+)\}\}/", "", $Contents);
								
							}elseif($FormID == 16){	// "Physical Key Courier"
							
								// Write each item to the database and replace the token in the DOCX
								
								$Count = 1;
								
								foreach(array_unique(array_filter($AllItems)) as $Item){

									// Lookup HSM info
									
									if($Info = lookup_physical_key_info($Item)){									
										$ItemInfo['execution_id']    = $InsertID;
										$ItemInfo['physical_key_id'] = $Item;
										$ItemInfo['serial_number']   = $Info['serial_number'];
										$ItemInfo['tamper_bag_id']   = $Info['bag_id'];
								
										// Insert record into the database
									
										if(!db_query(create_sql_insert($ItemInfo, DB_TABLE_FORM_KEY_COURIER_ITEMS))){ $Success = FALSE; }

										// Replace the tokens
																				
										$Contents = str_replace("{{ITEM" . $Count . "}}", htmlspecialchars($Info['label']), $Contents);
										$Contents = str_replace("{{IGNORE_BAG" . $Count . "}}", htmlspecialchars(lookup_tamper_evident_bag($Info['bag_id'])), $Contents);										
										$Contents = str_replace("{{IGNORE_SERIAL" . $Count . "}}", htmlspecialchars($Info['serial_number']), $Contents);										

										$Count++;									
									}
							
								}
								
								// Remove the remaining "ITEM" tokens
								
								$Contents = preg_replace("/\{\{([^\}]+)\}\}/", "", $Contents);
								
							}elseif($FormID == 22){	// "Share Courier"
							
								// Write each item to the database and replace the token in the DOCX
								
								$Count = 1;
								
								foreach(array_unique(array_filter($AllItems)) as $Item){

									// Lookup HSM info
									
									if($Info = lookup_share_info($Item)){									
										$ItemInfo['execution_id']  = $InsertID;
										$ItemInfo['share_id']      = $Item;
										$ItemInfo['serial_number'] = $Info['serial_number'];
										$ItemInfo['tamper_bag_id'] = $Info['bag_id'];
								
										// Insert record into the database
									
										if(!db_query(create_sql_insert($ItemInfo, DB_TABLE_FORM_SHARE_COURIER_ITEMS))){ $Success = FALSE; }

										// Replace the tokens
																				
										$Contents = str_replace("{{ITEM" . $Count . "}}", htmlspecialchars($Info['share_label']), $Contents);
										$Contents = str_replace("{{IGNORE_BAG" . $Count . "}}", htmlspecialchars(lookup_tamper_evident_bag($Info['bag_id'])), $Contents);										
										$Contents = str_replace("{{IGNORE_SERIAL" . $Count . "}}", htmlspecialchars($Info['serial_number']), $Contents);										
									
										$Count++;									
									}
							
								}
								
								// Remove the remaining "ITEM" tokens
								
								$Contents = preg_replace("/\{\{([^\}]+)\}\}/", "", $Contents);
								
							}elseif($FormID == 48){	// "HSM Out-of-Band Verification"
							
								// Write each item to the database and replace the token in the DOCX
								
								$Count = 1;
								
								foreach(array_unique(array_filter($AllItems)) as $Key => $Value){

									// Only process the "ITEM"s
									
									if(preg_match('/^ITEM[0-9]{1,2}$/', $Key)){
									
										$ItemInfo['execution_id']      = $InsertID;
										$ItemInfo['item_description']  = $Value;
										$ItemInfo['serial_number']     = $AllItems[$Key . '_SERIAL'];
										$ItemInfo['tamper_bag_number'] = $AllItems[$Key . '_BAG'];
								
										// Insert record into the database
									
										if(!db_query(create_sql_insert($ItemInfo, DB_TABLE_FORM_HSM_OUT_OF_BAND_ITEMS))){ $Success = FALSE; }

										// Replace the tokens
																				
										$Contents = str_replace("{{ITEM" . $Count . "}}", htmlspecialchars($Value), $Contents);
										$Contents = str_replace("{{ITEM" . $Count . "_BAG}}", htmlspecialchars($AllItems[$Key . '_BAG']), $Contents);										
										$Contents = str_replace("{{ITEM" . $Count . "_SERIAL}}", htmlspecialchars($AllItems[$Key . '_SERIAL']), $Contents);										

										$Count++;		
									
									}
							
								}							
							
								// Remove the remaining "ITEM" tokens
								
								$Contents = preg_replace("/\{\{([^\}]+)\}\}/", "", $Contents);
							
							}elseif($FormID == 18 || $FormID == 35){	// "HSM Activation" &&	"HSM Reactivation"
							
								// Remove the remaining "ITEM" tokens
								
								$Contents = preg_replace("/\{\{([^\}]+)\}\}/", "N/A", $Contents);
								
							}
							
							// Remove the old XML file
							
							unlink($XMLFile);							
							
							// Write the new XML file
							
							file_put_contents($XMLFile, $Contents);
														
							// Insert the timestamp (and filename) into the footer (Word is goofy and sometimes has multiple footer files and the token could be in any one of them, so try all of them)
							
							foreach(glob($TempDirectory . "/word/footer*.xml") as $XMLFileFooter){
							//	$Footer = str_replace("{{IGNORE_TIMESTAMP}}", basename($Filename, ".docx") . "_" . $Timestamp, file_get_contents($XMLFileFooter));								
                                                                $Footer = str_replace("{{IGNORE_TIMESTAMP}}", $OutputFilename, file_get_contents($XMLFileFooter));

                                                                #$Footer = preg_replace('/\{\{IGNORE_SIG(.*?)\}\}/', '', file_get_contents($XMLFileFooter));
								unlink($XMLFileFooter);
								file_put_contents($XMLFileFooter, $Footer);
							}

							// Rezip everything
							
							if(zip_docx($OutputFilename)){	
								commit_db_transaction();
								add_message('success', "Download the form by clicking <a class='download' href='" . PATH_FORMS_COMPLETED . "/" . $OutputFilename . "'><img style='vertical-align: middle;' src='" . PATH_IMAGES . "/document-green.png'> here</a>.");								
							}else{
								rollback_db_transaction();
								add_message('error', $GLOBALS['errorMessage']['failed_to_generate_form']);
							}
					
						}else{							
							rollback_db_transaction();
							add_message('error', $GLOBALS['errorMessage']['db_write_failure_multiple']);							
						}
						
					}else{
						add_message('error', $GLOBALS['errorMessage']['db_unable_to_begin_transaction']);
					}
					
				}
				
			}else{	
				add_message('error', "There are $TotalTokens tokens found in the file but only $TokensSubmitted fields where submitted.");
			}
			
			// Cleanup the docx temp files
			
			recursive_remove_directory($TempDirectory, TRUE);
			
		}else{
			add_message('error', $GLOBALS['errorMessage']['from_doesnt_exist']);	// Could also mean we were unable to decompress it (check file permissions)
		}
	
	############################
	##    DISPLAY THE FORM    ##
	############################
	
	}elseif(@$_REQUEST['form_id']){
		
		$FormID   = validate("int", @$_GET['form_id'], "form ID", 1);
				
		// Load the form data (if avaliable)
		
		$Query = "SELECT l.*, f.instructions FROM " . DB_TABLE_FORM_LAYOUT . " l LEFT JOIN " . DB_TABLE_FORMS . " f ON f.form_id=l.form_id WHERE l.form_id='" . $FormID . "' AND l.deleted=0 ORDER BY FIELD(field_type, 'text_area', 'text', 'dropdown', 'date') DESC, FIELD(dropdown_option, 'shareholder_cbo', 'shareholder_not_sysadmin', 'shareholder_physical_key', 'shareholder_access', 'shareholder', 'tamper_evident_bag', 'tamper_evident_bag_all', 'product', 'escrow_location_traka', 'escrow_location_not_traka', 'escrow_location', 'location', 'site', 'box', 'password', 'share_escrowed', 'share_distributed', 'share', 'equipment_non_escrowed', 'equipment_escrowed', 'equipment', 'equipment_hsm_non_escrowed', 'equipment_hsm_escrowed', 'equipment_hsm', 'physical_key_traka_distributed', 'physical_key_traka_escrowed', 'physical_key_escrowed', 'physical_key_distributed', 'physical_key') DESC, dropdown_option, field_name";
		$Result = db_query($Query);
		$RowCount = row_count($Result);
		
		if($RowCount > 0){
			while($Current = row_fetch_assoc($Result)){
				$Values[$Current['token_name']] = array("field_name" => $Current['field_name'], "field_type" => $Current['field_type'], "dropdown_option" => $Current['dropdown_option'], "table_column_name" => $Current['table_column_name'], "auto_populate_trigger" => $Current['auto_populate_trigger'], "auto_populate_value" => $Current['auto_populate_value'], "instructions" => $Current['instructions']);
			}

			// Figure out which fields trigger changes and map them to the destination field
			
			foreach($Values as $ID => $Current){
				if($Current['auto_populate_trigger'] && $Current['auto_populate_value']){
					$AutoPopulateTriggers[$Current['auto_populate_trigger']] = array("trigger" => $Current['auto_populate_trigger']);					
					$AutoPopulateValues[str_replace("}}", "", str_replace("{{", "", $ID))] = array("value" => $Current['auto_populate_value'], "trigger" => $Current['auto_populate_trigger']);
				}
			}
			
			// Create empty arrays if now auto-populating will be taking place
			
			if(!@$AutoPopulateTriggers){ $AutoPopulateTriggers = array(); }
			if(!@$AutoPopulateValues){ $AutoPopulateValues = array(); }
				
			// If at least one token was found, generate the form
			
			if(array_filter(@$Values)){
			
				// Display the form
				
				form_start(array("action" => $_SERVER['PHP_SELF'], 'name' => 'new_form'));

					foreach($Values as $Token => $CurrentField){
					
						$Token = str_replace("}}", "", str_replace("{{", "", $Token));
						
						if($CurrentField['field_type'] == "date"){
							
							$DatePicker = form_date_time(array("title" => $CurrentField['field_name'], "name" => $Token, "value" => NULL, "date_only" => TRUE, "css" => "autocomplete='off' class='datepicker'"));
							echo $DatePicker;
						
						}elseif($CurrentField['field_type'] == "text"){	// Text fields can only be auto-populated via a dropdown; they cannot trigger an auto-population

							form_text_field(array("title" => $CurrentField['field_name'], "name" => $Token, "value" => NULL, "size" => 40, "javascript" => (array_key_exists($Token, @$AutoPopulateValues) ? "data-auto-populate-value='" . $AutoPopulateValues[$Token]['value'] . "' my_trigger_is='" . $AutoPopulateValues[$Token]['trigger'] . "'" : NULL) ));
					
						}elseif($CurrentField['field_type'] == "dropdown"){	// Dropdowns can be auto-populated as well as be a trigger for auto-population
						
							form_dropdown(array("title" => $CurrentField['field_name'], "name" => $Token, "value" => NULL, "multiselect" => TRUE, "items" => lookup_dropdown_menu($CurrentField['dropdown_option'], $CurrentField['auto_populate_value']), "javascript" => (array_key_exists($Token, @$AutoPopulateTriggers) ? "data-lookup-values-for='" . $CurrentField['dropdown_option'] . "'" : NULL) . " " . (array_key_exists($Token, @$AutoPopulateValues) ? "data-auto-populate-value='" . $AutoPopulateValues[$Token]['value'] . "' my_trigger_is='" . $AutoPopulateValues[$Token]['trigger'] . "'" : NULL), "css" => "class='dropdown'", "select_opt" => FALSE));

						}elseif($CurrentField['field_type'] == "text_area"){

							form_text_area(array("title" => $CurrentField['field_name'], "name" => $Token, "value" => NULL, "cols" => 35));

						}
					
					}
				
					form_hidden(array("value" => $FormID, "name" => 'form_id'));
					form_break();
					form_submit(array("value" => "Submit"));
				form_end();	
			
				if($CurrentField['instructions']){				
					echo "<div id='instructions'>";
						echo "<img src='" . PATH_IMAGES . "/document.png'>";
						echo "<strong>INSTRUCTIONS</strong>: " . nl2br($CurrentField['instructions']);
					echo "</div>";
				}
			}
		
		}else{
			add_message('error', $GLOBALS['errorMessage']['form_not_configured']);	
		}
		
	}else{	
		add_message('error', $GLOBALS['errorMessage']['cant_detect_form']);		
	}
	
	// Display any messages
	
	if(!check_messages()){
		echo "<div class='inner_messages'>\n";
			print_messages();
		echo "</div>\n";		
	}
	
	db_close();
		
?>
