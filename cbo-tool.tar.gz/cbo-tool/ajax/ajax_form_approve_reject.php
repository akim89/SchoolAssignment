<?php

	require_once("../includes.php");
	db_connect();

	############################
	##    PROCESS THE FORM    ##
	############################

	$UserID    = validate("int", $_COOKIE['user_id'], "user ID", 1, NULL, $GLOBALS['errorMessage']['cookie_no_detect_user']);
	$RowInfo   = preg_split('/--/', $_POST['id']);
	$TableName = validate("regex", $RowInfo[0], "form name", 1, "short");
	$ID        = validate("int", $RowInfo[1], "row ID", 1);
	$Action    = validate("regex", $_POST['submit'], "action", 1, "decision");

	if(check_messages()){

		// Determine if the Form is in Pending Status or Not
		$Query = "SELECT status_id FROM " . $TableName . " WHERE id=$ID";
		$Result = db_query($Query);
		$Row = row_fetch($Result);
		$StatusID = $Row[0];

		// If the Form is Not in Pending Status Any Longer, Throw an Error
		if($StatusID != 1){
			add_message('error', $GLOBALS['errorMessage']['form_not_pending']);
		}else{

			// Prevent the creator from approving/rejecting the form

			$Query = "SELECT created_by FROM " . $TableName . " WHERE id=$ID";
			$Result = db_query($Query);
			$Row = row_fetch($Result);
			$CreatedByID = $Row[0];

			if($CreatedByID == $UserID && $Action == "Approve"){
				add_message('error', $GLOBALS['errorMessage']['creator_cannot_approve']);
			}else{

				$Success = TRUE;

				if(begin_db_transaction()){

					// Mark the form as approved or denied

					if($Action == "Approve"){
						$Info['status_id']   = 2;
						$Info['approved_by'] = $UserID;
					}elseif($Action == "Reject"){
						$Info['status_id']   = 3;
						$Info['rejected_by'] = $UserID;
					}

					$Info['decision_date'] = "NOW()";
					$Info['updated_by']    = $UserID;

					$Where['id'] = $ID;

					if(!db_query(create_sql_update($Info, $Where, $TableName))){ $Success = FALSE; }

					// If approved, mark bag as "used" and update the tables

					if($Action == "Approve"){

						// Find the bags associated with this form

						$Query  = "SELECT l.table_column_name FROM " . DB_TABLE_FORM_LAYOUT . " l LEFT JOIN " . DB_TABLE_FORMS . " f ON f.form_id=l.form_id WHERE (dropdown_option='tamper_evident_bag' OR dropdown_option='tamper_evident_bag_all') AND l.deleted=0 AND f.deleted=0 AND form_table='$TableName' AND (auto_populate_value IS NULL OR auto_populate_value != 'used_bag')";
						$Result = db_query($Query);
						$Count  = row_count($Result);

						if($Count > 0){

							while($Current = row_fetch_assoc($Result)){
								$TableColumns[] = $Current['table_column_name'];
							}

							// Grab the IDs of all bags from all tables that have a form in "pending" status

							if(@$TableColumns){
								foreach($TableColumns as $Column){
									$Query = "SELECT " . $Column . " FROM " . $TableName . " f LEFT JOIN " . DB_TABLE_TAMPER_EVIDENT_BAGS . " b ON b.bag_id=f." . $Column . " WHERE f.deleted=0 AND id=$ID";

									$Result = db_query($Query);
									$Count = row_count($Result);

									if($Count > 0){
										while($Current = row_fetch($Result)){
											$BagIDs[] = $Current[0];
										}
									}
								}
							}

							// Mark each bag as used

							if(@$BagIDs){

								foreach($BagIDs as $BagID){
									$BagInfo['used']    = 1;
									$BagWhere['bag_id'] = $BagID;

									if(!db_query(create_sql_update($BagInfo, $BagWhere, DB_TABLE_TAMPER_EVIDENT_BAGS))){ $Success = FALSE; }
								}

							}

						}

						##################################
						## UPDATE BASE AND AUDIT TABLES ##
						##################################

						// Set a few variables that will be used with each form

						$FormInfo['updated_by']   = $UserID;
						$FormInfo['date_updated'] = "NOW()";

						if($TableName == DB_TABLE_FORM_EQUIP_COURIER || $TableName == DB_TABLE_FORM_HSM_COURIER){	// Equipment/HSM should already be in escrow, and therfore is in a bag

							// Lookup some data

							$Query  = "SELECT outer_tamper_bag_id, escrow_location_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Mark the outer bag as "opened"

							if(!mark_bag_as_opened($Row[0])){ $Success = FALSE; }

							// Grab each piece of equipment

							$Query  = "SELECT equipment_id, tamper_bag_id FROM " . $TableName . "_items" . " WHERE execution_id=" . $ID;
							$Result = db_query($Query);

							// Loop through each piece of equipment

							while($Equipment = row_fetch($Result)){

								// Make sure the equpment is in escrow

								if(!is_equipment_in_escrow($Equipment[0])){
									add_message('error', $GLOBALS['errorMessage']['equipment_not_in_escrow']);
								}

								// Check to see if the status is set to "offline"

								if(equipment_status($Equipment[0]) != "Offline"){
									add_message('error', $GLOBALS['errorMessage']['equipment_not_offline']);
								}

								// Update the escrow location for the equipment

								$FormInfo['escrow_location_id'] = $Row[1];
								$FormWhere['equipment_id']      = $Equipment[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

								// Add an entry to the equipment audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

								if(!create_audit_entry(DB_TABLE_EQUIP, $Equipment[0], $UserID, $AuditInfo)){ $Success = FALSE; }
							}

						}elseif($TableName == DB_TABLE_FORM_EQUIP_ESCROW || $TableName == DB_TABLE_FORM_HSM_ESCROW){

							// Lookup some data

							$Query  = "SELECT equipment_id, tamper_bag_id,  escrow_location_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the equpment is NOT currently in escrow

							if(!is_equipment_not_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['equipment_in_escrow']);
							}

							// Check to see if the status is set to "offline"

							if(equipment_status($Row[0]) != "Offline"){
								add_message('error', $GLOBALS['errorMessage']['equipment_not_offline']);
							}

							// Verify the "rack location" is blank

							$Info = lookup_equipment_info($Row[0]);
							if($Info['rack_location']){
								add_message('error', $GLOBALS['errorMessage']['equipment_is_racked']);
							}

							// Move the equipment into a bag and then place it into an escrow location (bag was marked as "sealed" at top of script)

							$FormInfo['bag_id']             = $Row[1];
							$FormInfo['escrow_location_id'] = $Row[2];
							$FormWhere['equipment_id']      = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_EQUIP_REBAG || $TableName == DB_TABLE_FORM_HSM_REBAG){	// Eqiupment/HSM should be in escrow prior to rebag

							// Lookup some data

							$Query  = "SELECT equipment_id, new_tamper_bag_id, original_tamper_bag_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the equpment is in escrow

							if(!is_equipment_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['equipment_not_in_escrow']);
							}

							// Check to see if the status is set to "offline"

							if(equipment_status($Row[0]) != "Offline"){
								add_message('error', $GLOBALS['errorMessage']['equipment_not_offline']);
							}

							// Place the equipment into the new bag (the new bag was marked as "sealed" at top of script)

							$FormInfo['bag_id']        = $Row[1];
							$FormWhere['equipment_id'] = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Mark the original bag as "opened"

							if(!mark_bag_as_opened($Row[2])){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_EQUIP_OUT_OF_BAND){

							// No database updates required

						}elseif($TableName == DB_TABLE_FORM_HSM_ACCEPTANCE_TEST){

							// Lookup some data

							$Query  = "SELECT equipment_id, activity_date  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Mark the equipment as acceptance tested

							$FormInfo['date_acceptance_tested'] = $Row[1];
							$FormInfo['is_acceptance_tested']   = 1;
							$FormWhere['equipment_id']          = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_HSM_ACTIVATION){

							// Lookup some data

							$Query  = "SELECT equipment_id, activity_date, location FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Check to see if this device has been activated already and grab the bag ID

							$Query = "SELECT date_online, bag_id FROM " . DB_TABLE_EQUIP . " WHERE equipment_id='" . $Row[0] . "'";
							$Result = db_query($Query);
							$Data = row_fetch($Result);

							if($Data[0]){
								add_message('error', $GLOBALS['errorMessage']['hsm_already_activated']);
							}else{

								// Mark the bag as "opened"

								if(!mark_bag_as_opened($Data[1])){ $Success = FALSE; }

								// Mark the equipment as activated

								$FormInfo['rack_location']      = $Row[2];
								$FormInfo['date_online']        = $Row[1];
								$FormInfo['escrow_location_id'] = NULL;
								$FormInfo['bag_id']             = NULL;
								$FormInfo['status']             = "Online";
								$FormWhere['equipment_id']      = $Row[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

								// Add an entry to the equipment audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

								if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }
							}

						}elseif($TableName == DB_TABLE_FORM_HSM_DEACTIVATION){

							// Lookup some data

							$Query  = "SELECT equipment_id, activity_date  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the equpment is NOT currently in escrow

							if(is_equipment_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['equipment_in_escrow']);
							}

							// Verify the "rack location" is not blank

							$Info = lookup_equipment_info($Row[0]);
							if(!$Info['rack_location']){
								add_message('error', $GLOBALS['errorMessage']['equipment_is_not_racked']);
							}

							// Mark the equipment as de-activated

							$FormInfo['date_offline']  = $Row[1];
							$FormInfo['rack_location'] = NULL;
							$FormInfo['status']        = "Offline";
							$FormWhere['equipment_id'] = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_HSM_DESTRUCTION){

							// Lookup some data

							$Query  = "SELECT equipment_id, activity_date, inner_tamper_bag_id, outer_tamper_bag_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Verify that the device is offline

							if(equipment_status($Row[0]) !== "Offline"){
								add_message('error', $GLOBALS['errorMessage']['hsm_offline_before_destruction']);
							}

							// Make sure the equpment IS currently in escrow

							if(!is_equipment_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['equipment_not_in_escrow']);
							}

							// Verify the "rack location" is blank

							$Info = lookup_equipment_info($Row[0]);
							if($Info['rack_location']){
								add_message('error', $GLOBALS['errorMessage']['equipment_is_racked']);
							}

							// Mark the bags as "opened"

							if(!mark_bag_as_opened($Row[2])){ $Success = FALSE; }
							if(!mark_bag_as_opened($Row[3])){ $Success = FALSE; }

							// Mark the equipment as de-activated

							$FormInfo['date_destroyed']  = $Row[1];
							$FormInfo['status']          = "Destroyed";
							$FormWhere['equipment_id']   = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_HSM_OUT_OF_BAND){

							// Lookup # of assets in HSM Out-Of-Band Verification Attestation Items
							
							$AssetQuery  ="SELECT item_description, serial_number, tamper_bag_number FROM form_hsm_out_of_band_verification_attestation_items WHERE execution_id=" . $ID;
							$AssetResult = db_query($AssetQuery);
							
							//Ensure there is at least one HSM that is being inserted
							
							$NumItems = row_count($AssetResult);
							
							if($NumItems < 1){
								add_message('error', "No Item Available to Insert");
							}
							else{
								// Lookup some data in HSM Out-Of-Band Verification Attestation
									
								$Query  = "SELECT activity_date, vendor_id, po_number, date_shipped, model_type_id, equipment_version_id, escrow_location_id, environment_id, product_id, firmware_version  FROM " . $TableName . " WHERE id=" . $ID;
								$Result = db_query($Query);
								$Row    = row_fetch($Result);
								
								//Find the corresponding model type name based on its model id
								
								$ModelQuery = "SELECT model_type_name FROM model_type WHERE model_type_id=" . $Row[4];
								$ModelResult = db_query($ModelQuery);
								$ModelRow = row_fetch($ModelResult);
								
								//Find the corresponding vendor name based on its vendor id
								
								$VendorQuery = "SELECT vendor_name FROM vendor WHERE vendor_id=" . $Row[1];
								$VendorResult = db_query($VendorQuery);
								$VendorRow = row_fetch($VendorResult);
								
								//Insert each HSM to equipment table
								
								for ($i= 0; $i < $NumItems; $i++){
									
									$AssetRow = row_fetch($AssetResult);
									
									$HSMInfo['equipment_type_id'] = 3;
									$HSMInfo['vendor_id'] = $Row[1];
									$HSMInfo['serial_number'] = $AssetRow[1];
									$HSMInfo['asset_tag_number'] = "Not Assigned";
									$HSMInfo['description'] = "{$VendorRow[0]} {$ModelRow[0]}";
									$HSMInfo['model_number'] = $ModelRow[0];
									$HSMInfo['model_type_id'] = $Row[4];
									$HSMInfo['equipment_version_id'] = $Row[5];
									$HSMInfo['firmware_version'] = $Row[9];
									$HSMInfo['purchase_order_number'] = $Row[2];
									$HSMInfo['escrow_location_id'] = $Row[6];
									$HSMInfo['product_id'] = $Row[8];
									$HSMInfo['environment_id'] = $Row[7];
									$HSMInfo['label_name'] = $AssetRow[0];
									$HSMInfo['status'] = 'Offline';
									$HSMInfo['date_offline'] = $Row[0];
									$HSMInfo['date_shipped'] = $Row[3];
									$HSMInfo['created_by'] = $UserID;
									
									//Add new TEB to TEB table
									
									$TEBInfo['bag_serial'] = $AssetRow[2];
									if(!db_query(create_sql_insert($TEBInfo, DB_TABLE_TAMPER_EVIDENT_BAGS))){ $Success = FALSE; }
									$TEBQuery = "SELECT bag_id FROM tamper_evident_bag ORDER BY bag_id DESC LIMIT 1";
									$TEBResult = db_query($TEBQuery);
									$TEBRow = row_fetch($TEBResult);
									$HSMInfo['bag_id'] = $TEBRow[0];
									
									//Check to see if it is assigned for PROD
									
									if ($Row[7] == lookup_db_value(environment_name, environment_id, PROD, environment)){
										$HSMInfo['is_production_capable'] = 1;
									}
									else{
										$HSMInfo['is_production_capable'] = 0;
									}
									
									//Insert into both equipment and audit equipment table
									
									if(!db_query(create_sql_insert($HSMInfo, DB_TABLE_EQUIP))){ $Success = FALSE; }
									if(!db_query(create_sql_insert($HSMInfo, DB_TABLE_AUDIT_EQUIP))){ $Success = FALSE; }
										
								}
								
								//Update audit equipment table with additional data
								
								$EquipQuery = "SELECT equipment_id, serial_number, description FROM equipment ORDER BY equipment_id DESC LIMIT 3";
								$EquipResult = db_query($EquipQuery);
								
								for ($i=0; $i < $NumItems; $i++){
									
									$EquipRow = row_fetch($EquipResult);
									$AuditData['audit_created_by'] = $UserID;
									$AuditData['equipment_id'] = $EquipRow[0];
									$AuditLocation['serial_number'] = $EquipRow[1];
									
									if(!db_query(create_sql_update($AuditData, $AuditLocation, DB_TABLE_AUDIT_EQUIP))){ $Success = FALSE; }
								}
							}

						}elseif($TableName == DB_TABLE_FORM_HSM_REACTIVATION){

							// Lookup some data

							$Query  = "SELECT equipment_id, activity_date, location  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Check to see if this device has had its initial activation

							$Query = "SELECT date_online FROM " . DB_TABLE_EQUIP . " WHERE equipment_id='" . $Row[0] . "'";
							$Result = db_query($Query);
							$Data = row_fetch($Result);

							if(!$Data[0]){
								add_message('error', $GLOBALS['errorMessage']['hsm_never_activated']);
							}

							// Verify that the device is offline
							// Removed check on 2015-04-13 per requst of Thomas Jordan

							// if(equipment_status($Row[0]) != "Offline"){
								// add_message('error', $GLOBALS['errorMessage']['equipment_not_offline']);
							// }

							// Create a restart entry

							$RestartInfo['equipment_id']   = $Row[0];
							$RestartInfo['date_restarted'] = $Row[1];
							$RestartInfo['execution_id']   = $ID;
							$RestartInfo['form_id']        = lookup_from_id_from_table_name($TableName);
							$RestartInfo['created_by']     = $UserID;

							if(!db_query(create_sql_insert($RestartInfo, DB_TABLE_EQUIP_RESTARTS))){ $Success = FALSE; }

							// Update the equipment

							$FormInfo['status']        = 'Online';
							$FormInfo['rack_location'] = $Row[2];
							$FormWhere['equipment_id'] = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_HSM_RELABEL){

							// Lookup some data

							$Query  = "SELECT equipment_id, new_label  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Update the equipments label

							$FormInfo['label_name']    = $Row[1];
							$FormWhere['equipment_id'] = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_HSM_RELOCATION || $TableName == DB_TABLE_FORM_EQUIP_RELOCATION){	// Equipment must be in escrow

							// Lookup some data

							$Query  = "SELECT equipment_id, transferred_to_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the equipment is in escrow

							if(!is_equipment_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['equipment_not_in_escrow']);
							}

							// Check to see if the status is set to "offline"

							if(equipment_status($Row[0]) != "Offline"){
								add_message('error', $GLOBALS['errorMessage']['equipment_not_offline']);
							}

							// Verify the "rack location" is blank

							$Info = lookup_equipment_info($Row[0]);
							if($Info['rack_location']){
								add_message('error', $GLOBALS['errorMessage']['equipment_is_racked']);
							}

							// Update the equipments location

							$FormInfo['escrow_location_id'] = $Row[1];
							$FormWhere['equipment_id']      = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_EQUIP))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_EQUIP, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_KSR_RECEIPT){

							// No database updates required

						}elseif($TableName == DB_TABLE_FORM_KEY_COURIER){	// Key should already be in escrow prior to courier

							// Look up some data

							$Query  = "SELECT outer_tamper_bag_id, escrow_location_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Mark the outer bag as "opened"

							if(!mark_bag_as_opened($Row[0])){ $Success = FALSE; }

							// Grab each key

							$Query  = "SELECT physical_key_id, tamper_bag_id FROM " . $TableName . "_items" . " WHERE execution_id=" . $ID;
							$Result = db_query($Query);

							// Loop through each key

							while($Key = row_fetch($Result)){

								// Make sure the physical key is in escrow

								if(!is_key_in_escrow($Key[0])){
									add_message('error', $GLOBALS['errorMessage']['key_not_in_escrow']);
								}

								// Update the escrow location for the key

								$FormInfo['escrow_location_id'] = $Row[1];
								$FormWhere['physical_key_id']   = $Key[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_KEYS))){ $Success = FALSE; }

								// Add an entry to the key audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

								if(!create_audit_entry(DB_TABLE_KEYS, $Key[0], $UserID, $AuditInfo)){ $Success = FALSE; }

							}

						}elseif($TableName == DB_TABLE_FORM_KEY_DISTRIBUTION){	// Key should be in escorw prior to distribution

							// Find some information about the key

							$Query  = "SELECT physical_key_id, tamper_bag_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the physical key is in escrow

							if(!is_key_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['key_not_in_escrow']);
							}

							// Mark the original bag as "opened"

							if(!mark_bag_as_opened($Row[1])){ $Success = FALSE; }

							// Lookup the receiving shareholder

							$Query = "SELECT shareholder_id FROM " . DB_TABLE_FORM_ROLES . " WHERE form_id='" . lookup_from_id_from_table_name($TableName) . "' AND execution_id=$ID AND role_id=7";
							$Result = db_query($Query);
							$Shareholder = row_fetch($Result);

							// Verify that one or both keys for a given box are being distributed to the same shareholder

							if(!can_key_be_distributed_to_shareholder($Row[0], $Shareholder[0])){
								add_message('error', $GLOBALS['errorMessage']['both_keys_same_shareholder']);
							}

							// Verify that the key can be assigned accordingly

							check_key_movement($Shareholder[0], $Row[0]);

							// Remove the key from the bag and move the key out of the escrow location (it is no longer in escrow); Update the key's owner according to the receiving shareholder

							if(!db_query(create_sql_update(array('shareholder_id' => $Shareholder[0], 'escrow_location_id' => NULL, 'bag_id' => NULL), array('physical_key_id' => $Row[0]), DB_TABLE_KEYS))){ $Success = FALSE; }

							// Add an entry to the key audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_KEYS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_KEY_ESCROW){	// Key should be distributed prior to placing it in escrow

							// Lookup some information

							$Query  = "SELECT physical_key_id, tamper_bag_id, escrow_location_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the physical key is currently distributed

							if(!is_key_distributed($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['key_not_distributed']);
							}

							// Place the key into a bag and then move it into an escrow location (bag was marked as "sealed" at top of script); The shareholder will also be NULLified since it no longer belongs to anyone

							$FormInfo['bag_id']             = $Row[1];
							$FormInfo['escrow_location_id'] = $Row[2];
							$FormInfo['shareholder_id']     = NULL;
							$FormWhere['physical_key_id']   = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_KEYS))){ $Success = FALSE; }

							// Add an entry to the key audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_KEYS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_KEY_REBAG){		// Key should be in escrow prior to rebag

							// Lookup some information

							$Query  = "SELECT physical_key_id, new_tamper_bag_id, original_tamper_bag_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the physical key is in escrow

							if(!is_key_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['key_not_in_escrow']);
							}

							// Place the key into the new bag (the new bag was marked as "sealed" at top of script)

							$FormInfo['bag_id']           = $Row[1];
							$FormWhere['physical_key_id'] = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_KEYS))){ $Success = FALSE; }

							// Mark the original bag as "opened"

							if(!mark_bag_as_opened($Row[2])){ $Success = FALSE; }

							// Add an entry to the physical key audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_KEYS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_KEY_RELOCATION){		// Key should be in escrow prior to relocation

							// Lookup some data

							$Query  = "SELECT physical_key_id, transferred_to_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the equpment is in escrow

							if(!is_key_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['key_not_in_escrow']);
							}

							// Update the equipments location

							$FormInfo['escrow_location_id'] = $Row[1];
							$FormWhere['physical_key_id']   = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_KEYS))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_KEYS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_KEY_TRANSFER){

							// Lookup the recieving shareholder

							$FormID = lookup_from_id_from_table_name($TableName);

							$Query = "SELECT shareholder_id FROM " . DB_TABLE_FORM_ROLES . " WHERE execution_id=" . $ID . " AND form_id=" . $FormID . " AND role_id=7";
							$Result = db_query($Query);
							$Receiving = row_fetch($Result);

							// Lookup the relinquishing shareholder

							$Query = "SELECT shareholder_id FROM " . DB_TABLE_FORM_ROLES . " WHERE execution_id=" . $ID . " AND form_id=" . $FormID . " AND role_id=8";
							$Result = db_query($Query);
							$Relinquishing = row_fetch($Result);

							// Find the physical key ID

							$Query  = "SELECT physical_key_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Key    = row_fetch($Result);

							// Verify the original key holder still possess the key

							$KeyInfo = lookup_physical_key_info($Key[0]);

							if($KeyInfo['shareholder_id'] == $Relinquishing[0]){

								// Transfer the physical key between shareholders

								$FormInfo['shareholder_id']   = $Receiving[0];
								$FormWhere['physical_key_id'] = $Key[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_KEYS))){ $Success = FALSE; }

								// Add an entry to the physical key audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = $FormID;

								if(!create_audit_entry(DB_TABLE_KEYS, $Key[0], $UserID, $AuditInfo)){ $Success = FALSE; }

							}else{
								add_message('error', $GLOBALS['errorMessage']['key_owner_changed']);
							}

						}elseif($TableName == DB_TABLE_FORM_KEY_TRAKA_ASSIGNMENT){	// Key should be assigned in escrow prior to assingment

							// Find the traka key being assigned

							$Query  = "SELECT physical_key_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the traka physical key is in escrow

							if(!is_traka_key_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['key_not_in_escrow']);
							}

							// Lookup the receiving shareholder

							$Query = "SELECT shareholder_id FROM " . DB_TABLE_FORM_ROLES . " WHERE form_id='" . lookup_from_id_from_table_name($TableName) . "' AND execution_id=$ID AND role_id=7";
							$Result = db_query($Query);
							$Shareholder = row_fetch($Result);

							// Verify that one or both keys for a given box are being distributed to the same shareholder

							if(!can_key_be_distributed_to_shareholder($Row[0], $Shareholder[0])){
								add_message('error', $GLOBALS['errorMessage']['both_keys_same_shareholder']);
							}

							// Verify that the key can be assigned accordingly

							check_key_movement($Shareholder[0], $Row[0]);

							// Remove the key from escrow location (it is no longer in escrow); Update the key's owner according to the receiving shareholder

							if(!db_query(create_sql_update(array('shareholder_id' => $Shareholder[0], 'escrow_location_id' => NULL), array('physical_key_id' => $Row[0]), DB_TABLE_KEYS))){ $Success = FALSE; }

							// Add an entry to the key audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_KEYS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_KEY_TRAKA_REVOCATION){	// Key should be assigned prior to revoking

							// Lookup some information

							$Query  = "SELECT physical_key_id, escrow_location_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the physical key is currently distributed

							if(!is_traka_key_distributed($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['key_not_distributed']);
							}

							// Move the traka key into an escrow location; The shareholder will also be NULLified since it no longer belongs to anyone

							$FormInfo['escrow_location_id'] = $Row[1];
							$FormInfo['shareholder_id']     = NULL;
							$FormWhere['physical_key_id']   = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_KEYS))){ $Success = FALSE; }

							// Add an entry to the key audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_KEYS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_LOCK_REPAIR){

							// No database changes required

						}elseif($TableName == DB_TABLE_FORM_PARTITION_PASSWORD_CREATION){

							// No database changes required

						}elseif($TableName == DB_TABLE_FORM_ROOT_KEY_SIGNING){

							// No database changes required

						}elseif($TableName == DB_TABLE_FORM_SAFE_CHANGE){		// Only used for "access" shareholders

							// Find the access function as well as what access user was used

							$Query = "SELECT r.shareholder_id, f.function_id FROM " . $TableName . " f LEFT JOIN " . DB_TABLE_FORM_ROLES . " r ON r.execution_id=f.id WHERE f.id=$ID AND r.form_id=" . lookup_from_id_from_table_name($TableName) . " AND role_id=6";
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							$AccessShareholderID = $Row[0];
							$AccessFunctionID    = $Row[1];

							// Verify the user is still assigned as an access shareholder

							if(lookup_shareholder_function_type($AccessShareholderID) == 1){
								add_message('error', $GLOBALS['errorMessage']['not_access_function_type']);
							}

							// Verify they still hold the function for which we are about to reset

							if(!in_array($AccessFunctionID, lookup_shareholder_functions($AccessShareholderID))){
								add_message('error', $GLOBALS['errorMessage']['doesnt_hold_function']);
							}

							if(check_messages()){

								// Find all users who have a function that is part of the access pool that was changed and set their function to unassigned

								$Query = "SELECT shareholder_id, function_id, function_id_secondary FROM " . DB_TABLE_SHAREHOLDERS . " WHERE shareholder_id != '$AccessShareholderID' AND (function_id=" . $AccessFunctionID . " OR function_id_secondary=" . $AccessFunctionID . ") AND function_type_id=2 AND deleted=0";
								$Result = db_query($Query);
								$Count = row_count($Result);

								if($Count > 0){

									// Set audit entry values

									$AuditInfo['execution_id'] = $ID;
									$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

									// Manipulate each matching shareholders function by changing it to "Unassigned"

									while($Current = row_fetch($Result)){

										if($Current[1] == $AccessFunctionID){	// Determine if the matching function is primary
											$FormInfo['function_id'] = 4;
										}elseif($Current[2] == $AccessFunctionID){	// Determine if the matching function is secondary
											$FormInfo['function_id_secondary'] = 4;
										}
										$FormWhere['shareholder_id'] = $Current[0];

										if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHAREHOLDERS))){ $Success = FALSE; }
										if(!create_audit_entry(DB_TABLE_SHAREHOLDERS, $Current[0], $UserID, $AuditInfo)){ $Success = FALSE; }

										unset($FormInfo);	// Reset the array so we don't accidentally change the wrong function for another user
									}
								}

							}else{
								$Success = FALSE;
							}

						}elseif($TableName == DB_TABLE_FORM_SAFE_COMBO_DISTRIBUTION){

							// Find the access function as well as what access user was used

							$Query = "SELECT r.shareholder_id, f.function_id  FROM " . $TableName . " f LEFT JOIN " . DB_TABLE_FORM_ROLES . " r ON r.execution_id=f.id WHERE f.id=$ID AND r.form_id=" . lookup_from_id_from_table_name($TableName) . " AND role_id=14";
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Perform some sanity checks to make sure the shareholder can still take on the new access function

							$ShareholderFunctions = lookup_shareholder_functions($Row[0], TRUE);
							if(!in_array($Row[1], $ShareholderFunctions)){	// Ignore the check if the user alredy is assigned to that function

								can_shareholder_take_on_access_function($Row[0], $Row[1]);

								// If no errors, save the changes

								if(check_messages()){

									$CurrentFunctions = lookup_shareholder_functions($Row[0]);

									if($CurrentFunctions['primary'] == 4){
										$FormInfo['function_id'] = $Row[1];
									}elseif($CurrentFunctions['secondary'] == 4){
										$FormInfo['function_id_secondary'] = $Row[1];
									}
									$FormWhere['shareholder_id'] = $Row[0];

									if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHAREHOLDERS))){ $Success = FALSE; }

									// Set some audit variables

									$AuditInfo['execution_id'] = $ID;
									$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

									if(!create_audit_entry(DB_TABLE_SHAREHOLDERS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

								}else{
									$Success = FALSE;
								}

							}

						}elseif($TableName == DB_TABLE_FORM_SAFE_DEPOSIT_BOX_AUDIT){

							// Set some audit variables

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							// Update the last audit date of the box and create an audit entry for the box

							$Query  = "SELECT box_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							$FormInfo['last_audit_date'] = "CURDATE()";
							$FormWhere['box_id']         = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_BOXES))){ $Success = FALSE; }
							if(!create_audit_entry(DB_TABLE_BOXES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

							// Update each share's last audit date and create an audit entry for that share

							$Query = "SELECT share_id FROM " . DB_TABLE_SHARES . " WHERE box_id='" . $FormWhere['box_id'] . "' AND deleted=0";
							$Result = db_query($Query);

							while($Share = row_fetch($Result)){
								if(!db_query(create_sql_update($FormInfo, array("share_id" => $Share[0]), DB_TABLE_SHARES))){ $Success = FALSE; }
								if(!create_audit_entry(DB_TABLE_SHARES, $Share[0], $UserID, $AuditInfo)){ $Success = FALSE; }
							}

						}elseif($TableName == DB_TABLE_FORM_SHARE_COURIER){	// Share should already be in escrow prior to courier

							// Lookup some information

							$Query  = "SELECT outer_tamper_bag_id, escrow_location_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Mark the original bag as "opened"

							if(!mark_bag_as_opened($Row[0])){ $Success = FALSE; }

							// Grab each share

							$Query  = "SELECT share_id, tamper_bag_id FROM " . $TableName . "_items" . " WHERE execution_id=" . $ID;
							$Result = db_query($Query);

							// Loop through each share

							while($Share = row_fetch($Result)){

								// Make sure the share is in escrow

								if(!is_share_in_escrow($Share[0])){
									add_message('error', $GLOBALS['errorMessage']['share_not_in_escrow']);
								}

								// Update the escrow location for for the share

								$FormInfo['escrow_location_id'] = $Row[1];
								$FormWhere['share_id']          = $Share[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

								// Add an entry to the share audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

								if(!create_audit_entry(DB_TABLE_SHARES, $Share[0], $UserID, $AuditInfo)){ $Success = FALSE; }
							}

						}elseif($TableName == DB_TABLE_FORM_SHARE_DESTRUCTION){	// Share should be in escrow prior to destruction

							// Lookup some form information

							$Query  = "SELECT share_id, tamper_bag_id, activity_date FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the share is in escrow

							if(!is_share_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['share_not_in_escrow']);
							}else{

								// Mark the bag as "opened"

								if(!mark_bag_as_opened($Row[1])){ $Success = FALSE; }

								// Mark the share as destroyed

								$FormInfo['bag_id']             = NULL;
								$FormInfo['escrow_location_id'] = NULL;
								$FormInfo['date_destroyed']     = $Row[2];
								$FormWhere['share_id']          = $Row[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

								// Add an entry to the share audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

								if(!create_audit_entry(DB_TABLE_SHARES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }
							}

						}elseif($TableName == DB_TABLE_FORM_SHARE_DISTRIBUTION){	// Share should be in escrow prior to distribution

							/* Note: The form specifies a destination box because we cannot simply look up the box the shareholder owns because some users (like CBO) have more than one box */

							// Lookup some form information

							$Query  = "SELECT share_id, tamper_bag_id, activity_date, box_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the share is in escrow

							if(!is_share_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['share_not_in_escrow']);
							}

							// Mark the original bag as "opened", as long as the share is not always bagged

							if(!is_share_always_bagged($Row[0])){
								if(!mark_bag_as_opened($Row[1])){ $Success = FALSE; }
							}

							// Set the original distrubituion date if this is the first time that the share was distributed

							$Query  = "SELECT original_distribution_date FROM " . DB_TABLE_SHARES . " WHERE share_id=" . $Row[0];
							$Result = db_query($Query);
							$DistributionDate = row_fetch($Result);

							if($DistributionDate[0] === NULL){
								$DistributionDateInfo['original_distribution_date'] = $Row[2];
								if(!db_query(create_sql_update($DistributionDateInfo, array('share_id' => $Row[0]), DB_TABLE_SHARES))){ $Success = FALSE; }
							}

							// Find the receiving shareholder and make sure they still own the box (someone could have changed it by the time this form was approved)

							$Query = "SELECT IF(box_id IS NOT NULL, 1, 0) AS still_has_box FROM " . DB_TABLE_KEYS . " WHERE shareholder_id=(SELECT shareholder_id FROM " . DB_TABLE_FORM_ROLES . " WHERE form_id='" . lookup_from_id_from_table_name($TableName) . "' AND execution_id=$ID AND role_id=14) AND box_id=" . $Row[3];
							$Result = db_query($Query);
							$HasBox = row_fetch($Result);

							if(@$HasBox[0] == 1){

								// Place the share into a box to establish a link to the reciving shareholder and remove the share from the bag and escrow location

								$FormInfo['box_id']             = $Row[3];
								if(!is_share_always_bagged($Row[0])){
									$FormInfo['bag_id']             = NULL;
								}
								$FormInfo['escrow_location_id'] = NULL;
								$FormWhere['share_id']          = $Row[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

							}else{
								$Success = FALSE;
								add_message('error', $GLOBALS['errorMessage']['shareholder_doesnt_have_box']);
							}

							// Create a snapshot of the impacted box

							if(!create_box_snapshot($Row[3], lookup_from_id_from_table_name($TableName), $ID, $UserID)){ $Success = FALSE; }

							// Add an entry to the share audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_SHARES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_SHARE_ESCROW || $TableName == DB_TABLE_FORM_SHARE_CREATION){	// Share should be distributed prior to placing it in escrow

							// Lookup some information

							$Query  = "SELECT share_id, tamper_bag_id, escrow_location_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Grab all information about the share

							$ShareInfo = lookup_share_info($Row[0]);

							// If the share is "always bagged" make sure the original bag was selected

							if($ShareInfo['always_bagged'] == 1){
								if($ShareInfo['bag_id'] != $Row[1]){
									add_message('error', $GLOBALS['errorMessage']['share_same_bag']);
								}
							}

							$BoxID = lookup_box_for_share($Row[0]);		// Lookup the box ID for the given share so we can create a snapshot after the update

							// Make sure the share is distributed Also create a snap shot if the TableName is share_escrow
                                                        if ($TableName == DB_TABLE_FORM_SHARE_ESCROW) {

							     if(!is_share_distributed($Row[0])){
							 	add_message('error', $GLOBALS['errorMessage']['share_not_distributed']);
							      }

							     // Create a snapshot of the impacted box if this is an escrow form
							     if(!create_box_snapshot($BoxID, lookup_from_id_from_table_name($TableName), $ID, $UserID)){ $Success = FALSE; }
                                                         }
                                                         else {
                                                            // Error out if the share is already in a box while doing the creation
                                                            if ($BoxID > 0) {
                                                               add_message('error', $GLOBALS['errorMessage']['share_already_in_box']);
                                                            }
                                                         }

							// Place the share into a bag (if NOT "always bagged") and then move it into an escrow location (bag was marked as "sealed" at top of script); The box will also be NULLified which will remove the link to a shareholder

							if(!is_share_always_bagged($Row[0])){
								$FormInfo['bag_id']         = $Row[1];
							}
							$FormInfo['escrow_location_id'] = $Row[2];
							$FormInfo['box_id']             = NULL;
							$FormWhere['share_id']          = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

                                                         
							// Add an entry to the share audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_SHARES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_SHARE_REBAG){	// Share should be in escrow prior to rebag

							// Lookup some information

							$Query  = "SELECT share_id, new_tamper_bag_id, original_tamper_bag_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the share is in escrow (unless it is "always bagged", in which case it may be distributed)

							if(!is_share_always_bagged($Row[0])){
								if(!is_share_in_escrow($Row[0])){
									add_message('error', $GLOBALS['errorMessage']['share_not_in_escrow']);
								}
							}

							// Place the share into the new bag (the new bag was marked as "sealed" at top of script)

							$FormInfo['bag_id']    = $Row[1];
							$FormWhere['share_id'] = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

							// Mark the original bag as "opened"

							if(!mark_bag_as_opened($Row[2])){ $Success = FALSE; }

							// Add an entry to the share audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_SHARES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_SHARE_RELABEL){

							// Lookup some data

							$Query  = "SELECT share_id, new_label FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Update the share label

							$FormInfo['share_label'] = $Row[1];
							$FormWhere['share_id']   = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

							// Add an entry to the share audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_SHARES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_SHARE_RELOCATION){	// Share should be in escrow prior to relocation

							// Lookup some data

							$Query  = "SELECT share_id, transferred_to_id  FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the share is in escrow

							if(!is_share_in_escrow($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['share_not_in_escrow']);
							}

							// Update the equipments location

							$FormInfo['escrow_location_id'] = $Row[1];
							$FormWhere['share_id']          = $Row[0];

							if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

							// Add an entry to the equipment audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

							if(!create_audit_entry(DB_TABLE_SHARES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_SHARE_TRANSFER){	// Share should be distributed prior to transfer

							/* Note: The form specifies a destination box because we cannot simply look up the box the sharehholder owns because some users (like CBO) have more than one box */

							$FormID = lookup_from_id_from_table_name($TableName);

							// Find some form information

							$Query  = "SELECT share_id, box_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							// Make sure the share is distributed

							if(!is_share_distributed($Row[0])){
								add_message('error', $GLOBALS['errorMessage']['share_not_distributed']);
							}

							// Find the current box that the share is in (the one that share will be leaving)

							$ShareInfo = lookup_share_info($Row[0]);
							$OldBox    = $ShareInfo['box_id'];

							// Find the reliquishing shareholder and make sure they still own the box (someone could have changed it by the time this form was approved)

							$Query = "SELECT IF(box_id IS NOT NULL, 1, 0) AS still_has_box FROM " . DB_TABLE_KEYS . " WHERE shareholder_id=(SELECT shareholder_id FROM " . DB_TABLE_FORM_ROLES . " WHERE form_id='" . $FormID . "' AND execution_id=$ID AND role_id=15) AND box_id=" . $Row[1];
							$Result2 = db_query($Query);
							$HasBox = row_fetch($Result2);

							if(@$HasBox[0] == 1){

								// Place the share into a box to establish a link to the reciving shareholder

								$FormInfo['box_id']    = $Row[1];
								$FormWhere['share_id'] = $Row[0];

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHARES))){ $Success = FALSE; }

							}else{
								$Success = FALSE;
								add_message('error', $GLOBALS['errorMessage']['shareholder_doesnt_have_box2']);
							}

							// Create a snapshot of the impacted boxes

							if(check_messages()){
								if(!create_box_snapshot($Row[1], $FormID, $ID, $UserID)){ $Success = FALSE; }
								if(!create_box_snapshot($OldBox, $FormID, $ID, $UserID)){ $Success = FALSE; }
							}

							// Add an entry to the share audit table

							$AuditInfo['execution_id'] = $ID;
							$AuditInfo['form_id']      = $FormID;

							if(!create_audit_entry(DB_TABLE_SHARES, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

						}elseif($TableName == DB_TABLE_FORM_SHAREHOLDER_FUNCTION_CHANGE){	// Only used for "physical key" shareholders

							// Find the shareholder and their new function

							$Query  = "SELECT shareholder_id, new_function_id, site_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							$FormInfo['function_id']     = $Row[1];
							$FormInfo['site_id']         = $Row[2];
							$FormWhere['shareholder_id'] = $Row[0];

							// Verify again that the user can take on the new function (someone could have made changes in the admin panel prior to the approval)

							can_shareholder_take_on_physical_key_function($Row[0], $Row[1]);

							// Verify the user can still be assigned to the site

							can_shareholder_be_assigned_to_site($Row[0], $Row[2]);

							if(check_messages()){

								// Save the change

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHAREHOLDERS))){ $Success = FALSE; }

								// Add an entry to the shareholders audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

								if(!create_audit_entry(DB_TABLE_SHAREHOLDERS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

							}else{
								$Success = FALSE;	// The user cannot be changed to the new function
							}

						}elseif($TableName == DB_TABLE_FORM_SHAREHOLDER_ROLE_CHANGE){

							// Find the shareholder and their new role

							$Query  = "SELECT shareholder_id, new_function_type_id FROM " . $TableName . " WHERE id=" . $ID;
							$Result = db_query($Query);
							$Row    = row_fetch($Result);

							$FormInfo['function_type_id']      = $Row[1];
							$FormInfo['function_id']           = 4;			// Setting function to "Unassigned" since a Physical Key user does not have to be set to "Unassigned" when changing roles, they simply must possess no keys
							$FormInfo['function_id_secondary'] = 4;
							$FormWhere['shareholder_id']       = $Row[0];

							// Verify the shareholder does not possess any keys (if currently a Physical Key user)

							$CurrentFunctionType = lookup_shareholder_function_type($Row[0]);

							if($CurrentFunctionType == 1){
								if(shareholder_box_count($Row[0]) > 0){
									add_message('error', $GLOBALS['errorMessage']['shareholder_still_possesses_key']);
								}

							// Verify the shareholder does not know any combos (if currently an Access user)

							}elseif($CurrentFunctionType == 2){
								if(count(lookup_shareholder_functions($Row[0], TRUE)) > 0){
									add_message('error', $GLOBALS['errorMessage']['shareholder_knows_combo']);
								}
							}

							if(check_messages()){

								// Save the change

								if(!db_query(create_sql_update($FormInfo, $FormWhere, DB_TABLE_SHAREHOLDERS))){ $Success = FALSE; }

								// Add an entry to the shareholders audit table

								$AuditInfo['execution_id'] = $ID;
								$AuditInfo['form_id']      = lookup_from_id_from_table_name($TableName);

								if(!create_audit_entry(DB_TABLE_SHAREHOLDERS, $Row[0], $UserID, $AuditInfo)){ $Success = FALSE; }

							}else{
								$Success = FALSE;	// The user cannot be change roles
							}

						}elseif($TableName == DB_TABLE_FORM_SKR_RECEIPT_INSTALL){

							// No database updates required

						}

					}

					// Rollback or commit the transaction

					if($Success && check_messages()){
						commit_db_transaction();
						add_message('success', $GLOBALS['successMessage']['changes_saved']);
					}else{
						rollback_db_transaction();
						add_message('error', $GLOBALS['errorMessage']['db_write_failure_multiple']);
					}

				}else{
					add_message('error', $GLOBALS['errorMessage']['db_unable_to_begin_transaction']);
				}

			}

		}

	}else{
		add_message('error', $GLOBALS['errorMessage']['cannot_identify_form']);
	}

	// Display any messages

	if(!check_messages()){
		echo "<div class='inner_messages'>\n";
			print_messages();
		echo "</div>\n";
	}

	db_close();

?>
