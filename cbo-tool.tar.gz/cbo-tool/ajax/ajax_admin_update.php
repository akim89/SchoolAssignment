<?php

	/* 
		Note: To insert large BLOB's (attachments) you must edit /etc/my.cnf, 
		otherwise you may recieve a "MySQL server has gone away" error
		
		[mysqld]
		...
		max_allowed_packet = 200M
		...
	*/

	require_once("../includes.php");
	db_connect();	
		
	$Table = clean_sql_value(@$_POST['table']);
	$UserID = validate("int", $_COOKIE['user_id'], "user ID", 1, NULL, $GLOBALS['errorMessage']['cookie_no_detect_user']);	
	
	if($Table){
	
		$Audit = FALSE;
		$Snapshot = FALSE;
		$MarkTEBOpened = FALSE;
		
		// Validate common variables
		
		$Submit = @$_POST['submit'];
		if($Submit == "Update"){ $ID = validate("int", @$_POST['id'], "ID", 1); }else{ $ID = NULL; }
		if($Table == DB_TABLE_USERS){
			$Info['disabled'] = validate("regex", @$_POST['deleted'], "disabled", 1, "bool");
		}else{
			$Info['deleted'] = validate("regex", @$_POST['deleted'], "deleted", 1, "bool");
		}
		
		// Validate unique variables
		
		if($Table == DB_TABLE_BOXES){
			$Audit = TRUE;
			
			$Where['box_id']     = $ID;
			$Info['box_number']  = validate("regex", @$_POST['box_number'],  "box number", 1, "text");
			$Info['site_id']     = validate("int",   @$_POST['site_id'],     "site",       1);	
		}elseif($Table == DB_TABLE_CABINETS){
			$Where['cabinet_id']  = $ID;
			$Info['cabinet_name'] = validate("regex", @$_POST['cabinet_name'], "cabinet name", 1, "text");
		}elseif($Table == DB_TABLE_DESTRUCTION_METHODS){
			$Where['destruction_method_id']  = $ID;
			$Info['destruction_method_name'] = validate("regex", @$_POST['destruction_method_name'], "destruction method", 1, "text");
		}elseif($Table == DB_TABLE_EMAIL_TEMPLATES){
			$Where['email_template_id']  = $ID;
			$Info['email_template_name'] = validate("regex", @$_POST['email_template_name'], "template name", 1, "text");	
			$Info['subject']             = validate("regex", @$_POST['subject'], "subject", 1, "text");	
			$Info['body']                = validate("regex", @$_POST['body'], "body", 1, "alltext");	
			$Info['default_recipients']  = validate("regex", preg_replace("/\s/", "", @$_POST['default_recipients']), "default recipients", 1, "alltext");
		}elseif($Table == DB_TABLE_ENVIRONMENTS){
			$Where['environment_id']  = $ID;
			$Info['environment_name'] = validate("regex", @$_POST['environment_name'], "environment", 1, "text");
		}elseif($Table == DB_TABLE_EQUIP_TYPES){
			$Where['equipment_type_id']  = $ID;
			$Info['equipment_type_name'] = validate("regex", @$_POST['equipment_type_name'], "equipment type", 1, "text");
		}elseif($Table == DB_TABLE_EQUIP){
			$Audit = TRUE;
			
			// Check to see if the equipment has been marked as destoryed
			
			if($ID){
				if(is_eqiupment_destroyed($ID)){			
					add_message('error', $GLOBALS['errorMessage']['no_changes_after_destoryed']);
				}
			}
			
			$Where['equipment_id'] = $ID;			
			$Info['label_name']             = validate("regex", @$_POST['label_name'], "label", 0, "text");
			$Info['equipment_type_id']      = validate("int",   @$_POST['equipment_type_id'], "equipment type", 1);
			$Info['vendor_id']              = validate("int",   @$_POST['vendor_id'], "vendor", 1);
			$Info['serial_number']          = validate("regex", @$_POST['serial_number'], "serial number", 1, "text");
			$Info['asset_tag_number']       = validate("regex", @$_POST['asset_tag_number'], "asset tag", 1, "text");
			$Info['server_name']            = validate("regex", @$_POST['server_name'], "server_name", 0, "text");
			$Info['description']            = validate("regex", @$_POST['description'], "description", 0, "text");
			$Info['model_number']           = validate("regex", @$_POST['model_number'], "model number", 1, "text");
			$Info['model_type_id']          = validate("int",   @$_POST['model_type_id'], "model type", 0);
			$Info['equipment_version_id']   = validate("int",   @$_POST['equipment_version_id'], "version", 0);
			$Info['firmware_version']       = validate("regex", @$_POST['firmware_version'], "firmware version", 0, "text");
			$Info['part_number']            = validate("regex", @$_POST['part_number'], "part number", 0, "text");
			$Info['purchase_order_number']  = validate("regex", @$_POST['purchase_order_number'], "purchase order number", 0, "text");
			$Info['tamper_seal_number']     = validate("regex", @$_POST['tamper_seal_number'], "tamper seal number", 0, "text");
			$Info['bag_id']                 = validate("int",   @$_POST['bag_id'], "tamper evident bag", 0);
			$Info['servicenow_id']          = validate("regex", @$_POST['servicenow_id'], "ServiceNow SysID", 0, "alphanum");
			$Info['escrow_location_id']     = validate("int",   @$_POST['escrow_location_id'], "escrow location", 0);
			$Info['product_id']             = validate("int",   @$_POST['product_id'], "product", 0);
			$Info['environment_id']         = validate("int",   @$_POST['environment_id'], "environment", 0);
			$Info['status']                 = validate("regex", @$_POST['status'], "status", 1, "equip_status");
			$Info['date_online']            = validate("regex", @$_POST['date_online'], "date online", ($Info['status'] == "Online" ? 1 : 0), "date");
			$Info['date_offline']           = validate("regex", @$_POST['date_offline'], "date offline", ($Info['status'] == "Offline" || $Info['status'] == "Destroyed" ? 1 : 0), "date");
			$Info['date_destroyed']         = validate("regex", @$_POST['date_destroyed'], "date destroyed", ($Info['status'] == "Destroyed" ? 1 : 0), "date");
			$Info['rack_location']          = validate("regex", @$_POST['rack_location'], "rack location", 0, "text");
			$Info['support_contract_id']    = validate("int",   @$_POST['support_contract_id'], "support contract", 0);
			$Info['date_shipped']           = validate("regex", @$_POST['date_shipped'], "date shipped", ($Info['equipment_type_id'] == 7 ? 0 : 1), "date");	// 7 == HP Drive
			$Info['notes']                  = validate("regex", @$_POST['notes'], "notes", 0, "text");
			$Info['is_production_capable']  = validate("regex", @$_POST['is_production_capable'], "is production capable", 0, "bool");
			$Info['is_acceptance_tested']   = validate("regex", @$_POST['is_acceptance_tested'], "is acceptance tested", 1, "bool");
			$Info['date_acceptance_tested'] = validate("regex", @$_POST['date_acceptance_tested'], "date acceptance tested", 0, "date");
			$Info['date_last_verified']     = validate("regex", @$_POST['date_last_verified'], "date last verified", 0, "date");
			$UpdateRack                     = (@$_POST['update_rack'] ? 1 : 0);
			
			// Automatically try to update the rack if user requests it
			
			if($UpdateRack){
				$Command = PATH_ROOT_DIR . "/" . PATH_WWW . "/lookupRackLocation.pl " . $Info['servicenow_id'];
				exec(escapeshellcmd($Command), $Output);
				
				if(@$Output[0]){
					$Info['rack_location'] = clean_sql_value($Output[0]);
				}else{
					add_message('info', $GLOBALS['infoMessage']['rack_location_not_found']);
				}
			}
			
			// If the equipment is marked as "Online" perform a few checks
			
			if($Info['status'] == "Online"){
			
				// Verify that the device is not marked as "in escrow"
				
				if($Info['bag_id'] || $Info['escrow_location_id']){
					add_message('error', $GLOBALS['errorMessage']['device_still_in_escrow']);
				}
				
				// Verify that the device has a rack location
				
				if(!$Info['rack_location']){
					add_message('error', $GLOBALS['errorMessage']['rack_location_required']);
				}
				
				// Verify that no offline or destruction date has been entered
				
				if($Info['date_destroyed']){
					add_message('error', $GLOBALS['errorMessage']['no_offline_destruction_dates']);
				}
			}
			
			// If the equipment is marked as "Offline" perform a few checks
			
			if($Info['status'] == "Offline"){
			
				// Verify that the device is marked as "in escrow"
				
				if($Info['environment_id'] == 4){	// Production
					if(!$Info['bag_id'] || !$Info['escrow_location_id']){
						add_message('error', $GLOBALS['errorMessage']['device_must_be_escrowed']);
					}
				}else{
					if(!$Info['escrow_location_id']){	// Non-Production
						add_message('error', $GLOBALS['errorMessage']['device_must_be_escrowed']);
					}
				}
				
				// Verify that the device does not have a rack location
				
				if($Info['rack_location']){
					add_message('error', $GLOBALS['errorMessage']['device_no_rack_location']);
				}
				
				// Verify that no destruction date has been entered
				
				if($Info['date_destroyed']){
					add_message('error', $GLOBALS['errorMessage']['no_destruction_date']);
				}
			}
			
			// If the equipment is marked as "Destroyed" perform a few checks
			
			if($Info['status'] == "Destroyed"){
			
				// Set the bag to "opened"
				
				$MarkTEBOpened = $Info['bag_id'];	
									
				// Verify that the device is not marked as "in escrow"
				
				if($Info['bag_id'] || $Info['escrow_location_id']){
					add_message('error', $GLOBALS['errorMessage']['device_still_in_escrow']);
				}
				
				// Verify that their is no rack location
				
				if($Info['rack_location']){
					add_message('error', $GLOBALS['errorMessage']['equipment_is_racked']);
				}					
			}

			// Verify the serial number is unique
			
			if(does_serial_number_exist($Info['serial_number'], $Table, @$ID)){
				add_message('error', $GLOBALS['errorMessage']['duplicate_serial_number']);
			}
		
		}elseif($Table == DB_TABLE_EQUIP_VERSIONS){
			$Where['equipment_version_id']  = $ID;
			$Info['equipment_version_name'] = validate("regex", @$_POST['equipment_version_name'], "equipment version", 1, "text");			
		}elseif($Table == DB_TABLE_EQUIP_ATTACHMENTS){
		
			$Filename = preg_replace("/'|\"/", "", str_replace(" ", "_", @$_POST['filename']));
			$FullFilename = "../" . PATH_UPLOADS . '/' . $Filename;

			if(file_exists($FullFilename)){
			
				$Where['attachment_id']         = $ID;
				$Info1['attachment_description'] = validate("regex", @$_POST['attachment_description'], "attachment description", 1, "text");
				$Info1['attachment_name']        = validate("regex", @$Filename, "filename", 1, "text");
				$Info1['attachment_filesize']    = clean_sql_value(filesize($FullFilename));
				$Info1['attachment_filetype']    = clean_sql_value(returnMIMEType($FullFilename));
				$Info1['binary_data']            = clean_sql_value(fread(fopen($FullFilename, "r"), filesize($FullFilename)));
				
				$Info2['equipment_id']           = validate("int",   @$_POST['equipment_id'], "equipment", 1);
		
			}else{
				add_message('error', $GLOBALS['errorMessage']['cannot_locate_file']);
			}
		
		}elseif($Table == DB_TABLE_ESCROW_LOCATIONS){
			$Where['escrow_location_id']  = $ID;
			$Info['escrow_location_name'] = validate("regex", @$_POST['escrow_location_name'], "escrow location name", 1, "text");
			$Info['escrow_location_type_id'] = validate("int",   @$_POST['escrow_location_type_id'], "escrow location type", 1);
			$Info['site_id']              = validate("int",   @$_POST['site_id'], "site", 1);				
		}elseif($Table == DB_TABLE_ESCROW_LOCATION_TYPES){
			$Where['escrow_location_type_id']  = $ID;
			$Info['escrow_location_type_name'] = validate("regex", @$_POST['escrow_location_type_name'], "escrow location type", 1, "text");
		}elseif($Table == DB_TABLE_FORMS){
			$Where['form_id']  = $ID;
			$Info['instructions'] = validate("regex", @$_POST['instructions'], "instructions", 1, "alltext");
		}elseif($Table == DB_TABLE_FUNCTIONS){
			$Where['function_id']     = $ID;
			$Info['function_name']    = validate("regex", @$_POST['function_name'], "function", 1, "text");
			$Info['function_type_id'] = validate("int",   @$_POST['function_type_id'], "function type", 1);
		}elseif($Table == DB_TABLE_KEY_TYPES){
			$Where['key_type_id']  = $ID;
			$Info['key_type_name'] = validate("regex", @$_POST['key_type_name'], "key type", 1, "text");
		}elseif($Table == DB_TABLE_MEDIA_TYPES){
			$Where['media_type_id']  = $ID;
			$Info['media_type_name'] = validate("regex", @$_POST['media_type_name'], "media type", 1, "text");
		}elseif($Table == DB_TABLE_MODEL_TYPES){
			$Where['model_type_id']  = $ID;
			$Info['model_type_name'] = validate("regex", @$_POST['model_type_name'], "model type", 1, "text");
			$Info['equipment_type_id'] = validate("int", @$_POST['equipment_type_id'], "equipment type", 1);
		}elseif($Table == DB_TABLE_KEYS){
			$Audit = TRUE;
		
			$Where['physical_key_id']     = $ID;
			$Info['label']                = validate("regex", @$_POST['label'], "label", 1, "text");
			$Info['serial_number']        = validate("int",   @$_POST['serial_number'], "serial number", 1);
			$Info['physical_key_type_id'] = validate("int",   @$_POST['physical_key_type_id'], "physical key type", 1);			
			if($Info['physical_key_type_id'] != 2){ $Info['box_id'] = validate("int",   @$_POST['box_id'], "box", 1); }else{ $Info['box_id'] = NULL; }	// If common key, then a box is not needed
			$Info['escrow_location_id']   = validate("int",   @$_POST['escrow_location_id'], "escrow location", (@$_POST['shareholder_id'] ? 0 : 1));
			$Info['shareholder_id']       = validate("int",   @$_POST['shareholder_id'], "shareholder", (@$_POST['bag_id'] || @$_POST['escrow_location_id'] ? 0 : 1));
			$Info['bag_id']               = validate("int",   @$_POST['bag_id'], "tamper bag number", (@$_POST['shareholder_id'] ? 0 : (lookup_type_of_escrow_location($Info['escrow_location_id']) == 3 ? 0 : 1)));
			$Info['servicenow_sys_id']    = validate("regex", @$_POST['servicenow_sys_id'], "ServiceNow SysID", 0, "sys_id");
			
			// If shareholder is set, make sure the bag and escrow location are not
			
			$InvalidEntry = FALSE;
			
			if($Info['shareholder_id']){
				if($Info['bag_id'] || $Info['escrow_location_id']){
					$InvalidEntry = TRUE;
				}
			}

			// If the the bag or escrow location are set perform a few checks
			
			if($Info['bag_id'] || $Info['escrow_location_id']){
			
				// If the escrow location is a Traka box, ensure that the bag is NOT set
				
				if(lookup_type_of_escrow_location($Info['escrow_location_id']) == 3){
					if($Info['bag_id']){
						add_message('error', $GLOBALS['errorMessage']['traka_no_bag']);
					}	
					
				// If the the bag and escrow location are set, and the escrow location is not a Traka box, make sure the shareholder is not
					
				}elseif($Info['bag_id'] || $Info['escrow_location_id']){
					if($Info['shareholder_id']){
						$InvalidEntry = TRUE;				
					}
				}
			
			}

			// If either of the two validations above fail add an error message
			
			if($InvalidEntry){
				add_message('error', $GLOBALS['errorMessage']['key_conflict']);
			}
			
			// If the shareholder and key is set, verify that the key can be assigned accordingly
			
			if($Info['shareholder_id'] && $ID){	
				check_key_movement($Info['shareholder_id'], $ID);
			}
			
			// Make sure "non-CBO" users are not obtaining a key for a site to which they do not belong
			
			if($Info['shareholder_id'] && $ID){
				$Query = "SELECT cbo_user, site_id FROM " . DB_TABLE_SHAREHOLDERS . " WHERE shareholder_id='" . $Info['shareholder_id'] . "'";
				$Result = db_query($Query);
				$Row = row_fetch_assoc($Result);
				
				if($Row['cbo_user'] == 0){	// Non-CBO user
					if($Row['site_id'] != lookup_box_site(lookup_key_box($ID))){
						add_message('error', $GLOBALS['errorMessage']['only_obtain_key_from_shareholder_site']);
					}
				}
			}
			
			// If the key is NOT a "common key" perform the following checks
			
			if($Info['physical_key_type_id'] != 2){
			
				// Verify that no more than 2 keys are assigned to a box (this prevents miss-selection of key->box mappings)
				
				if($Info['box_id']){
					$Query = "SELECT physical_key_id FROM " . DB_TABLE_KEYS . " WHERE deleted=0 AND physical_key_id!='" . $ID . "' AND box_id='" . $Info['box_id'] . "'";
					$Result = db_query($Query);
					$Count = row_count($Result);
					
					if($Count >= 2){
						add_message('error', $GLOBALS['errorMessage']['two_keys_per_box']);
					}
				}
				
				// Verify that the keys for a given box only belong to one shareholder (Note: both keys CAN be in escrow)
				
				if($Info['box_id'] && $Info['shareholder_id']){					
					if(!can_key_be_distributed_to_shareholder($ID, $Info['shareholder_id'])){
						add_message('error', $GLOBALS['errorMessage']['both_keys_same_shareholder']);
					}					
				}
				
			}
			
			// Verify the serial number is unique
			
			if(does_serial_number_exist($Info['serial_number'], $Table, @$ID)){
				add_message('error', $GLOBALS['errorMessage']['duplicate_serial_number']);
			}
		
		}elseif($Table == DB_TABLE_PHYSICAL_KEY_TYPES){
			$Where['physical_key_type_id']  = $ID;
			$Info['physical_key_type_name'] = validate("regex", @$_POST['physical_key_type_name'], "physical key type", 1, "text");		
		}elseif($Table == DB_TABLE_PRODUCTS){
			$Where['product_id']  = $ID;
			$Info['product_name'] = validate("regex", @$_POST['product_name'], "product", 1, "text");
		}elseif($Table == DB_TABLE_ROLES){
			$Where['role_id']  = $ID;
			$Info['role_name'] = validate("regex", @$_POST['role_name'], "role", 1, "text");
		}elseif($Table == DB_TABLE_SHARE_TYPES){
			$Where['share_type_id']  = $ID;
			$Info['share_type_name'] = validate("regex", @$_POST['share_type_name'], "share type", 1, "text");
		}elseif($Table == DB_TABLE_SHARES){
			$Audit = TRUE;
			
			if($ID){
				if(is_share_destroyed($ID)){			
					add_message('error', $GLOBALS['errorMessage']['no_changes_after_destoryed_share']);
				}
			}
			
			$Where['share_id']                  = $ID;			
			$Info['share_label']                = validate("regex", @$_POST['share_label'], "share label", 1, "text");
			$Info['serial_number']              = validate("int",   @$_POST['serial_number'], "serial number", 1);
			$Info['share_type_id']              = validate("int",   @$_POST['share_type_id'], "share type", 1);
			$Info['box_id']                     = validate("int",   @$_POST['box_id'], "box", (preg_match('/7|8/', @$_POST['share_type_id']) ? (@$_POST['escrow_location_id'] ? 0 : 1) : (@$_POST['escrow_location_id'] || @$_POST['bag_id'] ? 0 : 1)));
			$Info['escrow_location_id']         = validate("int",   @$_POST['escrow_location_id'], "escrow location", (@$_POST['box_id'] ? 0 : 1));
			$Info['product_id']                 = validate("int",   @$_POST['product_id'], "product", 1);
			$Info['environment_id']             = validate("int",   @$_POST['environment_id'], "environment", 1);
			$Info['key_type_id']                = validate("int",   @$_POST['key_type_id'], "key type", 1);
			$Info['media_type_id']              = validate("int",   @$_POST['media_type_id'], "media type", 1);
			$Info['mofn_threshold']             = validate("regex", @$_POST['mofn_threshold'], "MofN threshold", 1, "text");
			$Info['always_bagged']              = validate("regex", @$_POST['always_bagged'] , "always bagged", 1, "bool");
			$Info['bag_id']                     = validate("int",   @$_POST['bag_id'], "bag", (preg_match('/7|8/', @$_POST['share_type_id']) || @$_POST['always_bagged'] == 1 ? 1 : (@$_POST['box_id'] ? 0 : 1)));	// Passwords always in a bag
			$Info['share_creation_date']        = validate("regex", @$_POST['share_creation_date'], "creation date", 1, "date");
			$Info['original_distribution_date'] = validate("regex", @$_POST['original_distribution_date'], "distribution date", (@$_POST['date_destroyed'] ? 1 : 0), "date");
			$Info['date_destroyed']             = validate("regex", @$_POST['date_destroyed'], "destruction date", 0, "date");
			$Info['share_set']                  = validate("regex", @$_POST['share_set'], "share set", 0, "text");
			$Info['notes']                      = validate("regex", @$_POST['notes'], "notes", 0, "text");	

			$InvalidEntry = FALSE;
			$InvalidEntry2 = FALSE;
			
			if(preg_match('/7|8/', @$Info['share_type_id'])){
			
				// Make sure the password is not placed in a box and escrow at the same time
				
				if($Info['escrow_location_id'] && $Info['box_id']){
					$InvalidEntry = TRUE;					
				}
				
			}else{
			
				if($Info['always_bagged'] == 1){
					
					// If box is set, make sure the escrow location is not
					
					if($Info['box_id']){
						if($Info['escrow_location_id']){
							$InvalidEntry2 = TRUE;
						}
					}
					
					// If the the escrow location is set make sure the box is not
					
					if($Info['escrow_location_id']){
						if($Info['box_id']){
							$InvalidEntry2 = TRUE;
											
						}
					}
			
				}else{
				
					// If box is set, make sure the bag and escrow location are not
					
					if($Info['box_id']){
						if($Info['bag_id'] || $Info['escrow_location_id']){
							$InvalidEntry = TRUE;
						}
					}
					
					// If the the bag and escrow location are set make sure the box is not
					
					if($Info['bag_id'] || $Info['escrow_location_id']){
						if($Info['box_id']){
							$InvalidEntry = TRUE;					
						}
					}
				}
			
			}
			
			// If of the above validations fail add an error message (this prevents duplicate error messages)
			
			if($InvalidEntry){
				add_message('error', $GLOBALS['errorMessage']['share_conflict']);
			}
			
			if($InvalidEntry2){
				add_message('error', $GLOBALS['errorMessage']['share_conflict2']);
			}
			
			// If the share is being destoryed make a few changes
			
			if($Info['date_destroyed']){
				
				// Set the bag to "opened"
				
				$MarkTEBOpened = $Info['bag_id'];
				
				// Remove the device from escrow
				
				$Info['escrow_location_id'] = NULL;
				$Info['bag_id'] = NULL;
			}
			
			// Check to see if the share's box is changing
			
			if($ID){			
				$Query = "SELECT box_id FROM " . DB_TABLE_SHARES . " WHERE share_id=" . $ID;
				$Result = db_query($Query);
				$BoxID = row_fetch($Result);
							
				if($Info['box_id'] != $BoxID[0]){
					$Snapshot = TRUE;	// The box is changing, make sure to preform a snapshot
					$OldBox = $BoxID[0];	// We will also want to snapshot the old box
				}					
			}else{
				$Snapshot = TRUE;	// This is a new share
			}

			// Verify the serial number is unique
			
			if(does_serial_number_exist($Info['serial_number'], $Table, @$ID)){
				add_message('error', $GLOBALS['errorMessage']['duplicate_serial_number']);
			}			
			
		}elseif($Table == DB_TABLE_SHAREHOLDERS){
			$Audit = TRUE;
			
			$Where['shareholder_id']        = $ID;
			$Info['shareholder_name']       = validate("regex", $_POST['shareholder_name'], "name", 1, "text");
			$Info['username']               = validate("regex", $_POST['username'], "VCORP username", 1, "text");
			$Info['function_type_id']       = validate("regex", $_POST['function_type_id'], "function type", 1, "text");
			$Info['cbo_user']               = validate("regex", $_POST['cbo_user'] , "CBO user", 1, "bool");
			$Info['has_data_center_access'] = validate("regex", $_POST['has_data_center_access'] , "data center access", 1, "bool");
			$Info['manager_name']           = validate("regex", $_POST['manager_name'], "manager name ", 0, "text");
			$Info['function_id']            = validate("int",   $_POST['function_id'], "primary function", ($_POST['function_id_secondary'] ? 0 : 1));
			$Info['function_id_secondary']  = validate("int",   $_POST['function_id_secondary'], "secondary function", ($_POST['function_type_id'] == 1 || $_POST['function_id'] || ($_POST['function_type_id'] == 2 && !$_POST['function_id']) ? 0 : 1));
			$Info['site_id']                = validate("int",   $_POST['site_id'], "site", 1);
			$Info['phone_number']           = validate("regex", $_POST['phone_number'], "phone number", 0, "text");
			$Info['desk_location']          = validate("regex", $_POST['desk_location'], "desk location", 0, "text");
			$Info['notes']                  = validate("regex", $_POST['notes'], "notes ", 0, "text");
			
			// If the user is assigned the access function type but only one function is assigned, make sure it is being placed into the primary function column in the database
			
			if($Info['function_type_id'] == 2){
				if($Info['function_id_secondary'] && !$Info['function_id']){
					$Info['function_id'] = $Info['function_id_secondary'];
					$Info['function_id_secondary'] = NULL;
				}
			}
			
			// Verify that the type of user is not assigned to the wrong site
			
			if($Info['cbo_user'] == 1 && $Info['site_id'] != 1){
				add_message('error', $GLOBALS['errorMessage']['site_cbo_users']);
			}
			
			if($Info['cbo_user'] == 0 && $Info['site_id'] == 1){
				add_message('error', $GLOBALS['errorMessage']['site_non_cbo_users']);
			}
			
			// Verify a valid site was selected
			
			if(!preg_match('/^(1|2|3|5)$/', $Info['site_id'])){
				add_message('error', $GLOBALS['errorMessage']['not_valid_sharehholder_site']);
			}
			
			// Verifty that if the Physical Key or Sysadmin function type was selected they only have one function assigned to them

			if(($Info['function_type_id'] == 1 || $Info['function_type_id'] == 4) && $Info['function_id_secondary']){
				add_message('error', $GLOBALS['errorMessage']['only_one_function']);
			}
			
			// Verify that the user is not a CBO user and has data center access
			
			if($Info['has_data_center_access'] == 1 && $Info['cbo_user'] == 1){
				add_message('error', $GLOBALS['errorMessage']['cannot_be_cbo_dca']);
			}
			
			// Verify the user is not in the blacklist (unless they are a "Sysadmin", then it doesn't matter, all they can do is sign a document)
			
			if($Info['username'] && $Info['function_type_id'] != 4){
				if(is_shareholder_blacklisted($Info['username'])){
					add_message('error', $GLOBALS['errorMessage']['shareholder_blacklisted']);
				}
			}
			
			// Verify that the selected "function" coinsides with the selected "function type"
			
			if($Info['function_type_id'] == 1){	// If Physical Key type make sure they aren't assigned to an access or sysadmin function
				if($Info['function_id'] != 4 && ($Info['function_id'] && !array_key_exists($Info['function_id'], list_physical_key_functions()))){	
					add_message('error', $GLOBALS['errorMessage']['function_type_disagree_function']);
				}
			}
			
			if($Info['function_type_id'] == 2){	// If Access type make sure they aren't assigned to any physical key or sysadmin functions
				if($Info['function_id'] != 4 && ($Info['function_id'] && !array_key_exists($Info['function_id'], list_access_functions()))){
					add_message('error', $GLOBALS['errorMessage']['function_type_disagree_function']);
				}
				
				if($Info['function_id_secondary'] != 4 && ($Info['function_id_secondary'] && !array_key_exists($Info['function_id_secondary'], list_access_functions()))){
					add_message('error', $GLOBALS['errorMessage']['function_type_disagree_function']);
				}
			}
			
			if($Info['function_type_id'] == 4){	// If Sysadmin type make sure they aren't assigned to any physical key or access functions
				if($Info['function_id'] != 4 && ($Info['function_id'] && !array_key_exists($Info['function_id'], list_sysadmin_functions()))){
					add_message('error', $GLOBALS['errorMessage']['function_type_disagree_function']);
				}				
			}

			// Verify that the "type" of user is not assigned to the wrong primary function			
					
			if($Info['cbo_user'] == 1 && !is_permitted_cbo_function($Info['function_id'])){	// Permits Unassigned, HSM, Passwords, Common, Pool A, Pool B
				add_message('error', $GLOBALS['errorMessage']['cbo_function_violation']);
			}
			
			if($Info['has_data_center_access'] == 1 && !is_permitted_data_center_access_function($Info['function_id'])){	// Permits Unassigned, MegaSafe
				add_message('error', $GLOBALS['errorMessage']['dca_function_violation']);
			}
			
			// Verify that the "type" of user is not assigned to the wrong secondary function (same checks as above just for 2nd function)
			
			if($Info['function_type_id'] == 2){
			
				if($Info['function_id_secondary']){
					if($Info['cbo_user'] == 1 && !is_permitted_cbo_function($Info['function_id_secondary'])){	// Permits Unassigned, HSM, Passwords, Common, Pool A, Pool B
						add_message('error', $GLOBALS['errorMessage']['cbo_function_violation']);
					}
					
					if($Info['has_data_center_access'] == 1 && !is_permitted_data_center_access_function($Info['function_id_secondary'])){	// Permits Unassigned, MegaSafe
						add_message('error', $GLOBALS['errorMessage']['dca_function_violation']);
					}
					
					// Verify that the primary and secondary functions are not the same
					
					if($Info['function_id'] == $Info['function_id_secondary']){
						add_message('error', $GLOBALS['errorMessage']['same_function']);
					}
					
					// Verify that a user is not assigned Pool A and Pool B access to the same site
			
					if($Info['function_id'] && $Info['function_id_secondary']){
						if((preg_match(REGEX_POOL_BRN_FUNCTIONS, $Info['function_id']) && preg_match(REGEX_POOL_BRN_FUNCTIONS, $Info['function_id_secondary'])) || (preg_match(REGEX_POOL_ILG_FUNCTIONS, $Info['function_id']) && preg_match(REGEX_POOL_ILG_FUNCTIONS, $Info['function_id_secondary']))){
							add_message('error', $GLOBALS['errorMessage']['both_pools_same_site']);
						}
					}
						
				}
			
			}				
			
			// Verify if switching functions the user has no keys in their posession	
				
			if($ID != NULL){
				if(count(array_diff(array_filter(array($Info['function_id'], $Info['function_id_secondary'])), lookup_shareholder_functions($ID))) > 0){
					if(shareholder_box_count($ID) > 0){
						add_message('error', $GLOBALS['errorMessage']['shareholder_still_possesses_key']);
					}
				}
			}
			
			// Prevent change of "function type" unless all functions are unassigned/NULL
			
			if($Info['function_type_id'] != lookup_shareholder_function_type($ID)){
				if(count(lookup_shareholder_functions($ID)) > 0){
					add_message('error', $GLOBALS['errorMessage']['cannot_change_function_type']);
				}
			}
			
			// If no secondary function is given, set it to "unassigned" (for access users) or NULL (for physical key and sysadmin users)
			
			if($Info['function_type_id'] == 2 && !$Info['function_id_secondary']){
				$Info['function_id_secondary'] = 4;
			}elseif($Info['function_type_id'] == 1 || $Info['function_type_id'] == 4){
				$Info['function_id_secondary'] = NULL;
			}

		}elseif($Table == DB_TABLE_SHAREHOLDER_BLACKLIST){
			$Where['shareholder_blacklist_id'] = $ID;
			$Info['username']                  = validate("regex", @$_POST['username'], "username", 1, "basic");

			// Verify the user being blacklisted is not already a shareholder (unless they are a sysadmin, then it doesn't matter)
			
			$Query = "SELECT shareholder_id FROM " . DB_TABLE_SHAREHOLDERS . " WHERE username='" . $Info['username'] . "' AND function_type_id!=4";
			$Result = db_query($Query);
			
			if(row_count($Result)){
				add_message('error', $GLOBALS['errorMessage']['cannot_blacklist_user']);
			}

		}elseif($Table == DB_TABLE_SITES){
			$Where['site_id']  = $ID;
			$Info['site_name'] = validate("regex", @$_POST['site_name'], "site", 1, "text");
		}elseif($Table == DB_TABLE_TAMPER_EVIDENT_BAGS){	
			$Where['bag_id']    = $ID;
			$Info['bag_serial'] = validate("regex", @$_POST['bag_serial'], "bag serial number", 1, "alphanum");
			$Info['used']       = validate("regex", @$_POST['used'], "used", 1, "bool");
		}elseif($Table == DB_TABLE_USERS){
			$Where['user_id']          = $ID;
			$Info['name']              = validate("regex", @$_POST['name'], "name", 1, "text");
			$Info['email']             = validate("email", @$_POST['email'], "email", 1);
			$Info['office_phone']      = validate("regex", @$_POST['office_phone'], "office phone number", 0, "phone");
			$Info['cell_phone']        = validate("regex", @$_POST['cell_phone'], "cell phone number", 0, "phone");
			$Info['title']             = validate("regex", @$_POST['title'], "title", 0, "text");
			$Info['reporting_manager'] = validate("regex", @$_POST['reporting_manager'], "reporting manager", 1, "basic");
			$Info['is_admin']          = validate("regex", @$_POST['is_admin'] , "admin", 1, "bool");
		}elseif($Table == DB_TABLE_USER_ACL){
			$Where['user_acl_id'] = $ID;
			$Info['username']     = validate("regex", @$_POST['username'], "username", 1, "basic");
		}elseif($Table == DB_TABLE_VENDORS){
			$Where['vendor_id']             = $ID;
			$Info['vendor_name']            = validate("regex", @$_POST['vendor_name'], "vendor", 1, "text");
			$Info['vendor_website']         = validate("url",   @$_POST['vendor_website'], "website", 0);
			$Info['vendor_address_street']  = validate("regex", @$_POST['vendor_address_street'], "street address", 0, "text");
			$Info['vendor_address_city']    = validate("regex", @$_POST['vendor_address_city'], "city", 0, "alphanum");
			$Info['vendor_address_state']   = validate("regex", @$_POST['vendor_address_state'], "state", 0, "alphanum");
			$Info['vendor_address_zip']     = validate("regex", @$_POST['vendor_address_zip'], "zip", 0, "zip");
			$Info['vendor_address_country'] = validate("regex", @$_POST['vendor_address_country'], "country", 1, "alphanum");
			$Info['vendor_support_email']   = validate("email", @$_POST['vendor_support_email'], "email", 0);
			$Info['vendor_support_phone']   = validate("regex", @$_POST['vendor_support_phone'], "phone number", 0, "phone");
			$Info['vendor_account_number']  = validate("regex", @$_POST['vendor_account_number'], "account number", 0, "basic");
			$Info['notes']                  = validate("regex", @$_POST['notes'], "notes", 0, "text");
			// $Info['comments']               = validate("regex", @$_POST['comments'], "comments", 0, "text");
		}elseif($Table == DB_TABLE_VENDOR_ATTACHMENTS){
		
			$Filename = preg_replace("/'|\"/", "", str_replace(" ", "_", @$_POST['filename']));
			$FullFilename = "../" . PATH_UPLOADS . '/' . $Filename;

			if(file_exists($FullFilename)){
			
				$Where['attachment_id']         = $ID;
				$Info1['attachment_description'] = validate("regex", @$_POST['attachment_description'], "attachment description", 1, "text");
				$Info1['attachment_name']        = validate("regex", @$Filename, "filename", 1, "text");
				$Info1['attachment_filesize']    = clean_sql_value(filesize($FullFilename));
				$Info1['attachment_filetype']    = clean_sql_value(returnMIMEType($FullFilename));
				$Info1['binary_data']            = clean_sql_value(fread(fopen($FullFilename, "r"), filesize($FullFilename)));
				
				$Info2['vendor_id']              = validate("int",   @$_POST['vendor_id'], "vendor", 1);
		
			}else{
				add_message('error', $GLOBALS['errorMessage']['cannot_locate_file']);
			}
			
		}elseif($Table == DB_TABLE_VENDOR_CONTACTS){
			$Where['vendor_contact_id']          = $ID;
			$Info['vendor_contact_name']         = validate("regex", @$_POST['vendor_contact_name'], "contact name", 1, "text");
			$Info['vendor_contact_title']        = validate("regex", @$_POST['vendor_contact_title'], "title", 1, "text");			
			$Info['vendor_contact_office_phone'] = validate("regex", @$_POST['vendor_contact_office_phone'], "office number", 1, "phone");
			$Info['vendor_contact_cell_phone']   = validate("regex", @$_POST['vendor_contact_cell_phone'], "cell number", 1, "phone");
			$Info['vendor_contact_email']        = validate("email", @$_POST['vendor_contact_email'], "email", 1);
			$Info['vendor_id']                   = validate("int",   @$_POST['vendor_id'], "vendor", 1);
			$Info['priority_rank']               = validate("regex", @$_POST['priority_rank'], "priority rank", 1, "text");
		}elseif($Table == DB_TABLE_SUPPORT_CONTRACTS){
			$Where['support_contract_id']  = $ID;
			$Info['purchase_order_number'] = validate("regex", @$_POST['purchase_order_number'], "purchase order number", 0, "text");			
			$Info['contract_number']       = validate("regex", @$_POST['contract_number'], "contract number", 1, "text");
			$Info['date_start']            = validate("regex", @$_POST['date_start'], "start date", 0, "date");
			$Info['date_end']              = validate("regex", @$_POST['date_end'], "end date", 0, "date");			
			$Info['maintenance_plan_type'] = validate("regex", @$_POST['maintenance_plan_type'], "maintenance plan type", 0, "text");
		}else{
			add_message('error', $GLOBALS['errorMessage']['unknown_table']);
		}

		// If the form is using a bag, make sure it is usable
						
		if(@$Info['bag_id']){

			// This is an update and the bag may still be the same as it was previously
			
			if(@$ID){

				list($Key, $Value) = each($Where);
				$Query = "SELECT bag_id FROM " . $Table . " WHERE " . $Key . "=" . $Value . " AND bag_id=" . $Info['bag_id'];
				$Result = db_query($Query);
				$Row = row_fetch($Result);
				
				// If the bag is different, make sure it is usable
				
				if($Row[0] != $Info['bag_id']){
					if(!can_bag_be_used($Info['bag_id'])){
						add_message('error', $GLOBALS['errorMessage']['bag_already_used']);
					}
				}
			
			// This is a new entry so the bag will always be "different"
			
			}elseif(!can_bag_be_used($Info['bag_id'])){
				add_message('error', $GLOBALS['errorMessage']['bag_already_used']);
			}
			
		}		

		// If all data passes validation write it to the database
		
		if(check_messages()){
		
			if(begin_db_transaction()){
			
				$Success = TRUE;			
		
				#########################
				## Update the database ##
				#########################
				
				if($Submit == "Update"){
				
					// Process admin panel items that involve attachments differently
					
					if($Table == DB_TABLE_VENDOR_ATTACHMENTS || $Table ==  DB_TABLE_EQUIP_ATTACHMENTS){
					
						$Info1['updated_by'] = $UserID;
						
						if(!db_query(create_sql_update($Info1, $Where, DB_TABLE_ATTACHMENTS), FALSE)){ $Success = FALSE; }
						if(!db_query(create_sql_update($Info2, $Where, $Table))){ $Success = FALSE; }

						unlink($FullFilename);	// Cleanup any uploaded files
									
					// Process all other admin panel items
					
					}else{
					
						// Tables that are audited must have a user ID associated with the change
						
						if($Audit){ $Info['updated_by'] = $UserID; }
						
						// Update the table
						
						if(!db_query(create_sql_update($Info, $Where, $Table))){ $Success = FALSE; }

						// If the previous update requires an audit, add the entry to the audit table
						
						if($Audit){						
							if(!create_audit_entry($Table, $Where[$Table . '_id'], $UserID)){ $Success = FALSE; }
						}
						
						// If making a change to any of the shares create a new snapshot
						
						if($Snapshot){
							if(@$OldBox){ if(!create_box_snapshot($OldBox, NULL, NULL, $UserID)){ $Success = FALSE; } }     // New shares don't have an old box
							if($Info['box_id']){ if(!create_box_snapshot($Info['box_id'], NULL, NULL, $UserID)){ $Success = FALSE; } }	// Shares being placed into escrow don't have a "new" box
						}
						
						// If vendor is deleted also delete the associated attachments and contacts
						
						if($Table == DB_TABLE_VENDORS && $ID && $Info['deleted'] == 1){
						
							$Query = "SELECT a.attachment_id FROM " . DB_TABLE_ATTACHMENTS . " a LEFT JOIN " . DB_TABLE_VENDOR_ATTACHMENTS . " va ON va.attachment_id=a.attachment_id WHERE a.deleted=0 AND va.vendor_id=" . $ID;
							$Result = db_query($Query);
							
							while($CurrentAttachement = row_fetch($Result)){
								$AttachmentInfo['deleted']        = 1;
								$AttachmentInfo['updated_by']     = $UserID;
								$AttachmentWhere['attachment_id'] = $CurrentAttachement[0];
								
								if(!db_query(create_sql_update($AttachmentInfo, $AttachmentWhere, DB_TABLE_ATTACHMENTS))){ $Success = FALSE; }
							}
							
							// Delete associated contacts
							
							$ContactInfo['deleted']    = 1;
							$ContactWhere['vendor_id'] = $ID;
						
							if(!db_query(create_sql_update($ContactInfo, $ContactWhere, DB_TABLE_VENDOR_CONTACTS))){ $Success = FALSE; }
						
						// If equipment is deleted also delete the associated attachments
						
						}elseif($Table == DB_TABLE_EQUIP && $ID && $Info['deleted'] == 1){
						
							$Query = "SELECT a.attachment_id FROM " . DB_TABLE_ATTACHMENTS . " a LEFT JOIN " . DB_TABLE_EQUIP_ATTACHMENTS . " ea ON ea.attachment_id=a.attachment_id WHERE a.deleted=0 AND ea.equipment_id=" . $ID;
							$Result = db_query($Query);
							
							while($CurrentAttachement = row_fetch($Result)){
								$AttachmentInfo['deleted']        = 1;
								$AttachmentInfo['updated_by']     = $UserID;
								$AttachmentWhere['attachment_id'] = $CurrentAttachement[0];
								
								if(!db_query(create_sql_update($AttachmentInfo, $AttachmentWhere, DB_TABLE_ATTACHMENTS))){ $Success = FALSE; }
							}					
						
						}
						
					}
				
				###################################
				## Add a new row to the database ##
				###################################
				
				}elseif($Submit == "Add"){
				
					// Process admin panel items that involve attachments
					
					if($Table == DB_TABLE_VENDOR_ATTACHMENTS || $Table ==  DB_TABLE_EQUIP_ATTACHMENTS){
						
						$Info1['created_by']   = $UserID;
						if(!db_query(create_sql_insert($Info1, DB_TABLE_ATTACHMENTS), FALSE)){ $Success = FALSE; }
						$ID = last_query_id();
						
						$Info2['attachment_id'] = $ID;
						if(!db_query(create_sql_insert($Info2, $Table))){ $Success = FALSE; }
						
						unlink($FullFilename);	// Cleanup any uploaded files	
					
					// Process all other admin panel items
					
					}else{
						
						// Tables that are audited must have a user ID associated with the change
						
						if($Audit){ $Info['created_by'] = $UserID; }
					
						// Add to the table
						
						if(!db_query(create_sql_insert($Info, $Table))){ $Success = FALSE; }
						$ID = last_query_id();						
						
						// If the previous insert requires an audit, add the entry to the audit table
						
						if($Audit && $ID){						
							if(!create_audit_entry($Table, $ID, $UserID)){ $Success = FALSE; }				
						}

						// If making a change to any of the shares create a new snapshot
						
						if($Snapshot){
							if(@$OldBox){ if(!create_box_snapshot($OldBox, NULL, NULL, $UserID)){ $Success = FALSE; } }     // New shares don't have an old box
							if($Info['box_id']){ if(!create_box_snapshot($Info['box_id'], NULL, NULL, $UserID)){ $Success = FALSE; } }	// Shares being placed into escrow don't have a "new" box
						}
					}
					
				}
				
				// If the change used a tamper evident bag, mark it as "used" (1) or "opened" (2)
						
				if(@$Info['bag_id'] || $MarkTEBOpened){			
					$BagInfo['used']    = ($MarkTEBOpened ? 2 : 1);
					$BagWhere['bag_id'] = ($MarkTEBOpened ? $MarkTEBOpened : $Info['bag_id']);

					if(!db_query(create_sql_update($BagInfo, $BagWhere, DB_TABLE_TAMPER_EVIDENT_BAGS))){ $Success = FALSE; }

					// Use these values to pass the bag ID back to JavaScript so it can be removed from other dropdowns
					
					$BagMarkedAsUsed = TRUE;
					$BagID = ($MarkTEBOpened ? $MarkTEBOpened : $Info['bag_id']);					
				}
			
				// Commit or rollback the database changes and return a message to the user
			
				if($Success){
					commit_db_transaction();
					add_message('success', "<span class='hidden'>ID $ID</span>" . (@$BagMarkedAsUsed ? "<span class='hidden bag'>$BagID</span>" : NULL) . "Changes to " . str_replace("_", " ", $Table) . " were saved at " . date('H:i:s') . ".");
				}else{
					rollback_db_transaction();
					add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
				}
			
			}else{
				add_message('error', $GLOBALS['errorMessage']['db_unable_to_begin_transaction']);
			}			

		}
	
	}else{
		add_message('error', $GLOBALS['errorMessage']['cant_detect_table']);
	}
	
	// Display any messages
	
	if(!check_messages()){
		echo "<div class='inner_messages'>\n";
			print_messages();
		echo "</div>\n";		
	}
	
	db_close();
		
?>
