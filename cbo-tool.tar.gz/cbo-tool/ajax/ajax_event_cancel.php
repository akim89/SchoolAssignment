<?php

	include("../includes.php");
	require_once('../' . PATH_FRAMEWORK_LANGUAGE . '/en/messages.php');
	autoload_classes();
	db_connect();
			
	$ID = validate("int", @$_POST['event_id'], "event", 1);
	
	if(check_messages()){
	
		// Cancel the event
		
		if(db_query(create_sql_update(array("cancelled" => 1), array("event_id" => $ID), DB_TABLE_EVENTS))){

			// Lookup the recipients of the email

			$Recipients = list_event_recipients($ID);
			
			// Lookup the event information

			$EventInfo = lookup_event_infromation($ID);
			
			// Check to see if any email reminders have been sent yet, if not, this step can be skipped
			
			// if($EventInfo['ical_uid']){
			
				// // Generate the iCal cancellation file
				
				// $meeting = new iCalendarEvent();
				// $meeting->setSubject("CANCELLED: " . $EventInfo['start_date'] . " - " . $EventInfo['site_name'] . " - CBO - " . $EventInfo['event_name'])
				// ->setDescription("This is reminder of your participation in a CBO Event. Please remember to bring your badge.\n\nThank you,\nCBO team")
				// ->setLocation($EventInfo['site_name'])
				// ->setOrganizerEmail(ICAL_FROM)
				// ->setStartTimestamp(gmdate('Y-m-d H:i:s', (strtotime($EventInfo['start_date'] . " " . $EventInfo['start_time']))))
				// ->setEndTimestamp(gmdate('Y-m-d H:i:s', (strtotime($EventInfo['start_date'] . " " . $EventInfo['end_time']))))
				// ->setSequenceNumber(1)
				// ->setEventStatus("CANCELLED")
				// ->setUID($EventInfo['ical_uid']);
			 
				// foreach($Recipients as $Email){
					// if($Email){
						// $attendee = new iCalendarAttendee;
						// $attendee->setEmail($Email)->setRSVP(TRUE);
						// $meeting->addAttendee($attendee);
					// }
				// }
				
				// if(count($meeting->getErrors())){
					// add_message('error', $GLOBALS['successMessage']['cant_create_ical']);				
				// }else{
					// $iCalString = $meeting->returnString()->create();						
				// }
			
			// }

			// Load and replace the template tokens

			$Subject = $EventInfo['subject'];
			$Body    = "This event has been cancelled.";
				
			$Subject = str_replace("%date%", "CANCELLED - " . $EventInfo['start_date'], $Subject);		
			$Subject = str_replace("%reminder_type%", "", $Subject);
			$Subject = str_replace("Reminder", "", $Subject);
			$Subject = str_replace("%site%", $EventInfo['site_name'], $Subject);
			$Subject = str_replace("%event_name%", $EventInfo['event_name'], $Subject);
			
			// Send the email
			
			$Mail = new Rmail();
			$Mail->setFrom(EMAIL_FROM);
			$Mail->setBcc(EMAIL_BCC);
			$Mail->setHeadCharset('utf-8');
			$Mail->setTextCharset('utf-8');
			$Mail->setHTMLCharset('utf-8');
			
			if(get_magic_quotes_gpc()){
				$Mail->setSubject(stripslashes($Subject));
				$Mail->setHTML(stripslashes($Body));
			}else{
				$Mail->setSubject($Subject);
				$Mail->setHTML($Body);
			}
			
			// if($EventInfo['ical_uid']){
				// if(count($meeting->getErrors()) == 0){
					// $Mail->addAttachment(new StringAttachment($iCalString, "cbo_event_cancellation.ics", 'text/Calendar'));
				// }
			// }

			$MailResult = $Mail->send($Recipients);
							
			if($MailResult){
				add_message('success', $GLOBALS['successMessage']['cancellation_email_sent']);				
			}else{
				add_message('error', $GLOBALS['errorMessage']['cancellation_email_failure']);
			}
		
			add_message('success', $GLOBALS['successMessage']['changes_saved']);
			
		}else{
			add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
		}

	}
	
	print_messages();

?>
