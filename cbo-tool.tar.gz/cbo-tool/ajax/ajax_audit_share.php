<?php

	require_once("../includes.php");
	db_connect();

		$ID = clean_sql_value($_GET['id']);
		
		if($ID){
		
			$Query  = "SELECT IF(f.form_name IS NOT NULL, f.form_name, 'Admin Panel') AS form_name, a.form_id, a.execution_id, a.share_id, a.share_label, IF(sh.shareholder_name IS NULL, 'Unassigned', sh.shareholder_name) AS shareholder_name, s.share_type_name, IF(b.box_number IS NOT NULL, b.box_number, 'In Escrow') AS box_number, IF(l.escrow_location_name IS NOT NULL, l.escrow_location_name, 'Not In Escrow') AS escrow_location_name, p.product_name, e.environment_name, k.key_type_name, m.media_type_name, a.mofn_threshold, IF(t.bag_serial IS NOT NULL, t.bag_serial, 'Not In Escrow') AS bag_serial, IF(a.original_distribution_date IS NOT NULL, a.original_distribution_date, 'Not Distributed') AS original_distribution_date, a.date_destroyed, a.share_set, a.last_audit_date, a.notes, a.deleted, u.name, a.audit_date_created FROM " . DB_TABLE_AUDIT_SHARES . " a LEFT JOIN " . DB_TABLE_BOXES . " b ON b.box_id=a.box_id LEFT JOIN " . DB_TABLE_TAMPER_EVIDENT_BAGS . " t ON t.bag_id=a.bag_id LEFT JOIN " . DB_TABLE_USERS . " u ON u.user_id=a.audit_created_by LEFT JOIN " . DB_TABLE_FORMS . " f ON f.form_id=a.form_id LEFT JOIN " . DB_TABLE_SHARE_TYPES . " s ON s.share_type_id=a.share_type_id LEFT JOIN " . DB_TABLE_PRODUCTS . " p ON p.product_id=a.product_id LEFT JOIN " . DB_TABLE_ENVIRONMENTS . " e ON e.environment_id=a.environment_id LEFT JOIN " . DB_TABLE_KEY_TYPES . " k ON k.key_type_id=a.key_type_id LEFT JOIN " . DB_TABLE_MEDIA_TYPES . " m ON m.media_type_id=a.media_type_id LEFT JOIN " . DB_TABLE_ESCROW_LOCATIONS . " l ON l.escrow_location_id=a.escrow_location_id LEFT JOIN " . DB_TABLE_KEYS . " pk ON pk.box_id=b.box_id LEFT JOIN " . DB_TABLE_SHAREHOLDERS . " sh ON sh.shareholder_id=pk.shareholder_id WHERE share_id=" . $ID . " GROUP BY a.audit_share_id ORDER BY audit_date_created";
			$Result = db_query($Query);		
			$Count  = row_count($Result);
			
			if($Count > 0){			

				echo "<div style='width: 2700px;'>";
				
					// Display a header
					
					echo "<div class='boxed_group'>\n";
						echo "<h3>Share</h3>\n";
						echo "<div class='boxed_group_inner clearfix'>\n";
					
							// Display the table
							
							echo "<table id='" . DB_TABLE_SHARES . "_table' class='audit_table'>\n";
								echo "<thead>\n";
									echo "<tr>\n";
										echo "<td width='25'>&nbsp;</td>\n";
										echo "<th>Source</th>\n";
										echo "<th>Share Label</th>\n";
										echo "<th>Share Type</th>\n";
										echo "<th>Shareholder</th>\n";								
										echo "<th>Box</th>\n";
										echo "<th>Escrow Location</th>\n";
										echo "<th>TEB Serial</th>\n";
										echo "<th>Product</th>\n";
										echo "<th>Environment</th>\n";
										echo "<th>Key Type</th>\n";
										echo "<th>Media Type</th>\n";
										echo "<th>M of N Threshold</th>\n";								
										echo "<th>Distribution Date</th>\n";
										echo "<th>Destruction Date</th>\n";
										echo "<th>Share Set</th>\n";
										echo "<th>Last Audit</th>\n";							
										echo "<th>Notes</th>\n";							
										echo "<th>Status</th>\n";
										echo "<th>Changed By</th>\n";
										echo "<th>Change Date</th>\n";
									echo "</tr>\n";
								echo "</thead>\n";
								echo "<tbody>\n";
								
									$Count = 1;
									
									while($Row = row_fetch_assoc($Result)){
									
										foreach($Row as $ID => $Value){
											$Row[$ID] = ($Value ? $Value : "----");
										}
									
										echo "<tr>\n";
											echo "<td>" . $Count . ".</td>\n";
											echo "<td>" . ($Row['form_name'] == "Admin Panel" ? $Row['form_name'] : "<a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . lookup_filename_for_form_execution($Row['form_id'], $Row['execution_id']) . "'>" . $Row['form_name'] . "</a>") . "</td>\n";
											echo "<td>" . $Row['share_label'] . "</td>\n";
											echo "<td>" . $Row['share_type_name'] . "</td>\n";
											echo "<td>" . $Row['shareholder_name'] . "</td>\n";
											echo "<td>" . $Row['box_number'] . "</td>\n";
											echo "<td>" . $Row['escrow_location_name'] . "</td>\n";
											echo "<td>" . $Row['bag_serial'] . "</td>\n";
											echo "<td>" . $Row['product_name'] . "</td>\n";
											echo "<td>" . $Row['environment_name'] . "</td>\n";
											echo "<td>" . $Row['key_type_name'] . "</td>\n";
											echo "<td>" . $Row['media_type_name'] . "</td>\n";
											echo "<td>" . $Row['mofn_threshold'] . "</td>\n";									
											echo "<td>" . $Row['original_distribution_date'] . "</td>\n";
											echo "<td>" . $Row['date_destroyed'] . "</td>\n";
											echo "<td>" . $Row['share_set'] . "</td>\n";
											echo "<td>" . $Row['last_audit_date'] . "</td>\n";							
											echo "<td>" . $Row['notes'] . "</td>\n";							
											echo "<td>" . ($Row['date_destroyed'] && $Row['date_destroyed'] != '----' ? "Decommissioned" : "In Use") . "</td>\n";
											echo "<td>" . $Row['name'] . "</td>\n";
											echo "<td>" . $Row['audit_date_created'] . "</td>\n";		
										echo "</tr>\n";
										
										$Count++;
									}
								
								echo "</tbody>\n";	
							echo "</table>\n";
					
						echo "</div>\n";
					echo "</div>\n";
				echo "</div>\n";
				
			}else{
				add_message('info', $GLOBALS['infoMessage']['no_audit_information']);
				print_messages();
			}
		}
		
	db_close();
	
?>