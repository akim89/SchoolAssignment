<?php

    require_once("../includes.php");

function get_docx_filename($FormID, $form_data, $docx_name_formats) {

  $Filename = lookup_form_name($FormID);

  // Find the form format
  $all_formats=$docx_name_formats['docx_formats'];
  //echo '<pre>' . print_r($all_formats, true) . '</pre>';
  // intialize the format to NA
  $this_format="NA";
  // Check if the category is defined
  $found_format=false;
  foreach ($all_formats as $format => $formIds) {

      foreach ($formIds as $fid) {

          if ($FormID== $fid ) {
              $this_format = $format;
              $found_format=true;
              break;
           };
       };
           if ($found_format) {
                break;
           }
  };

  // if there is FORM File name format id defined in the JSON object
  if ($found_format) {

      $out_docx_name='';
      $cat_parts=preg_split('/-/', $this_format);
      $total_parts=count($cat_parts);
      $x=0;

      // do the SQL query once to get the values to constuct the formname
      $Query = "SELECT * FROM " . DB_TABLE_FORM_LAYOUT . " WHERE form_id='" . $FormID . "' AND field_type='dropdown' AND deleted=0";
      $Result = db_query($Query);

      $RowCount = row_count($Result);
                     
      if($RowCount > 0){
           while($Current = row_fetch_assoc($Result)){

               $Values[$Current['token_name']] = $Current['dropdown_option'];
           }
      }
      else {
         return "NA";
      }
     // constuct the docx filename based on each part of the NAME format found in JSON 
      foreach ($cat_parts as $part) {

          if ($part == "FORMNAME") {
             //construct short formname remove word Attestation
             $f_name_1=str_replace("Attestation", "", $Filename);
             $this_part=str_replace(" ", "", $f_name_1);
          }
          elseif (preg_match('/DATE/', $part)) {
              // format the DATE for the pdf filename
              $act_date=str_replace('-', '', $form_data[$part]);
              $now_time= date('His');
              $this_part=$act_date . $now_time;
          }
          else {

              // Replace form tokens with submitted values
              // Make sure the docx Label format(parts) are defined is in form_data keys
              if (array_key_exists($part,$form_data)) {

                 $form_data_val=$form_data[$part];
                 $layout_key="{{" . $part . "}}";

                 // If the token is based off of a dropdown menu, then lookup the actual value
                 if (array_key_exists($layout_key, $Values)) { 
                     
                    $Value = find_dropdown_value($Values[$layout_key], $form_data_val);
                    $this_part = preg_replace('/\s+/', '_', $Value);
                 }
                 else {
                    // directly assign the values to the label
                   $this_part = $form_data_val;
                }
             }
          }
          $x=$x+1;
          if ($x == $total_parts) {
            // Final construction of the docx file
             $out_docx_name= $out_docx_name. $this_part .'.docx';
          }
          else {
             $out_docx_name=$out_docx_name . $this_part .'-';
          }
    }
    //echo '<pre>' . print_r($out_docx_name, true) . '</pre>';
   }
    else {
    $out_docx_name="NA";
    }
   return $out_docx_name;
}

?>
