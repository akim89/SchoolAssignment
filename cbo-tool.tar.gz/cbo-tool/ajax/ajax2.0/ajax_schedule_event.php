<?php

	include("../../includes.php");
	db_connect();

	$EventInfo['email_template_id'] = validate("int",   @$_POST['email_template_id'][0], "email template", 1);
	$EventInfo['event_name']        = validate("regex", @$_POST['event_name'], "event name", 1, "text");
	$EventInfo['site_id']           = validate("int",   @$_POST['site_id'][0], "site", 1);
	$EventInfo['start_date']        = validate("regex", @$_POST['start_date'], "start date", 1, "date");
	$EventInfo['start_time']        = validate("regex", @$_POST['start_time'][0], "start time", 1, "timehms");
	$EventInfo['end_time']          = validate("regex", @$_POST['end_time'][0], "end time", 1, "timehms");
	$EventInfo['cc_recipients']     = validate("regex", preg_replace("/\s/", "", @$_POST['cc_recipients']), "CC recipients", (count(@array_filter(@$_POST['shareholder_id'])) ? 0 : 1), "text");
	$Products                       = @$_POST['product_id']; validate_array("int", @$_POST['product_id'], "product IDs", 1);
	$Shareholders                   = @$_POST['shareholder_id']; validate_array("int", @$_POST['shareholder_id'], "shareholders", (strlen(trim(@$_POST['cc_recipients'])) ? 0 : 1));
  $Keys                           = @$_POST['physical_key_id']; //validate_array("int", @$_POST['physical_key_id'], "physical keys", (strlen(trim(@$_POST['cc_recipients'])) ? 0 : 1));

	// Make sure each shareholder has a key selected
	if(count($Shareholders) != count($Keys)){
		add_message('error', $GLOBALS['errorMessage']['event_shareholder_key_required']);
	}else{
		if(count($Shareholders)){
			$Count = 0;
			foreach($Shareholders as $ShareholderID){
        if($Keys[$Count] != ""){
          $KeyDetails = lookup_physical_key_info($Keys[$Count]);
          if($KeyDetails['shareholder_id'] != $ShareholderID){
            message_substitution('error', $GLOBALS['errorMessage']['event_shareholder_doesnt_own_key'], lookup_shareholder($ShareholderID));
          }
        }
        $Count++;
			}
		}
	}

	// Make sure the end time comes after the start time
	if(strtotime($EventInfo['start_time']) >= strtotime($EventInfo['end_time'])){
		add_message('error',  $GLOBALS['errorMessage']['end_time_conflict']);
	}

	if(check_messages()){

		if(begin_db_transaction()){

			$Success = TRUE;

			// Add the event details

			if(!db_query(create_sql_insert($EventInfo, DB_TABLE_EVENTS))){ $Success = FALSE; }
			$EventID = last_query_id();

			// Add the event products

			foreach($Products as $ProductID){
				$EventProductInfo['event_id']   = $EventID;
				$EventProductInfo['product_id'] = $ProductID;

				if(!db_query(create_sql_insert($EventProductInfo, DB_TABLE_EVENT_PRODUCTS))){ $Success = FALSE; }
			}

			// Add the event shareholders and keys

			if(count($Shareholders)){
				$Count = 0;
				foreach($Shareholders as $ShareholderID){
					$EventShareholderInfo['event_id']   = $EventID;
					$EventShareholderInfo['shareholder_id'] = $ShareholderID;
					$EventShareholderInfo['physical_key_id'] = $Keys[$Count];
					if(!db_query(create_sql_insert($EventShareholderInfo, DB_TABLE_EVENT_SHAREHOLDERS))){ $Success = FALSE; }
					$Count++;
				}
			}

			// Create the email reminder schedule

			foreach($_GLOBALS['email_reminders'] as $Days){
				$ScheduleInfo['event_id']      = $EventID;
				$ScheduleInfo['trigger_date']  = date('Y-m-d', strtotime("-" . $Days . " day", strtotime($EventInfo['start_date'])));
				$ScheduleInfo['days_notice']   = $Days;

				if(time() < strtotime($ScheduleInfo['trigger_date'])){
					if(!db_query(create_sql_insert($ScheduleInfo, DB_TABLE_EVENT_SCHEDULE))){ $Success = FALSE; }
				}
			}

			// Commit or rollback the database changes and return a message to the user

			if($Success){
				commit_db_transaction();
				add_message('success', $GLOBALS['successMessage']['changes_saved']);
			}else{
				rollback_db_transaction();
				add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
			}

		}else{
			add_message('error', $GLOBALS['errorMessage']['db_unable_to_begin_transaction']);
		}

	}

	print_messages();

?>
