<?php

	include("../../includes.php");
	db_connect();

	$Confirm = FALSE;

	if(isset($_POST['update_event_id'])){
		$Confirm = FALSE;
		$EventID = $_POST['update_event_id'];
	}elseif(isset($_POST['confirm_event_id'])){
		$Confirm = TRUE;
		$EventID = $_POST['confirm_event_id'];
	}

	$EventID                        = validate("int",   @$EventID, "event", 1);
	if(!$Confirm){
		$EventInfo['email_template_id'] = validate("int",   @$_POST['email_template_id'][0], "email template", 1);
		$EventInfo['event_name']        = validate("regex", @$_POST['event_name'], "event name", 1, "text");
		$EventInfo['site_id']           = validate("int",   @$_POST['site_id'][0], "site", 1);
		// $EventInfo['start_date']        = validate("regex", @$_POST['start_date'], "start date", 1, "date");	// Events don't move, they get cancelled and rescheduled
		$EventInfo['start_time']        = validate("regex", @$_POST['start_time'][0], "start time", 1, "timehms");
		$EventInfo['end_time']          = validate("regex", @$_POST['end_time'][0], "end time", 1, "timehms");
		$EventInfo['cc_recipients']     = validate("regex", preg_replace("/\s/", "", @$_POST['cc_recipients']), "CC recipients", (count(@array_filter(@$_POST['shareholder_id'])) || $Confirm ? 0 : 1), "text");
		$Products                       = @$_POST['product_id']; validate_array("int", @$_POST['product_id'], "product IDs", 1);
	}
	$Shareholders                   = @$_POST['shareholder_id']; validate_array("int", @$_POST['shareholder_id'], "shareholders", (strlen(trim(@$_POST['cc_recipients'])) || $Confirm ? 0 : 1));
	$Keys                           = @$_POST['physical_key_id']; //validate_array("int", @$_POST['physical_key_id'], "physical keys", (strlen(trim(@$_POST['cc_recipients'])) || $Confirm ? 0 : 1));

	// Make sure each shareholder has a key selected

	if(count($Shareholders) != count($Keys)){
		add_message('error', $GLOBALS['errorMessage']['event_shareholder_key_required']);
	}else{
		if(count($Shareholders)){
			$Count = 0;
			foreach($Shareholders as $ShareholderID){
        if($Keys[$Count] != ""){
  				$KeyDetails = lookup_physical_key_info($Keys[$Count]);
  				if($KeyDetails['shareholder_id'] != $ShareholderID){
  					message_substitution('error', $GLOBALS['errorMessage']['event_shareholder_doesnt_own_key'], lookup_shareholder($ShareholderID));
  				}
        }
				$Count++;
			}
		}
	}

	if(!$Confirm){

		// Make sure the end time comes after the start time

		if(strtotime($EventInfo['start_time']) >= strtotime($EventInfo['end_time'])){
			add_message('error',  $GLOBALS['errorMessage']['end_time_conflict']);
		}

		// Make sure the start date is at least 2 weeks in the future

		// if(strtotime('+14 day', time()) > strtotime($EventInfo['start_date'])){
			// add_message('error',  $GLOBALS['errorMessage']['event_to_soon']);
		// }
	}

	if(check_messages()){

		// Grab all the shareholders from the database for this event

		$Query = "SELECT * FROM " . DB_TABLE_EVENT_SHAREHOLDERS . " WHERE event_id=" . $EventID;
		$Result = db_query($Query);

		while($Row = row_fetch_assoc($Result)){
			$DBShareholders[$Row['shareholder_id']] = array('row_id' => $Row['event_shareholder_id'], "physical_key_id" => $Row['physical_key_id']);
		}

		if(begin_db_transaction()){

			$Success = TRUE;

			// Add the event details

			if($Confirm === TRUE){
				if(!db_query(create_sql_update(array("confirmed" => 1), array("event_id" => $EventID), DB_TABLE_EVENTS))){ $Success = FALSE; }
			}else{
				if(!db_query(create_sql_update($EventInfo, array("event_id" => $EventID), DB_TABLE_EVENTS))){ $Success = FALSE; }

				// Delete all event products

				if(!db_query(create_sql_update(array("deleted" => 1), array("event_id" => $EventID), DB_TABLE_EVENT_PRODUCTS))){ $Success = FALSE; }

				// Add the event products

				foreach($Products as $ProductID){
					$EventProductInfo['event_id']   = $EventID;
					$EventProductInfo['product_id'] = $ProductID;

					if(!db_query(create_sql_insert($EventProductInfo, DB_TABLE_EVENT_PRODUCTS))){ $Success = FALSE; }
				}
			}

			// Delete all shareholders and keys

			if(!db_query(create_sql_update(array("deleted" => 1), array("event_id" => $EventID), DB_TABLE_EVENT_SHAREHOLDERS))){ $Success = FALSE; }

			// Add the event shareholders and keys

			if(count((array)$Shareholders)){
				$Count = 0;
				foreach($Shareholders as $ShareholderID){

					// Shareholder was never in the database, add them

					if(!isset($DBShareholders[$ShareholderID])){
						$EventShareholderInfo['event_id']   = $EventID;
						$EventShareholderInfo['shareholder_id'] = $ShareholderID;
						$EventShareholderInfo['physical_key_id'] = $Keys[$Count];

						if(!db_query(create_sql_insert($EventShareholderInfo, DB_TABLE_EVENT_SHAREHOLDERS))){ $Success = FALSE; }

					// Shareholder was in the database and was assigned the same key, undelete the entry

					}elseif(isset($DBShareholders[$ShareholderID]) && $DBShareholders[$ShareholderID]['physical_key_id'] == $Keys[$Count]){

						if(!db_query(create_sql_update(array("deleted" => 0), array("event_shareholder_id" => $DBShareholders[$ShareholderID]['row_id']), DB_TABLE_EVENT_SHAREHOLDERS))){ $Success = FALSE; }

					// Shareholder was in the database and was assigned a new key, update and undelete the entry

					}elseif(isset($DBShareholders[$ShareholderID]) && $DBShareholders[$ShareholderID]['physical_key_id'] != $Keys[$Count]){

						if(!db_query(create_sql_update(array("deleted" => 0, "physical_key_id" => $Keys[$Count]), array("event_shareholder_id" => $DBShareholders[$ShareholderID]['row_id']), DB_TABLE_EVENT_SHAREHOLDERS))){ $Success = FALSE; }

					}

					$Count++;
				}
			}

			// Commit or rollback the database changes and return a message to the user

			if($Success){
				commit_db_transaction();
				add_message('success', $GLOBALS['successMessage']['changes_saved']);
			}else{
				rollback_db_transaction();
				add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
			}

		}else{
			add_message('error', $GLOBALS['errorMessage']['db_unable_to_begin_transaction']);
		}

	}

	print_messages();

?>
