<?php

	require_once("../includes.php");
	db_connect();

		$ID = clean_sql_value($_GET['id']);
		
		if($ID){
		
			$Query  = "SELECT IF(f.form_name IS NOT NULL, f.form_name, 'Admin Panel') AS form_name, a.form_id, a.execution_id, a.equipment_id, a.label_name, vendor_name AS vendor, eq.equipment_type_name, a.serial_number, a.asset_tag_number, a.server_name, a.description, a.model_number, a.firmware_version, a.part_number, a.purchase_order_number, a.tamper_seal_number, t.bag_serial, a.servicenow_id, s.site_name, IF(l.escrow_location_name IS NOT NULL, l.escrow_location_name, 'Not In Escrow') AS escrow_location_name, p.product_name, e.environment_name, a.status, a.date_online, a.date_offline, a.date_destroyed, a.rack_location, sc.contract_number, a.notes, IF(a.is_production_capable=1, 'Yes', 'No') AS is_production_capable, IF(a.is_acceptance_tested=1, 'Yes', 'No') AS is_acceptance_tested, a.date_acceptance_tested, a.date_last_verified, a.deleted, u.name, a.audit_date_created FROM " . DB_TABLE_AUDIT_EQUIP . " a LEFT JOIN " . DB_TABLE_USERS . " u ON u.user_id=a.audit_created_by LEFT JOIN " . DB_TABLE_FORMS . " f ON f.form_id=a.form_id LEFT JOIN " . DB_TABLE_PRODUCTS . " p ON p.product_id=a.product_id LEFT JOIN " . DB_TABLE_ENVIRONMENTS . " e ON e.environment_id=a.environment_id LEFT JOIN " . DB_TABLE_TAMPER_EVIDENT_BAGS . " t ON t.bag_id=a.bag_id LEFT JOIN " . DB_TABLE_ESCROW_LOCATIONS . " l ON l.escrow_location_id=a.escrow_location_id LEFT JOIN " . DB_TABLE_SITES . " s ON s.site_id=l.site_id LEFT JOIN " . DB_TABLE_SUPPORT_CONTRACTS . " sc ON sc.support_contract_id=a.support_contract_id LEFT JOIN " . DB_TABLE_EQUIP_TYPES . " eq ON eq.equipment_type_id=a.equipment_type_id LEFT JOIN " . DB_TABLE_VENDORS . " v ON v.vendor_id=a.vendor_id WHERE equipment_id=" . $ID . " ORDER BY audit_date_created";
			$Result = db_query($Query);		
			$Count  = row_count($Result);

			if($Count > 0){
			
				echo "<div style='width: 4000px;'>";
					
					// Display a header
					
					echo "<div class='boxed_group' >\n";
						echo "<h3>Equipment</h3>\n";
						echo "<div class='boxed_group_inner clearfix'>\n";
					
							// Display the table
							
							echo "<table id='" . DB_TABLE_EQUIP . "_table' class='audit_table'>\n";
								echo "<thead>\n";
									echo "<tr>\n";
										echo "<td width='25'>&nbsp;</td>\n";
										echo "<th>Source</th>\n";
										echo "<th>Label</th>\n";
										echo "<th>Vendor</th>\n";
										echo "<th>Type</th>\n";
										echo "<th>Serial Number</th>\n";
										echo "<th>Asset Tag</th>\n";
										echo "<th>Server Name</th>\n";
										echo "<th>Description</th>\n";
										echo "<th>Model Number</th>\n";
										echo "<th>Firmware Version</th>\n";
										echo "<th>Part Number</th>\n";
										echo "<th>PO Number</th>\n";
										echo "<th>Tamper Seal</th>\n";
										echo "<th>TEB Serial</th>\n";
										echo "<th>SeviceNow SysID</th>\n";								
										echo "<th>Escrow Location</th>\n";
										echo "<th>Site</th>\n";
										echo "<th>Product</th>\n";
										echo "<th>Environment</th>\n";
										echo "<th>Status</th>\n";
										echo "<th>Date Online</th>\n";
										echo "<th>Date Offline</th>\n";
										echo "<th>Date Destroyed</th>\n";
										echo "<th>Rack Location</th>\n";
										echo "<th>Contract number</th>\n";
										echo "<th>Notes</th>\n";
										echo "<th>Production Capable</th>\n";
										echo "<th>Acceptance Tested</th>\n";
										echo "<th>Date Acceptance Tested</th>\n";
										echo "<th>Date Last Verified</th>\n";
										echo "<th>Deleted</th>\n";							
										echo "<th>Changed By</th>\n";
										echo "<th>Change Date</th>\n";
									echo "</tr>\n";
								echo "</thead>\n";
								echo "<tbody>\n";
								
									$Count = 1;
									
									while($Row = row_fetch_assoc($Result)){
									
										foreach($Row as $ID => $Value){
											$Row[$ID] = ($Value ? $Value : "----");
										}
										
										echo "<tr>\n";
											echo "<td>" . $Count . ".</td>\n";
											echo "<td>" . ($Row['form_name'] == "Admin Panel" ? $Row['form_name'] : "<a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . lookup_filename_for_form_execution($Row['form_id'], $Row['execution_id']) . "'>" . $Row['form_name'] . "</a>") . "</td>\n";
											echo "<td>" . $Row['label_name'] . "</td>\n";								
											echo "<td>" . $Row['vendor'] . "</td>\n";								
											echo "<td>" . $Row['equipment_type_name'] . "</td>\n";
											echo "<td>" . $Row['serial_number'] . "</td>\n";
											echo "<td>" . $Row['asset_tag_number'] . "</td>\n";
											echo "<td>" . $Row['server_name'] . "</td>\n";
											echo "<td>" . $Row['description'] . "</td>\n";
											echo "<td>" . $Row['model_number'] . "</td>\n";
											echo "<td>" . $Row['firmware_version'] . "</td>\n";
											echo "<td>" . $Row['part_number'] . "</td>\n";
											echo "<td>" . $Row['purchase_order_number'] . "</td>\n";
											echo "<td>" . $Row['tamper_seal_number'] . "</td>\n";
											echo "<td>" . $Row['bag_serial'] . "</td>\n";
											echo "<td>" . $Row['servicenow_id'] . "</td>\n";									
											echo "<td>" . $Row['escrow_location_name'] . "</td>\n";
											echo "<td>" . $Row['site_name'] . "</td>\n";
											echo "<td>" . $Row['product_name'] . "</td>\n";
											echo "<td>" . $Row['environment_name'] . "</td>\n";
											echo "<td>" . $Row['status'] . "</td>\n";
											echo "<td>" . $Row['date_online'] . "</td>\n";
											echo "<td>" . $Row['date_offline'] . "</td>\n";
											echo "<td>" . $Row['date_destroyed'] . "</td>\n";
											echo "<td>" . $Row['rack_location'] . "</td>\n";
											echo "<td>" . $Row['contract_number'] . "</td>\n";
											echo "<td>" . $Row['notes'] . "</td>\n";
											echo "<td>" . $Row['is_production_capable'] . "</td>\n";
											echo "<td>" . $Row['is_acceptance_tested'] . "</td>\n";
											echo "<td>" . $Row['date_acceptance_tested'] . "</td>\n";
											echo "<td>" . $Row['date_last_verified'] . "</td>\n";								
											echo "<td>" . ($Row['deleted'] == 0 ? "No" : "Yes") . "</td>\n";
											echo "<td>" . $Row['name'] . "</td>\n";
											echo "<td>" . $Row['audit_date_created'] . "</td>\n";		
										echo "</tr>\n";
										
										$Count++;
									}
								
								echo "</tbody>\n";	
							echo "</table>\n";	
				
						echo "</div>";
					echo "</div>";
				echo "</div>";
				
			}else{
				add_message('info', $GLOBALS['infoMessage']['no_audit_information']);
				print_messages();
			}
		}
		
	db_close();
	
?>
