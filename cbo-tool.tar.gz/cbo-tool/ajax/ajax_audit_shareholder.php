<?php

	require_once("../includes.php");
	db_connect();

		$ID = clean_sql_value($_GET['id']);
		
		if($ID){
		
			$Query  = "SELECT IF(f.form_name IS NOT NULL, f.form_name, 'Admin Panel') AS form_name, a.form_id, a.execution_id, a.shareholder_id, a.shareholder_name, s.site_name, IF(a.cbo_user=1, 'Yes', 'No') AS cbo_user, IF(a.has_data_center_access=1, 'Yes', 'No') AS has_data_center_access , a.manager_name, ft.function_type_name, fn.function_name, fn2.function_name AS function_name_secondary, a.phone_number, a.desk_location, a.deleted, u.name, a.audit_date_created, a.job_title FROM " . DB_TABLE_AUDIT_SHAREHOLDERS . " a LEFT JOIN " . DB_TABLE_USERS . " u ON u.user_id=a.audit_created_by LEFT JOIN " . DB_TABLE_FORMS . " f ON f.form_id=a.form_id LEFT JOIN " . DB_TABLE_SITES . " s ON s.site_id=a.site_id LEFT JOIN " . DB_TABLE_FUNCTIONS . " fn ON fn.function_id=a.function_id LEFT JOIN " . DB_TABLE_FUNCTIONS . " fn2 ON fn2.function_id=a.function_id_secondary LEFT JOIN " . DB_TABLE_FUNCTION_TYPES . " ft ON ft.function_type_id=a.function_type_id WHERE shareholder_id=" . $ID . " ORDER BY audit_date_created";
			$Result = db_query($Query);		
			$Count  = row_count($Result);

			if($Count > 0){
			
				echo "<div style='width: 2000px;'>";
					
					// Display a header
					
					echo "<div class='boxed_group' >\n";
						echo "<h3>Personnel</h3>\n";
						echo "<div class='boxed_group_inner clearfix'>\n";
					
							// Display the table
							
							echo "<table id='" . DB_TABLE_SHAREHOLDERS . "_table' class='audit_table'>\n";
								echo "<thead>\n";
									echo "<tr>\n";
										echo "<td width='25'>&nbsp;</td>\n";
										echo "<th>Source</th>\n";
										echo "<th>Name</th>\n";
										echo "<th>CBO User</th>\n";
										echo "<th>DC Access</th>\n";
										echo "<th>Manager</th>\n";
										echo "<th>Function Type</th>\n";
										echo "<th>Primary Function</th>\n";
										echo "<th>Secondary Function</th>\n";
										echo "<th>Site</th>\n";
										echo "<th>Phone</th>\n";
										echo "<th>Location</th>\n";
										echo "<th>Job Title</th>\n";
										echo "<th>Deleted</th>\n";							
										echo "<th>Changed By</th>\n";
										echo "<th>Change Date</th>\n";
									echo "</tr>\n";
								echo "</thead>\n";
								echo "<tbody>\n";
								
									$Count = 1;
									
									while($Row = row_fetch_assoc($Result)){
									
										foreach($Row as $ID => $Value){
											$Row[$ID] = ($Value ? $Value : "----");
										}
										
										echo "<tr>\n";
											echo "<td>" . $Count . ".</td>\n";
											echo "<td>" . ($Row['form_name'] == "Admin Panel" ? $Row['form_name'] : "<a target='_blank' href='" . PATH_FORMS_COMPLETED . "/" . lookup_filename_for_form_execution($Row['form_id'], $Row['execution_id']) . "'>" . $Row['form_name'] . "</a>") . "</td>\n";
											echo "<td>" . $Row['shareholder_name'] . "</td>\n";								
											echo "<td>" . $Row['cbo_user'] . "</td>\n";								
											echo "<td>" . $Row['has_data_center_access'] . "</td>\n";								
											echo "<td>" . $Row['manager_name'] . "</td>\n";								
											echo "<td>" . $Row['function_type_name'] . "</td>\n";								
											echo "<td>" . $Row['function_name'] . "</td>\n";								
											echo "<td>" . $Row['function_name_secondary'] . "</td>\n";								
											echo "<td>" . $Row['site_name'] . "</td>\n";								
											echo "<td>" . $Row['phone_number'] . "</td>\n";								
											echo "<td>" . $Row['desk_location'] . "</td>\n";								
											echo "<td>" . $Row['job_title'] . "</td>\n";								
											echo "<td>" . ($Row['deleted'] == 0 ? "No" : "Yes") . "</td>\n";
											echo "<td>" . $Row['name'] . "</td>\n";
											echo "<td>" . $Row['audit_date_created'] . "</td>\n";		
										echo "</tr>\n";
										
										$Count++;
									}
								
								echo "</tbody>\n";	
							echo "</table>\n";	
				
						echo "</div>";
					echo "</div>";
				echo "</div>";
				
			}else{
				add_message('info', $GLOBALS['infoMessage']['no_audit_information']);
				print_messages();
			}
		}
		
	db_close();
	
?>
