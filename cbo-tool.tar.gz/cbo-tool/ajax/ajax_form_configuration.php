<?php

	require_once("../includes.php");
	db_connect();	

	############################
	##     DELETE A FORM      ##
	############################
	
	if(@$_GET['submit'] == "Delete"){
	
		$FormID = validate("int", @$_GET['form_id'], "form ID", 1);
		
		// If no errors have occurred update the info to the database
		
		if(check_messages()){
			
			// Cleanup any database entries for this form
			
			if(!db_query(create_sql_update(array("deleted" => 1), array('form_id' => $FormID), DB_TABLE_FORMS))){
				add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
			}
			
			// If the database was cleaned up, delete the file
			
			if(check_messages()){

				$FormName = lookup_form_name($FormID);
				$Filename = lookup_form_filename($FormID);			
			
				if(rename(PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS . "/" . $Filename, PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_DELETED . "/" . $Filename)){
					add_message('success', "<span class='deleted_file hidden'>" . $FormID . "</span>" . $FormName . " has been sucessfully deleted.");
				}else{
					add_message('error', $GLOBALS['errorMessage']['unable_to_delete']);
				}
			}
		}
		
	
	############################
	##    PROCESS THE FORM    ##
	############################
		
	}elseif(preg_match('/Create Web Form|Update Web Form/', @$_POST['submit'])){
	
		$Count = 1;
		$Rows = array();
		
		// Validate all the data
		
		$FormID = validate("int", @$_POST['form_id'], "form ID", 1);
		
		while($Count <= $_POST['count']){
		
			$Rows[$Count]['field_name'] = validate("regex", @$_POST["field_name{$Count}"], "field name (row $Count)", 1, "text");
			$Rows[$Count]['token_name'] = validate("regex", @$_POST["token{$Count}"], "token (row $Count)", 1, "text");
			$Rows[$Count]['field_type'] = validate("regex", @$_POST["field_type{$Count}"], "field type (row $Count)", 1, "short");
			
			$IsRequired = ($Rows[$Count]['field_type'] == "dropdown" ? 1 : 0);			
			$Rows[$Count]['dropdown_option'] = validate("regex", @$_POST["dropdown_option{$Count}"], "dropdown option (row $Count)", $IsRequired, "short");
						
			$IsRequired = (preg_match('/^shareholder_?.*$/', $Rows[$Count]['dropdown_option']) ? ($Rows[$Count]['token_name'] == "{{SHAREHOLDER}}" && preg_match('/34|36/', $FormID) ? 0 : 1) : 0);
			$Rows[$Count]['role_id'] = validate("int", @$_POST["role_id{$Count}"], "role (row $Count)", $IsRequired);
			
			$IsRequired = (preg_match('/\{\{ITEM[0-9]{1,2}.*\}\}/', $Rows[$Count]['token_name']) && !preg_match('/^(18|35)$/', $FormID) ? 0 : ($Rows[$Count]['field_type'] == "dropdown" && preg_match('/^shareholder_?.*$/', $Rows[$Count]['dropdown_option']) ? ($Rows[$Count]['token_name'] == "{{SHAREHOLDER}}" && preg_match('/34|36/', $FormID) ? 1 : 0) : 1));	
			$Rows[$Count]['table_column_name'] = validate("regex", @$_POST["table_column_name{$Count}"], "database column name (row $Count)", $IsRequired, "basic");
			
			$Rows[$Count]['auto_populate_trigger'] = validate("regex", @$_POST["auto_populate_trigger{$Count}"], "auto-populate trigger (row $Count)", (@$_POST["auto_populate_value{$Count}"] ? 1 : 0), "basic");
			$Rows[$Count]['auto_populate_value'] = validate("regex", @$_POST["auto_populate_value{$Count}"], "auto-populate value (row $Count)", (@$_POST["auto_populate_trigger{$Count}"] ? 1 : 0), "basic");
			
			$Count++;		
		}
		
		// If no errors have occurred add the info to the database
		
		if(check_messages()){
		
			// Start the database transaction
			
			if(begin_db_transaction()){
			
				// Cleanup any previous entries
				
				db_query(create_sql_update(array("deleted" => 1), array('form_id' => $FormID), DB_TABLE_FORM_LAYOUT));
			
				// Add the new entries
				
				$Success = TRUE;
				foreach($Rows as $Current){				
					$Current['form_id'] = $FormID;	// Append to "Current" array
					if(!db_query(create_sql_insert($Current, DB_TABLE_FORM_LAYOUT))){ $Success = FALSE; }
				}
			
				// Commit or rollback the changes
				
				($Success ? commit_db_transaction() : rollback_db_transaction());
				
				// Display a success or error message
				
				$Success ? add_message('success', "Changes to " . lookup_form_name($FormID) . " have been saved.") : add_message('error', $GLOBALS['errorMessage']['db_write_failure_multiple']);
		
			}else{
				add_message('error', $GLOBALS['errorMessage']['db_unable_to_begin_transaction']);
			}
		}	
	
	############################
	##    DISPLAY THE FORM    ##
	############################
	
	}elseif(@$_REQUEST['form_id']){
		
		// Setup some file/directory variables
		
		$TempDirectory = PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_TEMP;
		$FormID        = validate("int", @$_GET['form_id'], "form ID", 1);
		$Filename      = lookup_form_filename($FormID);

		// Verify that the form exists and that we can uncompress it
		
		if(unzip_docx($Filename)){
			
			// Find all possible tokens in the XML file

			preg_match_all("/\{\{([^\}]+)\}\}/", file_get_contents($TempDirectory . "/word/document.xml"), $Matches);
			$Matches = array_filter($Matches[0], create_function('$Value', 'if(!preg_match("/\{\{IGNORE_.*/", $Value)){ return $Value; }'));		// Remove "ignoreable" tokens
			
			// Generate an array of "clean" tokens
			
			foreach($Matches as $CurrentMatch){
				$CleanToken = str_replace('}', '', str_replace('{', '', $CurrentMatch));	
				$AllTokens[$CleanToken] = $CleanToken;
			}
			
			// Cleanup the temp files
			
			recursive_remove_directory($TempDirectory, TRUE);			

			// Find the table name
			
			$Query = "SELECT form_table FROM " . DB_TABLE_FORMS . " WHERE form_id=" . $FormID;
			$Result = db_query($Query);
			$Row = row_fetch($Result);			

			$Query = "SELECT * FROM " . $Row[0] . " LIMIT 1";
			$Result = db_query($Query);
			$AllTableColumns = fetch_field_names($Result);
			
			$RemoveColumns = array('date_created', 'date_updated', 'created_by', 'updated_by', 'approved_by', 'rejected_by', 'deleted', 'status_id', 'decision_date', 'filename', 'id', 'filename_signed');
			$TableColumns = array_diff($AllTableColumns, $RemoveColumns);
			
			foreach($TableColumns as $Current){
				$Columns[$Current] = $Current;
			}
			
			// Load the form data (if avaliable)
			
			$Query = "SELECT * FROM " . DB_TABLE_FORM_LAYOUT . " WHERE form_id='" . $FormID . "' AND deleted=0";
			$Result = db_query($Query);
			$RowCount = row_count($Result);
			
			if($RowCount > 0){
				while($Current = row_fetch_assoc($Result)){									
					$Values[$Current['token_name']] = array("field_name" => $Current['field_name'], "field_type" => $Current['field_type'], "dropdown_option" => $Current['dropdown_option'], "role_id" => $Current['role_id'], "table_column_name" => $Current['table_column_name'], "auto_populate_trigger" => $Current['auto_populate_trigger'], "auto_populate_value" => $Current['auto_populate_value']);
				}
			}		

			// If at least one token was found, generate the form
			
			if(array_filter($Matches)){
			
				echo "<div style='width: 1640px; margin-bottom: 20px;'>";
			
					// Display the form
					
					form_start(array("use_table" => FALSE, "action" => $_SERVER['PHP_SELF'], "name" => "configure_form"));
					
						echo "<table id='form_manager'>\n";			
							echo "<thead>\n";		
							
								echo "<tr>\n";					
									echo "<th width='12' class='clear'>&nbsp;</th>\n";
									echo "<th>Field Name</th>\n";
									echo "<th width='230'>Token</th>\n";
									echo "<th width='150'>DB Column Name</th>\n";
									echo "<th width='150'>Field Type</th>\n";
									echo "<th width='160'>Possible Values</th>\n";					
									echo "<th width='150'>Role</th>\n";					
									echo "<th width='170'>Auto-Populate Trigger</th>\n";					
									echo "<th width='170'>Auto-Populate Value</th>\n";					
								echo "</tr>\n";	
								
							echo "</thead>\n";				
							echo "<tbody>\n";	
							
								sort($Matches);
								$Count = 0;
								
								// Place each token on its own row
								
								foreach(array_unique($Matches) as $Token){
									$Count++;
									
									echo "<tr id='row-$Count'>\n";					
										echo "<td>$Count.</td>\n";
										echo "<td>\n";
											form_text_field(array("use_table" => FALSE, "name" => "field_name$Count", "value" => @$Values[$Token]['field_name']));
										echo "</td>\n";
										echo "<td>\n";									
											form_text_field(array("use_table" => FALSE, "name" => "token$Count", "value" => $Token, "disabled" => TRUE));									
										echo "</td>\n";									
										echo "<td align='center'>";									
											form_dropdown(array("use_table" => FALSE, "name" => "table_column_name$Count", "multiselect" => TRUE, "css" => "class='table_column_name'", "items" => $Columns, "value" => @$Values[$Token]['table_column_name'], "disabled" => (preg_match('/\{\{ITEM[0-9]{1,2}.*\}\}/', $Token) && !preg_match('/^(18|35)$/', $FormID) ? "disabled='disabled'" : (preg_match('/^shareholder_?.*$/', @$Values[$Token]['dropdown_option']) ? ($Token == "{{SHAREHOLDER}}" && preg_match('/34|36/', $FormID) ? NULL : "disabled='disabled'") : NULL)), "select_opt" => FALSE));
										echo "</td>\n";										
										echo "<td align='center'>";									
											form_dropdown(array("use_table" => FALSE, "name" => "field_type$Count", "multiselect" => TRUE, "css" => "class='field_type'", "items" => field_types(), "value" => @$Values[$Token]['field_type'], "select_opt" => FALSE));
										echo "</td>\n";
										echo "<td align='center'>";									
											form_dropdown(array("use_table" => FALSE, "name" => "dropdown_option$Count", "multiselect" => TRUE, "css" => "class='dropdown_option'", "items" => dropdown_options(), "value" => @$Values[$Token]['dropdown_option'], "disabled" => (@$Values[$Token]['dropdown_option'] ? NULL : "disabled='disabled'"), "select_opt" => FALSE));
										echo "</td>\n";		
										echo "<td align='center'>";									
											form_dropdown(array("use_table" => FALSE, "name" => "role_id$Count", "multiselect" => TRUE, "css" => "class='role_id'", "items" => list_roles(), "value" => @$Values[$Token]['role_id'], "disabled" => (@$Values[$Token]['role_id'] ? NULL : "disabled='disabled'"), "select_opt" => FALSE));
										echo "</td>\n";										
										echo "<td align='center'>";									
											form_dropdown(array("use_table" => FALSE, "name" => "auto_populate_trigger$Count", "multiselect" => TRUE, "css" => "class='auto_populate_trigger'", "items" => $AllTokens, "value" => @$Values[$Token]['auto_populate_trigger'], "disabled" => (@$Values[$Token]['field_type'] == "date" ? "disabled='disabled'" : NULL), "select_opt" => FALSE));
										echo "</td>\n";	
										echo "<td align='center'>";									
											form_dropdown(array("use_table" => FALSE, "name" => "auto_populate_value$Count", "multiselect" => TRUE, "css" => "class='auto_populate_value'", "items" => auto_populate_choices(), "value" => @$Values[$Token]['auto_populate_value'], "disabled" => (@$Values[$Token]['field_type'] == "date" ? "disabled='disabled'" : NULL), "select_opt" => FALSE));
										echo "</td>\n";	
									echo "</tr>\n";					
								}
								
							echo "</tbody>\n";			
						echo "</table>\n";		
					
						form_hidden(array("use_table" => FALSE, "value" => $FormID, "name" => 'form_id'));
						form_hidden(array("use_table" => FALSE, "value" => $Count, "name" => "count"));
						form_submit(array("use_table" => FALSE, "value" => ($RowCount > 0 ? "Update Web Form" : "Create Web Form"), "id" => "configure"));
					form_end(array("use_table" => FALSE));	
				
				echo "</div>";
			
			}else{
				add_message('warning', $GLOBALS['warningMessage']['no_tokens_found']);
			}
			
		}else{
			add_message('error', $GLOBALS['errorMessage']['from_doesnt_exist']);	// Could also mean we were unable to decompress it (check file permissions)
		}
		
	}else{	
		add_message('error', $GLOBALS['errorMessage']['cant_detect_form']);		
	}
	
	// Display any messages
	
	if(!check_messages()){
		echo "<div class='inner_messages'>\n";
			print_messages();
		echo "</div>\n";		
	}
	
	db_close();
		
?>
