<?php

	include("../includes.php");
	autoload_classes();
	db_connect();

	$Action         = $_GET['action'];
	$UserID         = validate("int", $_COOKIE['user_id'], "user ID", 1, NULL, $GLOBALS['errorMessage']['cookie_no_detect_user']);
	$TypeID         = validate("int", @$_POST['type_id'], "notification type", ($Action == "start" ? 1 : 0));
	$SiteID         = validate("int", @$_POST['site_id'], "site", ($Action == "start" ? 1 : 0));
	$WorkLocationID = validate("int", @$_POST['work_location_id'], "work location", ($Action == "start" && @$_POST['type_id'] == 1 ? 1 : 0));
	$NotificationID = validate("int", @$_POST['notification_id'], "notification ID", ($Action == "end" ? 1 : 0));

	// Make sure a valid action was submitted

	if(!preg_match('/^(start|end)$/', $Action)){
		add_message('error', $GLOBALS['errorMessage']['invalid_security_action']);
	}

	if(check_messages()){

		$DBSuccess = TRUE;

		// Update the database

		if($Action == "start"){

			// Set email recipients

			if($TypeID == 1){
				$Recipients[] = "naming-cbo@verisign.com";
				if($SiteID == 5){	// ILG
					$Recipients[] = "Site-SecurityDelaware@verisign.com";
				}else{	// BRN & FRI
					$Recipients[] = "Site-SecurityEast@verisign.com";
				}
			}elseif($TypeID == 2){
				$Recipients[] = "rjacobson@verisign.com";
			}elseif($TypeID == 3){
				$Recipients[] = "mpalmer@verisign.com";
			}

			// Add record to database

			$Info['security_notification_type_id'] = $TypeID;
			$Info['site_id']	                   = $SiteID;
			$Info['work_location_id']              = $WorkLocationID;
			$Info['recipients']                    = implode(',', $Recipients);
			$Info['start_send_time']               = "NOW()";
			$Info['created_by']                    = $UserID;

			if(!db_query(create_sql_insert($Info, DB_TABLE_SECURITY_NOTIFICATIONS))){ $DBSuccess = FALSE; }

		}else{

			$Query = "SELECT * FROM " . DB_TABLE_SECURITY_NOTIFICATIONS . " WHERE security_notification_id=" . $NotificationID;
			$Result = db_query($Query);
			$Data = row_fetch_assoc($Result);

			$Recipients = explode(',', $Data['recipients']);

			// Update record in database

			$Info['end_send_time']             = "NOW()";
			$Info['updated_by']                = $UserID;
			$Where['security_notification_id'] = $NotificationID;

			if(!db_query(create_sql_update($Info, $Where, DB_TABLE_SECURITY_NOTIFICATIONS))){ $DBSuccess = FALSE; }
		}

		if($DBSuccess){
			add_message('success', $GLOBALS['successMessage']['changes_saved']);
		}else{
			add_message('error', $GLOBALS['errorMessage']['db_write_failure']);
		}

		// Setup email variables

		if($TypeID == 1){
			$UserInfo = lookup_user_information($UserID);
			$From = $UserInfo['email'];
			$BCC = EMAIL_BCC;

			if($Action == "start"){
				$Subject = date('Y-m-d') . ": " . lookup_site($SiteID) . " - Working in " . lookup_work_location($WorkLocationID);
				$Body = "Team,<br><br>We will be working in the " . strtolower(lookup_work_location($WorkLocationID)) . ". Please disregard the alarms.<br><br>Thanks,<br>" . $UserInfo['name'];
			}else{
				$Subject = date('Y-m-d') . ": " . lookup_site($Data['site_id']) . " - Working in " . lookup_work_location($Data['work_location_id']);
				$Body = "Team,<br><br>We have completed working in the " . strtolower(lookup_work_location($Data['work_location_id'])) . ". Please resume monitoring.<br><br>Thanks,<br>" . $UserInfo['name'];
			}

		}elseif($TypeID == 2){
			$From = "naming-cbo@verisign.com";
			$BCC = "naming-cbo@verisign.com,janwilliams@verisign.com";
			$Subject = "Traka Box Check for " . lookup_site($SiteID) . " Safe Room";
			$Body = "Ricardo,<br><br>The CBO team is having an event tomorrow in " . lookup_site($SiteID) . ". Could you please check to ensure the Traka Box at " . lookup_site($SiteID) . " is working properly so that we can be prepared in case it isn’t operating correctly.<br><br>Thanks,<br>CBO Team";

		}elseif($TypeID == 3){
			$From = "naming-cbo@verisign.com";
			$BCC = "naming-cbo@verisign.com";
			$Subject = "Ceremony Room/Safe Room temperature Check in " . lookup_site($Data['site_id']);
			$Body = "Mark,<br><br>Could you please make sure the temperature in the " . lookup_site($SiteID) . " Ceremony and Safe room is set to 70°F? We want to make sure that the room maintains a comfortable temperature for our shareholders during the event.<br><br>Thanks,<br>CBO Team";

		}

		// Send the email

		$Mail = new Rmail();
		$Mail->setFrom($From);
		$Mail->setBcc($BCC);
		$Mail->setHeadCharset('utf-8');
		$Mail->setTextCharset('utf-8');
		$Mail->setHTMLCharset('utf-8');

		if(get_magic_quotes_gpc()){
			$Mail->setSubject(stripslashes($Subject));
			$Mail->setHTML(stripslashes($Body));
		}else{
			$Mail->setSubject($Subject);
			$Mail->setHTML($Body);
		}

		if($Mail->send($Recipients)){
			add_message('success', $GLOBALS['successMessage']['email_sent']);
		}else{
			add_message('error', $GLOBALS['errorMessage']['email_failed']);
		}

	}

	print_messages();

?>
