<?php

	require_once("includes.php");
	db_connect();	
	
	// If the user is not an admin redirect them to the default page
	
	if(!is_admin(clean_sql_value($_COOKIE['user_id']))){
		redirect('.');
	}
	
	header_start("Form Configuration");
	multiselect_headers();
	uploadify_headers();
	custom_jquery_alert_boxes();
	
?>
	
	<script>
	
		$(document).ready(function(){
		
			<!-- Display the uploader -->

			$('#uploadify_filename').uploadify({
				'uploader'        : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify.swf',
				'script'          : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify.php',
				'cancelImg'       : '<?php echo PATH_JS_UPLOADIFY; ?>/cancel.png',
				'folder'          : '<?php echo PATH_FORMS; ?>',
				'removeCompleted' : false,
				'sizeLimit'       : <?php echo UPLOADIFY_FILESIZE; ?>,								
				'expressInstall'  : '<?php echo PATH_JS_UPLOADIFY; ?>/expressInstall.swf',
				'auto'            : true,
				'fileExt'         : '*<?php echo FROMS_FILE_EXTENSION; ?>',
				'fileDesc'        : 'Word Documents (*<?php echo FROMS_FILE_EXTENSION; ?>)'
			});
			
			<!-- Style the single-select dropdown menus -->
				
			$('.forms_dropdown').multiselect({
				multiple: false,
				header: "Select a form",
				noneSelectedText: "Select a form",
				selectedList: 1,
				minWidth: 350
			}).multiselectfilter();
			
			<!-- Load the form information via AJAX -->
			
			$('#edit_forms').on('change', function(){
				$.ajax({
					type: "GET",  
					url: "<?php echo PATH_AJAX; ?>/ajax_form_configuration.php",  
					data: "form_id=" + $('#edit_forms > option:selected').val(),  
					success: function(response){
						
						// Display the repsonse
						
						$('#results').slideDown(0500).html(response);
												
						// Skin the dropdown menus

						$('.field_type, .dropdown_option, .role_id, .table_column_name, .auto_populate_trigger, .auto_populate_value').multiselect({
							multiple: false,
							header: "Select an option",
							noneSelectedText: "Select an option",
							selectedList: 1,
							minWidth: 170
						});
		
						// Skin the button
						
						$('input:submit').button();
						
						// Update the auto-populate fields
						
						$('.auto_populate_trigger > option:selected:first').trigger('change');
						
						// Clear out any messages
						
						$('#edit_messages').html("");
						
					} 
				});			
			});
			
			<!-- Load the unmapped form information via AJAX -->

			$('#unmapped_forms').on('change', function(){
				$.ajax({
					type: "GET",  
					url: "<?php echo PATH_AJAX; ?>/ajax_form_map.php",  
					data: "filename=" + $('#unmapped_forms > option:selected').val(),  
					success: function(response){
						
						// Display the repsonse
						
						$('#unmapped_results').slideDown(0500).html(response);
						
						// Skin the dropdown menus

						$('#form_table').multiselect({
							multiple: false,
							header: "Select an option",
							noneSelectedText: "Select an option",
							selectedList: 1,
							minWidth: 145
						});
		
						// Skin the button
						
						$('input:submit').button();
						
						// Clear out any messages
						
						$('#unmapped_messages').html();
					} 
				});	
			});
			
			<!-- Intercept the form submission and send the data via AJAX -->
			
			$('#configure:submit').live('click', function(e){
			
				// Create an object composed of all form fields
				
				var data = new Object();
				$('#configure_form').find('input').each(function(){
					var name  = $(this).attr('name');
					var value = $(this).val();
					
					data[name] = value;
				});		

				$('#configure_form').find('select').each(function(){
					var name  = $(this).attr('name');
					var value = $(this).multiselect("getChecked").val();
					
					data[name] = value;
				});	
			
				// Submit the form
				
				$.ajax({
					type: "POST",  
					url: "<?php echo PATH_AJAX; ?>/ajax_form_configuration.php",  
					data: data,
					success: function(response) {  
						$('#edit_messages').html(response);											
					} 
				});

				return false;
			});
			
			<!-- Intercept the unmapped form submission and send the data via AJAX -->
			
			$('#map_it:submit').live('click', function(e){
			
				var filename = $('#unmapped_forms').multiselect("getChecked").val();
			
				// Create an object composed of all form fields
				
				var data = new Object();
				$('#unmapped_form').find('input').each(function(){
					var name  = $(this).attr('name');
					var value = $(this).val();
					
					data[name] = value;
				});		

				$('#unmapped_form').find('select').each(function(){
					var name  = $(this).attr('name');
					var value = $(this).multiselect("getChecked").val();
					
					data[name] = value;
				});	
			
				// Submit the form
				
				$.ajax({
					type: "POST",  
					url: "<?php echo PATH_AJAX; ?>/ajax_form_map.php",  
					data: data,
					success: function(response) {  
						if(/success/.exec(response)){
							$('#unmapped_results').html("");			// Delete the form
							$('#unmapped_messages').html(response);		// Display success message	
							$('#unmapped_forms').find('option[value="'+filename+'"]').remove().end().multiselect("refresh");	// Refresh the form dropdown menu
						}else{
							$('#unmapped_messages').html(response);		// Display errors									
						}
					} 
				});

				return false;
			});
			
			<!-- Enable some additional dropdown menus if "Dropdown" or "Text" is selected from "Field Type" -->
			
			$('.field_type').live('change', function(){
				var row = $(this).parents('tr');
				
				// Enable or disable the "Possible Values" dropdown menu
				
				if($(this).find('option:selected').val() == "dropdown"){
					row.find('.dropdown_option').multiselect('enable');
				}else{					
					row.find('.dropdown_option').multiselect('uncheckAll').multiselect('disable');
				}
				
				// Enable or disable the "Auto-Populate" dropdown menus
				
				if($(this).find('option:selected').val() == "dropdown" || $(this).find('option:selected').val() == "text"){
					row.find('.auto_populate_value, .auto_populate_trigger').multiselect('enable');
				}else{					
					row.find('.auto_populate_value, .auto_populate_trigger').multiselect('uncheckAll').multiselect('disable');
				}
				
				// For "courier" forms we need to disable the DB column
				
				var selectedForm = $('#edit_forms').val();
				if(selectedForm != 35 && selectedForm != 18){	// HSM Activation & Reactivation forms use ITEM tokens but should be able to selected a DB column
					row.find('input').filter(function(){
						return /^\{\{ITEM[0-9]{1,2}.*\}\}$/.test(this.value); 
					}).parent().next('td').find('select').val('').attr('disabled', true).multiselect('disable');
				}
			});
			
			<!-- Enable an additional "Role" dropdown menu if "Shareholders" is selected from "Possible Values" and disable the "DB Column Name" -->
			
			$('.dropdown_option').live('change', function(){
				var row = $(this).parents('tr');
				var selectedForm = $('#edit_forms').val();
				var specialFieldExists = row.find('[value="{{SHAREHOLDER}}"]').length;
				
				// Enable or disable the "Roles" dropdown menu
				
				var selectedValue = $(this).find('option:selected').val();

				if(!!selectedValue && selectedValue.match(/^shareholder_?.*$/)){
					if(specialFieldExists == 1 && (selectedForm == 34 || selectedForm == 36)){
						// If the selected form is the "shareholder function/role change" form and the token is {{SHAREHOLDER}} do not make any changes to the web form
					}else{
						row.find('.role_id').multiselect('enable');
						row.find('.table_column_name').val('').multiselect("uncheckAll").multiselect("disable");
					}
				}else{					
					row.find('.role_id').multiselect('uncheckAll').multiselect('disable');
					row.find('.table_column_name').multiselect("enable");
				}
				
				// For "courier" forms we need to disable the DB column
						
				if(selectedForm != 35 && selectedForm != 18){	// HSM Activation & Reactivation forms use ITEM tokens but should be able to selected a DB column
					row.find('input').filter(function(){
						return /^\{\{ITEM[0-9]{1,2}.*\}\}$/.test(this.value); // Find if a special token exists
					}).parent().next('td').find('select').val('').attr('disabled', true).multiselect('disable');	// If it exists, move to the next dropdown and disable it
				}
			});
									
			<!-- Delete a form -->
			
			$('#delete_forms').on('change', function(){
				$.alerts.okButton = "Yes";
				$.alerts.cancelButton = "Cancel";
				
				jConfirm('Are you sure you want to delete this form and its layout configuration?', 'Confirm Deletion', function(r){							
					if(r){
						$.ajax({
							type: "GET",  
							url: "<?php echo PATH_AJAX; ?>/ajax_form_configuration.php",  
							data: "submit=Delete&form_id=" + $('#delete_forms > option:selected').val(),  
							success: function(response) {  
								$('#delete_messages').slideDown(0500).html(response);
								
								// If a sucess message came back, remove the filename from all form dropdown menus
								
								var deletedFile = $('#delete_messages').find('.deleted_file').text();
								if(!!deletedFile){
									if($('#edit_forms > option:selected').val() == deletedFile){
										$('#edit_messages, #results').html("");
									}
									$('.forms_dropdown').find('option[value="'+deletedFile+'"]').remove().end().multiselect("refresh");
								}
							} 
						});
					}else{
						return false;
					}						
				});			
			
			});
					
		});
		
	</script>
	
<?php

	body_start();	
	navigation_start("form");

		echo "<div align='center'>";
			
			// Display the uploader
			
			echo "<div class='boxed_group'>\n";
				echo "<h3>Upload a New Form</h3>";
				echo "<div class='boxed_group_inner clearfix'>\n";				
					echo "Select the form you would like to upload.<br /><br />\n";				
					echo "<input id='uploadify_filename' name='uploadify_filename' type='file' />\n";				
				echo "</div>\n";
			echo "</div>\n";
			
			// Display a list of uploaded forms that have not yet been mapped
			
			if($UnmappedForms = list_unmapped_forms()){
			
				echo "<div class='boxed_group'>\n";
					echo "<h3>Unmapped Forms</h3>";			
					echo "<div class='boxed_group_inner clearfix'>\n";
							
						echo "<div class='vertical_margin_10px'>";					
							form_dropdown(array("use_table" => FALSE, "name" => "unmapped_forms", "multiselect" => TRUE, "css" => "class='forms_dropdown'", "items" => $UnmappedForms, "select_opt" => FALSE));
						echo "</div>";
						
						// Containers to hold the AJAX responses
						
						echo "<div id='unmapped_messages'></div>";			
						echo "<div id='unmapped_results'></div>";

					echo "</div>\n";
				echo "</div>\n";
	
			}
			
			// Display forms that have had the initial configuration
			
			if($Forms = list_forms()){
			
				// Display a list of avaliable forms
				
				echo "<div class='boxed_group'>\n";
					echo "<h3>Form Layout Configuration</h3>";			
					echo "<div class='boxed_group_inner clearfix'>\n";
							
						echo "<div class='vertical_margin_10px'>";					
							form_dropdown(array("use_table" => FALSE, "name" => "edit_forms", "multiselect" => TRUE, "css" => "class='forms_dropdown'", "items" => $Forms, "select_opt" => FALSE));
						echo "</div>";
						
						// Containers to hold the AJAX responses
						
						echo "<div id='edit_messages'></div>";			
						echo "<div id='results' class='scroll_x'></div>";

					echo "</div>\n";
				echo "</div>\n";
				
				// Delete a file from the server
				
				echo "<div class='boxed_group'>\n";
					echo "<h3>Delete a Form</h3>";
					echo "<div class='boxed_group_inner clearfix'>\n";				
						echo "<div class='vertical_margin_10px'>";
						
							// Containers to hold the AJAX responses
						
							echo "<div id='delete_messages'></div>";
							
							// Display the dropdown menu
							
							form_dropdown(array("use_table" => FALSE, "name" => "delete_forms", "multiselect" => TRUE, "css" => "class='forms_dropdown'", "items" => $Forms, "select_opt" => FALSE));

						echo "</div>";		
					echo "</div>\n";
				echo "</div>\n";
			
			}
			
		echo "</div>";		
	
	footer_start();		
	db_close();
	
?>
