<?php

		ob_start();	
		include("includes.php");
	
		$ExpiryTime = 60 * 60 * 24 * COOKIE_AUTH_EXP_DAYS;
		
		setcookie("username", "", time() - $ExpiryTime);
		setcookie("user_id",  "", time() - $ExpiryTime);
		setcookie("token",    "", time() - $ExpiryTime);

		redirect('.');
		
?>