-- MySQL dump 10.13  Distrib 5.5.11, for Linux (x86_64)
--
-- Host: localhost    Database: cbo
-- ------------------------------------------------------
-- Server version	5.5.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment` (
  `attachment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attachment_name` varchar(72) NOT NULL,
  `attachment_filesize` varchar(50) NOT NULL,
  `attachment_filetype` varchar(50) NOT NULL,
  `attachment_description` varchar(500) NOT NULL,
  `binary_data` mediumblob NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`attachment_id`),
  KEY `attachment_namekey` (`attachment_name`),
  KEY `deleted` (`deleted`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `attachment_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `attachment_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `attachment_ctime` BEFORE INSERT ON `attachment` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `audit_box`
--

DROP TABLE IF EXISTS `audit_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_box` (
  `audit_box_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `box_id` bigint(20) NOT NULL,
  `box_number` varchar(72) NOT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `last_audit_date` date DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `audit_date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `audit_date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `audit_created_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`audit_box_id`),
  KEY `form_id` (`form_id`),
  KEY `box_id` (`box_id`),
  KEY `audit_created_by` (`audit_created_by`),
  KEY `site_id` (`site_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `audit_box_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `audit_box_ibfk_2` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `audit_box_ibfk_3` FOREIGN KEY (`audit_created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_box_ibfk_4` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `audit_box_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_box_ibfk_6` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audit_equipment`
--

DROP TABLE IF EXISTS `audit_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_equipment` (
  `audit_equipment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `equipment_id` bigint(20) DEFAULT NULL,
  `equipment_type_id` bigint(20) DEFAULT NULL,
  `vendor_id` bigint(20) DEFAULT NULL,
  `serial_number` varchar(72) DEFAULT NULL,
  `asset_tag_number` varchar(72) DEFAULT NULL,
  `server_name` varchar(128) DEFAULT NULL,
  `description` text,
  `model_number` varchar(72) DEFAULT NULL,
  `model_type_id` int(3) DEFAULT NULL,
  `equipment_version_id` int(3) DEFAULT NULL,
  `firmware_version` varchar(32) DEFAULT NULL,
  `part_number` varchar(72) DEFAULT NULL,
  `purchase_order_number` varchar(72) DEFAULT NULL,
  `tamper_seal_number` varchar(72) DEFAULT NULL,
  `bag_id` int(10) DEFAULT NULL,
  `servicenow_id` varchar(72) DEFAULT NULL,
  `escrow_location_id` int(3) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `environment_id` bigint(20) DEFAULT NULL,
  `label_name` varchar(128) DEFAULT NULL,
  `status` enum('Online','Offline','Destroyed') DEFAULT NULL,
  `date_online` date DEFAULT NULL,
  `date_offline` date DEFAULT NULL,
  `date_destroyed` date DEFAULT NULL,
  `rack_location` varchar(72) DEFAULT NULL,
  `support_contract_id` bigint(20) DEFAULT NULL,
  `date_shipped` date DEFAULT NULL,
  `notes` text,
  `is_production_capable` tinyint(1) DEFAULT NULL,
  `is_acceptance_tested` tinyint(1) NOT NULL DEFAULT '0',
  `date_acceptance_tested` date DEFAULT NULL,
  `date_last_verified` date DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `audit_date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `audit_date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `audit_created_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`audit_equipment_id`),
  KEY `form_id` (`form_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `equipment_type_id` (`equipment_type_id`),
  KEY `bag_id` (`bag_id`),
  KEY `product_id` (`product_id`),
  KEY `environment_id` (`environment_id`),
  KEY `support_contract_id` (`support_contract_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `audit_created_by` (`audit_created_by`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `model_type_id` (`model_type_id`),
  KEY `equipment_version_id` (`equipment_version_id`),
  CONSTRAINT `audit_equipment_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `audit_equipment_ibfk_10` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_equipment_ibfk_11` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_equipment_ibfk_12` FOREIGN KEY (`audit_created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_equipment_ibfk_13` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `audit_equipment_ibfk_14` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`vendor_id`),
  CONSTRAINT `audit_equipment_ibfk_15` FOREIGN KEY (`model_type_id`) REFERENCES `model_type` (`model_type_id`),
  CONSTRAINT `audit_equipment_ibfk_16` FOREIGN KEY (`equipment_version_id`) REFERENCES `equipment_version` (`equipment_version_id`),
  CONSTRAINT `audit_equipment_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `audit_equipment_ibfk_3` FOREIGN KEY (`equipment_type_id`) REFERENCES `equipment_type` (`equipment_type_id`),
  CONSTRAINT `audit_equipment_ibfk_4` FOREIGN KEY (`bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `audit_equipment_ibfk_7` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `audit_equipment_ibfk_8` FOREIGN KEY (`environment_id`) REFERENCES `environment` (`environment_id`),
  CONSTRAINT `audit_equipment_ibfk_9` FOREIGN KEY (`support_contract_id`) REFERENCES `support_contract` (`support_contract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1134 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_equipment_ctime BEFORE INSERT ON audit_equipment FOR EACH ROW SET NEW.audit_date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `audit_physical_key`
--

DROP TABLE IF EXISTS `audit_physical_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_physical_key` (
  `audit_physical_key_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `physical_key_id` bigint(20) DEFAULT NULL,
  `label` varchar(72) NOT NULL,
  `serial_number` varchar(16) DEFAULT NULL,
  `box_id` bigint(20) DEFAULT NULL,
  `physical_key_type_id` bigint(20) DEFAULT NULL,
  `shareholder_id` bigint(20) DEFAULT NULL,
  `bag_id` int(10) DEFAULT NULL,
  `escrow_location_id` int(3) DEFAULT NULL,
  `servicenow_sys_id` varchar(32) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `audit_date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `audit_date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `audit_created_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`audit_physical_key_id`),
  KEY `form_id` (`form_id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `box_id` (`box_id`),
  KEY `shareholder_id` (`shareholder_id`),
  KEY `bag_id` (`bag_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `audit_created_by` (`audit_created_by`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `physical_key_type_id` (`physical_key_type_id`),
  CONSTRAINT `audit_physical_key_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `audit_physical_key_ibfk_10` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `audit_physical_key_ibfk_11` FOREIGN KEY (`physical_key_type_id`) REFERENCES `physical_key_type` (`physical_key_type_id`),
  CONSTRAINT `audit_physical_key_ibfk_2` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `audit_physical_key_ibfk_3` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `audit_physical_key_ibfk_4` FOREIGN KEY (`shareholder_id`) REFERENCES `shareholder` (`shareholder_id`),
  CONSTRAINT `audit_physical_key_ibfk_5` FOREIGN KEY (`bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `audit_physical_key_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_physical_key_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_physical_key_ibfk_9` FOREIGN KEY (`audit_created_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=610 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_physical_key_ctime BEFORE INSERT ON audit_physical_key FOR EACH ROW SET NEW.audit_date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `audit_share`
--

DROP TABLE IF EXISTS `audit_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_share` (
  `audit_share_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `share_id` bigint(20) DEFAULT NULL,
  `share_label` varchar(72) NOT NULL,
  `serial_number` varchar(16) DEFAULT NULL,
  `share_type_id` bigint(20) NOT NULL,
  `box_id` bigint(20) DEFAULT NULL,
  `escrow_location_id` int(3) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `environment_id` bigint(20) DEFAULT NULL,
  `key_type_id` bigint(20) DEFAULT NULL,
  `media_type_id` bigint(20) DEFAULT NULL,
  `mofn_threshold` varchar(12) DEFAULT NULL,
  `bag_id` int(10) DEFAULT NULL,
  `always_bagged` tinyint(1) NOT NULL DEFAULT '0',
  `share_creation_date` date DEFAULT NULL,
  `original_distribution_date` date DEFAULT NULL,
  `date_destroyed` date DEFAULT NULL,
  `share_set` varchar(72) DEFAULT NULL,
  `notes` text,
  `last_audit_date` date DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `audit_date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `audit_date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `audit_created_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`audit_share_id`),
  KEY `form_id` (`form_id`),
  KEY `share_id` (`share_id`),
  KEY `share_type_id` (`share_type_id`),
  KEY `box_id` (`box_id`),
  KEY `product_id` (`product_id`),
  KEY `environment_id` (`environment_id`),
  KEY `key_type_id` (`key_type_id`),
  KEY `media_type_id` (`media_type_id`),
  KEY `bag_id` (`bag_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `audit_created_by` (`audit_created_by`),
  KEY `escrow_location_id` (`escrow_location_id`),
  CONSTRAINT `audit_share_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `audit_share_ibfk_10` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_share_ibfk_11` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_share_ibfk_12` FOREIGN KEY (`audit_created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_share_ibfk_13` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `audit_share_ibfk_2` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `audit_share_ibfk_3` FOREIGN KEY (`share_type_id`) REFERENCES `share_type` (`share_type_id`),
  CONSTRAINT `audit_share_ibfk_4` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `audit_share_ibfk_5` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `audit_share_ibfk_6` FOREIGN KEY (`environment_id`) REFERENCES `environment` (`environment_id`),
  CONSTRAINT `audit_share_ibfk_7` FOREIGN KEY (`key_type_id`) REFERENCES `key_type` (`key_type_id`),
  CONSTRAINT `audit_share_ibfk_8` FOREIGN KEY (`media_type_id`) REFERENCES `media_type` (`media_type_id`),
  CONSTRAINT `audit_share_ibfk_9` FOREIGN KEY (`bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3362 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_share_ctime BEFORE INSERT ON audit_share FOR EACH ROW SET NEW.audit_date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `audit_shareholder`
--

DROP TABLE IF EXISTS `audit_shareholder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_shareholder` (
  `audit_audit_shareholder_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `shareholder_id` bigint(20) NOT NULL,
  `shareholder_name` varchar(72) NOT NULL,
  `username` varchar(128) DEFAULT NULL,
  `cbo_user` tinyint(1) DEFAULT '0',
  `has_data_center_access` tinyint(1) DEFAULT '0',
  `manager_name` varchar(150) DEFAULT NULL,
  `function_type_id` int(3) NOT NULL,
  `function_id` bigint(20) DEFAULT NULL,
  `function_id_secondary` bigint(20) DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `phone_number` varchar(25) DEFAULT NULL,
  `desk_location` varchar(50) DEFAULT NULL,
  `job_title` varchar(128) DEFAULT NULL,
  `notes` text,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `audit_date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `audit_date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `audit_created_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`audit_audit_shareholder_id`),
  KEY `function_id` (`function_id`),
  KEY `site_id` (`site_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `audit_created_by` (`audit_created_by`),
  KEY `form_id` (`form_id`),
  KEY `function_type_id` (`function_type_id`),
  KEY `function_id_secondary` (`function_id_secondary`),
  CONSTRAINT `audit_shareholder_ibfk_1` FOREIGN KEY (`function_id`) REFERENCES `function` (`function_id`),
  CONSTRAINT `audit_shareholder_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `audit_shareholder_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_shareholder_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_shareholder_ibfk_5` FOREIGN KEY (`audit_created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `audit_shareholder_ibfk_6` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `audit_shareholder_ibfk_7` FOREIGN KEY (`function_type_id`) REFERENCES `function_type` (`function_type_id`),
  CONSTRAINT `audit_shareholder_ibfk_8` FOREIGN KEY (`function_id_secondary`) REFERENCES `function` (`function_id`)
) ENGINE=InnoDB AUTO_INCREMENT=647 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `box`
--

DROP TABLE IF EXISTS `box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `box` (
  `box_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `box_number` varchar(72) NOT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `last_audit_date` date DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`box_id`),
  KEY `box_namekey` (`box_number`),
  KEY `site_id` (`site_id`),
  KEY `deleted` (`deleted`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `box_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `box_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `box_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `box_ctime` BEFORE INSERT ON `box` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `box_snapshot`
--

DROP TABLE IF EXISTS `box_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `box_snapshot` (
  `box_snapshot_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `box_id` bigint(20) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`box_snapshot_id`),
  KEY `form_id` (`form_id`),
  KEY `box_id` (`box_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `box_snapshot_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `box_snapshot_ibfk_2` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `box_snapshot_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `box_snapshot_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1037 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER box_snapshot_ctime BEFORE INSERT ON box_snapshot FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `box_snapshot_contents`
--

DROP TABLE IF EXISTS `box_snapshot_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `box_snapshot_contents` (
  `box_snapshot_contents_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `box_snapshot_id` bigint(20) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`box_snapshot_contents_id`),
  KEY `box_snapshot_id` (`box_snapshot_id`),
  KEY `share_id` (`share_id`),
  CONSTRAINT `box_snapshot_contents_ibfk_1` FOREIGN KEY (`box_snapshot_id`) REFERENCES `box_snapshot` (`box_snapshot_id`),
  CONSTRAINT `box_snapshot_contents_ibfk_2` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14471 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cabinet`
--

DROP TABLE IF EXISTS `cabinet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cabinet` (
  `cabinet_id` int(3) NOT NULL AUTO_INCREMENT,
  `cabinet_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cabinet_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER cabinet_ctime BEFORE INSERT ON cabinet FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `dblog`
--

DROP TABLE IF EXISTS `dblog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dblog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `ipv4` varchar(16) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `script` varchar(255) DEFAULT NULL,
  `query` text,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dblog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58308 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `destruction_method`
--

DROP TABLE IF EXISTS `destruction_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `destruction_method` (
  `destruction_method_id` int(3) NOT NULL AUTO_INCREMENT,
  `destruction_method_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`destruction_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER destruction_method_ctime BEFORE INSERT ON destruction_method FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `email_template`
--

DROP TABLE IF EXISTS `email_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_template` (
  `email_template_id` int(3) NOT NULL AUTO_INCREMENT,
  `email_template_name` varchar(128) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `body` text NOT NULL,
  `default_recipients` text,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`email_template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER email_template_ctime BEFORE INSERT ON email_template FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `environment`
--

DROP TABLE IF EXISTS `environment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `environment` (
  `environment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `environment_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`environment_id`),
  KEY `deleted_key` (`deleted`),
  KEY `ename` (`environment_name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `e_ctime` BEFORE INSERT ON `environment` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment` (
  `equipment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `equipment_type_id` bigint(20) DEFAULT NULL,
  `vendor_id` bigint(20) DEFAULT NULL,
  `serial_number` varchar(72) DEFAULT NULL,
  `asset_tag_number` varchar(72) DEFAULT NULL,
  `server_name` varchar(128) DEFAULT NULL,
  `description` text,
  `model_number` varchar(72) DEFAULT NULL,
  `model_type_id` int(3) DEFAULT NULL,
  `equipment_version_id` int(3) DEFAULT NULL,
  `firmware_version` varchar(32) DEFAULT NULL,
  `part_number` varchar(72) DEFAULT NULL,
  `purchase_order_number` varchar(72) DEFAULT NULL,
  `tamper_seal_number` varchar(72) DEFAULT NULL,
  `bag_id` int(10) DEFAULT NULL,
  `servicenow_id` varchar(72) DEFAULT NULL,
  `escrow_location_id` int(3) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `environment_id` bigint(20) DEFAULT NULL,
  `label_name` varchar(128) DEFAULT NULL,
  `status` enum('Online','Offline','Destroyed') DEFAULT NULL,
  `date_online` date DEFAULT NULL,
  `date_offline` date DEFAULT NULL,
  `date_destroyed` date DEFAULT NULL,
  `rack_location` varchar(72) DEFAULT NULL,
  `support_contract_id` bigint(20) DEFAULT NULL,
  `date_shipped` date DEFAULT NULL,
  `notes` text,
  `is_production_capable` tinyint(1) DEFAULT NULL,
  `is_acceptance_tested` tinyint(1) NOT NULL DEFAULT '0',
  `date_acceptance_tested` date DEFAULT NULL,
  `date_last_verified` date DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`equipment_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `date_created` (`date_created`),
  KEY `date_updated` (`date_updated`),
  KEY `servicenow_id` (`servicenow_id`),
  KEY `is_production_capable` (`is_production_capable`),
  KEY `support_contract_id` (`support_contract_id`),
  KEY `environment_id` (`environment_id`),
  KEY `location_id` (`escrow_location_id`),
  KEY `equipment_type_id` (`equipment_type_id`),
  KEY `deleted_key` (`deleted`),
  KEY `is_acceptance_tested` (`is_acceptance_tested`),
  KEY `esn_key` (`serial_number`),
  KEY `easn_key` (`asset_tag_number`),
  KEY `emn_key` (`model_number`),
  KEY `epnn_key` (`part_number`),
  KEY `epon_key` (`purchase_order_number`),
  KEY `etesn_key` (`tamper_seal_number`),
  KEY `product_id` (`product_id`),
  KEY `bag_id` (`bag_id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `model_type_id` (`model_type_id`),
  KEY `equipment_version_id` (`equipment_version_id`),
  CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `equipment_ibfk_10` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `equipment_ibfk_11` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`vendor_id`),
  CONSTRAINT `equipment_ibfk_12` FOREIGN KEY (`model_type_id`) REFERENCES `model_type` (`model_type_id`),
  CONSTRAINT `equipment_ibfk_13` FOREIGN KEY (`equipment_version_id`) REFERENCES `equipment_version` (`equipment_version_id`),
  CONSTRAINT `equipment_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `equipment_ibfk_3` FOREIGN KEY (`support_contract_id`) REFERENCES `support_contract` (`support_contract_id`),
  CONSTRAINT `equipment_ibfk_6` FOREIGN KEY (`equipment_type_id`) REFERENCES `equipment_type` (`equipment_type_id`),
  CONSTRAINT `equipment_ibfk_7` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `equipment_ibfk_8` FOREIGN KEY (`environment_id`) REFERENCES `environment` (`environment_id`),
  CONSTRAINT `equipment_ibfk_9` FOREIGN KEY (`bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `equipment_ctime` BEFORE INSERT ON `equipment` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment_attachment`
--

DROP TABLE IF EXISTS `equipment_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_attachment` (
  `equipment_attachment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `equipment_id` bigint(20) DEFAULT NULL,
  `attachment_id` bigint(20) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`equipment_attachment_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `attachment_id` (`attachment_id`),
  CONSTRAINT `equipment_attachment_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`) ON DELETE CASCADE,
  CONSTRAINT `equipment_attachment_ibfk_2` FOREIGN KEY (`attachment_id`) REFERENCES `attachment` (`attachment_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `equipment_attachment_ctime` BEFORE INSERT ON `equipment_attachment` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment_restart`
--

DROP TABLE IF EXISTS `equipment_restart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_restart` (
  `equipment_restart_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `equipment_id` bigint(20) NOT NULL,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `date_restarted` date NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`equipment_restart_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `form_id` (`form_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `equipment_restart_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `equipment_restart_ibfk_2` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `equipment_restart_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `equipment_restart_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER equipment_restart_ctime BEFORE INSERT ON equipment_restart FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment_type`
--

DROP TABLE IF EXISTS `equipment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_type` (
  `equipment_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `equipment_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`equipment_type_id`),
  KEY `deleted_key` (`deleted`),
  KEY `equipment_type_namekey` (`equipment_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `equipment_type_ctime` BEFORE INSERT ON `equipment_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment_version`
--

DROP TABLE IF EXISTS `equipment_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_version` (
  `equipment_version_id` int(3) NOT NULL AUTO_INCREMENT,
  `equipment_version_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`equipment_version_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER equipment_version_ctime BEFORE INSERT ON equipment_version FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `escrow_location`
--

DROP TABLE IF EXISTS `escrow_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrow_location` (
  `escrow_location_id` int(3) NOT NULL AUTO_INCREMENT,
  `escrow_location_name` varchar(50) NOT NULL,
  `escrow_location_type_id` bigint(20) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`escrow_location_id`),
  KEY `site_id` (`site_id`),
  KEY `escrow_location_type_id` (`escrow_location_type_id`),
  CONSTRAINT `escrow_location_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `escrow_location_ibfk_2` FOREIGN KEY (`escrow_location_type_id`) REFERENCES `escrow_location_type` (`escrow_location_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER escrow_location_ctime BEFORE INSERT ON escrow_location FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `escrow_location_type`
--

DROP TABLE IF EXISTS `escrow_location_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrow_location_type` (
  `escrow_location_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `escrow_location_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`escrow_location_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER escrow_location_type_ctime BEFORE INSERT ON escrow_location_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(128) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `start_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `cc_recipients` text,
  `ical_uid` varchar(256) DEFAULT NULL,
  `email_template_id` int(3) NOT NULL,
  `confirmed` tinyint(1) DEFAULT '0',
  `cancelled` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_id`),
  KEY `site_id` (`site_id`),
  KEY `email_template_id` (`email_template_id`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `event_ibfk_2` FOREIGN KEY (`email_template_id`) REFERENCES `email_template` (`email_template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER event_ctime BEFORE INSERT ON event FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `event_email_schedule`
--

DROP TABLE IF EXISTS `event_email_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_email_schedule` (
  `event_schedule_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `trigger_date` date NOT NULL,
  `days_notice` int(3) NOT NULL,
  `sent` tinyint(1) DEFAULT '0',
  `sent_time` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_schedule_id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `event_email_schedule_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER event_email_schedule_ctime BEFORE INSERT ON event_email_schedule FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `event_product`
--

DROP TABLE IF EXISTS `event_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_product` (
  `event_product_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `product_id` bigint(10) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_product_id`),
  KEY `event_id` (`event_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `event_product_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`),
  CONSTRAINT `event_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER event_product_ctime BEFORE INSERT ON event_product FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `event_shareholder`
--

DROP TABLE IF EXISTS `event_shareholder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_shareholder` (
  `event_shareholder_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `shareholder_id` bigint(20) NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_shareholder_id`),
  KEY `event_id` (`event_id`),
  KEY `shareholder_id` (`shareholder_id`),
  KEY `physical_key_id` (`physical_key_id`),
  CONSTRAINT `event_shareholder_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`),
  CONSTRAINT `event_shareholder_ibfk_2` FOREIGN KEY (`shareholder_id`) REFERENCES `shareholder` (`shareholder_id`),
  CONSTRAINT `event_shareholder_ibfk_3` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER event_shareholder_ctime BEFORE INSERT ON event_shareholder FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form`
--

DROP TABLE IF EXISTS `form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form` (
  `form_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_name` varchar(72) NOT NULL,
  `form_table` varchar(128) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `instructions` text,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`form_id`),
  KEY `deleted` (`deleted`),
  KEY `form_namekey` (`form_name`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `form_ctime` BEFORE INSERT ON `form` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_equip_courier_attestation`
--

DROP TABLE IF EXISTS `form_equip_courier_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_equip_courier_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `from_site_id` bigint(20) NOT NULL,
  `to_site_id` bigint(20) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `outer_tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `outer_tamper_bag_id` (`outer_tamper_bag_id`),
  KEY `from_site_id` (`from_site_id`),
  KEY `to_site_id` (`to_site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_1` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_2` FOREIGN KEY (`outer_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_3` FOREIGN KEY (`from_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_4` FOREIGN KEY (`to_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_courier_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_equip_courier_attestation_ctime BEFORE INSERT ON form_equip_courier_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_equip_courier_attestation_items`
--

DROP TABLE IF EXISTS `form_equip_courier_attestation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_equip_courier_attestation_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label_name` varchar(128) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `execution_id` (`execution_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  CONSTRAINT `form_equip_courier_attestation_items_ibfk_1` FOREIGN KEY (`execution_id`) REFERENCES `form_equip_courier_attestation` (`id`),
  CONSTRAINT `form_equip_courier_attestation_items_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_equip_courier_attestation_items_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_equip_escrow_attestation`
--

DROP TABLE IF EXISTS `form_equip_escrow_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_equip_escrow_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label_name` varchar(128) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `escrow_location_id` (`escrow_location_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_escrow_attestation_ibfk_9` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_equip_escrow_attestation_ctime BEFORE INSERT ON form_equip_escrow_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_equip_out_of_band_verification_attestation`
--

DROP TABLE IF EXISTS `form_equip_out_of_band_verification_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_equip_out_of_band_verification_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_equip_out_of_band_verification_attestation_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_out_of_band_verification_attestation_ibfk_2` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_out_of_band_verification_attestation_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_out_of_band_verification_attestation_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_equip_out_of_band_verification_attestation_ctime BEFORE INSERT ON form_equip_out_of_band_verification_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_equip_rebag_attestation`
--

DROP TABLE IF EXISTS `form_equip_rebag_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_equip_rebag_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `equipment_label` varchar(128) NOT NULL,
  `original_tamper_bag_id` int(10) NOT NULL,
  `new_tamper_bag_id` int(10) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `original_tamper_bag_id` (`original_tamper_bag_id`),
  KEY `new_tamper_bag_id` (`new_tamper_bag_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_2` FOREIGN KEY (`original_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_3` FOREIGN KEY (`new_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_4` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_rebag_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_equipment_rebag_attestation_ctime BEFORE INSERT ON `form_equip_rebag_attestation` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_equip_relocation_attestation`
--

DROP TABLE IF EXISTS `form_equip_relocation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_equip_relocation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label` varchar(128) NOT NULL,
  `transferred_from_id` int(3) NOT NULL,
  `transferred_to_id` int(3) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `transferred_from_id` (`transferred_from_id`),
  KEY `transferred_to_id` (`transferred_to_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_2` FOREIGN KEY (`transferred_from_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_3` FOREIGN KEY (`transferred_to_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_4` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_equip_relocation_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_equip_relocation_attestation_ctime BEFORE INSERT ON form_equip_relocation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_acceptance_test_attestation`
--

DROP TABLE IF EXISTS `form_hsm_acceptance_test_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_acceptance_test_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `vendor_id` bigint(20) DEFAULT NULL,
  `equipment_model` varchar(72) DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `site_id` (`site_id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_3` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`vendor_id`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_acceptance_test_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_hsm_activation_attestation`
--

DROP TABLE IF EXISTS `form_hsm_activation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_activation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_label` varchar(128) NOT NULL,
  `location` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `share1_id` bigint(20) NOT NULL,
  `share2_id` bigint(20) DEFAULT NULL,
  `share3_id` bigint(20) DEFAULT NULL,
  `share4_id` bigint(20) DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `share1_id` (`share1_id`),
  KEY `share2_id` (`share2_id`),
  KEY `share3_id` (`share3_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `share4_id` (`share4_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_10` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_11` FOREIGN KEY (`share4_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_3` FOREIGN KEY (`share1_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_4` FOREIGN KEY (`share2_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_5` FOREIGN KEY (`share3_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_6` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_7` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_8` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_activation_attestation_ibfk_9` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_activation_attestation_ctime BEFORE INSERT ON form_hsm_activation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_courier_attestation`
--

DROP TABLE IF EXISTS `form_hsm_courier_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_courier_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `from_site_id` bigint(20) NOT NULL,
  `to_site_id` bigint(20) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `outer_tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `updated_by` (`updated_by`),
  KEY `outer_tamper_bag_id` (`outer_tamper_bag_id`),
  KEY `from_site_id` (`from_site_id`),
  KEY `to_site_id` (`to_site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_1` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_3` FOREIGN KEY (`outer_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_4` FOREIGN KEY (`from_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_5` FOREIGN KEY (`to_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_6` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_7` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_8` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_courier_attestation_ibfk_9` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_courier_attestation_ctime BEFORE INSERT ON form_hsm_courier_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_courier_attestation_items`
--

DROP TABLE IF EXISTS `form_hsm_courier_attestation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_courier_attestation_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label_name` varchar(128) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `execution_id` (`execution_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  CONSTRAINT `form_hsm_courier_attestation_items_ibfk_1` FOREIGN KEY (`execution_id`) REFERENCES `form_hsm_courier_attestation` (`id`),
  CONSTRAINT `form_hsm_courier_attestation_items_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_courier_attestation_items_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_hsm_deactivation_attestation`
--

DROP TABLE IF EXISTS `form_hsm_deactivation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_deactivation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label` varchar(128) NOT NULL,
  `location` varchar(256) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_deactivation_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_deactivation_attestation_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_deactivation_attestation_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_deactivation_attestation_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_deactivation_attestation_ibfk_5` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_deactivation_attestation_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_deactivation_attestation_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_deactivation_attestation_ctime BEFORE INSERT ON form_hsm_deactivation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_destruction_attestation`
--

DROP TABLE IF EXISTS `form_hsm_destruction_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_destruction_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `vendor_id` bigint(20) NOT NULL,
  `reason` text NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label` varchar(128) NOT NULL,
  `inner_tamper_bag_id` int(10) NOT NULL,
  `outer_tamper_bag_id` int(10) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `notes` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `inner_tamper_bag_id` (`inner_tamper_bag_id`),
  KEY `outer_tamper_bag_id` (`outer_tamper_bag_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`vendor_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_10` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_3` FOREIGN KEY (`inner_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_4` FOREIGN KEY (`outer_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_5` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_6` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_7` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_8` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_destruction_attestation_ibfk_9` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_hsm_escrow_attestation`
--

DROP TABLE IF EXISTS `form_hsm_escrow_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_escrow_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label_name` varchar(128) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_2` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_3` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_4` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_escrow_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_escrow_attestation_ctime BEFORE INSERT ON form_hsm_escrow_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_out_of_band_verification_attestation`
--

DROP TABLE IF EXISTS `form_hsm_out_of_band_verification_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_out_of_band_verification_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `vendor_id` bigint(20) NOT NULL,
  `date_submitted` date NOT NULL,
  `po_number` varchar(64) DEFAULT NULL,
  `number_of_assets` int(2) NOT NULL,
  `date_shipped` date NOT NULL,
  `date_received` date NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_out_of_band_verification_attestation_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`vendor_id`),
  CONSTRAINT `form_hsm_out_of_band_verification_attestation_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_out_of_band_verification_attestation_ibfk_3` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_out_of_band_verification_attestation_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_out_of_band_verification_attestation_ibfk_5` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_out_of_band_verification_attestation_ctime BEFORE INSERT ON form_hsm_out_of_band_verification_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_out_of_band_verification_attestation_items`
--

DROP TABLE IF EXISTS `form_hsm_out_of_band_verification_attestation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_out_of_band_verification_attestation_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) NOT NULL,
  `item_description` varchar(128) NOT NULL,
  `serial_number` varchar(128) NOT NULL,
  `tamper_bag_number` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `execution_id` (`execution_id`),
  CONSTRAINT `form_hsm_out_of_band_verification_attestation_items_ibfk_1` FOREIGN KEY (`execution_id`) REFERENCES `form_hsm_out_of_band_verification_attestation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_hsm_reactivation_attestation`
--

DROP TABLE IF EXISTS `form_hsm_reactivation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_reactivation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_label` varchar(128) NOT NULL,
  `location` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `share1_id` bigint(20) NOT NULL,
  `share2_id` bigint(20) DEFAULT NULL,
  `share3_id` bigint(20) DEFAULT NULL,
  `share4_id` bigint(20) DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `share1_id` (`share1_id`),
  KEY `share2_id` (`share2_id`),
  KEY `share3_id` (`share3_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `share4_id` (`share4_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_10` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_11` FOREIGN KEY (`share4_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_3` FOREIGN KEY (`share1_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_4` FOREIGN KEY (`share2_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_5` FOREIGN KEY (`share3_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_6` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_7` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_8` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_reactivation_attestation_ibfk_9` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_reactivation_attestation_ctime BEFORE INSERT ON form_hsm_reactivation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_rebag_attestation`
--

DROP TABLE IF EXISTS `form_hsm_rebag_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_rebag_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `equipment_label` varchar(128) NOT NULL,
  `original_tamper_bag_id` int(10) NOT NULL,
  `new_tamper_bag_id` int(10) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `original_tamper_bag_id` (`original_tamper_bag_id`),
  KEY `new_tamper_bag_id` (`new_tamper_bag_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_2` FOREIGN KEY (`original_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_3` FOREIGN KEY (`new_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_4` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_rebag_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_rebag_attestation_ctime BEFORE INSERT ON form_hsm_rebag_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_relabel_attestation`
--

DROP TABLE IF EXISTS `form_hsm_relabel_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_relabel_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `old_label` varchar(128) NOT NULL,
  `new_label` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_relabel_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_relabel_attestation_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_relabel_attestation_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_relabel_attestation_ibfk_4` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_relabel_attestation_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_relabel_attestation_ibfk_6` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_relabel_attestation_ctime BEFORE INSERT ON form_hsm_relabel_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_hsm_relocation_attestation`
--

DROP TABLE IF EXISTS `form_hsm_relocation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_hsm_relocation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `equipment_id` bigint(20) NOT NULL,
  `label` varchar(128) NOT NULL,
  `transferred_from_id` int(3) NOT NULL,
  `transferred_to_id` int(3) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `transferred_from_id` (`transferred_from_id`),
  KEY `transferred_to_id` (`transferred_to_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_2` FOREIGN KEY (`transferred_from_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_3` FOREIGN KEY (`transferred_to_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_4` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_hsm_relocation_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_hsm_transfer_attestation_ctime BEFORE INSERT ON `form_hsm_relocation_attestation` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_ksr_receipt_attestation`
--

DROP TABLE IF EXISTS `form_ksr_receipt_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_ksr_receipt_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `zone` varchar(128) DEFAULT NULL,
  `ksr_filename` varchar(100) NOT NULL,
  `date_ksr_generated` date NOT NULL,
  `date_ksr_received` date NOT NULL,
  `hash` varchar(64) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_ksr_receipt_attestation_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `form_ksr_receipt_attestation_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_ksr_receipt_attestation_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_ksr_receipt_attestation_ibfk_4` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_ksr_receipt_attestation_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_ksr_receipt_attestation_ibfk_6` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_ksr_receipt_attestation_ctime BEFORE INSERT ON form_ksr_receipt_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_layout`
--

DROP TABLE IF EXISTS `form_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_layout` (
  `form_layout_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) NOT NULL,
  `field_name` varchar(50) NOT NULL,
  `token_name` varchar(50) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `dropdown_option` varchar(50) DEFAULT NULL,
  `role_id` int(3) DEFAULT NULL,
  `table_column_name` varchar(50) DEFAULT NULL,
  `auto_populate_trigger` varchar(100) DEFAULT NULL,
  `auto_populate_value` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`form_layout_id`),
  KEY `form_layout_namekey` (`form_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `form_layout_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `form_layout_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3942 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `form_layout_ctime` BEFORE INSERT ON `form_layout` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_lock_repair_attestation`
--

DROP TABLE IF EXISTS `form_lock_repair_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_lock_repair_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `lock_type` varchar(128) NOT NULL,
  `location` varchar(128) NOT NULL,
  `repaired_by` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_lock_repair_attestation_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_lock_repair_attestation_ibfk_2` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_lock_repair_attestation_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_lock_repair_attestation_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_lock_repair_attestation_ctime BEFORE INSERT ON form_lock_repair_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_partition_password_creation_attestation`
--

DROP TABLE IF EXISTS `form_partition_password_creation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_partition_password_creation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_partition_password_creation_attestation_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `form_partition_password_creation_attestation_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_partition_password_creation_attestation_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_partition_password_creation_attestation_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_partition_password_creation_attestation_ibfk_5` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_partition_password_creation_attestation_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_partition_password_creation_attestation_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_partition_password_creation_attestation_ctime BEFORE INSERT ON form_partition_password_creation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_physical_key_courier_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_courier_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_courier_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `from_site_id` bigint(20) NOT NULL,
  `to_site_id` bigint(20) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `outer_tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `outer_tamper_bag_id` (`outer_tamper_bag_id`),
  KEY `from_site_id` (`from_site_id`),
  KEY `to_site_id` (`to_site_id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_1` FOREIGN KEY (`outer_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_2` FOREIGN KEY (`from_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_3` FOREIGN KEY (`to_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_4` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_courier_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_physical_key_courier_attestation_items`
--

DROP TABLE IF EXISTS `form_physical_key_courier_attestation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_courier_attestation_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `execution_id` (`execution_id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  CONSTRAINT `form_physical_key_courier_attestation_items_ibfk_1` FOREIGN KEY (`execution_id`) REFERENCES `form_physical_key_courier_attestation` (`id`),
  CONSTRAINT `form_physical_key_courier_attestation_items_ibfk_2` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_courier_attestation_items_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_physical_key_distribution_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_distribution_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_distribution_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_2` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_distribution_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=348 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_physical_key_distribution_attestation_ctime BEFORE INSERT ON form_physical_key_distribution_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_physical_key_escrow_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_escrow_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_escrow_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `escrow_location_id` (`escrow_location_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_2` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_escrow_attestation_ibfk_9` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_physical_key_escrow_attestation_ctime BEFORE INSERT ON form_physical_key_escrow_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_physical_key_rebag_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_rebag_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_rebag_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `original_tamper_bag_id` int(10) NOT NULL,
  `new_tamper_bag_id` int(10) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `original_tamper_bag_id` (`original_tamper_bag_id`),
  KEY `new_tamper_bag_id` (`new_tamper_bag_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_1` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_2` FOREIGN KEY (`original_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_3` FOREIGN KEY (`new_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_4` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_rebag_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_physical_key_rebag_attestation_ctime BEFORE INSERT ON form_physical_key_rebag_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_physical_key_relocation_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_relocation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_relocation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `transferred_from_id` int(3) NOT NULL,
  `transferred_to_id` int(3) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `transferred_from_id` (`transferred_from_id`),
  KEY `transferred_to_id` (`transferred_to_id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_2` FOREIGN KEY (`transferred_from_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_3` FOREIGN KEY (`transferred_to_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_4` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_relocation_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_physical_key_relocation_attestation_ctime BEFORE INSERT ON form_physical_key_relocation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_physical_key_traka_access_assignment_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_traka_access_assignment_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_traka_access_assignment_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_physical_key_traka_access_assignment_attestation_ibfk_1` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_traka_access_assignment_attestation_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_traka_access_assignment_attestation_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_traka_access_assignment_attestation_ibfk_4` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_traka_access_assignment_attestation_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_traka_access_assignment_attestation_ibfk_6` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_physical_key_traka_access_assignment_attestation_ctime BEFORE INSERT ON form_physical_key_traka_access_assignment_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_physical_key_traka_access_revocation_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_traka_access_revocation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_traka_access_revocation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_physical_key_traka_access_revocation_attestation_ibfk_1` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_traka_access_revocation_attestation_ibfk_2` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_physical_key_traka_access_revocation_attestation_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_traka_access_revocation_attestation_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_traka_access_revocation_attestation_ibfk_5` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_traka_access_revocation_attestation_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_traka_access_revocation_attestation_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_physical_key_traka_access_revocation_attestation_ctime BEFORE INSERT ON form_physical_key_traka_access_revocation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_physical_key_transfer_attestation`
--

DROP TABLE IF EXISTS `form_physical_key_transfer_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_physical_key_transfer_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `physical_key_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `physical_key_id` (`physical_key_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_physical_key_transfer_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_physical_key_transfer_attestation_ibfk_2` FOREIGN KEY (`physical_key_id`) REFERENCES `physical_key` (`physical_key_id`),
  CONSTRAINT `form_physical_key_transfer_attestation_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_physical_key_transfer_attestation_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_transfer_attestation_ibfk_5` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_transfer_attestation_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_physical_key_transfer_attestation_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_physical_key_transfer_attestation_ctime BEFORE INSERT ON form_physical_key_transfer_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_roles`
--

DROP TABLE IF EXISTS `form_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_roles` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) DEFAULT NULL,
  `execution_id` int(10) DEFAULT NULL COMMENT 'This ID could belong to one of 25+ tables',
  `role_id` int(3) DEFAULT NULL,
  `shareholder_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `role_id` (`role_id`),
  KEY `shareholder_id` (`shareholder_id`),
  CONSTRAINT `form_roles_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  CONSTRAINT `form_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `form_roles_ibfk_3` FOREIGN KEY (`shareholder_id`) REFERENCES `shareholder` (`shareholder_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8458 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_root_key_signing_ceremony_attestation`
--

DROP TABLE IF EXISTS `form_root_key_signing_ceremony_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_root_key_signing_ceremony_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL COMMENT 'Date KSR received',
  `quarter_id` int(3) NOT NULL,
  `date_ksr_generated` date NOT NULL,
  `ksr_hash` varchar(128) NOT NULL,
  `signing_date` date NOT NULL,
  `location` varchar(128) NOT NULL,
  `word_list` text NOT NULL,
  `date_skr_generated` date NOT NULL,
  `date_skr_received` date NOT NULL,
  `date_skr_installed` date NOT NULL,
  `skr_hash` varchar(128) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_root_key_signing_ceremony_attestation_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_root_key_signing_ceremony_attestation_ibfk_2` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_root_key_signing_ceremony_attestation_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_root_key_signing_ceremony_attestation_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_root_key_signing_ceremony_attestation_ctime BEFORE INSERT ON form_root_key_signing_ceremony_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_safe_combo_change_attestation`
--

DROP TABLE IF EXISTS `form_safe_combo_change_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_safe_combo_change_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `function_id` bigint(20) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `model` varchar(250) DEFAULT NULL,
  `reason` text NOT NULL,
  `cabinet_id` int(3) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `function_id` (`function_id`),
  KEY `site_id` (`site_id`),
  KEY `cabinet_id` (`cabinet_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_1` FOREIGN KEY (`function_id`) REFERENCES `function` (`function_id`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_3` FOREIGN KEY (`cabinet_id`) REFERENCES `cabinet` (`cabinet_id`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_combo_change_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_safe_combo_change_attestation_ctime BEFORE INSERT ON form_safe_combo_change_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_safe_combo_distribution_attestation`
--

DROP TABLE IF EXISTS `form_safe_combo_distribution_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_safe_combo_distribution_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `model_number` varchar(32) NOT NULL,
  `function_id` bigint(20) NOT NULL COMMENT 'For what safe was the comboination distributed',
  `cabinet_id` int(3) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `function_id` (`function_id`),
  KEY `cabinet_id` (`cabinet_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_1` FOREIGN KEY (`function_id`) REFERENCES `function` (`function_id`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_2` FOREIGN KEY (`cabinet_id`) REFERENCES `cabinet` (`cabinet_id`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_3` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_combo_distribution_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_safe_deposit_box_audit_attestation`
--

DROP TABLE IF EXISTS `form_safe_deposit_box_audit_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_safe_deposit_box_audit_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `box_id` bigint(20) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `box_id` (`box_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_safe_deposit_box_audit_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_safe_deposit_box_audit_attestation_ibfk_2` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `form_safe_deposit_box_audit_attestation_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_safe_deposit_box_audit_attestation_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_deposit_box_audit_attestation_ibfk_5` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_deposit_box_audit_attestation_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_safe_deposit_box_audit_attestation_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_safe_deposit_box_audit_attestation_ctime BEFORE INSERT ON form_safe_deposit_box_audit_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_safe_deposit_box_audit_contents`
--

DROP TABLE IF EXISTS `form_safe_deposit_box_audit_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_safe_deposit_box_audit_contents` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `execution_id` (`execution_id`),
  KEY `share_id` (`share_id`),
  CONSTRAINT `form_safe_deposit_box_audit_contents_ibfk_1` FOREIGN KEY (`execution_id`) REFERENCES `form_safe_deposit_box_audit_attestation` (`id`),
  CONSTRAINT `form_safe_deposit_box_audit_contents_ibfk_2` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2462 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_share_courier_attestation`
--

DROP TABLE IF EXISTS `form_share_courier_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_courier_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `from_site_id` bigint(20) NOT NULL,
  `to_site_id` bigint(20) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `outer_tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `outer_tamper_bag_id` (`outer_tamper_bag_id`),
  KEY `from_site_id` (`from_site_id`),
  KEY `to_site_id` (`to_site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_share_courier_attestation_ibfk_1` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_2` FOREIGN KEY (`outer_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_3` FOREIGN KEY (`from_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_4` FOREIGN KEY (`to_site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_courier_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_share_courier_attestation_items`
--

DROP TABLE IF EXISTS `form_share_courier_attestation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_courier_attestation_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `execution_id` (`execution_id`),
  KEY `share_id` (`share_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  CONSTRAINT `form_share_courier_attestation_items_ibfk_1` FOREIGN KEY (`execution_id`) REFERENCES `form_share_courier_attestation` (`id`),
  CONSTRAINT `form_share_courier_attestation_items_ibfk_2` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_courier_attestation_items_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=298 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_share_destruction_attestation`
--

DROP TABLE IF EXISTS `form_share_destruction_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_destruction_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `reason` text,
  `share_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `destruction_method_id` int(3) NOT NULL,
  `notes` text,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `share_id` (`share_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `destruction_method_id` (`destruction_method_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_1` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_2` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_3` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_destruction_attestation_ibfk_9` FOREIGN KEY (`destruction_method_id`) REFERENCES `destruction_method` (`destruction_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_share_destruction_attestation_ctime BEFORE INSERT ON form_share_destruction_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_share_distribution_attestation`
--

DROP TABLE IF EXISTS `form_share_distribution_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_distribution_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `box_id` bigint(20) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `share_id` (`share_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `box_id` (`box_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_2` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_distribution_attestation_ibfk_9` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`)
) ENGINE=InnoDB AUTO_INCREMENT=232 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_share_distribution_attestation_ctime BEFORE INSERT ON form_share_distribution_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_share_escrow_attestation`
--

DROP TABLE IF EXISTS `form_share_escrow_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_escrow_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `escrow_location_id` int(3) NOT NULL,
  `tamper_bag_id` int(10) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `share_id` (`share_id`),
  KEY `tamper_bag_id` (`tamper_bag_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `escrow_location_id` (`escrow_location_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_2` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_3` FOREIGN KEY (`tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_escrow_attestation_ibfk_9` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_share_escrow_attestation_ctime BEFORE INSERT ON form_share_escrow_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_share_rebag_attestation`
--

DROP TABLE IF EXISTS `form_share_rebag_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_rebag_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `original_tamper_bag_id` int(10) NOT NULL,
  `new_tamper_bag_id` int(10) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `share_id` (`share_id`),
  KEY `original_tamper_bag_id` (`original_tamper_bag_id`),
  KEY `new_tamper_bag_id` (`new_tamper_bag_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_1` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_2` FOREIGN KEY (`original_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_3` FOREIGN KEY (`new_tamper_bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_4` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_rebag_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_share_rebag_attestation_ctime BEFORE INSERT ON form_share_rebag_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_share_relabel_attestation`
--

DROP TABLE IF EXISTS `form_share_relabel_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_relabel_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `new_label` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `share_id` (`share_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_share_relabel_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_relabel_attestation_ibfk_2` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_relabel_attestation_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_relabel_attestation_ibfk_4` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_relabel_attestation_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_relabel_attestation_ibfk_6` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_share_relabel_attestation_ctime BEFORE INSERT ON form_share_relabel_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_share_relocation_attestation`
--

DROP TABLE IF EXISTS `form_share_relocation_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_relocation_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `transferred_from_id` int(3) NOT NULL,
  `transferred_to_id` int(3) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `transferred_from_id` (`transferred_from_id`),
  KEY `transferred_to_id` (`transferred_to_id`),
  KEY `share_id` (`share_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_2` FOREIGN KEY (`transferred_from_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_3` FOREIGN KEY (`transferred_to_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_4` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_relocation_attestation_ibfk_9` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_share_relocation_attestation_ctime BEFORE INSERT ON form_share_relocation_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_share_transfer_attestation`
--

DROP TABLE IF EXISTS `form_share_transfer_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_share_transfer_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `share_id` bigint(20) NOT NULL,
  `serial_number` varchar(16) NOT NULL,
  `box_id` bigint(20) NOT NULL,
  `reason` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `share_id` (`share_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `box_id` (`box_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_1` FOREIGN KEY (`share_id`) REFERENCES `share` (`share_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_5` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_share_transfer_attestation_ibfk_8` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_share_transfer_attestation_ctime BEFORE INSERT ON form_share_transfer_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_shareholder_function_change_attestation`
--

DROP TABLE IF EXISTS `form_shareholder_function_change_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_shareholder_function_change_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `shareholder_id` bigint(20) NOT NULL,
  `existing_function_id` bigint(20) NOT NULL,
  `new_function_id` bigint(20) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `shareholder_id` (`shareholder_id`),
  KEY `existing_function_id` (`existing_function_id`),
  KEY `new_function_id` (`new_function_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `site_id` (`site_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_1` FOREIGN KEY (`shareholder_id`) REFERENCES `shareholder` (`shareholder_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_2` FOREIGN KEY (`existing_function_id`) REFERENCES `function` (`function_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_3` FOREIGN KEY (`new_function_id`) REFERENCES `function` (`function_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_shareholder_function_change_attestation_ibfk_9` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_shareholder_role_change_attestation`
--

DROP TABLE IF EXISTS `form_shareholder_role_change_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_shareholder_role_change_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `shareholder_id` bigint(20) NOT NULL,
  `existing_function_type_id` int(3) NOT NULL,
  `new_function_type_id` int(3) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `shareholder_id` (`shareholder_id`),
  KEY `existing_function_type_id` (`existing_function_type_id`),
  KEY `new_function_type_id` (`new_function_type_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_1` FOREIGN KEY (`shareholder_id`) REFERENCES `shareholder` (`shareholder_id`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_2` FOREIGN KEY (`existing_function_type_id`) REFERENCES `function_type` (`function_type_id`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_3` FOREIGN KEY (`new_function_type_id`) REFERENCES `function_type` (`function_type_id`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_6` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_shareholder_role_change_attestation_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `form_skr_receipt_install_attestation`
--

DROP TABLE IF EXISTS `form_skr_receipt_install_attestation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_skr_receipt_install_attestation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `activity_date` date NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `zone` varchar(128) DEFAULT NULL,
  `skr_filename` varchar(100) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `date_sent_to_ops` date DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `filename_signed` varchar(100) DEFAULT NULL,
  `status_id` int(3) NOT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `rejected_by` bigint(20) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `site_id` (`site_id`),
  KEY `status_id` (`status_id`),
  KEY `approved_by` (`approved_by`),
  KEY `rejected_by` (`rejected_by`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `form_skr_receipt_install_attestation_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `form_skr_receipt_install_attestation_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `form_skr_receipt_install_attestation_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `form_statuses` (`status_id`),
  CONSTRAINT `form_skr_receipt_install_attestation_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_skr_receipt_install_attestation_ibfk_5` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_skr_receipt_install_attestation_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `form_skr_receipt_install_attestation_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_skr_receipt_install_attestation_ctime BEFORE INSERT ON form_skr_receipt_install_attestation FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_statuses`
--

DROP TABLE IF EXISTS `form_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_statuses` (
  `status_id` int(3) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_statuses_ctime BEFORE INSERT ON form_statuses FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `function`
--

DROP TABLE IF EXISTS `function`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `function` (
  `function_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `function_name` varchar(72) NOT NULL,
  `function_type_id` int(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`function_id`),
  KEY `fname` (`function_name`),
  KEY `function_type_id` (`function_type_id`),
  CONSTRAINT `function_ibfk_1` FOREIGN KEY (`function_type_id`) REFERENCES `function_type` (`function_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `f_ctime` BEFORE INSERT ON `function` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `function_type`
--

DROP TABLE IF EXISTS `function_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `function_type` (
  `function_type_id` int(3) NOT NULL AUTO_INCREMENT,
  `function_type_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`function_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER function_type_ctime BEFORE INSERT ON function_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `key_type`
--

DROP TABLE IF EXISTS `key_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `key_type` (
  `key_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_type_id`),
  KEY `key_type_namekey` (`key_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `key_type_ctime` BEFORE INSERT ON `key_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `media_type`
--

DROP TABLE IF EXISTS `media_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_type` (
  `media_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `media_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`media_type_id`),
  KEY `media_type_namekey` (`media_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `media_type_ctime` BEFORE INSERT ON `media_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `model_type`
--

DROP TABLE IF EXISTS `model_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_type` (
  `model_type_id` int(3) NOT NULL AUTO_INCREMENT,
  `model_type_name` varchar(50) NOT NULL,
  `equipment_type_id` bigint(20) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`model_type_id`),
  KEY `equipment_type_id` (`equipment_type_id`),
  CONSTRAINT `model_type_ibfk_1` FOREIGN KEY (`equipment_type_id`) REFERENCES `equipment_type` (`equipment_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER model_type_ctime BEFORE INSERT ON model_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `physical_key`
--

DROP TABLE IF EXISTS `physical_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physical_key` (
  `physical_key_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `label` varchar(72) NOT NULL,
  `serial_number` varchar(16) DEFAULT NULL,
  `box_id` bigint(20) DEFAULT NULL COMMENT 'I moved the site location field from key to box',
  `physical_key_type_id` bigint(20) DEFAULT NULL,
  `shareholder_id` bigint(20) DEFAULT NULL,
  `bag_id` int(10) DEFAULT NULL,
  `escrow_location_id` int(3) DEFAULT NULL,
  `servicenow_sys_id` varchar(32) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`physical_key_id`),
  KEY `box_id` (`box_id`),
  KEY `shareholder_id` (`shareholder_id`),
  KEY `deleted` (`deleted`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `physical_key_namekey` (`label`),
  KEY `bag_id` (`bag_id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  KEY `physical_key_type_id` (`physical_key_type_id`),
  CONSTRAINT `physical_key_ibfk_10` FOREIGN KEY (`physical_key_type_id`) REFERENCES `physical_key_type` (`physical_key_type_id`),
  CONSTRAINT `physical_key_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `physical_key_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `physical_key_ibfk_4` FOREIGN KEY (`shareholder_id`) REFERENCES `shareholder` (`shareholder_id`),
  CONSTRAINT `physical_key_ibfk_5` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `physical_key_ibfk_6` FOREIGN KEY (`bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`),
  CONSTRAINT `physical_key_ibfk_9` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `physical_key_ctime` BEFORE INSERT ON `physical_key` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `physical_key_type`
--

DROP TABLE IF EXISTS `physical_key_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physical_key_type` (
  `physical_key_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `physical_key_type_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`physical_key_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER physical_key_type_ctime BEFORE INSERT ON physical_key_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `product_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_id`),
  KEY `product_namekey` (`product_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `product_ctime` BEFORE INSERT ON `product` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `quarter`
--

DROP TABLE IF EXISTS `quarter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quarter` (
  `quarter_id` int(3) NOT NULL AUTO_INCREMENT,
  `quarter_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`quarter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER quarter_ctime BEFORE INSERT ON quarter FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(3) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER role_ctime BEFORE INSERT ON role FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `security_notification`
--

DROP TABLE IF EXISTS `security_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_notification` (
  `security_notification_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `security_notification_type_id` int(3) DEFAULT NULL,
  `site_id` bigint(20) NOT NULL,
  `work_location_id` int(3) DEFAULT NULL,
  `recipients` tinytext,
  `start_send_time` datetime DEFAULT NULL,
  `end_send_time` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`security_notification_id`),
  KEY `site_id` (`site_id`),
  KEY `work_location_id` (`work_location_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `security_notification_type_id` (`security_notification_type_id`),
  CONSTRAINT `security_notification_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `security_notification_ibfk_2` FOREIGN KEY (`work_location_id`) REFERENCES `work_location` (`work_location_id`),
  CONSTRAINT `security_notification_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `security_notification_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `security_notification_ibfk_5` FOREIGN KEY (`security_notification_type_id`) REFERENCES `security_notification_type` (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER security_notification_ctime BEFORE INSERT ON security_notification FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `security_notification_type`
--

DROP TABLE IF EXISTS `security_notification_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_notification_type` (
  `type_id` int(3) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER security_notification_type_ctime BEFORE INSERT ON security_notification_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `share`
--

DROP TABLE IF EXISTS `share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share` (
  `share_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `share_label` varchar(72) NOT NULL,
  `serial_number` varchar(16) DEFAULT NULL,
  `share_type_id` bigint(20) NOT NULL,
  `box_id` bigint(20) DEFAULT NULL,
  `escrow_location_id` int(3) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `environment_id` bigint(20) DEFAULT NULL,
  `key_type_id` bigint(20) DEFAULT NULL,
  `media_type_id` bigint(20) DEFAULT NULL,
  `mofn_threshold` varchar(12) DEFAULT NULL,
  `bag_id` int(10) DEFAULT NULL,
  `always_bagged` tinyint(1) NOT NULL DEFAULT '0',
  `share_creation_date` date DEFAULT NULL,
  `original_distribution_date` date DEFAULT NULL,
  `date_destroyed` date DEFAULT NULL,
  `share_set` varchar(72) DEFAULT NULL,
  `notes` text,
  `last_audit_date` date DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`share_id`),
  KEY `share_namekey` (`share_label`),
  KEY `share_type_id` (`share_type_id`),
  KEY `box_id` (`box_id`),
  KEY `product_id` (`product_id`),
  KEY `environment_id` (`environment_id`),
  KEY `key_type_id` (`key_type_id`),
  KEY `media_type_id` (`media_type_id`),
  KEY `original_distribution_date` (`original_distribution_date`),
  KEY `share_set` (`share_set`),
  KEY `deleted` (`deleted`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `date_updated` (`date_updated`),
  KEY `date_created` (`date_created`),
  KEY `bag_id` (`bag_id`),
  KEY `escrow_location_id` (`escrow_location_id`),
  CONSTRAINT `share_ibfk_1` FOREIGN KEY (`share_type_id`) REFERENCES `share_type` (`share_type_id`),
  CONSTRAINT `share_ibfk_10` FOREIGN KEY (`escrow_location_id`) REFERENCES `escrow_location` (`escrow_location_id`),
  CONSTRAINT `share_ibfk_2` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `share_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `share_ibfk_4` FOREIGN KEY (`environment_id`) REFERENCES `environment` (`environment_id`),
  CONSTRAINT `share_ibfk_5` FOREIGN KEY (`key_type_id`) REFERENCES `key_type` (`key_type_id`),
  CONSTRAINT `share_ibfk_6` FOREIGN KEY (`media_type_id`) REFERENCES `media_type` (`media_type_id`),
  CONSTRAINT `share_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `share_ibfk_8` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `share_ibfk_9` FOREIGN KEY (`bag_id`) REFERENCES `tamper_evident_bag` (`bag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=880 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `share_ctime` BEFORE INSERT ON `share` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `share_type`
--

DROP TABLE IF EXISTS `share_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share_type` (
  `share_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `share_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`share_type_id`),
  KEY `share_type_namekey` (`share_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `share_type_ctime` BEFORE INSERT ON `share_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `shareholder`
--

DROP TABLE IF EXISTS `shareholder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shareholder` (
  `shareholder_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `shareholder_name` varchar(72) NOT NULL,
  `username` varchar(128) NOT NULL,
  `cbo_user` tinyint(1) DEFAULT '0',
  `has_data_center_access` tinyint(1) DEFAULT '0',
  `manager_name` varchar(150) DEFAULT NULL,
  `function_type_id` int(3) NOT NULL,
  `function_id` bigint(20) NOT NULL,
  `function_id_secondary` bigint(20) DEFAULT NULL,
  `site_id` bigint(20) NOT NULL,
  `phone_number` varchar(25) DEFAULT NULL,
  `desk_location` varchar(50) DEFAULT NULL,
  `job_title` varchar(128) DEFAULT NULL,
  `notes` text,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`shareholder_id`),
  KEY `function_id` (`function_id`),
  KEY `site_id` (`site_id`),
  KEY `deleted` (`deleted`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `shareholder_namekey` (`shareholder_name`),
  KEY `function_type_id` (`function_type_id`),
  KEY `function_id_secondary` (`function_id_secondary`),
  CONSTRAINT `shareholder_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `shareholder_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `shareholder_ibfk_3` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `shareholder_ibfk_4` FOREIGN KEY (`function_id`) REFERENCES `function` (`function_id`),
  CONSTRAINT `shareholder_ibfk_5` FOREIGN KEY (`function_type_id`) REFERENCES `function_type` (`function_type_id`),
  CONSTRAINT `shareholder_ibfk_6` FOREIGN KEY (`function_id_secondary`) REFERENCES `function` (`function_id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `shareholder_ctime` BEFORE INSERT ON `shareholder` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `shareholder_blacklist`
--

DROP TABLE IF EXISTS `shareholder_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shareholder_blacklist` (
  `shareholder_blacklist_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`shareholder_blacklist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER shareholder_blacklist_ctime BEFORE INSERT ON shareholder_blacklist FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `site_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`site_id`),
  KEY `site_namekey` (`site_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `site_ctime` BEFORE INSERT ON `site` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `support_contract`
--

DROP TABLE IF EXISTS `support_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_contract` (
  `support_contract_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order_number` varchar(72) DEFAULT NULL,
  `contract_number` varchar(72) DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `maintenance_plan_type` varchar(128) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`support_contract_id`),
  KEY `deleted_key` (`deleted`),
  KEY `purchase_order_number` (`purchase_order_number`),
  KEY `contract_number` (`contract_number`),
  KEY `date_start` (`date_start`),
  KEY `date_end` (`date_end`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `support_contract_ctime` BEFORE INSERT ON `support_contract` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `tamper_evident_bag`
--

DROP TABLE IF EXISTS `tamper_evident_bag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tamper_evident_bag` (
  `bag_id` int(10) NOT NULL AUTO_INCREMENT,
  `bag_serial` varchar(50) NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:new, 1:used->sealed, 2:used->opened',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bag_id`),
  UNIQUE KEY `unique_bag_serial` (`bag_serial`)
) ENGINE=InnoDB AUTO_INCREMENT=5644 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER tamper_evident_bag_ctime BEFORE INSERT ON tamper_evident_bag FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `token_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `token` varchar(128) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=541 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) DEFAULT NULL,
  `name` varchar(172) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `office_phone` varchar(32) DEFAULT NULL,
  `cell_phone` varchar(32) DEFAULT NULL,
  `employee_number` varchar(32) DEFAULT NULL,
  `title` varchar(72) DEFAULT NULL,
  `reporting_manager` varchar(196) DEFAULT NULL,
  `notes` text,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `registered` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `dddddddd` (`disabled`),
  KEY `username` (`username`),
  KEY `name` (`name`),
  KEY `eeemail` (`email`),
  KEY `is_admin` (`is_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_acl`
--

DROP TABLE IF EXISTS `user_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_acl` (
  `user_acl_id` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_acl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER user_acl_ctime BEFORE INSERT ON user_acl FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor` (
  `vendor_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(72) NOT NULL,
  `vendor_website` varchar(196) DEFAULT NULL,
  `vendor_address_street` varchar(128) DEFAULT NULL,
  `vendor_address_city` varchar(128) DEFAULT NULL,
  `vendor_address_state` varchar(12) DEFAULT NULL,
  `vendor_address_zip` varchar(12) DEFAULT NULL,
  `vendor_address_country` varchar(12) NOT NULL DEFAULT 'US',
  `vendor_support_email` varchar(172) DEFAULT NULL,
  `vendor_support_phone` varchar(32) DEFAULT NULL,
  `vendor_account_number` varchar(128) DEFAULT NULL,
  `notes` text,
  `comments` text,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vendor_id`),
  KEY `deleted_key` (`deleted`),
  KEY `vendor_namekey` (`vendor_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `vendor_ctime` BEFORE INSERT ON `vendor` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `vendor_attachment`
--

DROP TABLE IF EXISTS `vendor_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_attachment` (
  `vendor_attachment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `vendor_id` bigint(20) DEFAULT NULL,
  `attachment_id` bigint(20) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vendor_attachment_id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `attachment_id` (`attachment_id`),
  KEY `date_created` (`date_created`),
  CONSTRAINT `vendor_attachment_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`vendor_id`) ON DELETE CASCADE,
  CONSTRAINT `vendor_attachment_ibfk_2` FOREIGN KEY (`attachment_id`) REFERENCES `attachment` (`attachment_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `vendor_attachment_ctime` BEFORE INSERT ON `vendor_attachment` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `vendor_contact`
--

DROP TABLE IF EXISTS `vendor_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_contact` (
  `vendor_contact_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `vendor_contact_name` varchar(172) NOT NULL,
  `vendor_contact_title` varchar(72) NOT NULL,
  `vendor_contact_office_phone` varchar(36) NOT NULL,
  `vendor_contact_cell_phone` varchar(36) NOT NULL,
  `vendor_contact_email` varchar(172) NOT NULL,
  `vendor_id` bigint(20) NOT NULL,
  `priority_rank` tinyint(4) NOT NULL DEFAULT '1',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vendor_contact_id`),
  KEY `vendor_contact_namekey` (`vendor_contact_name`),
  KEY `vendor_id` (`vendor_id`),
  KEY `priority_rank` (`priority_rank`),
  KEY `vendor_id_2` (`vendor_id`,`priority_rank`),
  KEY `deleted` (`deleted`),
  CONSTRAINT `vendor_contact_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`vendor_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `vendor_contact_ctime` BEFORE INSERT ON `vendor_contact` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `work_location`
--

DROP TABLE IF EXISTS `work_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_location` (
  `work_location_id` int(3) NOT NULL AUTO_INCREMENT,
  `location` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`work_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER work_location_ctime BEFORE INSERT ON work_location FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-21 13:41:38
-- MySQL dump 10.13  Distrib 5.5.11, for Linux (x86_64)
--
-- Host: localhost    Database: cbo
-- ------------------------------------------------------
-- Server version	5.5.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `destruction_method`
--

DROP TABLE IF EXISTS `destruction_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `destruction_method` (
  `destruction_method_id` int(3) NOT NULL AUTO_INCREMENT,
  `destruction_method_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`destruction_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destruction_method`
--

LOCK TABLES `destruction_method` WRITE;
/*!40000 ALTER TABLE `destruction_method` DISABLE KEYS */;
INSERT INTO `destruction_method` VALUES (1,'Drill',0,'0000-00-00 00:00:00','2013-10-28 18:06:37'),(2,'Shredder',0,'0000-00-00 00:00:00','2013-10-28 18:06:42');
/*!40000 ALTER TABLE `destruction_method` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER destruction_method_ctime BEFORE INSERT ON destruction_method FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `environment`
--

DROP TABLE IF EXISTS `environment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `environment` (
  `environment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `environment_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`environment_id`),
  KEY `deleted_key` (`deleted`),
  KEY `ename` (`environment_name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `environment`
--

LOCK TABLES `environment` WRITE;
/*!40000 ALTER TABLE `environment` DISABLE KEYS */;
INSERT INTO `environment` VALUES (1,'DEV',0,'2013-02-25 19:21:19','2013-04-29 12:52:48'),(2,'OTE',0,'2013-02-25 19:21:19','2013-04-29 12:52:48'),(3,'OTHER',0,'2013-02-25 19:21:19','2013-04-29 12:52:48'),(4,'PROD',0,'2013-02-25 19:21:19','2013-04-29 12:52:48'),(5,'P&S',0,'2013-02-25 19:21:19','2013-04-29 12:52:48'),(6,'QA',0,'2013-02-25 19:21:19','2013-03-20 17:55:52'),(20,'CBO',0,'2013-10-07 18:02:46','2013-10-07 18:02:46'),(21,'UNASSIGNED',0,'2014-06-18 14:44:11','2014-06-18 14:44:11');
/*!40000 ALTER TABLE `environment` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `e_ctime` BEFORE INSERT ON `environment` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment_type`
--

DROP TABLE IF EXISTS `equipment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_type` (
  `equipment_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `equipment_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`equipment_type_id`),
  KEY `deleted_key` (`deleted`),
  KEY `equipment_type_namekey` (`equipment_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_type`
--

LOCK TABLES `equipment_type` WRITE;
/*!40000 ALTER TABLE `equipment_type` DISABLE KEYS */;
INSERT INTO `equipment_type` VALUES (1,'Computer',0,'2013-02-25 19:21:20','2013-04-29 14:47:51'),(2,'Dockreader',0,'2013-02-25 19:21:20','2013-04-29 14:47:51'),(3,'HSM',0,'2013-02-25 19:21:20','2013-04-29 14:47:51'),(4,'PED',0,'2013-02-25 19:21:20','2013-04-29 14:47:51'),(5,'Others',0,'2013-02-25 19:21:20','2013-03-20 18:00:17'),(7,'HP Drive',0,'2013-10-07 13:44:35','2013-10-07 13:44:35');
/*!40000 ALTER TABLE `equipment_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `equipment_type_ctime` BEFORE INSERT ON `equipment_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment_version`
--

DROP TABLE IF EXISTS `equipment_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_version` (
  `equipment_version_id` int(3) NOT NULL AUTO_INCREMENT,
  `equipment_version_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`equipment_version_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_version`
--

LOCK TABLES `equipment_version` WRITE;
/*!40000 ALTER TABLE `equipment_version` DISABLE KEYS */;
INSERT INTO `equipment_version` VALUES (1,'v3',0,'0000-00-00 00:00:00','2013-11-06 14:16:28'),(2,'v5',0,'0000-00-00 00:00:00','2013-11-06 14:16:29');
/*!40000 ALTER TABLE `equipment_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER equipment_version_ctime BEFORE INSERT ON equipment_version FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `escrow_location`
--

DROP TABLE IF EXISTS `escrow_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrow_location` (
  `escrow_location_id` int(3) NOT NULL AUTO_INCREMENT,
  `escrow_location_name` varchar(50) NOT NULL,
  `escrow_location_type_id` bigint(20) NOT NULL,
  `site_id` bigint(20) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`escrow_location_id`),
  KEY `site_id` (`site_id`),
  KEY `escrow_location_type_id` (`escrow_location_type_id`),
  CONSTRAINT `escrow_location_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `site` (`site_id`),
  CONSTRAINT `escrow_location_ibfk_2` FOREIGN KEY (`escrow_location_type_id`) REFERENCES `escrow_location_type` (`escrow_location_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow_location`
--

LOCK TABLES `escrow_location` WRITE;
/*!40000 ALTER TABLE `escrow_location` DISABLE KEYS */;
INSERT INTO `escrow_location` VALUES (1,'ILG1 Ceremony Room',1,5,0,'2013-06-25 19:03:41','2014-04-28 18:09:02'),(2,'BRN1 Travel Safe',2,2,0,'2013-06-25 19:03:48','2014-04-28 18:18:37'),(3,'ILG1 Mega Safe',2,5,0,'2013-06-25 19:03:58','2014-04-28 18:18:35'),(4,'ILG1 Travel Safe',2,5,0,'2013-06-25 19:04:07','2014-04-28 18:18:32'),(5,'BRN1 Mega Safe',2,2,0,'2013-06-25 19:04:26','2014-04-28 18:18:39'),(6,'BRN1 Ceremony Room',1,2,0,'2013-06-25 19:04:43','2014-04-28 18:09:02'),(7,'BRN1 Safe Room',1,2,0,'2013-06-25 19:04:52','2014-04-28 18:09:02'),(8,'ILG1 Safe Room',1,5,0,'2013-10-07 18:04:11','2014-04-28 18:09:02'),(9,'CBO Lab',1,1,0,'2013-10-07 18:04:20','2014-04-28 18:09:02'),(10,'Other',5,1,0,'2013-10-07 18:04:26','2014-04-28 18:19:13'),(11,'FRI2 Online Safe',2,3,0,'2013-10-15 14:07:15','2014-04-28 18:18:37'),(12,'BRN1 Data Center',4,2,0,'2013-10-29 19:23:38','2014-04-28 18:17:43'),(13,'ILG1 Data Center',4,5,0,'2013-10-29 19:23:50','2014-04-28 18:18:36'),(14,'BRN1 Traka Box',3,2,0,'2014-04-10 18:26:24','2014-04-28 18:18:38'),(15,'ILG1 Traka Box',3,5,0,'2014-04-10 18:26:41','2014-04-28 18:18:38');
/*!40000 ALTER TABLE `escrow_location` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER escrow_location_ctime BEFORE INSERT ON escrow_location FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cabinet`
--

DROP TABLE IF EXISTS `cabinet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cabinet` (
  `cabinet_id` int(3) NOT NULL AUTO_INCREMENT,
  `cabinet_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cabinet_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cabinet`
--

LOCK TABLES `cabinet` WRITE;
/*!40000 ALTER TABLE `cabinet` DISABLE KEYS */;
INSERT INTO `cabinet` VALUES (1,'BRN1 Traka',1,'0000-00-00 00:00:00','2014-04-14 18:11:56'),(2,'FRI2 Online Cabinet',0,'2014-07-14 12:33:43','2014-07-14 12:33:43'),(3,'FRI2 Online Safe',0,'2014-07-14 12:34:41','2014-07-14 12:34:41'),(4,'BRN1 Online Cabinet',0,'2014-08-19 13:07:16','2014-08-19 13:07:16'),(5,'BRN1 Offline Safe',0,'2014-08-19 13:07:25','2014-08-19 13:07:25'),(6,'ILG1 Online Cabinet',0,'2014-08-19 13:07:34','2014-08-19 13:07:34'),(7,'ILG1 Offline Safe',0,'2014-08-19 13:08:07','2014-08-19 13:08:07');
/*!40000 ALTER TABLE `cabinet` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER cabinet_ctime BEFORE INSERT ON cabinet FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `escrow_location_type`
--

DROP TABLE IF EXISTS `escrow_location_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrow_location_type` (
  `escrow_location_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `escrow_location_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`escrow_location_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow_location_type`
--

LOCK TABLES `escrow_location_type` WRITE;
/*!40000 ALTER TABLE `escrow_location_type` DISABLE KEYS */;
INSERT INTO `escrow_location_type` VALUES (1,'Room',0,'2014-04-28 18:09:46','2014-04-28 18:09:46'),(2,'Safe',0,'2014-04-28 18:09:46','2014-04-28 18:09:46'),(3,'Traka Box',0,'2014-04-28 18:09:46','2014-04-28 18:19:04'),(4,'Data Center',0,'2014-04-28 18:09:46','2014-04-28 18:09:46'),(5,'Other',0,'2014-04-28 18:18:57','2014-04-28 18:18:57');
/*!40000 ALTER TABLE `escrow_location_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER escrow_location_type_ctime BEFORE INSERT ON escrow_location_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `form_statuses`
--

DROP TABLE IF EXISTS `form_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_statuses` (
  `status_id` int(3) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_statuses`
--

LOCK TABLES `form_statuses` WRITE;
/*!40000 ALTER TABLE `form_statuses` DISABLE KEYS */;
INSERT INTO `form_statuses` VALUES (1,'Pending',0,'2013-04-15 13:38:19','2013-04-15 13:38:19'),(2,'Approved',0,'2013-04-15 13:38:19','2013-04-15 13:38:19'),(3,'Rejected',0,'2013-04-15 13:38:19','2013-04-15 13:38:19');
/*!40000 ALTER TABLE `form_statuses` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER form_statuses_ctime BEFORE INSERT ON form_statuses FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `function`
--

DROP TABLE IF EXISTS `function`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `function` (
  `function_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `function_name` varchar(72) NOT NULL,
  `function_type_id` int(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`function_id`),
  KEY `fname` (`function_name`),
  KEY `function_type_id` (`function_type_id`),
  CONSTRAINT `function_ibfk_1` FOREIGN KEY (`function_type_id`) REFERENCES `function_type` (`function_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `function`
--

LOCK TABLES `function` WRITE;
/*!40000 ALTER TABLE `function` DISABLE KEYS */;
INSERT INTO `function` VALUES (2,'D/SO',1,0,'2013-02-25 19:21:20','2013-08-27 19:51:13'),(3,'M of N',1,0,'2013-02-25 19:21:20','2013-08-27 19:51:13'),(4,'Unassigned',3,0,'2013-02-25 19:21:20','2013-08-27 19:59:03'),(9,'HSM',1,0,'2013-07-11 18:13:20','2013-08-27 19:51:13'),(10,'App Cards/Partition Passwords',1,0,'2013-07-11 18:13:26','2013-09-11 19:46:30'),(11,'Common',1,0,'2013-07-11 18:13:33','2013-08-27 19:51:13'),(22,'MegaSafe (BRN1)',2,0,'2013-09-11 19:47:04','2013-09-11 19:47:04'),(23,'MegaSafe (ILG1)',2,0,'2013-09-11 19:47:13','2013-09-11 19:47:13'),(24,'Crypto Cabinet Access Pool A (BRN1)',2,0,'2013-09-11 19:47:37','2013-09-11 19:47:37'),(25,'Crypto Cabinet Access Pool A (ILG1)',2,0,'2013-09-11 19:47:44','2013-09-11 19:47:44'),(26,'Crypto Cabinet Access Pool B (BRN1)',2,0,'2013-09-11 19:47:53','2013-09-11 19:47:53'),(27,'Crypto Cabinet Access Pool B (ILG1)',2,0,'2013-09-11 19:48:10','2013-09-11 19:48:10'),(28,'Crypto Cabinet/Safe Access (FRI2)',2,0,'2014-07-14 12:32:49','2014-07-14 12:32:49'),(29,'Bank Access (FRI2)',2,0,'2014-07-15 07:42:06','2014-07-15 07:42:06'),(30,'Sysadmin',4,0,'2014-11-07 18:57:08','2014-11-07 18:57:08');
/*!40000 ALTER TABLE `function` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `f_ctime` BEFORE INSERT ON `function` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `function_type`
--

DROP TABLE IF EXISTS `function_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `function_type` (
  `function_type_id` int(3) NOT NULL AUTO_INCREMENT,
  `function_type_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`function_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `function_type`
--

LOCK TABLES `function_type` WRITE;
/*!40000 ALTER TABLE `function_type` DISABLE KEYS */;
INSERT INTO `function_type` VALUES (1,'Physical Key',0,'2013-08-27 19:49:39','2013-08-27 19:49:39'),(2,'Access',0,'2013-08-27 19:49:40','2013-08-27 19:49:40'),(3,'Physical Key + Access',0,'2013-08-27 19:58:57','2014-11-07 18:56:19'),(4,'Sysadmin',0,'2014-11-07 18:56:09','2014-11-07 18:56:09');
/*!40000 ALTER TABLE `function_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER function_type_ctime BEFORE INSERT ON function_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `key_type`
--

DROP TABLE IF EXISTS `key_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `key_type` (
  `key_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_type_id`),
  KEY `key_type_namekey` (`key_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_type`
--

LOCK TABLES `key_type` WRITE;
/*!40000 ALTER TABLE `key_type` DISABLE KEYS */;
INSERT INTO `key_type` VALUES (1,'CASH',0,'2013-02-25 19:21:20','2013-02-25 19:21:20'),(2,'KSK',0,'2013-02-25 19:21:20','2013-02-25 19:21:20'),(3,'ZSK',0,'2013-02-25 19:21:20','2013-02-25 19:21:20'),(4,'Other',0,'2013-02-25 19:21:20','2013-03-20 18:07:40'),(5,'KWK',0,'2014-10-20 19:09:28','2014-10-20 19:09:28');
/*!40000 ALTER TABLE `key_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `key_type_ctime` BEFORE INSERT ON `key_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `media_type`
--

DROP TABLE IF EXISTS `media_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_type` (
  `media_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `media_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`media_type_id`),
  KEY `media_type_namekey` (`media_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_type`
--

LOCK TABLES `media_type` WRITE;
/*!40000 ALTER TABLE `media_type` DISABLE KEYS */;
INSERT INTO `media_type` VALUES (1,'iKey',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(2,'Card',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(3,'Paper',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(4,'MiniCD',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(5,'USB',0,'2013-02-25 19:21:21','2013-03-20 18:11:45'),(6,'Other',0,'2013-02-25 19:21:21','2013-02-25 19:21:21');
/*!40000 ALTER TABLE `media_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `media_type_ctime` BEFORE INSERT ON `media_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `model_type`
--

DROP TABLE IF EXISTS `model_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_type` (
  `model_type_id` int(3) NOT NULL AUTO_INCREMENT,
  `model_type_name` varchar(50) NOT NULL,
  `equipment_type_id` bigint(20) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`model_type_id`),
  KEY `equipment_type_id` (`equipment_type_id`),
  CONSTRAINT `model_type_ibfk_1` FOREIGN KEY (`equipment_type_id`) REFERENCES `equipment_type` (`equipment_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_type`
--

LOCK TABLES `model_type` WRITE;
/*!40000 ALTER TABLE `model_type` DISABLE KEYS */;
INSERT INTO `model_type` VALUES (1,'CA4',3,0,'0000-00-00 00:00:00','2013-11-06 14:57:43'),(2,'G5',3,0,'0000-00-00 00:00:00','2013-11-06 14:57:52'),(3,'PCIE-7000',3,0,'0000-00-00 00:00:00','2013-11-15 15:33:58'),(4,'Keyper Enterprise',3,0,'0000-00-00 00:00:00','2013-12-02 16:12:05');
/*!40000 ALTER TABLE `model_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER model_type_ctime BEFORE INSERT ON model_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `physical_key_type`
--

DROP TABLE IF EXISTS `physical_key_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physical_key_type` (
  `physical_key_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `physical_key_type_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`physical_key_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physical_key_type`
--

LOCK TABLES `physical_key_type` WRITE;
/*!40000 ALTER TABLE `physical_key_type` DISABLE KEYS */;
INSERT INTO `physical_key_type` VALUES (1,'CBO Key',0,'2013-07-10 17:30:27','2013-07-10 17:30:27'),(2,'Common Key',0,'2013-07-10 17:30:27','2013-07-10 17:54:50'),(3,'Shareholder Key',0,'2013-07-10 17:30:31','2013-07-10 17:30:31'),(4,'Cage Key',0,'2015-02-02 13:12:34','2015-02-02 13:12:34');
/*!40000 ALTER TABLE `physical_key_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER physical_key_type_ctime BEFORE INSERT ON physical_key_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `product_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_id`),
  KEY `product_namekey` (`product_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'DNSAS',0,'2013-02-25 19:21:21','2013-10-07 18:02:03'),(2,'CORE',0,'2013-02-25 19:21:21','2013-10-07 18:02:02'),(3,'CTLD',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(4,'GOV',0,'2013-02-25 19:21:21','2013-10-07 18:02:01'),(5,'ROOT/ARPA',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(6,'OTHER',0,'2013-02-25 19:21:21','2013-10-07 18:02:19'),(7,'UNASSIGNED',0,'2014-06-18 14:44:22','2014-06-18 14:44:22'),(8,'ARPA',0,'2015-04-21 21:05:06','2015-04-21 21:05:06');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `product_ctime` BEFORE INSERT ON `product` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `quarter`
--

DROP TABLE IF EXISTS `quarter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quarter` (
  `quarter_id` int(3) NOT NULL AUTO_INCREMENT,
  `quarter_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`quarter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quarter`
--

LOCK TABLES `quarter` WRITE;
/*!40000 ALTER TABLE `quarter` DISABLE KEYS */;
INSERT INTO `quarter` VALUES (1,'1st',0,'0000-00-00 00:00:00','2013-10-31 16:57:00'),(2,'2nd',0,'0000-00-00 00:00:00','2013-10-31 16:57:00'),(3,'3rd',0,'0000-00-00 00:00:00','2013-10-31 16:57:00'),(4,'4th',0,'0000-00-00 00:00:00','2013-10-31 16:57:00');
/*!40000 ALTER TABLE `quarter` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER quarter_ctime BEFORE INSERT ON quarter FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(3) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Share Owner',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(2,'Performer',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(3,'Witness',0,'2013-04-12 16:50:54','2013-04-29 18:29:48'),(4,'CBO Engineer',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(5,'OPS Personnel',0,'2013-04-12 16:50:54','2013-04-29 18:29:48'),(6,'Access Personnel',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(7,'Receiving Key Holder',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(8,'Relinquishing Key Holder',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(9,'Courier',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(10,'Recipient',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(11,'Receiving Personal',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(12,'Escrowing Personal',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(13,'Auditor',0,'2013-04-12 16:50:54','2013-04-12 16:50:54'),(14,'Receiving Share Holder',0,'2013-04-12 16:50:54','2013-04-29 18:29:48'),(15,'Relinquishing Share Holder',0,'2013-04-12 16:50:55','2013-04-23 18:35:22'),(16,'Operator',0,'2013-07-01 15:10:41','2013-07-01 15:10:41'),(17,'Distributing Share Holder',0,'2013-07-02 18:18:40','2013-07-02 18:18:40');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER role_ctime BEFORE INSERT ON role FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `security_notification_type`
--

DROP TABLE IF EXISTS `security_notification_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_notification_type` (
  `type_id` int(3) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_notification_type`
--

LOCK TABLES `security_notification_type` WRITE;
/*!40000 ALTER TABLE `security_notification_type` DISABLE KEYS */;
INSERT INTO `security_notification_type` VALUES (1,'Access',0,'2015-09-28 13:50:13','2015-09-28 13:50:13'),(2,'Traka Checks',0,'2015-09-28 13:50:13','2015-09-28 13:50:13'),(3,'A/C Checks',0,'2015-09-28 13:50:14','2015-09-28 13:50:14');
/*!40000 ALTER TABLE `security_notification_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER security_notification_type_ctime BEFORE INSERT ON security_notification_type FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `share_type`
--

DROP TABLE IF EXISTS `share_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share_type` (
  `share_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `share_type_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`share_type_id`),
  KEY `share_type_namekey` (`share_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share_type`
--

LOCK TABLES `share_type` WRITE;
/*!40000 ALTER TABLE `share_type` DISABLE KEYS */;
INSERT INTO `share_type` VALUES (1,'AAK',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(2,'APP',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(3,'Domain',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(4,'M of N',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(5,'Operator',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(6,'Other',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(7,'Partition Password',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(8,'Password',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(9,'RPK',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(10,'Security Officer',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(11,'SMK',0,'2013-02-25 19:21:21','2013-02-25 19:21:21'),(12,'User',0,'2013-02-25 19:21:21','2013-03-20 18:15:11'),(13,'Database',0,'2014-05-19 15:33:24','2014-05-19 15:33:24');
/*!40000 ALTER TABLE `share_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `share_type_ctime` BEFORE INSERT ON `share_type` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `site_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(72) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`site_id`),
  KEY `site_namekey` (`site_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
INSERT INTO `site` VALUES (1,'ALL',0,'2013-02-25 19:21:22','2013-02-25 19:21:22'),(2,'BRN1',0,'2013-02-25 19:21:22','2013-04-26 20:02:50'),(3,'FRI2',0,'2013-02-25 19:21:22','2013-02-25 19:21:22'),(4,'IAD1',0,'2013-02-25 19:21:22','2013-02-25 19:21:22'),(5,'ILG1',0,'2013-02-25 19:21:22','2013-03-21 12:58:15'),(9,'Credit Suisse-FRI',0,'2013-10-15 14:10:04','2013-10-15 14:10:04'),(10,'Credit Suisse-BULLE',0,'2013-10-15 14:10:19','2013-10-15 14:10:19');
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `site_ctime` BEFORE INSERT ON `site` FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `work_location`
--

DROP TABLE IF EXISTS `work_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_location` (
  `work_location_id` int(3) NOT NULL AUTO_INCREMENT,
  `location` varchar(50) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`work_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_location`
--

LOCK TABLES `work_location` WRITE;
/*!40000 ALTER TABLE `work_location` DISABLE KEYS */;
INSERT INTO `work_location` VALUES (1,'Data Center',0,'2015-04-17 19:13:45','2015-04-17 19:13:45'),(2,'Safe Room',0,'2015-04-17 19:13:45','2015-04-17 19:13:45'),(3,'Data Center & Safe Room',0,'2015-04-17 19:13:45','2015-04-17 19:13:45');
/*!40000 ALTER TABLE `work_location` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER work_location_ctime BEFORE INSERT ON work_location FOR EACH ROW SET NEW.date_created = CURRENT_TIMESTAMP */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-21 13:51:58
