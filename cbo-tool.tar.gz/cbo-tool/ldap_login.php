<?php

	ob_start();
	require_once("includes.php");
	db_connect();	
	header_start("Login");
	
?>

	<script>

		$(document).ready(function(){
			
			// Place focus in the first text box
			
			$('#username').focus();
			
			// Detect if the browser is IE
			
			if($.browser.msie){

				// Display the message box to the top offset of browser
				
				$('#message_box').slideDown('slow');  
				
				// When the close button is clicked hide the message box
				
				$('#close_message').click(function(){					
					$('#message_box').animate({ top:"-=15px", opacity:0 }, "slow");
				});
				
			}
			
		});

	</script>

<?php	

		if(isset($_POST['submit'])){	
			
			// Set user variables
			
			$Password     = @$_POST['password'];
			$URL          = $_REQUEST['url'];			
			$Username     = clean_sql_value(strtolower(@$_POST['username']));
			
			if(!$Username){ add_message('error', $GLOBALS['errorMessage']['login_username_empty']); }			
			if(!$Password){ add_message('error', $GLOBALS['errorMessage']['login_password_empty']); }
			
			// The user has select to authenticate against active directory

			if(check_messages()){
								
				// Authenticate the user against active directory
				
				$LDAPData = authenticate_user($Username, $Password);
			
				if(!$LDAPData){
					add_message('error', $GLOBALS['errorMessage']['login_failed']);
				}else{
				
					// Verify the user is in the ACL
				
					if(!check_user_acl($Username)){
						add_message('error', $GLOBALS['errorMessage']['not_authorized']);
					}
				}
				
				if(check_messages()){
				
					// Find the employee's managers name
						
					preg_match('/(?<=CN=)(.*?)(?=,OU)/', @$LDAPData['manager'][0], $Matches);
					list($ManagerLast, $ManagerFirst) = array_map('trim', explode(',', str_replace('\\', '', $Matches[0])));
					$ManagersName = clean_sql_value($ManagerFirst . " " . $ManagerLast);

					// Check the database to see if this user has logged in using VCORP before, if the user was not found, add them to the database

					if(account_check($Username) != 1){

						// If the users email is not returned from AD set it up ourselves
						
						$Email = clean_sql_value($LDAPData['mail'][0]);
						
						if($Email === NULL){ $Email = $Username . "@" . DEFAULT_EMAIL_DOMAIN; }
						
						// Set the users first and last name
						
						$Fullname = explode(",", $LDAPData['name'][0]);
						
						$First = clean_sql_value(trim($Fullname[1]));
						$Last  = clean_sql_value(trim($Fullname[0]));	
						
						// Set some additional employees attributes
						
						$EmployeeID  = clean_sql_value(trim(@$LDAPData['employeenumber'][0]));
						$Title       = clean_sql_value(trim(@$LDAPData['title'][0]));
						$CellPhone   = clean_sql_value(trim(@$LDAPData['mobile'][0]));
						$OfficePhone = clean_sql_value(trim(@$LDAPData['telephonenumber'][0]));
						
						// If no errors update the database
						
						if(check_messages()){
						
							// Add the user to the database					
							
							$LDAPInfo['username']            = $Username;
							$LDAPInfo['disabled']            = 0;
							$LDAPInfo['email']               = $Email;
							$LDAPInfo['employee_number']     = $EmployeeID;
							$LDAPInfo['title']               = $Title;
							$LDAPInfo['cell_phone']          = $CellPhone;
							$LDAPInfo['office_phone']        = $OfficePhone;
							$LDAPInfo['reporting_manager']   = $ManagersName;
							$LDAPInfo['name']                = $First . " " . $Last;
							$LDAPInfo['last_login']          = "NOW()";
							
							$Result = db_query(create_sql_insert($LDAPInfo, DB_TABLE_USERS), FALSE);
							
							if(!$Result){
								add_message('error', $GLOBALS['errorMessage']['account_creation_failed']);
							}	
							
						}
																
					// The users account exists and their credentials are good, but lets verify that thier account hasn't been disabled

					}elseif(account_check($Username) == 1){		

						if(is_account_disabled($Username) == 0){
							add_message('error', $GLOBALS['errorMessage']['account_disabled']);			
						}
						
						// Update the users manager and last login time
						
						$LDAPInfo['reporting_manager'] = $ManagersName;
						$LDAPInfo['last_login']        = "NOW()";						
						$LDAPWhere['username']         = $Username;	

						$Result = db_query(create_sql_update($LDAPInfo, $LDAPWhere, DB_TABLE_USERS), FALSE);
					}
						
					if(check_messages()){
					
						// The user has been authenticated and their new account has been created if needed
					
						if($LDAPData){
						
							// Create a cookie for the user
							
							if(!create_cookie($Username)) {
								add_message('error', $GLOBALS['errorMessage']['cookie_update_failure']);
							}

							if(check_messages()){
								
								// Cleanup tokens older than 14 days
								
								token_cleanup();

								// Send the user to the home page or their desired destination
				
								(@$URL? redirect($URL) : redirect('.'));	
				
							}
						}
					}
				}				
			}
		}	
		
		body_start();	
		navigation_start("login");
		
		// Display a message to IE users
		
		echo "<div style='display: none;' id='message_box'><img id='close_message' src='images/delete-red.png' />This website is best viewed with Firefox or Chrome.</div>";

		// Display the login form
			
		echo "<div class='margin_bottom_15px'>Login using your VCORP credentials!</div>";
			
		form_start(array('action' => $_SERVER['PHP_SELF'], 'name' => 'login', 'show_legend' => FALSE ));
			form_text_field(array('title' => 'Username', 'name' => 'username', 'value' => @$_REQUEST['username']));			
			form_password_field(array('title' => 'Password', 'name' => 'password'));
			form_hidden(array('name' => 'url', 'value' => @$_GET['url']));	
			form_submit(array('value' => 'Log In'));
		form_end();	
				
	footer_start();
	db_close();

?>