<?php

// Require
require_once('../includes.php');

// ** Funciton to select a single value from a DB table. Heavily used in displaying
// ** pending form information
function select_db_value($from_col_name, $from_table, $where_col_name, $where_col_val) {
    // Form the Database Value Query Statement
    $db_val_query="SELECT " . $from_col_name . "
                   FROM " . $from_table . "
                   WHERE " . $where_col_name ."='". $where_col_val . "'";
    // DB Result
    $db_val_result = db_query($db_val_query);
    // Result Row Count
    $db_val_row_count = row_count($db_val_result);
    // Initialize Result Storage Variable
    $return_array = NULL;
    //echo '<pre>' . print_r($db_val_row_count, true) . '</pre>';
    // If there is One Value, Return a Success Status and Value
    if ($db_val_row_count == 1 ) {
      // Store the Desired Column Value
      $return_val= row_fetch_assoc($db_val_result)[$from_col_name];
      // Form the Return Array
      $return_array = array(
        'status'  => 'success',
        'value'   => $return_val
      );
    }
    // Send NA if we have no value received 
    elseif ($db_val_row_count == 0) {
         $return_array = array(
        'status'  => 'success',
        'value'   => 'N/A' 
      );
     } 
    // If There is Not Exactly One Response, Return a Failed Status and the Error Message as Value
    else {
      // Form the Return Array
      $return_array = array(
        'status'  => 'error',
        'value'   => "ERROR: Found Duplicate values!"
      );
    }
    // Return the Return Array
    return $return_array;
}

//
// **  Function to get the values of the physical key label and the Traka assignment person
function get_traka_assignment($phy_key_id) {

        $traka_assign="SELECT physical_key.label, shareholder.shareholder_name
                     FROM physical_key
                     INNER JOIN shareholder
                     ON shareholder.shareholder_id=". $ph_key_id . "
                     AND physical_key.shareholder_id=" . $ph_key_id;

        $traka_assign_res=db_query($traka_assign);
        $traka_assign_row_count=row_count($traka_assign_res);

        if ($traka_assign_row_count== 1 ) {

            $label= row_fetch_assoc($traka_assign_res)['label'];
            $traka_assigine = row_fetch_assoc($traka_assign_res)['shareholder_name'];
         }
         else {
             $response = array(
          'error' => "ERROR Traka assignment is not unique"
           );
         }
         return array($label, $traka_assigine);

}
// Get the shareholder name for the role
function get_share_holder_name($form_id, $exec_id, $role_id) {
      $sh_query = "SELECT shareholder.shareholder_name
                  FROM shareholder
                  LEFT JOIN form_roles 
                  ON form_roles.shareholder_id = shareholder.shareholder_id
                  WHERE form_roles.form_id=" . $form_id . "
                  AND form_roles.execution_id=" . $exec_id . "
                  AND form_roles.role_id=" . $role_id;
         $sh_query_res=db_query($sh_query);
         $sh_query_res_row_count=row_count($sh_query_res);

         if ($sh_query_res_row_count == 1 ) {
             $return_val=row_fetch_assoc($sh_query_res)['shareholder_name'];
           
             // Form the Return Array
             $return_array = array(
                  'status'  => 'success',
                  'value'   => $return_val
             );
          }
          // If There is Not Exactly One Response, Return a Failed Status and the Error Message as Value
          else {
          // Form the Return Array with errro message
              $return_array = array(
                    'status'  => 'error',
                     'value'   => "ERROR: No value or Duplicates"
                );
           }
    // Return the Return Array
    return $return_array;
}

// *** Function to Get the shareholder and the CBO Engineer information for the pending form// ** Also get the vaidation information
function get_shareholder_info($form_name, $form_id, $execution_id, $min_users, &$common_roles) {
  // Form the SQL Query
  $shareholder_query = "SELECT shareholder.shareholder_name, shareholder.username, shareholder.cbo_user, role.role_name
                        FROM shareholder
                        LEFT JOIN form_roles
                        ON shareholder.shareholder_id=form_roles.shareholder_id
                        LEFT JOIN role 
                        ON form_roles.role_id = role.role_id
                        WHERE form_roles.form_id=" . $form_id . "
                        AND form_roles.execution_id=" . $execution_id;
  // Execute the Query and Store the Results
  $sql_shareholder_result = db_query($shareholder_query);
  $shareholder_row_count = row_count($sql_shareholder_result);
  // Make Sure that the Row Count Returns at Least min_users for this form
  if($shareholder_row_count < $min_users){
    // Form the Return Array
    $response = array(
      'status'  => 'error',
      'value'   => 'ERROR There should be ' . $min_users . ' users for this form'
    );
    // Return the Array
    return $response;
  }

  // If There are  min_users , Store the Data
  else{
    // Data Storage
    $share_holder_info = [];
    $cbo_user_info  = [];
    // Iterate Through the Results
    while($shareholder_row = row_fetch_assoc($sql_shareholder_result)){
      // Get the Validation Status For the Shareholders for the
      // Specific Form
      $validation_query = "SELECT id, validated, validation_date
                           FROM validation_log
                           WHERE form_table_name='" . $form_name . "'
                           AND execution_id=" . $execution_id . "
                           AND shareholder_username='" . $shareholder_row['username'] . "'";
      // Storage for Returned Validation Data
      $validation_data = NULL;
      // Execute Validation Query
      $validation_query_result = db_query($validation_query);
      // Get the Row Count
      $validation_query_row_count = row_count($validation_query_result);
      // If There are No Results, the User has Not Validated the Form.
      // Form Validation Data Appropriately
      if($validation_query_row_count < 1){
        $validation_data = array(
          'id'              => NULL,
          'validated'       => '0',
          'validation_date' => NULL
        );
      }
      // If There is a Result, Form the Appropriate Array
      else{
        // Fetch Assoc
        $validation_data_row = row_fetch_assoc($validation_query_result);
        $validation_data = array(
          'id'              => $validation_data_row['id'],
          'validated'       => $validation_data_row['validated'],
          'validation_date' => $validation_data_row['validation_date']
        );
      }
      // Create a Map
      $temp_data = array(
        'name'            => $shareholder_row['shareholder_name'],
        'username'        => $shareholder_row['username'],
        'role'            => $shareholder_row['role_name'],
        'validation_data' => $validation_data
      );
      // Push the Map into  proper Storage ( cboeng or shareholderinfo)
      if ($shareholder_row['cbo_user'] == 0) {
          array_push($share_holder_info, $temp_data);
      }
      elseif ($shareholder_row['cbo_user'] == 1) {
             
         //If we have common roles, push to the shareholder array for proper mapping
         if (count($common_roles) > 0  ) {
            
             $match=false; 
             // iterate through the common role array 
             foreach ($common_roles as $com_role) {
                 
                if ((strcmp($shareholder_row['role_name'], $com_role)) == 0) {
                   $match=true;
                }
              }
              if ($match) {      
                   //echo '<pre>' . print_r(" Found Match " . $com_role, true) . '</pre>';
                   array_push($share_holder_info, $temp_data); 
              }
              // No common role then you are a CBO
              else array_push($cbo_user_info, $temp_data);
              
         }
         else {
              array_push($cbo_user_info, $temp_data);
         }
      }
      else {
        // Form the Return Array
        $response = array(
          'status'  => 'error',
          'value'   => 'ERROR Invalid category for the user'
      );
        // Return the Array
        return $response;
      }
    }
  }
  // Return the Data
  return array(
    'status' => 'success',
    'share_holder_info' => $share_holder_info,
    'cbo_user_info'     => $cbo_user_info
  );
}

// function to validate the input 
function  validate_get($execution_id)  {

   // if the execution id is integer
     //$valid = is_int($execution_id);
     $valid = is_numeric($execution_id);
     return $valid;
}
  // Function to Return an Error Message
  function return_error($message){
    // Form the Response Array
    $response = array(
      'error' => $message
    );
    // Return the Error JSON
    echo json_encode($response);
    // Exit
    exit(0);
  }

?>
