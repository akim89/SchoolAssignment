<?php

  // Includes
  require_once('../includes.php');

  db_connect();
  date_default_timezone_set('UTC');
  // Extract the Form ID From the POST Data
  $form_id = $_POST['form_id'];
  $OutputFilename = $_POST['form_filename'];
  $form_data = $_POST['data'];
  $exec_id = $_POST['exec_id'];
  $form_table_name = $_POST['form_table_name'];
  
  // Global Extraction/Write Variables
  $TempDirectory = PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_TEMP;
  $XMLFile = $TempDirectory . "/word/document.xml";
  $XMLFileTemp = $TempDirectory . "/word/document.xml.temp";
  $FormID = validate("int", $_POST['form_id'], "form ID", 1);
  $FormName = lookup_form_name($FormID);
  $Filename = lookup_form_filename($FormID);

 // ** Load Json file to get the filename format for the signed pdf
  $pdf_name_formats_raw = file_get_contents('./json/pdf_format.json');
  $pdf_name_formats = json_decode($pdf_name_formats_raw, true);

  // call the function to create the expected pdf filename
  $output_pdf_file=get_formatted_pdf($FormID, $FormName,$form_data,$pdf_name_formats);

  // Create/Initialize the XML Parser that will Read $XMLFile
  $parser = xml_parser_create();
  // The XML Datahandler for when the XML Parser Finds Document Text
  // The Datahandler will Call Function "char" and Pass in the Text it Found
  xml_set_character_data_handler($parser, "char");

  // Global Storage for All the Text Found by the "char" Function while Parsing
  // Through the XML Data
  $all_text_data = array();

  // Unzip the Corresponding DOCX Form Tempate
  $unzip_status = unzip_docx($Filename);
  // If the Unzip was Successful
  if($unzip_status){
    // Parse through $XMLFile and Attempt to Reattach Tokens Using Lexical Analysis
    // For Example, if the DOCX XML Seperates "{{" from the Rest of the Token (e.g. "DATE}}"),
    // this Function Attempts to Reattach Them Together. It will Work on Any Variation of
    // Seperation.
    cleanXML();
    // Write Data to the Extracted/Cleaned $XMLFile
    writeData($XMLFile, $form_data);
    // Write Data to the Extracted/Cleaned $XMLFooter
    // Approvar info is in footer. get that info from the data
    $approver_info=$form_data['IGNORE_SIGAPRV'];
    writeFooter($OutputFilename, $approver_info);
   
    // Zip Up the Contents of the File Back Into a DOCX
    if(docx_zip($OutputFilename)){
      // Convert the DOCX to PDF
      
      convertToPDF(PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_SIGNED. "/" . $OutputFilename, PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_SIGNED, $form_table_name, $exec_id,$output_pdf_file);
      // Return Download Link
      return_message("success", PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_SIGNED . "/" . $OutputFilename);
    }
    // If the Zip was Not Successful
    else return_message("error", "ERROR Could not zip file");
  }

  /*
  * Name: convertToPDF
  * Description: Converts a DOCX to PDF using the LibreOffice CLI.
  * @parameter $fileToConvert The path of the file to be converted.
  * @parameter $outputDirectory The path of the output directory.
  */
  function convertToPDF($fileToConvert, $outputDirectory, $form_table_name, $exec_id, $output_pdf_file){
    // Global $OutputFilename
    global $OutputFilename;
    // Store the DOCX FileName
    //$DOCXName = $OutputFilename;
    // Clear Cache
    clearstatcache();
    // Make Sure the File Exists
    if(file_exists($fileToConvert)){
      // Form the Conversion Command
      $Command = "/usr/bin/libreoffice --headless --convert-to pdf " . $fileToConvert . " --outdir " . $outputDirectory . " 2>&1";
     
      // Execute the Shell Command
      if(shell_exec($Command) !== NULL){
        
        // If the Command was a Success, Change the OutputFilename to the PDF Version
        //$OutputFilename = str_replace(".docx", ".pdf", $OutputFilename);
        if ($output_pdf_file == "NA") {
           $OutputFilename = str_replace(".docx", ".pdf", $OutputFilename);
        }
        else {
            
           $OutputFilename = str_replace(".docx", ".pdf", $OutputFilename);
           rename($outputDirectory . "/" .$OutputFilename, $outputDirectory . "/" . $output_pdf_file);
           $OutputFilename = $output_pdf_file;
        }
        // Remove the Digitaly Signed DOCX File
        unlink($fileToConvert);

        //update the form table with the signed pdf file name information
        $update_query="UPDATE " . $form_table_name . "
                      SET filename_signed='" . $OutputFilename . "'
                      WHERE id=" . $exec_id;
        $db_val_result = db_query($update_query);
         //error_log($update_query,0);
        // check if we have sucess in update
        // Add code
        
      }
    }
  }

  /*
  * Name: docx_zip
  * Description: Zips up the extracted, modified XML files back into DOCX form
  * and then places the completed form in the completed form directory.
  */
  function cleanXML(){
    // Globals
    global $XMLFile;
    global $XMLFileTemp;
    global $parser;
    // Open up the Specified $XMLFile in Read Mode
    $file = fopen($XMLFile, "r");
    // Read Through the XML File
    while($file_data = fread($file, filesize($XMLFile))){
      // Parse the File, This Process will Call the "char" Function
      // Implicitly because Text is Found as the XML is Parsed.
      xml_parse($parser, $file_data, TRUE);
    }
    // Free the XML Parser
    xml_parser_free($parser);
    // Perform the Lexical Analysis
    lexicalAnalysis();
  }

  /*
  * Name: lexicalAnalysis
  * Description: Performs lexical analysis on $all_text_data to determine which
  * lines need to be combined together to form valid tokens, and then actually
  * merge the data in the XML file.
  */
  function lexicalAnalysis(){
    // Global $all_text_data
    global $all_text_data;
    // Data that Needs to be Grouped Together to Form 1 Complete Token
    $lines_to_merge = array();
    // Array that Contains Multiple $lines_to_merge (i.e. This Array Holds the
    // Groups for all the Fragmented Tokens in the Document)
    $final_merge = array();
    // Missing Characters for Lexical Analysis
    $missing_chars = "";
    // Flag to Determine if a Piece of Data Needs to be Added to $lines_to_merge
    $FLAG = FALSE;
    // Iterate Through $all_text_data
    for($counter = 0; $counter < sizeof($all_text_data); $counter++){
      // The Text in Current Piece of Data
      $current_text = $all_text_data[$counter][0];
      // Turn the Current Text into a Character Array
      $current_text_array = str_split($current_text);
      // Go Through the Array Character by Character if a "{" is Found, Add it to
      // the $missing_chars String, and if the "}" is Found, A "{" is Removed From
      // $missing_chars.
      for($counter2 = 0; $counter2 < sizeof($current_text_array); $counter2++){
        $delete_number = 1;
        if($current_text_array[$counter2] == "{") $missing_chars = $missing_chars . "}";
        if($current_text_array[$counter2] == "}") $missing_chars = str_replace("}", "", $missing_chars, $delete_number);
      }
      // If There are Still Missing Characters When Trying to Form a Complete Token,
      // Set the Capture Flag to TRUE and Push the Data to $lines_to_merge.
      if($missing_chars !== ""){
        $FLAG = TRUE;
        array_push($lines_to_merge, $all_text_data[$counter]);
      }
      // If There are No More Missing Characters, but the Capture $FLAG is Enabled,
      // This Piece of Data Must be the Last Piece Required to Form 1 Complete Token
      // (e.g. {{TOKEN}}). Therefore, Push this Piece of Data into $lines_to_merge,
      // Turn the Capture $FLAG Off, Then Push the Data Group ($lines_to_merge) that
      // Forms a Complete Token to $final_merge.
      if($missing_chars === "" && $FLAG === TRUE){
        $FLAG = FALSE;
        array_push($lines_to_merge, $all_text_data[$counter]);
        array_push($final_merge, $lines_to_merge);
        // Unset and Empty the $lines_to_merge Array
        unset($lines_to_merge);
        $lines_to_merge = array();
      }
    }

    // Assemble Complete Text for Tokens and the Locations to Place the Completely
    // Formed Tokens.
    for($counter = sizeof($final_merge) - 1; $counter >= 0; $counter--){
      $current_replacement = $final_merge[$counter];
      $complete_text = "";
      $complete_line_num = $current_replacement[0][1];
      $complete_colm_num = $current_replacement[0][2] - mb_strlen($current_replacement[0][0]);
      // Iterate Through All the Token Pieces in a Group in Reverse
      for($counter2 = sizeof($current_replacement) - 1; $counter2 >= 0; $counter2--){
        $current_piece = $current_replacement[$counter2];
        // Add Text Piece to $complete_text
        $complete_text = $current_piece[0] . $complete_text;
        // Remove the Text From the XML
        writeXMLData($current_piece[0], $current_piece[1], $current_piece[2], "REMOVE");
      }
      // Write the Correct XML Token to the XML File
      writeXMLData($complete_text, $complete_line_num, $complete_colm_num, "ADD");
    }

  }

  /*
  * Name: char
  * Description: This function is called whenever the XML parser encounters
  * text data between XML tags. The goal is to store the text data and its location
  * in the file so lexical analysis can be performed later.
  */
  function char($parser, $data){
    // Brings the $all_text_data Variable into this Function's Scope
    global $all_text_data;
    // Push into the $all_text_data Array an Array Containing the text found,
    // the line it was found on, and the Character Number on the Line
    $temp_array = array($data, xml_get_current_line_number($parser), xml_get_current_column_number($parser));
    array_push($all_text_data, $temp_array);
  }

  /*
  * Name: writeXMLData
  * Description: Writes/Deleted intended data
  */
  function writeXMLData($text_to_change, $line_number, $column_number, $operation){
    // Globals
    global $XMLFile;
    global $XMLFileTemp;
    // Get the Length for $text_to_change
    $text_length = mb_strlen($text_to_change, "UTF-8");
    // Dtermine the Starting Position and the Ending Position of the Text to Add/
    // Delete in the XML
    $starting_delete = $column_number - 1;
    $ending_delete = $column_number - 1;
    // If We are Deleting XML Data, $starting_delete Needs to be Decremented by
    // the Size of $text_to_change
    if($operation === "REMOVE") $starting_delete = $starting_delete - $text_length;
    // Open Reading and Writing Files
    $reading = fopen($XMLFile, 'r');
    $writing = fopen($XMLFileTemp, 'w');
    // Line Counter
    $line_counter = 0;
    // Read the XML File Line by Line
    while(!feof($reading)){
      // Current Line
      $line = fgets($reading);
      $line_counter++;
      // If The Current Line is Not the One Being Modified, Just Write it
      if($line_counter !== $line_number) fputs($writing, $line);
      // If it is the Line that is Being Edited
      else{
        // Edit the Line
        $string_length = mb_strlen($line, "UTF-8");
        $substring1 = mb_substr($line, 0, $starting_delete);
        $substring2 = mb_substr($line, $ending_delete);
        $final_line = "";
        if($operation === "REMOVE") $final_line = $substring1 . $substring2;
        else $final_line = $substring1 . $text_to_change . $substring2;
        // Write the Line
        fputs($writing, $final_line);
      }
    }
    // Close the Files
    fclose($reading);
    fclose($writing);
    // Rename the Temp File to the $XMLFile to Overite the Unmodified XML File
    rename($XMLFileTemp, $XMLFile);
  }

  /*
  * Name: writeData
  * Description: Finds tokens in $XMLFile and replaces them with the values
  * specified in $Data.
  */
  function writeData($XMLFile, $Data){
   // Get All the Keys From the Data
   $fields_array = array_keys($Data);
   // Get the Contents of the XML File
   $file_contents = file_get_contents($XMLFile);
   // Iterate Through the Keys
   for($counter = 0; $counter < count($fields_array); $counter++){
     // The Current Key
     $key = $fields_array[$counter];
     // Field to Replace
     $field_replace = "{{". $key ."}}";
     //Replace the special charactores in data to xml liking
     $data_val=purify_data($Data[$key]);
     // Replace the DOCX Field With the Correct Value
     $file_contents = str_replace($field_replace, $data_val, $file_contents);
   }
   // Replace the Signature
   //$file_contents = str_replace("{{IGNORE_DIGITAL_SIGNATURE}}", "Digitally Signed", $file_contents);
   // Replace IGNORE_DATE With Current Date
   $file_contents = str_replace("{{IGNORE_DT}}", date("Y-m-d"), $file_contents);
   // Write the Contents
   file_put_contents($XMLFile, $file_contents);
 }

  /*
  * Name: writeFooter
  * Description: Updates footer XML with appropriate data.
  */
 function writeFooter($OutputFilename, $approver_stamp){
   // Define Global
   global $TempDirectory;
   // For Each Footer File, Replace the IGNORE_TIMESTAMP Token
   foreach(glob($TempDirectory . "/word/footer*.xml") as $XMLFileFooter){
     // Get the Contents of the XML File
     $file_contents = file_get_contents($XMLFileFooter);
     // Replace Ignore Timestamp
     $file_contents = str_replace("{{IGNORE_TIMESTAMP}}", $OutputFilename, $file_contents);
     //insert the form approvar stamp
     $file_contents = str_replace("{{IGNORE_SIGAPRV}}", $approver_stamp, $file_contents);
     // Write the Contents
     file_put_contents($XMLFileFooter, $file_contents);
   }
 }


  /*
  * Name: return_message
  * Description: A simple error message helper.
  */
  function return_message($status, $message){
    // Form the Response Array
    $response = array(
      'status'  => $status,
      'message'   => $message
    );
    // Return the Error JSON
    echo json_encode($response);
  }

  /*
  * Name: docx_zip
  * Description: Zips up the extracted, modified XML files back into DOCX form
  * and then places the completed form in the completed form directory.
  */
  function docx_zip($OutputFilename){
    $RootDirectory   = PATH_ROOT_DIR . "/" . PATH_WWW;
  	$OutputDirectory = PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_SIGNED;
		$TempDirectory   = $RootDirectory . "/" . PATH_FORMS_TEMP;

		$FilesToZip = array("_rels", "word", "[Content_Types].xml");
		$Command = "cd $TempDirectory && zip -r $OutputDirectory/$OutputFilename " . implode(" ", $FilesToZip);

		if(shell_exec($Command) !== NULL){   // "echo" this line to see command line output
			return TRUE;
		}else{
			return FALSE;
		}
  }

  /*
  * Name: get_formatted_pdf
  * Description: Create the formatted signed pdf filename 
  */
  function get_formatted_pdf($this_formid, $FormName,$form_data,$pdf_name_formats) {

      // Load  the pdf formats  
      $all_formats=$pdf_name_formats['pdf_formats'];
      // intialize the format to NA
      $this_format="NA";
      // Check if the category is defined
      $found_format=false;
      foreach ($all_formats as $format => $formIds) {

           foreach ($formIds as $fid) {

               if ($this_formid == $fid ) {
                    $this_format = $format;
                    $found_format=true;
                    break;
               };
           };
           if ($found_format) {
                break;
           }
      };
      
      // if we a format 
      if (($found_format)  and ($this_format != "NA")){
     
          $out_pdf='';
          $cat_parts=preg_split('/-/', $this_format);
          $total_parts=count($cat_parts);
          $x=0;
          // iterate through each part of file format
          foreach ($cat_parts as $part) {

             if ($part == "FORMNAME") {
                 //construct short formname remove word Attestation
                 $f_name_1=str_replace("Attestation", "", $FormName);
                 $this_part=str_replace(" ", "", $f_name_1);
              }
              elseif (preg_match('/DATE/', $part)) {
                  // format the DATE for the pdf filename
                  $act_date=str_replace('-', '', $form_data[$part]);
                   $now_time= date('His');
                   $this_part=$act_date . $now_time;
              }
              // if the pdf filename is different then use special 
              elseif ($part == "SPECIAL") {
                     $special_name=$pdf_name_formats['special_pdf_names'][$this_formid];
                     $this_part=$special_name;
              }
              else {
                   //Directly get the value from the docx data
                   // remove spaces (if any) on the data value
                   $this_part = preg_replace('/\s+/', '_', $form_data[$part]);
                   //$this_part=$form_data[$part];
              }
              $x=$x+1;
              if ($x == $total_parts) {
                 // final consctruction of the pdf file name
                 $out_pdf= $out_pdf . $this_part .'.pdf';
              }
              else {
              $out_pdf= $out_pdf . $this_part .'-';
              }
         }
         //return $out_pdf;
      }  
      
      // if no format
      else {
          $out_pdf="NA";
      }
      return $out_pdf;
  }

  //
  // function to clean up the special chars in data which could break the docx xml
  //
  function purify_data($data_str) {
     // xml speical characters and it's replacements
     $xml_dislikes=["&amp;-&", "&gt;->", "&lt;-<", "&apos;-'", '&quot;-"'];

     foreach ($xml_dislikes as $xml_dislike) {

         $xml_fix=preg_split('/-/', $xml_dislike);
         $data_str= str_replace($xml_fix[1],$xml_fix[0], $data_str);
     }
     return $data_str;
  }

?>
