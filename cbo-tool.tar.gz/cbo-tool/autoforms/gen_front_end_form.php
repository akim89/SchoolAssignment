<html>
  <head>

    <link rel="stylesheet" href="../autoforms/css/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="../autoforms/css/form_style.css" />
    <script type="text/javascript">
      window.onload = function(){
        var isIE = /*@cc_on!@*/false || !!document.documentMode;
        if (isIE){
            alert("Please use another web browser to complete this task.");
        }
}
</script>
  </head>
  <!-- Construct  Form Body -->
  <body>
  <div class="container">
   <p id="error_line"></p>
    <!-- Form -->
    <form>
      <!-- Form Header/Title -->
      <div class="headerWrap">
        <img src="../images/vrsnlogo.png" alt="logo" />
        <div class="titleWrap">
          <h1 id="head0"></h1>
          <h2 id="head1"></h2>
        </div>
      </div>

      <!-- Form Description line 1 -->
      <p id="line1"></p>
      <!-- Pending Form data Information -->
      <div id="pending_form_data"></div>

      <p id="line2"></p>
      <p id="line3"></p>
    </form>
    <!-- Error Messages Container -->
    <div id="messages" class="text-danger">
    </div>
      <!-- Some forms will have the share holders sign after line3 and 4 -->
    <!-- shareholder validation-->
    <form name="sep_shldr_sig_place_0" action="" method=""></form>
    <form name="shareholder_signature_info" action="" method=""></form>

    <p id="line4"></p>

    <form name="sep_shldr_sig_place_1" action="" method=""></form>

    <!-- Some forms will have the line5 if the shareholders are seperate-->
    <p id="line5"></p>

    <form name="cboeng_signature_info" action="" method=""></form>
    <form name="approve_reject_form" action="" method=""></form>

    <!-- Display any Warning messages for the pending form"-->
    <p class="text-warning" id="warn_msg"></p>

    <footer>
    <p id ="vsrn_msg"> <span>
    <p id ="file_timestamp"></span> </p>
   </footer>
    <!-- Retrieving Form Contents -->
    <script src="../js/jquery/jquery-1.8.0.min.js"></script>
    <script src="./js/construct_form.js"></script>
    <script src="./js/form_text.js"></script>
    <script>
      // Document on Ready
      $(window).load(function(){
         // Storage for the Form Data
         var form_data = {};
         // Store the string with form_name and id
         var selected_data_string = form_data.selected_data_string = "<?php echo $_POST['selected_data_string']; ?>" || localStorage.getItem('selected_data_string');
         var selected_data = selected_data_string.split("--");
         var form_table_name = form_data.form_table_name = selected_data[0];
         //console.log(selected_data);
         var execution_id = form_data.execution_id = selected_data[1];
         // Get the required pending form data from backend
         $.get("gen_backend_form_data.php", form_data, function(response, status){

            // console.log(response);
             //console.log(typeof date_to_string);
             // check for Error Message in response from backend
             if ("error" in response) {
                document.getElementById("error_line").innerHTML = response.error;
                return;
             }
             // print the warning message if any
             if (response.warn_msg != undefined ) {
                // console.log(response.warn_msg);
                  document.getElementById("warn_msg").innerHTML = response.warn_msg;
             }

             // Get the docx data from the backend
             var docx_data = response.docx_data;
             //get the form text
             var form_text=pick_text_for_form(form_table_name);

             // Check for Error message from form_text and exit
             if ("error_line" in form_text) {
                document.getElementById("error_line").innerHTML = form_text["error_line"];
                return;
             }
             // populate the form for the headings and lines
             for (key in form_text) {
                var key_str=String(key)

                if ((key_str.indexOf("line") > -1)  || (key_str.indexOf("head") > -1) ) {
                    //console.log(key_str);
                    document.getElementById(key).innerHTML = form_text[key];
                }
             }

             // get the form_filename to get the timestamp
             var form_filename=response.form_filename;

             //give the footer info
             document.getElementById("vsrn_msg").innerHTML ="Verisign Restricted";
             document.getElementById("file_timestamp").innerHTML =form_filename;

             // Assign the Form ID
             var form_id = response.formId;

             // Load Pending form table data
             $('#pending_form_data').empty().append(response.html);
             // The Number of Signatures Required Before the Approve/Reject Button is Shown
             var signaturesRemainingCounter = 0;
             // the Form and then Create the Appropriate Input Type
             var shareholder_array = response.shareholders;
             var cboengineer_array = response.cboeng;
             $('body').data('shareholder_array', shareholder_array);
             $('body').data('cboengineer_array', cboengineer_array);
             // in some cases the shareholders has to be presented last for the signatures
             // so decide the signatory group positions
             if (form_text["reverse_sig_disp_order"]) {
                    // shareholder at bottom
                 var signature_group_top = document.getElementsByName('cboeng_signature_info')[0];
                 var signature_group_bot = document.getElementsByName('shareholder_signature_info')[0];
              }
              else {
                 // common cases cbo at bottom
                 var signature_group_top = document.getElementsByName('shareholder_signature_info')[0];
                 var signature_group_bot = document.getElementsByName('cboeng_signature_info')[0];
              }

             // If the shareholder array have to be presented seperately then do it
             // The html is formated only for two share holder seperation
             if (form_text["div_sh_sep"]) {

                 var disp_order=form_text["div_sh_order"].split(',');

                 // Make sure the length of the shareholder array and the diplay order array is same
                 if (shareholder_array.length == disp_order.length) {

                    // Create the order of display for the shareholder signature
                    for (var i = 0; i < disp_order.length; i++) {

                       var sep_sh_array=[];
                       for (var j = 0; j < shareholder_array.length; j++) {

                         if (shareholder_array[j].role.indexOf(disp_order[i])  > -1  ) {

                             sep_sh_array[0] = shareholder_array[j];

                             var ret_shdiv_vals = construct_div_sh(sep_sh_array, form_id, execution_id, form_table_name);
                             var element_name="sep_shldr_sig_place_" + i;
                             var sep_sh_sign_form = document.getElementsByName(element_name)[0];
                             sep_sh_sign_form.innerHTML = ret_shdiv_vals.div_construction;
                             signaturesRemainingCounter += ret_shdiv_vals.signaturesRemainingCounter;

                         }
                       }
                    }
                 }
                 else {
                  console.log("ERROR: The expected shareholdders mismatch");
                 }
             }


             // do the common shareholder forms
             else {
                // Form Shareholder Div
                 var ret_shdiv_vals = construct_div_sh(shareholder_array, form_id, execution_id, form_table_name);
                 //var shareholder_sign_form = document.getElementsByName('shareholder_signature_info')[0];
                 var shareholder_sign_form = signature_group_top;
                 shareholder_sign_form.innerHTML = ret_shdiv_vals.div_construction;
                 signaturesRemainingCounter += ret_shdiv_vals.signaturesRemainingCounter;
            }

             // Form CBO Engineer Div
             var ret_cbosig_vals = construct_div_cbo(cboengineer_array, form_id, execution_id, form_table_name);
             //var cbo_sign_form = document.getElementsByName('cboeng_signature_info')[0];
             var cbo_sign_form = signature_group_bot;
             cbo_sign_form.innerHTML = ret_cbosig_vals.div_construction;
             signaturesRemainingCounter += ret_cbosig_vals.signaturesRemainingCounter;
             // Form the Approve/Reject Div
             var ret_approve_reject_div = construct_div_apr_reject(form_id, form_filename,  selected_data_string, signaturesRemainingCounter);
             var div_appr_reject = document.getElementsByName('approve_reject_form')[0];
             div_appr_reject.innerHTML = ret_approve_reject_div;
             // Bind the DOCX Data to the Approval Form
             $("#approvalForm").data("docx_data", docx_data);
         }, 'json');
      });
    </script>
  </div>
  </body>
</html>
