<?php

  // Load the Includes Module
  require_once('../includes.php');
  require_once('data_common_functions.php');
  // Connect to the Database
  db_connect();
  // POST Data
  $name = $_POST['name'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $form_id = $_POST['form_id'];
  $form_name = str_replace(".php", "", $_POST['data_form_name']);
  $form_name = str_replace("data_", "form_", $form_name);
  $execution_id = $_POST['execution_id'];
  $response = NULL;

  validateUser();

  /*
  * Validates the user's credentials based on the provided POST
  * data, and the marks that the provided user has been verified in
  * the database in the form_roles table.
  */
  function validateUser(){

    // Global Variables
    global $name, $username, $password, $form_id, $form_name, $execution_id, $response;

    // Validate POST Data
    if (!isset($name) || $name == '') validateError();
    if (!isset($username) || $username == '') validateError();
    if (!isset($password) || $password == '') validateError();
    if (!isset($form_id) || $form_id == '') validateError();
    if (!isset($form_name) || $form_name == '') validateError();
    if (!isset($execution_id) || $execution_id == '') validateError();

    // Query to Determine the User ID Based on the Username
    $user_id_response = select_db_value("shareholder_id", "shareholder", "username", $username);
    if($user_id_response['status'] == 'success') $user_id = $user_id_response['value'];
    else return_message('false', 'Could not find user id');

    // Make Sure that the User is Valid
    // Do LDAP authentication 
    $authentication_result = authenticate_user($username, $password);
    // $authentication_result = TRUE;
    // If the Authentication Fails, Return False
    if($authentication_result == FALSE) return_message('false', 'Could not authenticate user');
    // If the Authentication Succeeded, Make Sure that the User
    // is a Valid Shareholder that has Not Been Validated Yet.
    else{
      // Get the Shareholder Names and their Unique Usernames
      // Form the SQL Query
      $shareholder_query = "SELECT form_roles.id, form_roles.shareholder_id
                            FROM shareholder
                            LEFT JOIN form_roles
                            ON shareholder.shareholder_id=form_roles.shareholder_id
                            WHERE form_roles.form_id=" . $form_id . "
                            AND shareholder.username='" . $username . "'
                            AND shareholder.shareholder_name='" . $name . "'
                            AND form_roles.execution_id=" . $execution_id;
      // Execute the Query and Store the Results
      $sql_shareholder_result = db_query($shareholder_query);
      $sql_shareholder_row = row_fetch_assoc($sql_shareholder_result);
      $formRolesID = $sql_shareholder_row['id'];
      $shareholderID = $sql_shareholder_row['shareholder_id'];
      $shareholder_row_count = row_count($sql_shareholder_result);
      // If There are More or Less Than One User Returned
      if($shareholder_row_count != 1) return_message('false', 'Not a valid user');
      // If the User is a Shareholder
      else{
        // Check to Make Sure that the User has Not Already Validated the
        // Form
        $validation_check_query = "SELECT validated
                                 FROM validation_log
                                 WHERE form_table_name='" . $form_name . "'
                                 AND form_id=" . $form_id . "
                                 AND execution_id=" . $execution_id . "
                                 AND shareholder_username='" . $username . "'
                                 AND user_id=" . $user_id . "
                                 AND validated=1";
        // Execute Validation Query
        $validation_check_query_result = db_query($validation_check_query);
        // Get the Row Count
        $validation_check_query_row_count = row_count($validation_check_query_result);
        // If There are No Results, the User has Not Validated the Form.
        // and Therefore Must be Validated
        if($validation_check_query_row_count < 1){
          // Form the Query
          $validate_query = "INSERT INTO validation_log (`validated`, `form_table_name`, `execution_id`, `shareholder_username`, `user_id`, `form_id`)
                             VALUES (1, '" . $form_name . "', " . $execution_id . ", '" . $username . "', " . $user_id . ", " . $form_id . ")";
          // Execute the Query
          $sql_shareholder_result = db_query($validate_query);
          // Determine the Number of Affected Rows
          if(function_exists('mysqli_affected_rows')){
      			$number_rows_affected = mysqli_affected_rows($GLOBALS['DBLink']);
      		}else{
      			$number_rows_affected = mysql_affected_rows($GLOBALS['DBLink']);
      		}
          // Close the Database
          db_close();
          // Error Response Message
          if($number_rows_affected < 1) return_message('false', 'Could not validate user in the database');
          // Success Response Message
          else return_message('true', 'Successfully validated');
        }
        // If There are Results, the User has Already Been Validated
        else return_message('false', 'User already validated');
      }
    }
  }

  /*
  * Returns a POST validation error json.
  */
  function validateError(){
    // Form the Response Array
    return_message('false', 'Missing required fields');
    // exit
    exit(0);
  }

  // Function to Return an Error Message
  function return_message($status, $message){
    // Form the Response Array
    $response = array(
      'success' => $status,
      'message' => $message
    );
    // Return the Error JSON
    echo json_encode($response);
  }

?>
