function pick_text_for_form(form_name) {

    var text_array=[];
       // Define default values
        text_array["head0"]="Cryptographic Business Operations";
        text_array["div_sh_sep"]=false;
        text_array["div_cbo_sep"]=false;
        text_array["reverse_sig_disp_order"] = false;

    switch (form_name) {
       //form_id 5
       case "form_equip_escrow_attestation":
            text_array["head1"]="Equipment Escrow Attestation";
            text_array["line1"] = "This attestation form documents the escrow procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The two Verisign trusted personnel listed below witnessed the escrowing of the item as designated above."; 
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       //form_id 6
       case "form_hsm_deactivation_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Deactivation Attestation ";
            text_array["line1"] = "This attestation form documents the deactivation procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the above listed hardware security module was brought offline (deactivated) as described above."; 
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       //form_id 7
       case "form_share_escrow_attestation":
            text_array["head1"]="Share Escrow Attestation";
            text_array["line1"] = "This attestation form documents the escrow procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The Verisign trusted employee listed below attests that the above item was escrowed as described above."; 
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two Verisign trusted personnel listed below witnessed the escrowing of the item as designated above."; 
           break;

       //form_id 51
       case "form_share_creation_attestation":
            text_array["head1"]="Share Creation Attestation";
            text_array["line1"] = "This attestation form documents the creation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign Trusted Persons listed below witnessed the creation and escrow of the item as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       //form_id 9 (8 does not exist)
       case "form_share_distribution_attestation":
            text_array["head1"]="Share Distribution Attestation";
            text_array["line1"] = "This attestation form documents the distribution procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The Verisign trusted employee listed below attests that the above share was distributed as described above.  The Verisign trusted employee further attests that this share will only be used in connection with official Verisign business and that this share is not to be given to anyone under any circumstances unless he/she receives permission from the appropriate CBO personnel and the appropriate documentation to track this activity is completed."; 
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two Verisign trusted personnel listed below witnessed the distribution of the share as designated above."; 
           break;

       // form_id 10
       case "form_safe_deposit_box_audit_attestation":
            text_array["head1"]="Safe Deposit Box Audit Attestation";
            text_array["line1"] = "This attestation form documents the safe deposit box audit procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the safe deposit box has been audited as described above."; 
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 11
       case "form_physical_key_transfer_attestation":
            text_array["head1"]="Physical Key Transfer Attestation";
            text_array["line1"] = "This attestation form documents the transfer procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The Verisign trusted employee listed below attests that the above key was relinquished to the recipient listed below as part of his/her responsibilities."; 
            text_array["line3"] = "The Verisign trusted employee listed below attests that the above key was received from the trusted employee listed above as part of his/her responsibilities.  The Verisign trusted employee further attests that this key will only be used in connection with official Verisign business and that this key is not to be given to anyone under any circumstances unless he/she receives permission from the appropriate CBO personnel and the appropriate documentation to track this activity is completed."; 
            text_array["line4"] = "The two Verisign trusted personnel listed below witnessed the transferring of the key as designated above.";
           break;

       // form_id 12
       case "form_ksr_receipt_attestation":
            text_array["head1"] = "Key Signing Request (KSR) Receipt Attestation";
            text_array["line1"] = "This attestation form documents the receipt of the KSR and the procedures that were completed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The Verisign trusted operations personnel listed below attests that the KSR with the above hash value was sent as stated above."; 
           text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two CBO Engineers listed below attest that the KSR with the above hash value was received as described above.  "; 
           break;

       // form_id 13
       case "form_physical_key_distribution_attestation":
           text_array["head1"] = "Physical Key Distribution Attestation";
           text_array["line1"] = "This attestation form documents the distribution procedures that were performed by the Verisign personnel as designated below.";
           text_array["line2"] = "The Verisign trusted employee listed below attests that the physical key was distributed as described above.  The Verisign trusted employee further attests that this physical key will only be used in connection with official Verisign business and that this physical key is not to be given to anyone under any circumstances unless he/she receives permission from the appropriate CBO personnel and the appropriate documentation to track this activity is completed.";
           text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           text_array["line4"] = "The two Verisign trusted personnel listed below witnessed the distribution of the physical key as designated above.";
           break;
       
       // form_id 14
       case "form_physical_key_escrow_attestation":
            text_array["head1"] = "Physical Key Escrow Attestation";
            text_array["line1"] = "This attestation form documents the escrow procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The Verisign trusted employee listed below attests that the above item was escrowed as described above."; 
           text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two Verisign trusted personnel listed below witnessed the escrowing of the item as designated above."; 
           break;

       // form_id 15
       case "form_share_transfer_attestation":
            text_array["head1"]="Share Transfer Attestation";
            text_array["div_sh_sep"] = true;
            text_array["div_sh_order"] = "Relinquishing,Receiving";
            text_array["line1"] = "This attestation form documents the transfer procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The Verisign trusted employee listed below attests that the above share was relinquished to the recipient listed below as part of his/her responsibilities."; 
           text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The Verisign trusted employee listed below attests that the above share was received from the trusted employee listed above as part of his/her responsibilities.  The Verisign trusted employee further attests that this share will only be used in connection with official Verisign business and that this share is not to be given to anyone under any circumstances unless he/she receives permission from the appropriate CBO personnel and the appropriate documentation to track this activity is completed."; 
            text_array["line5"] = "The two Verisign trusted personnel listed below witnessed the transferring of the share as designated above."; 
           break;

       // form_id 16
       case "form_physical_key_courier_attestation":
            text_array["reverse_sig_disp_order"] = true;
            text_array["head1"]="Physical Key Courier Attestation"
            text_array["line1"]="This attestation form documents the courier procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The following CBO Engineer(s) listed below attest that the above item(s) is/are sealed inside the uniquely serialized tamper evident inner bag number(s) listed above and has/have been placed inside a second uniquely serialized tamper evident outer bag to create a double wrap as specified above.  The following CBO Engineer(s) further attest that the item(s) has/have been hand carried to the location specified above under dual control and that there have been no alterations, re-configuration or changes made to the item(s)."; 
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The Verisign trusted employee listed below attests that the above item(s) has/have been received at the location specified above and that there is no evidence of tampering."; 
           break;

       // form_id 18. 17 does not exist
       case "form_hsm_activation_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Initial Activation Attestation";
            text_array["line1"]="This attestation form documents the initial activation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The Verisign trusted employees listed below attest that the above hardware security module was brought online with the shares described above."; 
           text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two Verisign CBO Engineers listed below attest that the above listed HSM was brought online as described above."; 
           break;

       // form_id 19
       case "form_equip_courier_attestation":
            text_array["head1"]="Equipment Courier Attestation";
            text_array["line1"] = "This attestation form documents the courier procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The following CBO Engineer(s) listed below attest that the above item(s) is/are sealed inside the uniquely serialized tamper evident inner bag number(s) listed above and has/have been placed inside a second uniquely serialized tamper evident outer bag to create a double wrap as specified above.  The following CBO Engineer(s) further attest that the item(s) has/have been hand carried to the location specified above under dual control and that there have been no alterations, re-configuration or changes made to the item(s)."; 
            text_array["line3"] = "The Verisign trusted employee listed below attests that the above item(s) has/have been received at the location specified above and that there is no evidence of tampering. "; 
           break;

       // form_id 22 forms 20 and 21 does not exist
       case "form_share_courier_attestation":
            text_array["reverse_sig_disp_order"] = true;
            text_array["head1"]="Share Courier Attestation";
            text_array["line1"] = "This attestation form documents the courier procedures that were performed by the Verisign personnel as designated below."; 
            text_array["line2"] = "The following CBO Engineer(s) listed below attest that the above item(s) is/are sealed inside the uniquely serialized tamper evident inner bag number(s) listed above and has/have been placed inside a second uniquely serialized tamper evident outer bag to create a double wrap as specified above.  The following CBO Engineer(s) further attest that the item(s) has/have been hand carried to the location specified above under dual control and that there have been no alterations, re-configuration or changes made to the item(s)."; 
           text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The Verisign trusted employee listed below attests that the above item(s) has/have been received at the location specified above and that there is no evidence of tampering. "; 
           break;

       // form id 23
       case "form_share_rebag_attestation":
            text_array["head1"]="Share Rebag Attestation";
            text_array["line1"] = "This attestation form documents the rebag procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the equipment rebag was completed as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 24
       case "form_equip_rebag_attestation":
            text_array["head1"]="Equipment Rebag Attestation";
            text_array["line1"] = "This attestation form documents the rebag procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the equipment rebag was completed as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 25
       case "form_physical_key_rebag_attestation":
            text_array["head1"]="Physical Key Rebag Attestation";
            text_array["line1"] = "This attestation form documents the rebag procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the equipment rebag was completed as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 26
       case "form_hsm_acceptance_test_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Acceptance Test Attestation";
            text_array["line1"] = "This attestation form documents the completion of acceptance testing performed on the hardware security module designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the above listed hardware security module was tested following the appropriate CBO hardware security module acceptance testing procedures and successfully passed all required tests.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 27
       case "form_hsm_relocation_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Relocation Attestation";
            text_array["line1"] = "This attestation form documents the hardware security module (HSM) relocation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the hardware security module was transferred from the initial location specified above to the final location specified above under dual control.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 28
       case "form_hsm_destruction_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Destruction Attestation";
            text_array["line1"] = "This attestation form documents the destruction of the cryptographic hardware security module in its entirety.";
            text_array["line2"] = " The third party (Vendor) listed below attests that the item listed above was destroyed in its entirety.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two Verisign CBO Engineers listed below attest that the item listed above was destroyed in its entirety.";
           break;

       // form_id 29
       case "form_safe_combo_change_attestation":
            text_array["head1"]="Safe/Cabinet Combination Change Attestation";
            text_array["line1"] = "This attestation form documents the safe/cabinet combination change procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The Verisign trusted employee listed below attests that the above combination was changed as described above.  The Verisign trusted employee further attests that this combination will only be used in connection with official Verisign business and that this combination is not to be given to anyone under any circumstances unless he/she receives permission from the appropriate CBO personnel and the appropriate documentation to track this activity is completed.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two Verisign trusted employees listed below witnessed the combination change as designated above.";
           break;

       // form_id 30
       case "form_skr_receipt_install_attestation":
            text_array["reverse_sig_disp_order"] = true;
            text_array["head1"]="Signed Key Request (SKR) Receipt & Installation Attestation";
            text_array["line1"] = "This attestation form documents the receipt of the SKR and the procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two CBO Engineers listed below attest that the above SKR and hash value was generated and sent to operations.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The Verisign trusted operations personnel listed below attests that the SKR with corresponding hash listed above was received and installed as described above.";
           break;

       // form_id 31
       case "form_partition_password_creation_attestation":
            text_array["head1"]="Partition Password Creation Attestation";
            text_array["line1"] = "This attestation form documents the partition password creation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the above partition password was created under dual control and that this password is held and distributed only by Verisign CBO Engineers.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 32
       case "form_safe_combo_distribution_attestation":
            text_array["head1"]="Safe/Cabinet Combination Distribution Attestation";
            text_array["div_sh_sep"] = true;
            text_array["div_sh_order"] = "Distributing,Receiving";
            text_array["line1"] = "This attestation form documents the distribution procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The Verisign trusted employee listed below attests that the above combination was distributed to the recipient listed below as part of his/her responsibilities.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The Verisign trusted employee listed below attests that the above combination was received from the trusted employee listed above as part of his/her responsibilities.  The Verisign trusted employee further attests that this combination will only be used in connection with official Verisign business and that this combination is not to be given to anyone under any circumstances unless he/she receives permission from the appropriate CBO personnel and the appropriate documentation to track this activity is completed.";
           break;

       // form_id 33
       case "form_share_destruction_attestation":
            text_array["head1"]="Share Destruction Attestation";
            text_array["line1"] = "This attestation form documents the destruction of the cryptographic share in its entirety.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the item listed above was destroyed in its entirety.";  
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 34 Form Not found
       case "form_shareholder_function_change_attestation":
            text_array["head1"]="Personnel Intra Role Change Attestation  (Physical Key <->  Physical Key)";
            text_array["line1"] = "This attestation form documents a shareholder intra role change as designated below. ";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the shareholder intra role change was completed as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 35
       case "form_hsm_reactivation_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Reactivation Attestation";

            text_array["line1"] = "This attestation form documents the reactivation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The Verisign trusted employees listed below attest that the above hardware security module was brought back online with the shares described above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The two Verisign CBO Engineers listed below attest that the above listed HSM was brought back online as described above.";
           break;

       // form_id 36
       case "form_shareholder_role_change_attestation":
            text_array["head1"] = "Personnel Inter Role Change Attestation (Access <-> Physical Key)";
            text_array["line1"] = "This attestation form documents the personnel inter role change as designated below. ";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the personnel inter role change was completed as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 37
       case "form_hsm_courier_attestation":
            text_array["reverse_sig_disp_order"] = true;
            text_array["head1"]="Hardware Security Module (HSM) Courier Attestation";
            text_array["line1"] = "This attestation form documents the courier procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The following CBO Engineer(s) listed below attest that the above item(s) is/are sealed inside the uniquely serialized tamper evident inner bag number(s) listed above and has/have been placed inside a second uniquely serialized tamper evident outer bag to create a double wrap as specified above.  The following CBO Engineer(s) further attest that the item(s) has/have been hand carried to the location specified above under dual control and that there have been no alterations, re-configuration or changes made to the item(s).";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The Verisign trusted employee listed below attests that the above item(s) has/have been received at the location specified above and that there is no evidence of tampering.";
           break;

       // form_id 38
       case "form_hsm_escrow_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Escrow Attestation";
            text_array["line1"] = "This attestation form documents the escrow procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign trusted personnel listed below witnessed the escrowing of the item as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 39
       case "form_hsm_rebag_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Rebag Attestation";
            text_array["line1"] = "This attestation form documents the rebag procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the equipment rebag was completed as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 40
       case "form_share_relocation_attestation":
            text_array["head1"]="Share Relocation Attestation";
            text_array["line1"] = "This attestation form documents the share relocation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the share was transferred from the initial location specified above to the final location specified above under dual control.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 41
       case "form_physical_key_relocation_attestation":
            text_array["head1"]="Physical Key Relocation Attestation";
            text_array["line1"] = "This attestation form documents the physical key relocation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the physical key was transferred from the initial location specified above to the final location specified above under dual control.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 42
       case "form_equip_relocation_attestation":
            text_array["head1"]="Equipment Relocation Attestation";
            text_array["line1"] = "This attestation form documents the equipment relocation procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the equipment was transferred from the initial location specified above to the final location specified above under dual control.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 43
       case "form_equip_out_of_band_verification_attestation":
            text_array["head1"]="Equipment Out-Of-Band Verification Attestation";
            text_array["line1"] = "This attestation form documents the new equipment out-of-band verification procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The Verisign CBO personnel listed below attests that they performed the out-of-band verification as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 44
       case "form_hsm_relabel_attestation":
            text_array["head1"]="Hardware Security Module (HSM) Re-label Attestation";
            text_array["line1"] = "This attestation form documents the HSM relabeling procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that they performed the relabeling as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 45
       case "form_lock_repair_attestation":
            text_array["head1"]="Lock Repair/Replacement Attestation";
            text_array["line1"] = "This attestation form documents the lock repair/replacement as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the lock was repaired or replaced as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 46 // this form needs more lines and more headings 
       case "form_root_key_signing_ceremony_attestation":
            text_array["head1"]="Root Key Signing Ceremony Attestation";
            text_array["line1"] = "This attestation form documents the receipt, verification and installation procedures of the Root Key Signing Request (KSR) and Signed Key Request (SKR) that were completed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two CBO Engineers listed below attest that the KSR with the above hash value was received as described above.";  
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
            text_array["line4"] = "The CBO Engineer listed below attests that the Word List, which was generated from the hash above and was verified at the ICANN Root Key Signing Ceremony.";
           break;

       // form_id 47
       case "form_share_relabel_attestation":
            text_array["head1"]="Share Re-label Attestation";
            text_array["line1"] = "This attestation form documents the share relabeling procedures that were performed by the Verisign personnel as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that they performed the relabeling as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 48  Need work 
       case "form_hsm_out_of_band_verification_attestation":
            text_array["head1"] = "HSM Out-Of-Band Verification Attestation";
            text_array["line1"] = "The following information documents the initial purchase order of new assets and receipt verification procedures that were performed by the Verisign CBO Engineers as designated below.";
            text_array["line2"] = "The two Verisign CBO Engineers listed below attest that the above assets were received and verified with the information designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 49 
       case "form_physical_key_traka_access_revocation_attestation":
            text_array["head1"] = "Physical Key Traka Access Revocation Attestation";
            text_array["line1"] = "This attestation form documents the physical key access revocation procedures that were performed by the Verisign personnel as designated below";
            text_array["line2"] = "The two Verisign CBO Engineers listed below have confirmed that the request to revoke physical key access has been properly fulfilled as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

       // form_id 50 
       case "form_physical_key_traka_access_assignment_attestation":
            text_array["head1"] = "Physical Key Traka Access Assignment Attestation";
            text_array["line1"] = "This attestation form documents the physical key access assignment procedures that were performed by the Verisign personnel as designated below";
            text_array["line2"] = "The two Verisign CBO Engineers listed below have confirmed that the request to assign physical key access has been properly fulfilled as designated above.";
            text_array["line3"] = "By validating your LDAP login information below you agree to digitally sign this form.";
           break;

        default:
            text_array["error_line"] = "Form text not found"; 
     }
   return text_array;
}
      
          
          
