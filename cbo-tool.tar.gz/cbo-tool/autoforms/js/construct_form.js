// Construct the Shareholder Form in HTML
function construct_div_sh(shareholder_array, form_id, execution_id, data_form_name){
  // The Number of Signatures Required Before the Approve/Reject Button is Shown
  var signaturesRemainingCounter = 0;
  // For Each of the Shareholders Check if the Shareholder has Already Validated
  // the Form and then Create the Appropriate Input Type
  var div_construction = '';
  // Iterate Through the Shareholder Array
  for(var counter = 0; counter < shareholder_array.length; counter++){
    // If the Shareholder has Already Validated
    if(shareholder_array[counter].validation_data.validated == "1"){
      // Insert the HTML
      div_construction = div_construction + '<div class="cbo-signoff form-group">';
      div_construction = div_construction + '<div class="box">';
      div_construction = div_construction + '<label class="control-label">' + shareholder_array[counter].role + ' Name: </label>';
      div_construction = div_construction + '<span>' + shareholder_array[counter].name + '</span>';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="box">';
      div_construction = div_construction + '<label class="control-label">LDAP ID:</label>';
      div_construction = div_construction + '<span>' + shareholder_array[counter].username + '</span>';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="validated_container box">';
      div_construction = div_construction + '<label class="control-label"> ...Validated!</label>';
      div_construction = div_construction + '<img src="../images/checkmarkGreen.png" />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '</div>';
    }
    // If the Shareholder is Not Yet Validated
    else{
      // Insert the HTML
      div_construction = div_construction + '<div class="cbo-signoff form-group">';
      div_construction = div_construction + '<div class="role-name box">';
      div_construction = div_construction + '<label class="control-label">' + shareholder_array[counter].role + ' Name: </label>';
      div_construction = div_construction + '<input type="text" id="form_name" class="field form-control" value="' + shareholder_array[counter].name + '" readonly />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="ldap-id box">';
      div_construction = div_construction + '<label class="control-label"> LDAP ID:</label>';
      div_construction = div_construction + '<input type="text" id="form_username" class="field user form-control" value="' + shareholder_array[counter].username + '" readonly />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="validated_container box">';
      div_construction = div_construction + '<label class="control-label"> Password: </label>';
      div_construction = div_construction + '<div class="same-line">';
      div_construction = div_construction + '<input type="password" class="form-control" id="form_password" />';
      div_construction = div_construction + '<input type="button" class="btn btn-default" value="Validate" onclick="validate(((this.parentElement).parentElement).parentElement, ' + form_id + ', ' + execution_id + ', \'' + data_form_name + '\')" />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '</div>';
      // A Signature is Still Needed
      signaturesRemainingCounter++;
    }
  }
  // Return the div and Any Remaining Signatures
  return {
    div_construction: div_construction,
    signaturesRemainingCounter: signaturesRemainingCounter
  };
}

// Function to Construct the CBO Engineer Signature div
function construct_div_cbo(cboengineer_array, form_id, execution_id, data_form_name){
  // The Number of Signatures Required Before the Approve/Reject Button is Shown
  var signaturesRemainingCounter = 0;
  // For Each of the Shareholders Check if the Shareholder has Already Validated
  // the Form and then Create the Appropriate Input Type
  var div_construction = '';
  for(var counter = 0; counter < cboengineer_array.length; counter++){
    if(cboengineer_array[counter].validation_data.validated == "1"){
      // Insert the HTML
      div_construction = div_construction + '<div class="cboeng_signoff form-group">';
      div_construction = div_construction + '<div class="box">';
      div_construction = div_construction + '<label class="control-label">' + cboengineer_array[counter].role + ' Name: </label>';
      div_construction = div_construction + '<span>' + cboengineer_array[counter].name + '</span>';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="box">';
      div_construction = div_construction + '<label class="control-label">LDAP ID:</label>';
      div_construction = div_construction + '<span>' + cboengineer_array[counter].username + '</span>';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="validated_container box">';
      div_construction = div_construction + '<label class="control-label"> ...Validated!</label>';
      div_construction = div_construction + '<img src="../images/checkmarkGreen.png" />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '</div>';
    }
    // If the CBO Engineer is Not Yet Validated
    else{
      // Insert the HTML
      div_construction = div_construction + '<div class="cboeng_signoff form-group">';
      div_construction = div_construction + '<div class="role-name box">';
      div_construction = div_construction + '<label class="control-label">' + cboengineer_array[counter].role + ' Name: </label>';
      div_construction = div_construction + '<input type="text" id="form_name" class="field form-control" value="' + cboengineer_array[counter].name + '" readonly />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="ldap-id box">';
      div_construction = div_construction + '<label class="control-label"> LDAP ID: </label>';
      div_construction = div_construction + '<input type="text" id="form_username" class="field user form-control" value="' + cboengineer_array[counter].username + '" readonly />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '<div class="validated_container box">';
      div_construction = div_construction + '<label class="control-label"> Password:</label>';
      div_construction = div_construction + '<div class="same-line">';
      div_construction = div_construction + '<input type="password" class="form-control" id="form_password" />';
      div_construction = div_construction + '<input type="button" class="btn btn-default" value="Validate" onclick="validate((this.parentElement).parentElement.parentElement, ' + form_id + ', ' + execution_id + ', \'' + data_form_name + '\')" />';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '</div>';
      div_construction = div_construction + '</div>';
      // A Signature is Still Needed
      signaturesRemainingCounter++;
    }
  }
  // Return the div and Any Remaining Signatures
  return {
    div_construction: div_construction,
    signaturesRemainingCounter: signaturesRemainingCounter
  };
}

// Function to Construct the Approval and Rejection Buttons
function construct_div_apr_reject(form_id, form_filename,  selected_data_string, signaturesRemainingCounter){
  // Determine if the Approve Button Should be Disabled or Not
  var isDisabled = (signaturesRemainingCounter === 0) ? '' : 'disabled';
  // Initialize the div Construction for the Approve/Reject Buttons
  var div_construction = '';
  // Form the div
  div_construction = div_construction + '<br>';
  div_construction = div_construction + '<div id="approvalForm" class="formApproval" align="center">';
  div_construction = div_construction + ('<input type="button" class="btn btn-primary" value="Approve" onclick="approve_reject(' + form_id + ', \'' + form_filename + '\', \'' + selected_data_string + '\', \'Approve\')" ' + isDisabled + '/>');
  div_construction = div_construction + ('<input type="button" class="btn btn-warning" value="Reject" onclick="approve_reject(' + form_id + ', \'' + form_filename + '\', \'' + selected_data_string + '\', \'Reject\')" />');
  div_construction = div_construction + ('<input type="button" class="btn btn-danger" value="Cancel" onclick="download_redirect(\'\', 1, \'../home.php\')" />');
  div_construction = div_construction + '</div>';
  // Return the div
  return div_construction;
}

// Validate the Shareholder
function validate(verification_form, form_id, execution_id, data_file){
  // Get the Input Values
  var auth_data = {};
  var name = auth_data.name = $(verification_form).find('#form_name').val();
  //if (window.console) console.log(name);
  var username = auth_data.username = $(verification_form).find('#form_username').val();
 // if (window.console) console.log(username);
  var password = auth_data.password = $(verification_form).find('#form_password').val();
  //if (window.console) console.log(password);
  var form_name = auth_data.data_form_name = data_file;
  auth_data.execution_id = execution_id;
  auth_data.form_id = form_id;
  // POST Data
  $.post('authentication.php', auth_data, function(response, status){
    // Check the Response Status
    if(response.success == 'true'){
      // Update Validated Status in Div
      var verified_div = $(verification_form).find('.validated_container');
      verified_div.html(" ...Validated!<img src=\"../images/checkmarkGreen.png\" />");
      // Count the Number of Divs that Still Need to be Validated
      var signaturesRemaining = 0;
      var validated_containers = $('body').find('.validated_container');
      var num_validated_containers = validated_containers.length;
      // Iterate Through the Validation Containers
      for(var i = 0; i < num_validated_containers; i++){
        var current_container = validated_containers[i];
        signaturesRemaining += (current_container.innerText.indexOf('Password') > -1) ? 1 : 0;
      }
      // If There are No Remaining Signatures, Reload the Page
      if(signaturesRemaining === 0) window.location = window.location;
    }
    // If There was an Error Show Alert
    else alert(response.message);
  }, 'json');
}

// Approve/Reject Form
function approve_reject(form_id, form_filename, selected_data_string, action){
  // Get the docx_data from #approvalForm
  var docx_data = $("#approvalForm").data("docx_data");
  var form_string_components = selected_data_string.split("--");
  var form_table_name = form_string_components[0];
  var execution_id = form_string_components[1];
  // Check to See What the Required Number of Signatures is
  $.ajax({
    dataType: 'json',
    url: './form_data.json',
    success: function(json) {
      // Get the Number of Required Signatures for the Form
      var requiredSignatures = json.all_forms[form_id].req_sig;
      // Get the CBO and Shareholder Arrays
      var shareholder_array = $('body').data('shareholder_array');
      var cboengineer_array = $('body').data('cboengineer_array');
      // Get the Count of All the Shareholders that Have Been Validated
      var validated_users_count = 0;
      // Iterate Over Each of the Arrays
      if(shareholder_array.length > 0)
        shareholder_array.forEach(function(shareholder){
          if(shareholder.validation_data.validated == 1 || shareholder.validation_data.validated == "1")
            validated_users_count++;
        });
      if(cboengineer_array.length > 0)
        cboengineer_array.forEach(function(engineer){
          if(engineer.validation_data.validated == 1 || engineer.validation_data.validated == "1")
            validated_users_count++;
        });
      // If the validated_users_count is Less than the Required Number of Signatures,
      // Return an Error
      if(validated_users_count < requiredSignatures && action == "Approve") alert('This form requires ' + requiredSignatures + ' signatures, but only ' + validated_users_count + ' are provided!');
      else {
        // Form the AJAX Request
        $.ajax({
          type: "POST",
          url: "../ajax/ajax_form_approve_reject.php",
          data: 'submit=' + action + '&id=' + selected_data_string,
          success: function(response) {
            // If success, attempt to sign the template file
            if(/success/.exec(response)){
              if(action !== 'Reject'){
                // Form the JSON to Send to Sign the Form
                var data_to_send = {
                  'form_id': form_id,
                  'form_filename': form_filename,
                  'exec_id': execution_id,
                  'form_table_name': form_table_name,
                  'data': docx_data
                }
                // AJAX Request to Sign File
                $.ajax({
                  type: "POST",
                  url: "./sign_form.php",
                  data: data_to_send,
                  success: function(response) {
                    response = JSON.parse(response);
                    var status = response.status;
                    var message = '';
                    if(status == 'success'){
                      var download_link = (response.message).replace("\\", "");
                      message = "<b>SUCCESS!</b> Successfully signed form";
                      // Redirect the User Back to CBO Home After 5 Seconds
                      download_redirect(download_link, 2, '../home.php');
                    }
                    else message = "Failed! Failed to generate signed form";
                    $('#messages').append(message);
                  }
                });
              }
              // If the Form was Rejected, Redirect the User Home
              else download_redirect('', 1, '../home.php');
            }
            // Display any error messages
            $('#messages').append(response);
          }
        });
      }
    }
  });
}

// Convert Timestamp to Simple Date
function date_to_string(date){
  // Convert Date to String
  date = String(date).split(" ")[0];
  // Return Date String
  return date;
}

// Downloads a Created Form and Then Redirects to the CBO Home Page
function download_redirect(download_link, redirect_wait_seconds, redirect_location){
  // Attach an iFrame to the body
  $('<iframe>', {
    src: '',
    id:  'download_iframe',
    name: 'download_iframe',
    frameborder: 0,
    scrolling: 'no'
  }).appendTo('body');
  // Download PDF Page
  var form = $('<form action="downloadPDF.php" target="download_iframe" method="post">' +
      '<input type="text" name="downloadLink" value="' + download_link + '" />' +
      '</form>');
  $('body').append(form);
  form.submit();
  // Create a Redirection Counter Div
  $('<div>', {
    id: 'counter_container'
  }).appendTo('body');
  // Insert Text Into Counter Div
  $('#counter_container').html("<b>Redirecting You in: </b><span id='counter_seconds'></span> second(s)");
  // Start the Countdown Timer
  countDown(redirect_wait_seconds, redirect_location);
}

// Updates Counter for the Number of Seconds Remaining Till Redirection and
// then Redirects When Counter = 0
function countDown(seconds_to_wait, redirect_location){
  $('#counter_seconds').html(seconds_to_wait);
  seconds_to_wait--;
  if(seconds_to_wait > 0) setTimeout(function(){ countDown(seconds_to_wait, redirect_location); }, 1000);
  else window.location = redirect_location;
}
