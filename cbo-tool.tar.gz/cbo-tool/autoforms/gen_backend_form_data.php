<?php

  // Load the Includes Module
  require_once('../includes.php');
  require_once('data_common_functions.php');
  date_default_timezone_set('UTC');
  // Get the Form Name and Execution ID
  $execution_id = $_GET['execution_id'];
  $form_table_name = $_GET['form_table_name'];

  // Connect to the Database
  db_connect();

  // validate the exec id
  $can_proceed = validate_get($execution_id);
    if( ! $can_proceed ) {
          return_error("Error: Invalid  Data Received..");
          //exit();
  }

  // Read the JSON DATA
  //$str = file_get_contents('./autoforms/form_data.json');
  $str = file_get_contents('form_data.json');
  $all_json = json_decode($str, true);
  //echo '<pre>' . print_r($all_json, true) . '</pre>';

  // find the formid using function: select_db_value($from_col_name, $from_table, $where_col_name, $where_col_val)
  $form_id_return = select_db_value("form_id",  "form", "form_table", "$form_table_name");
  if($form_id_return['status'] == 'success') $form_id = $form_id_return['value'];
  else return_error($form_id_return['value']);

  // Get the form data
  $form_tb_data=$all_json['all_forms'][$form_id]['tb_data'];
  //echo '<pre>' . print_r($form_tb_data, true) . '</pre>';
  // Load the reference data json
  $ref_tb_info=$all_json['ref_tb_info'];
  // count the fields for creating the query
  $select_vals_count=count($form_tb_data);
  //echo $select_vals_count;
  if ($select_vals_count == 0) return_error("Error: Form Id  value is is not defined ");
  // parse the JSON data to different variables
  $form_reftb_info=$all_json['all_forms'][$form_id]['ref_tb'];
  $dig_sig_token_info=$all_json['all_forms'][$form_id]['dig_sig_info'];
  $req_sign=$all_json['all_forms'][$form_id]['req_sig'];

  // Form the SQL Query to get the data from the form in pending status and with the correct execution id (We get the excution id from front end)
  //$sql_query = "SELECT " . $data_fields .
  $sql_query = "SELECT  *
                 FROM " . $form_table_name .
                " WHERE status_id = 1
                AND id=" . $execution_id;

   //echo $sql_query;
  // Query the Database and Store the Results
  $sql_result = db_query($sql_query);
  $row_count = row_count($sql_result);

  // Do some preliminary checks
  if ($row_count == 0) return_error("Error: Form instance is NOT in pending status");
  if ($row_count > 1) return_error("Error: Found duplicates in pending status");

  // store the results into an array. WE expect only one row in the sql_result
  $data_row = row_fetch_assoc($sql_result);

  // Get the form_filename with the timestamp. Assumption field name is filename
  // if the field name is different then we need to insert this field in JSON.
  $form_filename=$data_row['filename'];

  // Start the header for the HTML table

  $htm_resp = '';
  $htm_resp .= "<div> ";
  $htm_resp .= "<table class='table table-striped table-hover'>";
  $htm_resp .= "<tr>";

  // Store the Specific Data for passing to the docx
  $docx_data=array();
  // set the skip_shhlder to default
  $skip_shlder_sig=false;

   // itetrate though the table data for the form
  foreach ($form_tb_data  as $tb_fd_key => $tb_fd_val)  {

           $extra_process=false;
           // Few forms the table data has to show the shareholder name
           // Pick the names from the form_roles table
           if ($tb_fd_key == "show_shareholder") {

               $extra_process=true;
               // Assumption: Since we are showing the share holder here we do not require a signature from him so skip the signature requirement from this shareholder
               $skip_shlder_sig=true;

               $sh_role_id = $tb_fd_val['role_id'];
               $disp_val_ret = get_share_holder_name($form_id, $execution_id,$sh_role_id);
           }
           // check if the ref_table key exists.
           if (array_key_exists('ref_tb', $tb_fd_val)) {

              $extra_process=true;
              // if it exists then we need to collect the correct data from ref table
              $ref_tb_name=$tb_fd_val['ref_tb'];

              // check if the ref table name exists in ref_table_info
              if (array_key_exists($ref_tb_name, $ref_tb_info))  {

                  $ref_field= $ref_tb_info[$ref_tb_name]['ref_field'];
                  $req_val = $ref_tb_info[$ref_tb_name]['req_val'];
              }
              else return_error("Error: table name missing from ref_table_info");

              // get the required display value
              $disp_val_ret = select_db_value($req_val, $ref_tb_name ,  $ref_field, $data_row[$tb_fd_key]);
           }

           if ($extra_process) {

              if($disp_val_ret['status'] == 'success') $disp_val = $disp_val_ret['value'];

              else return_error($dis_val_ret['value']);

              // store the token and values
              $docx_data[$tb_fd_val['token']] = $disp_val;

              $htm_resp .= "<tr>";
              $htm_resp .= "<td>" . $tb_fd_val['field_desc'] . "</td>" ;
              $htm_resp .= "<td>" . $disp_val . "</td>" ;
              $htm_resp .= "</tr>";

           }
           else {
              // store the token and values
              $docx_data[$tb_fd_val['token']] = $data_row[$tb_fd_key];

              $htm_resp .= "<tr>";
              $htm_resp .= "<td>" . $tb_fd_val['field_desc'] . "</td>" ;
              $htm_resp .= "<td>" . $data_row[$tb_fd_key] . "</td>" ;
              $htm_resp .= "</tr>";

           }

    }
      // Final lines for the creation of the Table DIV
      $htm_resp .= "</table>";
      $htm_resp .= "</div>";

      $htm_sec_tb= '';

   // Few forms require a second table created with different data
     if (array_key_exists('sec_table_data', $all_json['all_forms'][$form_id])) {

         $sec_tb_data=$all_json['all_forms'][$form_id]["sec_table_data"];
         $sec_tb_header=$sec_tb_data["sec_tb_header"];
         $sec_tokens=$sec_tb_data["sec_tokens"];
         $sec_tb_fields=$sec_tb_data["sec_fields"];

         $fld_count=sizeof($sec_tb_fields);

         // Find the Query to collect the data
         $sec_tb_data_qry=$sec_tb_data["query"] . $execution_id;;
         $sec_tb_qry_result=db_query($sec_tb_data_qry);
         $sec_tb_qry_row_count=row_count($sec_tb_qry_result);

         if ($sec_tb_qry_row_count == 0) return_error("Error: Could not find Data to insert into the second table");

         // consturct second html table
         // Consturct table  header
         $htm_sec_tb .= "<div> ";
         $htm_sec_tb .= "<table class='table table-striped table-hover'>";
         $htm_sec_tb .= "<tr>";
         $htm_sec_tb .= "<th>" . "No." . "</th>";

         foreach ($sec_tb_header as $tb_h) {

             $htm_sec_tb .= "<th>" . $tb_h  . "</th>";
         }
         $htm_sec_tb .= "</tr>";

         // consturct the table contents
         $r_count=0;
         while($sec_tb_row = mysqli_fetch_assoc($sec_tb_qry_result)) {

               $r_count= $r_count + 1;
               $htm_sec_tb .= "<tr>";
               $htm_sec_tb .= "<td>" . $r_count  . "</td>" ;
               // clue:  the tokens and the field name must be in the same order in the JSON
               for ($x = 0; $x < $fld_count; $x++) {

                   $data_val=$sec_tb_row[$sec_tb_fields[$x]];
                   $htm_sec_tb .= "<td>" . $data_val . "</td>" ;
                   // $ig_token=$sec_tokens[$x]. $r_count;
                   // change the xx to the item count
                   $ig_token=str_replace("xx", $r_count, $sec_tokens[$x]);

                   $docx_data[$ig_token]=$data_val;
                   // the tokens and the field name must be in the same order
               }
                $htm_sec_tb .= "</tr>";
           }

         $htm_sec_tb.= "</table>";
         $htm_sec_tb.= "</div>";

         ## clean up not used docx tokens
         ## if the r_count (row count) is less than the max rows then we need to create the docx tokens with empty values. This is because the docx template comes with all the rows(tokens) populated
         ##
         $max_rows=$sec_tb_data['max_rows'];

         //if ($sec_tb_qry_row_count < $max_rows) {

         $start_from=$sec_tb_qry_row_count +1 ;

         for ($k = $start_from; $k <= $max_rows; $k++) {

              for ($z = 0; $z < $fld_count; $z++) {

                  $ig_token=str_replace("xx", $k, $sec_tokens[$z]);
                  $docx_data[$ig_token]="";
              }
         }
         //}
   }
   //echo $htm_sec_tb;

   // combine both tables
   $htm_resp .= $htm_sec_tb;

  // Get the Shareholder Names and their Unique Usernames
  //$shareholder_data = get_shareholder_info($form_table_name, $form_id, $execution_id, $req_sign);
  // Find the proper bucket if we have common roles
  if (array_key_exists('common_roles', $dig_sig_token_info)) {
      $common_roles=$dig_sig_token_info['common_roles'];
    $shareholder_data = get_shareholder_info($form_table_name, $form_id, $execution_id, $req_sign, $common_roles);
  }
  else {
    $common_roles=[];
  $shareholder_data = get_shareholder_info($form_table_name, $form_id, $execution_id, $req_sign, $common_roles);
  }
  // Check to See if Shareholder Data Returned an Error
  if($shareholder_data['status'] == 'error'){
    // Return an Error
    return_error($shareholder_data['value']);
  }
  $share_holder_info = $shareholder_data['share_holder_info'];
   // empty the shareholder info if the skip is true
  if ($skip_shlder_sig) $share_holder_info =[];

  $cbo_user_info = $shareholder_data['cbo_user_info'];

  //echo '<pre>' . print_r($share_holder_info, true) . '</pre>';

  // take care of forms which needs only min shareholders
  // example HSM Reactivation
  $stored_shldr_count=count($dig_sig_token_info['sh_hldr']);
  $found_shldr_count=count($share_holder_info);

  if (array_key_exists('min_shldr_count', $dig_sig_token_info)) {
      $min_shldr_count=$dig_sig_token_info['min_shldr_count'];
       
      // if the shareholder info count and the stored count mismatches then go with the min count requried
      if ($stored_shldr_count !=  $found_shldr_count) {
          $stored_shldr_count = $min_shldr_count;
      }
  }

  // insert the share holder info to the docx.data
  if ($found_shldr_count  == $stored_shldr_count) {
       $counter=0;
       $sh_hldr_tokens=$dig_sig_token_info['sh_hldr'];
       //foreach ($dig_sig_token_info['sh_hldr'] as $sh_token) {
       foreach ($sh_hldr_tokens as $sh_name_token => $sh_sig_token) {
        $docx_data[$sh_name_token] = $share_holder_info[$counter]['name'];
       
        // Insert NA if the Shareholder Name is Null 
        if ($share_holder_info[$counter]['name'] == "") {
            $docx_data[$sh_name_token] = "N/A";
        }
        // Construct signature stamp
        $this_shldr=$share_holder_info[$counter];
        if ($this_shldr["validation_data"]["validated"] == 1) {
           $sig_sh_stamp="Digitally signed by " . $this_shldr["username"] . " at " . $this_shldr["validation_data"]["validation_date"];
           // get the Date of the signature
           $sig_date= preg_split('/ /', $this_shldr["validation_data"]["validation_date"])[0];
        }

        else {
           $sig_sh_stamp = "";
           $sig_date = "";
        }

        // Create signature token and the signed Date token
        // Assumption: the signed Date Token will be SIGTOKEN + DT
        $docx_data[$sh_sig_token] = $sig_sh_stamp;
        $sig_date_token=$sh_sig_token ."DT";
        $docx_data[$sig_date_token]= $sig_date;
        $counter = $counter + 1;
       }
  }
  //else  return_error("Error: Expected number of digital signatories mismatch!!", false);
  else  $warn_msg = "Warning: Expected number of digital signatories mismatch HIO!!";

  // insert the CBO Engineer info to the docx.data
  if (count($cbo_user_info) == count($dig_sig_token_info['cbo_eng'])) {
       $counter=0;
       $cbo_eng_tokens=$dig_sig_token_info['cbo_eng'];
       //foreach ($dig_sig_token_info['cbo_token'] as $cbo_token) {
       foreach ($cbo_eng_tokens as $cbo_name_token => $cbo_sig_token) {

         $docx_data[$cbo_name_token] = $cbo_user_info[$counter]['name'];
         //construct signature stamp
         $this_cbo=$cbo_user_info[$counter];
         if ($this_cbo["validation_data"]["validated"] == 1) {
           $sig_cbo_stamp = "Digitally signed by " . $this_cbo["username"] . " at " . $this_cbo["validation_data"]["validation_date"];
           $sig_date= preg_split('/ /', $this_cbo["validation_data"]["validation_date"])[0];
         }

         else {
            $sig_cbo_stamp = "Not Signed";
            $sig_date = "";
          }
        // Create signature token and the signed Date token
        // Assumption: the signed Date Token will be SIGTOKEN + DT
        $docx_data[$cbo_sig_token] = $sig_cbo_stamp;
        $sig_date_token=$cbo_sig_token ."DT";
        $docx_data[$sig_date_token]= $sig_date;
        $counter = $counter + 1;
       }
  }
  //else  return_error("Error: Expected number digital signatories (CBO Engineers) mismatch!!", false);
  else  $warn_msg="Warning: Expected number digital signatories (CBO Engineers) mismatch!!";

  // Gather From Approvar information and stick that to the docx data
  // so that we can stamp it in the pdf
   $UId    = validate("int", $_COOKIE['user_id'], "user ID", 1, NULL, $GLOBALS['errorMessage']['cookie_no_detect_user']);
   $UserID_ret =   select_db_value('username', 'user', 'user_id', $UId);

   if($UserID_ret['status'] == 'success') $UserID = $UserID_ret['value'];
     else return_error($UserID_ret['value']);

   $cur_timestamp=date('Y-m-d H:i:s');
   $cur_date=date('Y-m-d');
   $docx_data['IGNORE_SIGAPRV']="Form Approved by " . $UserID . " at " . $cur_timestamp;
   // Insert the Signature Date
   $docx_data['IGNORE_SIGDT']= $cur_date;
   //echo '<pre>' . print_r("User is ". $UserID, true) . '</pre>';

  // Create the Response to Send Back to the Corresponding Form
  $response = array(
    'formId'      => $form_id,
    'form_filename' => $form_filename,
    'executionId' => $execution_id,
    'html'        => $htm_resp,
    'shareholders'=> $share_holder_info,
    'cboeng'      => $cbo_user_info,
    'docx_data'    => $docx_data,
    'warn_msg'     => $warn_msg
  );

  // Return the Response
  echo json_encode($response);
  // Close the Database Connection
  db_close();

?>
