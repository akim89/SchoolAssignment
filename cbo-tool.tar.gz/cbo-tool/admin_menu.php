<?php

	require_once("includes.php");
	db_connect();	
	header_start("Administrative Tools");
	custom_jquery_alert_boxes();
	fancybox_headers();
	uploadify_headers();	
	
?>
	
	<!-- Special dropdown styling for this page only, we don't want to make these 
	styles global as they will interfere with the multiselect plugin on some pages.
	The plugin had to be disabled on this page as it was crashing the browser with some
	panels, such as "Physical Keys", where there are 100's of dropdown menus. -->
	
	<style>
	
		select.dropdown{
		   background: #EDEDED;
		   border: solid 1px #D3D3D3;
		   border-radius: 4px;
		   color: #555555;
		   padding: 3px;
		   font-size: 10px;
		   font-family: Verdana,Arial,sans-serif;
		   height: 24px;
		   width: 98%;
		}
		   
		select.dropdown > option{
			padding: 5px 5px;
			background-color: white;
		}
		
		select:hover, option:hover{
			background-color: lightgray;
		}
		
		option[disabled]{
			color: #C8C6C6;
		}
		
		.boxed_group_inner{
			max-height: 500px;
			overflow-y: auto;
		}

	</style>
		
	<script>
	
		$(document).ajaxComplete(function() {
			$('input:submit, input:button').button();
		});

		$(document).ready(function(){		
	
			<!-- Show an AJAX loader animation while generating the panels -->	
			
			$(document).ajaxStart(function(){
					$('#loader').show();
				}).ajaxStop(function(){
					$('#loader').remove();
				});
	
			<!-- Initialize the uploadify plugin -->
			
			function initialize_uploader(){
				$(".uploader").uploadify({
					'uploader'        : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify.swf',
					'script'          : '<?php echo PATH_JS_UPLOADIFY; ?>/uploadify.php',
					'cancelImg'       : '<?php echo PATH_JS_UPLOADIFY; ?>/cancel.png',
					'folder'          : '<?php echo PATH_UPLOADS; ?>',
					'removeCompleted' : false,
					'sizeLimit'       : <?php echo UPLOADIFY_FILESIZE; ?>,								
					'expressInstall'  : '<?php echo PATH_JS_UPLOADIFY; ?>/expressInstall.swf',
					'auto'            : true,
					'removeCompleted' : true,	
					'onComplete'      : function(event, queueID, fileObj, response, data){
					
											// Add the actual filename to the two input boxes (one visible, one hidden)
											
											$('#' + event.currentTarget.id).parents('tr').find('[name="filename"]').val(response);
											
											// If the user uploads a file mark the row as "changed"
						
											$('#' + event.currentTarget.id).parents('tr').removeClass('highlight').addClass('highlight_green');
											
											// Cleanup the uploadifyQueue container, it sometimes gets stuck when working with existing buttons (aka edits)
											
											$('#' + event.currentTarget.id).parents('tr').find('.uploadifyQueue').remove();
										}
				});
			}
						
			<!-- Style the dropdwon menus -->
			
			function style_dropdown(selector){
				
				// Set a static size for header columns that have dropdown menus
				
				var headerSizes = new Array();
				
				$('tr.header-row:first').find('th').each(function(){
					var index = $(this).index();
					
					if($('tr.data-row').eq(1).find('td').eq(index).find('.dropdown').length > 0){
						var width = parseInt($(this).css('width'));
						$(this).css('width', width);
						headerSizes[index] = width;
					}
				});

				// Find all the dropdown menus and resize them according to the header size
				
				// $('button').each(function(){
								
				$('select').each(function(){
					var position = $(this).parent('td').index();
					// var width = parseInt($('tr.header-row:first').find('th').eq(position).css('width'));
					// $(this).css('width', width + 'px')
					$(this).css('width', headerSizes[position] + 'px')
				});
			}
	
			<!-- Load the initial table data using AJAX -->			

			$('.admin_panel').click(function(){
			
				var $this = $(this);
				
				if($('.highlight_green').length > 0){				
					$.alerts.okButton = "Yes";
					$.alerts.cancelButton = "No";
					var panel = $('.ajax_container').prev('h3').text().toLowerCase();
					
					jConfirm('You have unsaved changes in the ' + panel + ' panel. Continuing will result in a loss of those changes. Do you want to continue?', 'Unsaved Changes', function(r){							
						if(r){
							load_ajax_table($this);
						}else{
							return false;
						}
					});
					
				}else{
					load_ajax_table($this);					
				}
				
			});
			
			function load_ajax_table(panel){
				
				cleanup_previous_panel(panel);			
				
				// Send the AJAX request
				
				$.ajax({
					type: "GET",
					url: "<?php echo PATH_AJAX; ?>/ajax_admin_load.php",
					data: "table="+panel.data('table'),
					success: function(response){
						
						// Display the repsonse
						
						panel.parent().append(response);
						
						// Clear out any messages
						
						$('#messages').html("");

						// On page load, add blank row and style objects (unless the table has no data)
					
						var records = (/no_records_found/.exec(response) ? 0 : 1);						
					
						if(panel.data('table') != "<?php echo DB_TABLE_USERS; ?>" && records == 1){
							add_new_row();
						}else{
						
							// Format the datepickers
						
							$(".datepicker" ).datepicker({
								changeMonth: true,
								changeYear: true,
								dateFormat: 'yy-mm-dd'
							});
						
							// Format the uploaders
							
							initialize_uploader();
							
							// Style the dropdowns
						
							style_dropdown($(".dropdown"));
						}
						
						<!-- Enable and disable certain sites in the shareholders panel based on wether or not they are a CBO user -->
						
						if(panel.data('table') == "<?php echo DB_TABLE_SHAREHOLDERS; ?>"){
						
							// Remove sites that do not apply to this panel
							
							$('select[name="site_id"]').find('option').not('[value="1"],[value=""],[value="2"],[value="3"],[value="5"]').remove();
							
							// Remove function types that do not apply to this panel
							
							$('select[name="function_type_id"]').find('option[value="3"]').remove();
							
							// Enable and disable site options
							
							disable_shareholder_sites($('tr.data-row'), false);
					
							// Enable and disable function options
							
							disable_shareholder_functions($('tr.data-row'), false);
						}	
						
					}
				});	
			}						
				
			<!-- Load 'special' forms using AJAX -->	
			
			$('.admin_panel_special').click(function(){

				var table = $(this).data('table').toLowerCase();
				var panel = $(this);
				
				if(table == "<?php echo DB_TABLE_TAMPER_EVIDENT_BAGS; ?>"){
				
					cleanup_previous_panel(panel);
				
					$.ajax({
						type: "GET",
						url: "<?php echo PATH_AJAX; ?>/ajax_tamper_evident_bags_bulk.php",
						data: "table=" + table,
						success: function(response){
							
							// Display the response
							
							panel.parent().append(response);
						
							// Clear out any messages
						
							$('#messages').html("");
						}
					});
				}
				
			});
			
			<!-- Before loading a new panel, empty out any others that were previously loaded -->
			
			function cleanup_previous_panel(panel){
				
				// Destroy any datepickers that may belong to another admin panel
				
				$(".datepicker").datepicker("destroy");
				
				// Clear out any other admin panels
				
				$('.ajax_container').remove();				
				
				// Add a loader animation to the panel that is about to be loaded
				
				panel.prepend("<div id='loader'><img src='<?php echo PATH_IMAGES; ?>/ajax-loader.gif'/></div>");
			}
			
			<!-- Add empty row to the bottom of the table -->
			
			function add_new_row(type){
			
				// Destroy all the datepickers (we will re-initialize them)

				$(".datepicker").datepicker("destroy");
				
				// Destroy all the uploaders (not really sure if this works or not)
				
				$('object, .uploadifyQueue').remove();
				
				// Clone the last table row
				
				$('tr.data-row:last').clone().find("input, textarea, select").each(function(){
					if($(this).val() == "Update"){
						$(this).val('Add');														// Rename the button
					}else if($(this).hasClass('datepicker')){
						$(this).val('').attr('id', 'dp' + Math.ceil(Math.random()*5000));		// Change the ID of any datepickers (otherwise they will not work)
					}else if($(this).hasClass('uploader')){
						$(this).val('').attr('id', 'uploader_' + Math.ceil(Math.random()*5000));	// Change the ID of any uploaders (otherwise they will not work)
					}else if($(this).attr('name') == "deleted"){
						$(this).attr('disabled', 'disabled').attr('checked', false);			// Disable the delete option
					}else{
					
						// On initial panel load, remove the bag that is in use by the cloned row (if applicable)
						
						if(type != "dynamic" && $(this).attr('name') == "bag_id"){					
							var selected = $(this).val();
							if(!!selected){
								$(this).children('option').filter('[value="'+selected+'"]').remove();
							}
						}
					
						$(this).val('').attr('checked', false);									// Nullify the values
					}                                                       
				}).end().appendTo("table#admin_manager");										// Append the row to the table

				// Give the new row an ID of temp_id

				$('tr.data-row:last').attr('id', 'temp_id');     
				
				// Skin the dropdown menus

				if(type == "dynamic"){
					style_dropdown($('tr.data-row:last').find('.dropdown'));
				}else{
					style_dropdown($(".dropdown"));
				}
				
				// Format the datepickers
						
				$(".datepicker" ).datepicker({
					changeMonth: true,
					changeYear: true,
					dateFormat: 'yy-mm-dd'
				});
				
				// Format the uploaders
				
				initialize_uploader();
				
			}
			
			<!-- Highlight a row when a change occurs -->
					
			$('input:not(:submit), select').live('change keyup', function(){
				$(this).parents('tr.data-row').removeClass('highlight').addClass('highlight_green');
			});
			
			<!-- Highlight the current row -->
					
			$('tr.data-row').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});	
			
			<!-- Process the changes when a user clicks the "Update/Add" button -->
					
			$('.regular_button:submit').live('click', function(){
				
				// Disable the button so the user cannot re-submit
				
				var button = $(this);
				$(this).attr('disabled', 'disabled');
				
				// Find the database ID for this host

				var data = new Object();
				data.id = $(this).parents('tr.data-row').attr('id');
				
				// Find the database table that this entry will be written to
				
				var table = $(this).parents('.ajax_container').prev('h3').data('table');
				data['table'] = table;
				
				// Find all form fields in the row
				
				$(this).parents('tr.data-row').find('input, select, textarea').each(function(){
					var name = $(this).attr('name');
												
					if($(this).is(':checkbox')){
						var value = ($(this).prop('checked') ? 1 : 0);	// Find if the box has been checked or not
					}else if($(this).is('select')){					
						var value = $(this).val();
					}else{
						var value = $(this).val();	// Find the value of each field
					}
					
					// Dynamically add the key => value pair to the JS object
					
					data[name] = value;					
				});
				
				// Send an AJAX request to commit the changes
				
				$.ajax({
					type: "POST",  
					url: "<?php echo PATH_AJAX; ?>/ajax_admin_update.php",  
					data: data,  
					success: function(response){
						
						// Update the messages container
						
						$('#messages').html(response);

						// If the request was successful perform a few actions
						
						if(/success/.exec(response)){
						
							// If the user deleted the item remove the row

							if(data.deleted == 1 && $('tr#' + data.id).find('.disabled_option').length == 0){
								$('tr#' + data.id).fadeOut('fast', function(){
									$(this).remove();
								});
							
							// The user did not delete the item process the row if needed
							
							}else{

								// Re-enable the button
							
								button.attr('disabled', false);
								
								// Remove highlighting
								
								button.parents('tr.data-row').removeClass('highlight_green');
								
								// The user added a new row, lets give them a new blank row
								
								if(data.submit == "Add"){
									
									// Rename the button to update if action was "Add"
									
									$('tr#' + data.id).find('input:submit').val('Update');
									
									// Enable the delete option
									
									$('tr#' + data.id).find('input[name="deleted"]').attr('disabled', false);
									
									// Alter the row ID if action was "Add"
									
									var ID = response.match(/ID\s\d+/);
									ID = response.match(/\d+/);		
									
									$('tr#' + data.id).attr('id', ID[0]);
									
									// Add a new row if action was "Add"
								
									add_new_row("dynamic");																						
									
								}

								remove_used_bag();								
								
							}						
						}else{
						
							// Re-enable the button
							
							button.attr('disabled', false);
						}
					}
				}); 

			});
			
			<!-- Disable the box dropdown if the box type is "common key" (only applies to "physical keys" panel) -->
					
			$('[name="physical_key_type_id"]').live('change', function(){
				
				var table = $(this).parents('.ajax_container').prev('h3').data('table').toLowerCase();
				var row = $(this).parents('tr.data-row');
				
				if(table == "<?php echo DB_TABLE_KEYS; ?>"){
					if($(this).val() == 2){
						row.find('select[name="box_id"]').val('').attr('disabled', true);	
					}else{
						row.find('select[name="box_id"]').attr('disabled', false);	
					}					
				}

			});
			
			<!-- Process the changes when a user clicks a "special" button -->
					
			$('.special_button:submit').live('click', function(){
				
				var panel = $(this);				
				var table = panel.parents('.ajax_container').prev('h3').data('table').toLowerCase();
				
				// Bulk insert of tamper eveident bags
				
				if(table == "<?php echo DB_TABLE_TAMPER_EVIDENT_BAGS; ?>"){
								
					$.ajax({
						type: "POST",
						url: "<?php echo PATH_AJAX; ?>/ajax_tamper_evident_bags_bulk.php",
						data: { 
							"table" : table, 
							"submit" : "Add", 
							"serial_start" : $('#serial_start').val(), 
							"serial_end" : $('#serial_end').val() 
						},
						success: function(response){
							
							// Update the messages container
						
							$('#messages').html(response);
							
							// Nullify the text fields
							
							if(/success/.exec(response)){
								$('#serial_start, #serial_end').val('');
							}
						}
					});
				}

			});
			
			<!-- Remove a used bag from all other tamper evident bag dropdown menus-->
			
			function remove_used_bag(){
				var bagID = $('.bag:hidden').text();
								
				if(!!bagID){
					$('select[name="bag_id"]').each(function(){
						var selected = $(this).val();
						
						if(selected != bagID){
							$(this).children('option').filter('[value="'+bagID+'"]').remove();
						}
					});
				}			
			}
			
			<!-- For the shareholders panel, all CBO users belong to site "All" and non-CBO users can be anything but "All"; Also, certain functions are only avaliable to certain types of users -->
			
			$('[name="cbo_user"], [name="has_data_center_access"], [name="function_type_id"]').live('change', function(){
				var table = $(this).parents('.ajax_container').prev('h3').data('table').toLowerCase();
				var row = $(this).parents('tr.data-row');
				var name = $(this).attr('name');
				
				if(table == "<?php echo DB_TABLE_SHAREHOLDERS; ?>"){
								
					// Only one of these options are selectable at a time
										
					if(name == "cbo_user"){
						row.find('[name="has_data_center_access"]').attr('checked', false);
					}else if(name == "has_data_center_access"){
						row.find('[name="cbo_user"]').attr('checked', false);
					}
			
					// Manipulate the sites and functions dropdown
					
					disable_shareholder_sites(row, true);
					disable_shareholder_functions(row, true);
				}
			});	

			<!-- Function to enable and disable certain shareholder sites based on the CBO checkbox -->
			
			function disable_shareholder_sites(rowSelector, clearValue){				
				rowSelector.each(function(){							
					var isChecked = ($(this).find('[name="cbo_user"]').attr('checked') == "checked" ? true : false);
					
					// Should any selected "site" values be de-selected (we don't want to clear the value when the panel is first loaded)
					
					if(!!clearValue){
						$(this).find('select[name="site_id"] > option').attr('selected', false);
					}
					
					// Make changes dependent on wether or not the "CBO User" option is selected
					
					if(isChecked){	// "CBO User" is selected
						$(this).find('select[name="site_id"]')	// Locate the site ID dropdown
						.find('option').attr('disabled', true).end()	// Disable all options
						.find('option[value="1"], option[value=""]').attr('disabled', false).end()	// Enable the generic "Select an option" message and the "All" option
						.find('option[value="1"]').attr('selected', true);	// Select the "All" option by default
					}else{	// "CBO User" is not selected
						$(this).find('select[name="site_id"]')	// Locate the site ID dropdown
						.find('option').attr('disabled', false).end()	// Enable all the options
						.find('option[value="1"]').attr('disabled', true);	// Disable the "All" option
					}										
				});			
			}
			
			<!-- Function to enable and disable certain shareholder functions based on the CBO and data center access checkboxes -->
			
			function disable_shareholder_functions(rowSelector, clearValue){				
				rowSelector.each(function(){							
					var isCBOChecked   = ($(this).find('[name="cbo_user"]').attr('checked') == "checked" ? true : false);
					var isDCAChecked   = ($(this).find('[name="has_data_center_access"]').attr('checked') == "checked" ? true : false);
					var functionTypeID = $(this).find('[name="function_type_id"]').val();
					
					// Locate the two function dropdowns
					
					var functionDropdowns = $(this).find('select[name="function_id"], select[name="function_id_secondary"]');	// Locate the function dropdowns

					// Enable all function options
					
					functionDropdowns.find('option').attr('disabled', false);	// Enable all the options
					
					// Limit the function dropdown menus based on the function type that was selected
					
					if(functionTypeID == 1){	// Physical Key was selected, disable Access & Sysadmin functions
						functionDropdowns.find('option').filter(function(){
							return this.value.match(/^(22|23|24|25|26|27|30)$/);
						}).attr('disabled', true);	// Disable Access Pool A & B, the MegaSafe
						
						$(this).find('select[name="function_id_secondary"]').prop('disabled', true);	// Physical Key function types can only be assigend to one function
					
					}else if(functionTypeID == 2){	// Access was selected, disable Physical Key & Sysadmin functions
						functionDropdowns.find('option').filter(function(){
							return this.value.match(/^(2|3|9|10|11|30)$/);
						}).attr('disabled', true);	// Disable App Cards/Passwords, Common, HSM, MofN, D/SO
						
						$(this).find('select[name="function_id_secondary"]').prop('disabled', false);	// Access function types can be assigend to two functions
						
					}else if(functionTypeID == 4){	// Sysadmin was selected, disable Physical Key & Access functions
						functionDropdowns.find('option').filter(function(){
							return (this.value.length == 0 || this.value.match(/^(|30)$/) ? false : true);
						}).attr('disabled', true);	// Disable everything but Sysadmin
						
						$(this).find('select[name="function_id_secondary"]').prop('disabled', true);	// Sysadmin function types can only be assigend to one function
					}

					// Further filter the functions list based on DBO or DCA				
					
					if(isCBOChecked || isDCAChecked){
						
						// Disable options based on CBO
						
						if(isCBOChecked){
							functionDropdowns.find('option').filter(function(){
								return this.value.match(/^(2|3|22|23)$/);
							}).attr('disabled', true);	// Disable MofN, D/SO, MegaSafe
						
						// Disable options based on data center access
						
						}else if(isDCAChecked){
							functionDropdowns.find('option').filter(function(){
								return this.value.match(/^(2|3|9|1[01]|2[4-7])$/);							
							}).attr('disabled', true);	// Disable Pool A|B, Safe, HSM, App Cards/Passwords, Common
						}
						
					}					
					
					// Should any selected "function" values be de-selected (we don't want to clear the value when the panel is first loaded)
					
					if(!!clearValue){
						functionDropdowns.find('option').attr('selected', false);
					}						
				});			
			}	
	
		});
		
	</script>
	
<?php

	body_start();	
	navigation_start("admin");

		echo "<div align='center'>";
						
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_BOXES . "'>Boxes</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_CABINETS . "'>Cabinets</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_DESTRUCTION_METHODS . "'>Destruction Methods</h3>";				
			echo "</div>\n";

			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_EMAIL_TEMPLATES . "'>Email Templates</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_ENVIRONMENTS . "'>Environments</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_EQUIP . "'>Equipment</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_EQUIP_TYPES . "'>Equipment Types</h3>";				
			echo "</div>\n";			
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_EQUIP_ATTACHMENTS . "'>Equipment Attachments</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_EQUIP_VERSIONS . "'>Equipment Versions</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_ESCROW_LOCATIONS . "'>Escrow Locations</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_ESCROW_LOCATION_TYPES . "'>Escrow Location Types</h3>";				
			echo "</div>\n";

			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_FORMS . "'>Form Instructions</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_FUNCTIONS . "'>Functions</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_KEY_TYPES . "'>Key Types</h3>";				
			echo "</div>\n";			
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_MEDIA_TYPES . "'>Media Types</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_MODEL_TYPES . "'>Model Types</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_SHAREHOLDERS . "'>Personnel</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_SHAREHOLDER_BLACKLIST . "'>Personnel Blacklist</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_KEYS . "'>Physical Keys</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_PHYSICAL_KEY_TYPES . "'>Physical Key Types</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_PRODUCTS . "'>Products</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_ROLES . "'>Roles</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_SHARES . "'>Shares</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_SHARE_TYPES . "'>Share Types</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_SITES . "'>Sites</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_SUPPORT_CONTRACTS . "'>Support Contracts</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_TAMPER_EVIDENT_BAGS . "'>Tamper Evident Bags</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel_special' data-table='" . DB_TABLE_TAMPER_EVIDENT_BAGS . "'>Tamper Evident Bags (Bulk Add)</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_USERS . "'>Users</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_USER_ACL . "'>User ACL</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_VENDORS . "'>Vendors</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_VENDOR_ATTACHMENTS . "'>Vendor Attachments</h3>";				
			echo "</div>\n";
			
			echo "<div class='boxed_group'>\n";
				echo "<h3 class='admin_panel' data-table='" . DB_TABLE_VENDOR_CONTACTS . "'>Vendor Contacts</h3>";				
			echo "</div>\n";
			
		echo "</div>";		
	
	footer_start();		
	db_close();
	
?>
