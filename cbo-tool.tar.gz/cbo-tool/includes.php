<?php

     // Display Errors 
      //ini_set('display_errors',1); 
      //ini_set('display_startup_errors',1); 
      //error_reporting(-1);
	
	include("includes/config.php");
	include(PATH_INCLUDE . "/html.php");
	include(PATH_INCLUDE . "/db_functions.php");
	include(PATH_INCLUDE . "/forms.php");
	include(PATH_INCLUDE . "/various_functions.php");
	include(PATH_INCLUDE . "/messages.php");
	include(PATH_INCLUDE . "/authentication.php");
	include(PATH_INCLUDE . "/validate.php");
	
?>
