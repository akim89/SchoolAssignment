// Replace Micrsoft Word chracters with ascii equivalents
// Resources: http://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references
//            http://www.fileformat.info/info/unicode/char/a.htm
//            http://kevinkorb.com/demo/findAsciiCode

function removeMSWordChars(str) {
    var myReplacements = new Array();
    var myCode, intReplacement;
	
	myReplacements[169]  = '(C)'; 		// Copyright
	myReplacements[174]  = '(R)'; 		// Registered
	myReplacements[176]  = ' degrees'; 	// Degree
	myReplacements[188]  = '1/4'; 		// Fraction (quarter)
	myReplacements[189]  = '1/2'; 		// Fraction (half)
	myReplacements[190]  = '3/4'; 		// Fraction (three quarters)
	myReplacements[338]  = 'OE'; 		// Capital ligature
	myReplacements[339]  = 'oe'; 		// Lowercase ligature
	myReplacements[8211] = '-';    		// En dash
	myReplacements[8212] = '--';   		// Em dash
	myReplacements[8216] = "'";    		// Left single quotation mark
	myReplacements[8217] = "'";    		// Right single quotation mark
	myReplacements[8218] = ',';    		// Single low quote
	myReplacements[8220] = '"';    		// Left double quotation mark
	myReplacements[8221] = '"';    		// Right double quotation mark
	myReplacements[8222] = '"';    		// Double low quote
	myReplacements[8224] = '*';  		// Dagger
	myReplacements[8225] = '**';  		// Double Dagger
	myReplacements[8226] = '-';    		// Bullet
	myReplacements[8230] = '...'; 		// Ellipsis
	myReplacements[8249] = '<';    		// Single left pointing angle
	myReplacements[8250] = '>';    		// Single right pointing angle
	myReplacements[8260] = '/';    		// Fraction slash
	myReplacements[8364] = 'E';    		// Euro
	myReplacements[8482] = '(TM)'; 		// Trademark    
	
	for(c=0; c<str.length; c++) {
		var myCode = str.charCodeAt(c);
		if(myReplacements[myCode] != undefined) {
			intReplacement = myReplacements[myCode];
			//str = str.substr(0,c) + String.fromCharCode(intReplacement) + str.substr(c+1);  // Use if you want to replace text based on character codes instead of strings
			str = str.substr(0,c) + intReplacement + str.substr(c+1);
		}
	}
	
    return str;
}