<?php

include('../../includes.php');

/*
Uploadify v2.1.4
Release Date: November 8, 2010

Copyright (c) 2010 Ronnie Garcia, Travis Nickels

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
if (!empty($_FILES)) {

	$tempFile = $_FILES['Filedata']['tmp_name'];
	$targetPath = $_SERVER['DOCUMENT_ROOT'] . $_REQUEST['folder'] . '/';
	
	$fileParts = pathinfo($_FILES['Filedata']['name']);	
	$newFilename = preg_replace("/'|\"/", "", str_replace(" ", "_", $fileParts['filename'] . "." . $fileParts['extension']));
	
	$targetFile =  str_replace('//','/',$targetPath) . $newFilename . "tmp";
		
	// $fileTypes  = str_replace('*.','',$_REQUEST['fileext']);
	// $fileTypes  = str_replace(';','|',$fileTypes);
	// $typesArray = split('\|',$fileTypes);
	// $fileParts  = pathinfo($_FILES['Filedata']['name']);
	
	// if (in_array($fileParts['extension'],$typesArray)) {
		// Uncomment the following line if you want to make the directory if it doesn't exist
		@mkdir(str_replace('//','/',$targetPath), 0755, true);
		
		// Save the file to a temporary location
		
		if(move_uploaded_file($tempFile, $targetFile)){
		
			// Strip off the version number if it exists (in case user uploaded a file with an existing version number)
			
			$UnversionedFilename = preg_replace('/_v\d+/', '', $newFilename);		
			$PathInfo = pathinfo($UnversionedFilename);
			
			// Find all previous version of this file
			
			$ExistingVersions = array_filter(glob(PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_TEMPLATES . "/" . $PathInfo['filename'] . "*"));
			
			// Determine the max file version and then add 1
			
			if(count($ExistingVersions) == 1){
				$Version = 1;
			}else{
				foreach($ExistingVersions as $Filename){
					preg_match('/_v\d+(?!=\..+$)/', basename($Filename), $Matches);
					if($Matches){
						preg_match('/\d+/', $Matches[0], $CurrentVersion);
						$AllVersions[] = $CurrentVersion[0];
					}
				}

				$Version = max($AllVersions) + 1;
			}
			
			// Rename the temp file to the new filename with the updated version number
			
			rename($targetFile, PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_TEMPLATES . "/" . $PathInfo['filename'] . "_v" . $Version . "." . $fileParts['extension']);					
		}
		
		// Return full path the filename
		// echo $targetFile;
		
		// Return path from root of site
		// echo str_replace($_SERVER['DOCUMENT_ROOT'],'',$targetFile);
		
		// Return upload path and filename
		echo $_FILES['Filedata']['name'];
		
	// } else {
		// 	echo 'Invalid file type.';
	// }
}
?>