<?php

include('../../includes.php');
db_connect();

/*
Uploadify v2.1.4
Release Date: November 8, 2010

Copyright (c) 2010 Ronnie Garcia, Travis Nickels

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
if (!empty($_FILES)) {

	$tempFile = $_FILES['Filedata']['tmp_name'];
	$targetPath = $_SERVER['DOCUMENT_ROOT'] . $_REQUEST['folder'] . '/';
	
	$fileParts = pathinfo($_FILES['Filedata']['name']);	
	$newFilename = preg_replace("/'|\"/", "", str_replace(" ", "_", $fileParts['filename'] . "." . $fileParts['extension']));
	
	$targetFile =  str_replace('//','/',$targetPath) . $newFilename;
		
	// $fileTypes  = str_replace('*.','',$_REQUEST['fileext']);
	// $fileTypes  = str_replace(';','|',$fileTypes);
	// $typesArray = split('\|',$fileTypes);
	// $fileParts  = pathinfo($_FILES['Filedata']['name']);
	
	// if (in_array($fileParts['extension'],$typesArray)) {
		// Uncomment the following line if you want to make the directory if it doesn't exist
		@mkdir(str_replace('//','/',$targetPath), 0755, true);
		
		if(move_uploaded_file($tempFile,$targetFile)){
		
			preg_match('/\d{14}(?=\.[A-Za-z]{3}$)/', $newFilename, $TimeStamp);	// 14 digits, followed by a "." and then 3 alpha characters, followed by the end of the string
			preg_match('/^.*?(?=_\d{14}\.[A-Za-z]{3}$)/', basename($newFilename), $FormName);	// All characters before an "_" followed by 14 digits a ".", 3 alpha chacters and the end of the string
		
			$Query  = "SELECT form_table FROM " . DB_TABLE_FORMS . " WHERE filename='" . clean_sql_value(@$FormName[0] . ".docx") . "'";
			$Result = db_query($Query);
			$Table  = row_fetch($Result);
			
			$Query  = "SELECT * FROM " . $Table[0] . " WHERE filename='" . clean_sql_value(basename(@$newFilename, ".pdf") . ".docx") . "'";
			$Result = db_query($Query);
			$Count  = row_count($Result);
			
			$Unmapped = FALSE;
			
			if($Count == 1){
				$RowID = row_fetch($Result);
				
				$Info['filename_signed'] = clean_sql_value($newFilename);
				$Info['date_updated']    = "NOW()";
				$Where['id']             = $RowID[0];
				
				if(!db_query(create_sql_update($Info, $Where, $Table[0]))){ $Unmapped = TRUE; }
			
			}else{
				$Unmapped = TRUE;
			}
			
			// Move unmapped file to "unmapped" directory
			
			if($Unmapped){
				rename($targetFile, PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_SIGNED_UNMAPPED . "/" . $newFilename);			
			}		
		
		}
		
		// Return full path the filename
		// echo $targetFile;
		
		// Return path from root of site
		// echo str_replace($_SERVER['DOCUMENT_ROOT'],'',$targetFile);
		
		// Return upload path and filename
		echo $_FILES['Filedata']['name'];
		
	// } else {
		// 	echo 'Invalid file type.';
	// }
}
?>
