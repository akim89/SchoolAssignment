<?php

	require_once("includes.php");
	db_connect();
	header_start("File Viewer");
	multiselect_headers();
	scrollTo_headers();

?>

	<script>

		$(document).ready(function(){

			<!-- Function to style the single-select dropdown menus -->

			$(".dropdown").multiselect({
				multiple: false,
				header: "Select a form",
				noneSelectedText: "Select a form",
				selectedList: 1,
				minWidth: 300
			}).multiselectfilter();

			<!-- Highlight the current row -->

			$('tbody > tr').live({
				mouseenter:
					function(){
						$(this).addClass('highlight');
					},
				mouseleave:
					function(){
						$(this).removeClass('highlight');
					}
			});

			<!-- Zebra stripe the rows -->

			function zebraStripeTables(element){
				element.addClass('zebra');
			}

			<!-- Scroll to the appropriate section -->

			$('#forms').on('change', function(){
				var selected = $(this).multiselect("getChecked").val();
				var destination = $('.boxed_group[data-form-id="' + selected + '"]');
				$.scrollTo(destination, 800);
			});

			$('#file_viewer_container').on('click', '.top', function(){
				$.scrollTo($('#forms:hidden').parents('div'), 800);
			});
			
			<!-- Load files for form -->
			
			function loadFiles(formID, page){
				var page = (!!page ? page : 1)
				var formID = (!!formID ? formID : "all")
				
				$.ajax({
					type: "GET",
					url: "<?php echo PATH_AJAX; ?>/ajax_file_viewer_load.php",
					data: { 'form_id' : formID, 'page' : page },
					success: function(response){
						if(formID == "all"){
							$('#file_viewer_container').html(response);
							zebraStripeTables($('tbody > tr:odd'));
						}else{
							$('div[data-form-id=' + formID + ']').replaceWith(response);
							zebraStripeTables($('div[data-form-id=' + formID + ']').find('tbody > tr:odd'));
						}
					}
				});
			}
			
			<!-- Load all file information on page load -->
			
			loadFiles();

			<!-- Load next page of results for a given form -->
			
			$('#file_viewer_container').on('click', '.page_number', function(){
				loadFiles($(this).parents('.boxed_group').attr('data-form-id'), $(this).attr('data-page-num'));
			});			

		});

	</script>

<?php

	body_start();
	navigation_start("file");

		echo "<div align='center'>";

			// Find all the file information

			$Query = "SELECT form_id, form_name, form_table FROM " . DB_TABLE_FORMS . " WHERE deleted=0 ORDER BY form_name";
			$Result = db_query($Query);
			$Forms = row_fetch_all($Result);

			// Display a list of avaliable forms

			foreach($Forms as $FormInfo){
				$FormsList[$FormInfo['form_id']] = $FormInfo['form_name'];
			}

			echo "<div class='vertical_margin_10px'>";
				form_dropdown(array("use_table" => FALSE, "name" => "forms", "multiselect" => TRUE, "css" => "class='dropdown'", "items" => $FormsList, "select_opt" => FALSE));
			echo "</div>";

			// Display file information

			echo "<div id='file_viewer_container'></div>";

		echo "</div>";

	footer_start();
	db_close();

?>
