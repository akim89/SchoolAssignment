<?php

	require_once("includes.php");
	db_connect();
	header_start("Reporting");
	multiselect_headers();
	
?>

	<script>

		$(document).ready(function(){
					
			// Skin the dropdown menus

			$('.dropdown').multiselect({
				multiple: false,
				header: "Select an option",
				noneSelectedText: "Select an option",
				selectedList: 1,
				minWidth: 170
			});
			
		});

	</script>	
	
<?php

	function menu_item($Title, $URL, $Icon){	
		echo "<div style='width: 300px; display: inline-block; text-align: left; margin: 7px 0 5px 0;'>";
			echo "<span style='width: 35px; float: left;'>";
				echo "<img src='" . PATH_IMAGES . "/$Icon'>";
			echo "</span>\n";
			echo "<a class='report' style='vertical-align: middle;' href='$URL'>$Title</a>";				
		echo "</div>\n";				
	}

	body_start();	
	navigation_start("report");
	
		// Equipment reports
		
		echo "<div class='boxed_group'>\n";
			echo "<h3>Equipment</h3>";			
			echo "<div class='boxed_group_inner clearfix'>\n";
			
				menu_item("Equipment Export", "csv_export.php?report=equipment", "document.png");
				menu_item("Equipment Model Types", "report_equipment_model_types.php", "document.png");
				menu_item("HSM Reactivation Dates", "report_hsm_restarts.php", "document.png");
				
			echo "</div>\n";
		echo "</div>\n";			
		
		// Boxes & Physical Key reports
		
		echo "<div class='boxed_group'>\n";
			echo "<h3>Boxes & Physical Key</h3>";			
			echo "<div class='boxed_group_inner clearfix'>\n";
			
				menu_item("Safe Deposit Box Contents", "report_box_contents.php", "document.png");
				menu_item("Safe Deposit Box Snapshots", "report_box_snapshots.php", "document.png");
					
			echo "</div>\n";
		echo "</div>\n";		
		
		// Share reports
		
		echo "<div class='boxed_group'>\n";
			echo "<h3>Shares</h3>";			
			echo "<div class='boxed_group_inner clearfix'>\n";
			
				menu_item("Share Export", "csv_export.php?report=share", "document.png");
			
			echo "</div>\n";
		echo "</div>\n";
		
		// Shareholder reports
		
		echo "<div class='boxed_group'>\n";
			echo "<h3>Shareholder</h3>";			
			echo "<div class='boxed_group_inner clearfix'>\n";
			
				menu_item("Shareholder Roles Used In Forms", "report_shareholder_roles.php", "document.png");
				menu_item("Shareholders Used In Events", "report_shareholder_events.php", "document.png");
				menu_item("Shareholder Event Back Outs", "report_shareholder_event_backouts.php", "document.png");
		
			echo "</div>\n";
		echo "</div>\n";
		
		// Miscellaneous reports
		
		echo "<div class='boxed_group'>\n";
			echo "<h3>Miscellaneous</h3>";			
			echo "<div class='boxed_group_inner clearfix'>\n";
			
				menu_item("Forms Missing PDF Scans", "report_missing_pdfs.php", "document.png");
					
			echo "</div>\n";
		echo "</div>\n";
			
	footer_start();		
	db_close();
	
?>
