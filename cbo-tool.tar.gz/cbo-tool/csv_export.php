<?php
	
	ob_start();	
	include("includes.php");
	db_connect();	
		
		// Determine what query to use
		
		if(@$_GET['report'] == "equipment"){
			$Query = "SELECT e.label_name AS label, vendor_name AS vendor, eq.equipment_type_name AS equipment_type, e.serial_number, e.asset_tag_number, e.server_name, e.description, e.model_number, m.model_type_name AS model_type, ev.equipment_version_name AS version, e.part_number, e.purchase_order_number, e.tamper_seal_number, t.bag_serial AS tamper_bag_serial, e.servicenow_id, s.site_name AS site, IF(l.escrow_location_name IS NOT NULL, l.escrow_location_name, 'Not In Escrow') AS escrow_location, p.product_name AS product, env.environment_name, e.status, e.date_shipped, e.date_online, e.date_offline, e.date_destroyed, e.rack_location, sc.contract_number AS support_contract, sc.date_start AS support_contract_start, sc.date_end AS support_contract_end, sc.maintenance_plan_type, IF(e.is_production_capable=1, 'Yes', 'No') AS is_production_capable, IF(e.is_acceptance_tested=1, 'Yes', 'No') AS is_acceptance_tested, e.date_acceptance_tested, e.date_last_verified, e.notes, u.name AS created_by, e.date_created, u2.name AS last_updated_by, e.date_updated AS last_updated FROM " . DB_TABLE_EQUIP . " e LEFT JOIN " . DB_TABLE_USERS . " u ON u.user_id=e.created_by LEFT JOIN " . DB_TABLE_USERS . " u2 ON u2.user_id=e.updated_by LEFT JOIN " . DB_TABLE_PRODUCTS . " p ON p.product_id=e.product_id LEFT JOIN " . DB_TABLE_ENVIRONMENTS . " env ON env.environment_id=e.environment_id LEFT JOIN " . DB_TABLE_TAMPER_EVIDENT_BAGS . " t ON t.bag_id=e.bag_id LEFT JOIN " . DB_TABLE_ESCROW_LOCATIONS . " l ON l.escrow_location_id=e.escrow_location_id LEFT JOIN " . DB_TABLE_SITES . " s ON s.site_id=l.site_id LEFT JOIN " . DB_TABLE_SUPPORT_CONTRACTS . " sc ON sc.support_contract_id=e.support_contract_id LEFT JOIN " . DB_TABLE_EQUIP_TYPES . " eq ON eq.equipment_type_id=e.equipment_type_id LEFT JOIN " . DB_TABLE_VENDORS . " v ON v.vendor_id=e.vendor_id LEFT JOIN " . DB_TABLE_MODEL_TYPES . " m ON m.model_type_id=e.model_type_id LEFT JOIN " . DB_TABLE_EQUIP_VERSIONS . " ev ON ev.equipment_version_id=e.equipment_version_id WHERE e.deleted=0";
			$Filename = "cbo_equipment_" . date('Ymd') . ".csv";
		}elseif(@$_GET['report'] == "share"){			
			$Query  = "SELECT s.share_label AS label, IF(sh.shareholder_name IS NULL, 'Unassigned', sh.shareholder_name) AS shareholder_name, st.share_type_name AS share_type, IF(b.box_number IS NOT NULL, b.box_number, 'In Escrow') AS box_number, IF(l.escrow_location_name IS NOT NULL, l.escrow_location_name, 'Not In Escrow') AS escrow_location_name, p.product_name, e.environment_name, k.key_type_name AS key_type, m.media_type_name AS media_type, s.mofn_threshold, IF(t.bag_serial IS NOT NULL, t.bag_serial, 'Not In Escrow') AS tamper_bag_serial, IF(s.original_distribution_date IS NOT NULL, s.original_distribution_date, 'Not Distributed') AS original_distribution_date, s.date_destroyed, s.share_set, s.last_audit_date, s.notes, u.name AS created_by, s.date_created, u2.name AS last_updated_by, s.date_updated AS last_updated FROM " . DB_TABLE_SHARES . " s LEFT JOIN " . DB_TABLE_BOXES . " b ON b.box_id=s.box_id LEFT JOIN " . DB_TABLE_KEYS . " pk ON pk.box_id=b.box_id AND pk.shareholder_id IS NOT NULL LEFT JOIN " . DB_TABLE_SHAREHOLDERS . " sh ON sh.shareholder_id=pk.shareholder_id AND pk.shareholder_id IS NOT NULL LEFT JOIN " . DB_TABLE_ESCROW_LOCATIONS . " l ON l.escrow_location_id=s.escrow_location_id LEFT JOIN " . DB_TABLE_TAMPER_EVIDENT_BAGS . " t ON t.bag_id=s.bag_id LEFT JOIN " . DB_TABLE_USERS . " u ON u.user_id=s.created_by LEFT JOIN " . DB_TABLE_USERS . " u2 ON u2.user_id=s.updated_by LEFT JOIN " . DB_TABLE_SHARE_TYPES . " st ON st.share_type_id=s.share_type_id LEFT JOIN " . DB_TABLE_PRODUCTS . " p ON p.product_id=s.product_id LEFT JOIN " . DB_TABLE_ENVIRONMENTS . " e ON e.environment_id=s.environment_id LEFT JOIN " . DB_TABLE_KEY_TYPES . " k ON k.key_type_id=s.key_type_id LEFT JOIN " . DB_TABLE_MEDIA_TYPES . " m ON m.media_type_id=s.media_type_id WHERE s.deleted=0 ORDER BY b.box_number, s.share_label";
			$Filename = "cbo_shares_" . date('Ymd') . ".csv";
		}
			
		$Result = db_query($Query);
		$Count = row_count($Result);
		
		// Convert a MySQL query into a CSV file
		
		if($Count > 0){
		
			$Fields  = str_replace('_', ' ', array_map('strtoupper', fetch_field_names($Result)));
			$CSV = '"' . implode('","', $Fields) . '"';
			
			while($Row = row_fetch($Result)){
				$CSV .= "\n";
				$CSV .= '"' . implode('","', $Row) . '"';				
			}
			
		}else{
			$CSV = "There are currently no records to export.";
		}
		
		header("Content-type: application/csv");
		header("Cache-Control: must-revalidate, no-cache");
		header("Content-Disposition: attachment; filename=\"" . $Filename . "\"");
		header("Content-Length: " . strlen($CSV));
		header("Pragma: public");
		header("Cache-Control: max-age=0");
		header("Expires: 0");		
		echo trim($CSV);
	
	db_close();
	
?>
