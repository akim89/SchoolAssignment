<?php
	
	// List of built in php filter types
	
	$FILTER_TYPES = array(
		"int"		=> FILTER_VALIDATE_INT,
		"float"		=> FILTER_VALIDATE_FLOAT,
		
		"email"		=> FILTER_VALIDATE_EMAIL,
		"url"		=> FILTER_VALIDATE_URL,
		"ip"		=> FILTER_VALIDATE_IP,
		
		"boolean"   => FILTER_VALIDATE_BOOLEAN,
		"regex"		=> FILTER_VALIDATE_REGEXP,
		
		"callback" 	=> FILTER_CALLBACK
	);
	
	// List of validation RegEx's
		
	$VALIDATION_REGEX = array(
			"int"           => "/^[0-9]+$/",
	        "short"         => "/^[a-z0-9-_]+$/",
			"alphanum"      => "/^[A-Za-z0-9]+$/",
		    "basic"         => "/^[A-Za-z0-9-_.,: ]+$/",
	        "text"          => "/^[A-Za-z0-9-_.,?:+=!@#$%&*(){} \/'\"\[\]\|\n\t\r]+$/",
			"alltext"       => "/^[[:print:]+[:space:]]+$/",
	      
	        "bool"          => "/^[01]*$/",
	        "yes_no"        => "/^yes$|^no$/",
	  
	        "date"          => "/^[012][019][0-9][0-9]-[01][0-9]-[0123][0-9]$/",
	        "datetime"      => "/^[012][019][0-9][0-9]-[01][0-9]-[0123][0-9] [0-2][0-9]:[0-5][0-9]:[0-5][0-9]$/",
			"timehms"       => "/^[0-2][0-9]{1,2}:[0-5][0-9]:[0-5][0-9]$/",
			"timehm"        => "/^[0-2][0-9]:[0-5][0-9]$/",
			
			"phone"         => "/(^[2-9]\d{2}-\d{3}-\d{4}$)|(^1-[2-9]\d{2}-\d{3}-\d{4}$)|(^\d{2}-\d{2}-\d{3}-\d{4}$)|(^\d{2}-\d{3}-\d{3}-\d{4}$)/",
			"zip5"          => "/^[0-9]{5}+$/",
			"zip9"          => "/(^\d{9}$)|(^\d{5}-\d{4}$)+$/",
			"zip"           => "/(^[0-9]{5}$)|(^\d{9}$)|(^\d{5}-\d{4}$)+$/",
			
			"decision"      => "/^[Aa]pprove$|^[Rr]eject$/",
			"equip_status"  => "/^[Oo]nline$|^[Oo]ffline$|^[Dd]estroyed$/",
			"sys_id"        => "/^[A-Za-z0-9]{32}?/"
	);
	
	// Function for validating data

	function validate($Type, $Value, $FieldName, $Required = 1, $Regex = NULL, $CustomValError = NULL, $CallbackFunction = NULL, $StripTags = TRUE){
		global $FILTER_TYPES;
		global $VALIDATION_REGEX;

		$OrigValue = $Value;
		$Value     = utf8_decode($Value);						// Convert unicode characters to ascii
		$Value     = trim($Value);								// Remove leading and trailing white spaces

		if($StripTags){
			$Value = strip_tags($Value);					// Remove HTML/PHP tags
		}
		
		$ErrorCount = 0;
		
		// Verify that the filter type exists
		
		if(!isset($FILTER_TYPES[$Type])){
			@$_SESSION['error'][] = "There is no validation filter called '$Type' to validate against, please reveiw your PHP script.";
			$ErrorCount++;
		}
		
		// If using a custom regex, make sure it exists
		
		if($Type == "regex" && !isset($VALIDATION_REGEX[$Regex])){
			@$_SESSION['error'][] = "There is no regular expression filter called '$Regex' to validate against, please reveiw your PHP script.";
			$ErrorCount++;
		}
		
		// If the value is required verify that one has been entered
		
		if($Value == "" && $Regex != "bool"){		
			if($Required == 1) {
				$_SESSION['error'][] = "The $FieldName field is required.";
				$ErrorCount++;
			}
		
		// If a required value was entered and no errores have occurred validate it
		
		}else{
		
			if($ErrorCount == 0){
			
				// Use a custom regaular expression filter filtering
				
				if($Type == "regex"){
					
					$Result = filter_var($Value, $FILTER_TYPES[$Type], array("options"=>array("regexp"=>$VALIDATION_REGEX[$Regex])));
					
					if($Result === FALSE){
						if($CustomValError){
							$_SESSION['error'][] = $CustomValError;
						}else{
						
							# If the value failed the regex, then highlight the invalid characters in yellow
							
							$Pattern   = $VALIDATION_REGEX[$Regex];
							$Pattern   = preg_replace("/^\/\^/", "/", $Pattern);	
							$Pattern   = preg_replace("/\\$\/$/", "/", $Pattern);
							$Highlight = '<font style="background-color: white">$0</font>';
							$Value     = preg_replace($Pattern, $Highlight, $Value);
						
							$_SESSION['error'][] = "'<font style=\"background-color: yellow\">$Value</font>' is an invalid entry for the '<strong>$Regex</strong>' regular expression in the '<strong>$FieldName</strong>' field. " . (($GLOBALS["errorMessage"]["regex_$Regex"]) ? $GLOBALS["errorMessage"]["regex_$Regex"] : "The data must match <strong>{$VALIDATION_REGEX[$Regex]}</strong>");
						}
						$ErrorCount++;
					}
				
				// The value is going to be validated using a custom function
		
				}elseif($Type == "callback"){
				
					$Result = filter_var($Value, FILTER_CALLBACK, array("options"=>"$CallbackFunction"));	
					
					if(!$Result){
						if($CustomValError){
							$_SESSION['error'][] = $CustomValError;
						}else{
							$_SESSION['error'][] = "The value entered in the $FieldName field does not pass validation.";
						}
						$ErrorCount++;
					}
		
				}else{
				
					// Use the built in PHP filtering
					
					$Result = filter_var($Value, $FILTER_TYPES[$Type]);
					
					if(!$Result){
						if($CustomValError){
							$_SESSION['error'][] = $CustomValError;
						}else{
							$_SESSION['error'][] = "The value entered in the $FieldName field does not pass validation.";
						}
						$ErrorCount++;
					}
				}
			}
		}

		// If no errors occured return the trimmed, validated and escaped string
		
		if($ErrorCount == 0){
		
			// If magic quotes is enabled strip any slashes that may have already be added
			
			if(get_magic_quotes_gpc()){
				$Value = stripslashes($Value);
			}

			// Escape the string for writing to a MySQL database
			// Not using addslashes() due to SQL injection possibility
			
			if (!is_numeric($Value)){ 
				if(function_exists('mysqli_real_escape_string')){
					$Value = mysqli_real_escape_string($GLOBALS['DBLink'], $Value);
				}else{
					$Value = mysql_real_escape_string($Value, $GLOBALS['DBLink']);
				}
			}				
			
			return $Value;
			
		}else{
		
			// If the value failes validation return the dirty value instead of FALSE so that it can be re-entered into the 
			// form so the user can make the necessary corrections

			// return FALSE;
			return $OrigValue;
		}
		
	}
	
	// Validate an array of items using the vaildate function
	
	function validate_array($DataType, $ArrayOfValues, $FieldName, $Required = 1, $Regex = NULL){
		
		// Value is an array
		
		if(is_array($ArrayOfValues)){	
			foreach($ArrayOfValues as $CurrentValue){
				validate("$DataType", $CurrentValue, "$FieldName", $Required, $Regex);
			}
			
		// Value is non-existant (Bascially check to see if we need to raise an alert for a requried form field)
		
		}elseif(!$ArrayOfValues){
		
			validate("$DataType", @$CurrentValue, "$FieldName", $Required, $Regex);
		
		// Value is string/int (not an array)
		
		}else{
			message_substitution("error", $GLOBALS['errorMessage']['not_expected_format'], $FieldName);
		}
	}

?>