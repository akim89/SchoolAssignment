<?php
	
	########################################################
	##               START AND STOP A FORM                ##
	########################################################
	
	// Start a form encased in a table
	
	function form_start($Args){
	
		if(!isset($Args['title'])){       $Args['title']       = NULL; }
		if(!isset($Args['action'])){      $Args['action']      = NULL; }
		
		if(!isset($Args['method'])){      $Args['method']      = "post"; }		
		if(!isset($Args['name'])){        $Args['name']        = "thisform"; }
		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		
		if(!isset($Args['blank'])){       $Args['blank']       = 0; }
		if(!isset($Args['javascript'])){  $Args['javascript']  = NULL; }
		if(!isset($Args['css'])){         $Args['css']         = NULL; }
		if(!isset($Args['show_legend'])){ $Args['show_legend'] = FALSE; }
		if(!isset($Args['use_table'])){   $Args['use_table']   = TRUE; }
	
		$ActionText = ($Args['action']) ? "action='{$Args['action']}'" : "action='#'";
		
		if($Args['title']){
			print "<h3>{$Args['title']}</h3>\n";
		}
		
		$Target = ($Args['blank']) ? "target='_blank'" : NULL;
		
		print "<form $ActionText method='{$Args['method']}' name='{$Args['name']}' id='{$Args['id']}' $Target {$Args['javascript']} >\n";
		
			if($Args['use_table']){
				print "<table {$Args['css']}>\n";
			
				if($Args['show_legend']){ 
					print "<tr align='left'><td>&nbsp;</td><td>Required fields are marked with a ";
					form_required();
					print "</td></tr>"; 
					form_break();
				}
			}
	}

	// End a form encased in a table
	
	function form_end($Args = NULL){
	
		if(!isset($Args['use_table'])){   $Args['use_table'] = TRUE; }
		
			if($Args['use_table']){
				print "</table>\n";
			}
		print "</form>\n";
	}

	########################################################
	##                 NORMAL FORM FIELDS                 ##
	########################################################
	
	// Insert text field
	
	function form_text_field($Args){
	
		if(!isset($Args['title'])){       $Args['title']       = NULL; }
		if(!isset($Args['name'])){        $Args['name']        = "textfield"; }
		
		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		if(!isset($Args['size'])){        $Args['size']        = 20; }
		if(!isset($Args['value'])){       $Args['value']       = NULL; }
		
		if(!isset($Args['disabled'])){    $Args['disabled']    = FALSE; }
		if(!isset($Args['required'])){    $Args['required']    = FALSE; }
		if(!isset($Args['placeholder'])){ $Args['placeholder'] = NULL; }
		if(!isset($Args['css'])){         $Args['css']         = NULL; }
		if(!isset($Args['javascript'])){  $Args['javascript']  = NULL; }
		if(!isset($Args['delimiter'])){   $Args['delimiter']   = ":"; }
		if(!isset($Args['use_table'])){   $Args['use_table']   = TRUE; }
		
		$Disabled    = ($Args['disabled'])    ? "disabled"                             : NULL;
		$Required    = ($Args['required'])    ? "required"                             : NULL;
		$Placeholder = ($Args['placeholder']) ? "placeholder='{$Args['placeholder']}'" : NULL;

		if($Args['use_table']){
			print "<tr>\n";
				print "<td align='right'>{$Args['title']}{$Args['delimiter']}";
		}
				if($Args['required']){ form_required(); }
				if($Args['use_table']){
					print "</td>\n";
					print "<td align='left'>";
				}
				print "<input type='text' size='{$Args['size']}' name='{$Args['name']}' id='{$Args['id']}' value=\"" . htmlentities(stripslashes($Args['value'])) . "\" $Disabled $Required $Placeholder {$Args['css']} {$Args['javascript']} />";	
				
		if($Args['use_table']){
				print "</td>\n";
			print "</tr>\n";
		}
	}

	// Insert boolean field in the form of a checkbox
	
	function form_boolean($Args){
	
		if(!isset($Args['title'])){       $Args['title']       = NULL; }
		if(!isset($Args['name'])){        $Args['name']        = "checkbox_field"; }
		
		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		if(!isset($Args['value'])){       $Args['value']       = NULL; }
		
		if(!isset($Args['disabled'])){    $Args['disabled']    = FALSE; }
		if(!isset($Args['css'])){         $Args['css']         = NULL; }
		if(!isset($Args['add_text'])){    $Args['add_text']    = NULL; }		
		if(!isset($Args['javascript'])){  $Args['javascript']  = NULL; }
		if(!isset($Args['delimiter'])){   $Args['delimiter']   = ":"; }
		if(!isset($Args['use_table'])){   $Args['use_table']   = TRUE; }
	
		$Checked  = ($Args['value'] == 1) ? "checked"  : NULL;
		$Disabled = ($Args['disabled'])   ? "disabled" : NULL;
		
		if($Args['use_table']){
			print "<tr>\n";
				print "<td align='right'>{$Args['title']}{$Args['delimiter']}</td>\n";
				print "<td align='left'>";
		}
			print "<input type='checkbox' name='{$Args['name']}' id='{$Args['id']}' value='1' $Checked $Disabled {$Args['css']} {$Args['javascript']} />";
			print "&nbsp;&nbsp;" . $Args['add_text'];
			
		if($Args['use_table']){
				print "</td>\n";
			print "</tr>\n";
		}
	}
	
	// Insert text area
	
	function form_text_area($Args){
		
		if(!isset($Args['title'])){       $Args['title']       = NULL; }
		if(!isset($Args['name'])){        $Args['name']        = "text_area_field"; }

		if(!isset($Args['rows'])){        $Args['rows']        = 8; }
		if(!isset($Args['cols'])){        $Args['cols']        = 50; }
		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		if(!isset($Args['value'])){       $Args['value']       = NULL; }
		
		if(!isset($Args['required'])){    $Args['required']    = FALSE; }
		if(!isset($Args['disabled'])){    $Args['disabled']    = FALSE; }
		if(!isset($Args['placeholder'])){ $Args['placeholder'] = NULL; }
		if(!isset($Args['css'])){         $Args['css']         = NULL; }
		if(!isset($Args['add_text'])){    $Args['add_text']    = NULL; }		
		if(!isset($Args['javascript'])){  $Args['javascript']  = NULL; }
		if(!isset($Args['delimiter'])){   $Args['delimiter']   = ":"; }
		if(!isset($Args['use_table'])){   $Args['use_table']   = TRUE; }
		
		$Disabled    = ($Args['disabled'])    ? "disabled"                             : NULL;
		$Required    = ($Args['required'])    ? "required"                             : NULL;
		$Placeholder = ($Args['placeholder']) ? "placeholder='{$Args['placeholder']}'" : NULL;
		
		if($Args['use_table']){
			print "<tr>\n";
				print "<td align='right'>{$Args['title']}{$Args['delimiter']}";
				if($Args['required']){ form_required(); }
				print "</td>\n";
				print "<td align='left'>";
		}
				print "<textarea rows='{$Args['rows']}' cols='{$Args['cols']}' id='{$Args['id']}' name='{$Args['name']}' $Disabled $Required $Placeholder {$Args['css']} {$Args['javascript']}>{$Args['value']}</textarea>";
		
		if($Args['use_table']){
				print "&nbsp;&nbsp;" . $Args['add_text'];	
				print "</td>\n";
			print "</tr>\n";
		}
	}
		
	// Insert password field
	
	function form_password_field($Args){
		
		if(!isset($Args['title'])){       $Args['title']       = NULL; }
		if(!isset($Args['name'])){        $Args['name']        = "password_field"; }

		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		if(!isset($Args['value'])){       $Args['value']       = NULL; }
		
		if(!isset($Args['size'])){        $Args['size']        = 20; }
		if(!isset($Args['required'])){    $Args['required']    = FALSE; }
		if(!isset($Args['disabled'])){    $Args['disabled']    = FALSE; }
		if(!isset($Args['placeholder'])){ $Args['placeholder'] = NULL; }
		if(!isset($Args['css'])){         $Args['css']         = NULL; }
		if(!isset($Args['add_text'])){    $Args['add_text']    = NULL; }		
		if(!isset($Args['javascript'])){  $Args['javascript']  = NULL; }
		if(!isset($Args['delimiter'])){   $Args['delimiter']   = ":"; }

		$Disabled    = ($Args['disabled'])    ? "disabled"                             : NULL;
		$Required    = ($Args['required'])    ? "required"                             : NULL;
		$Placeholder = ($Args['placeholder']) ? "placeholder='{$Args['placeholder']}'" : NULL;		
		
		print "<tr>\n";
			print "<td align='right'>{$Args['title']}{$Args['delimiter']}";
			if($Args['required']){ form_required(); }
			print "</td>\n";
			print "<td align='left'><input type='password' size='{$Args['size']}' id='{$Args['id']}' name='{$Args['name']}' value='{$Args['value']}' $Disabled $Required $Placeholder {$Args['css']} {$Args['javascript']} />";	
			print "&nbsp;&nbsp;" . $Args['add_text'];			
			print "</td>\n";
		print "</tr>\n";
	}
	
	// Insert radio buttons based on an associative array
	
	function form_radio($Args){
	
		if(!isset($Args['title'])){       $Args['title']       = NULL; }
		if(!isset($Args['name'])){        $Args['name']        = "radio_field"; }
		if(!isset($Args['items'])){       $Args['items']       = NULL; }

		if(!isset($Args['selected'])){    $Args['selected']    = NULL; }
		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		
		if(!isset($Args['brkVsSpace'])){  $Args['brkVsSpace']  = 0; }
	
		if(!isset($Args['required'])){    $Args['required']    = FALSE; }
		if(!isset($Args['disabled'])){    $Args['disabled']    = FALSE; }
		if(!isset($Args['css'])){         $Args['css']         = NULL; }
		if(!isset($Args['add_text'])){    $Args['add_text']    = NULL; }		
		if(!isset($Args['javascript'])){  $Args['javascript']  = NULL; }
		if(!isset($Args['delimiter'])){   $Args['delimiter']   = ":"; }
		if(!isset($Args['use_table'])){   $Args['use_table']   = TRUE; }
		
		$Required = ($Args['required'])   ? "required" : NULL;
		$Disabled = ($Args['disabled'])   ? "disabled" : NULL;
		$EOL      = ($Args['brkVsSpace']) ? "&nbsp;"   : "<br />";

		if($Args['use_table']){
			print "<tr>\n";
				print "<td align='right' valign='top'>{$Args['title']}{$Args['delimiter']}";
				if($Args['required']){ form_required(); }
				print "</td>\n";
				print "<td align='left'>\n";		
		}
		
			$IDCount = 1;
			
			foreach($Args['items'] as $Value => $Label){
				if($Value == $Args['selected']){
					print "<input type='radio' name='{$Args['name']}' id='{$Args['id']}_$IDCount' value='$Value' checked $Disabled $Required {$Args['css']} {$Args['javascript']} /> <label for='{$Args['id']}_$IDCount'>$Label</label> $EOL\n";
				} else {
					print "<input type='radio' name='{$Args['name']}' id='{$Args['id']}_$IDCount' value='$Value' $Disabled $Required {$Args['css']} {$Args['javascript']} /> <label for='{$Args['id']}_$IDCount'>$Label</label> $EOL\n";
				}
				$IDCount++;
			}	
			if($Args['add_text']){ print "&nbsp;&nbsp;" . $Args['add_text']; }
			
		if($Args['use_table']){
				print "</td>\n";
			print "</tr>\n";
		}
	}

	// Insert a hidden field
	
	function form_hidden($Args){
		
		if(!isset($Args['name'])){        $Args['name']        = "hidden_field"; }		
		if(!isset($Args['value'])){       $Args['value']       = NULL; }
		
		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		
		print "<input type='hidden' name='{$Args['name']}' id='{$Args['id']}' value='{$Args['value']}' />\n";
	}
	
	// Insert a drop down menu 
	
	function form_dropdown($Args){

		if(!isset($Args['title'])){           $Args['title']           = NULL; }
		if(!isset($Args['name'])){            $Args['name']            = "dropdown_field"; }
		if(!isset($Args['items'])){           $Args['items']           = NULL; }
		
		if(!isset($Args['value'])){           $Args['value']           = NULL; }
		if(!isset($Args['id'])){              $Args['id']              = $Args['name']; }
		
		if(!isset($Args['na_opt'])){          $Args['na_opt']          = FALSE; }
		if(!isset($Args['all_opt'])){         $Args['all_opt']         = FALSE; }
		if(!isset($Args['select_opt'])){      $Args['select_opt']      = TRUE; }
		if(!isset($Args['select_opt_text'])){ $Args['select_opt_text'] = "-- Select --"; }
		if(!isset($Args['color'])){           $Args['color']           = NULL; }
		if(!isset($Args['multiselect'])){     $Args['multiselect']     = FALSE; }
		if(!isset($Args['multisize'])){       $Args['multisize']       = FALSE; }
		if(!isset($Args['use_table'])){       $Args['use_table']       = TRUE; }
		if(!isset($Args['required'])){        $Args['required']        = FALSE; }
		if(!isset($Args['disabled'])){        $Args['disabled']        = FALSE; }
		if(!isset($Args['align'])){           $Args['align']           = "left"; }
		if(!isset($Args['css'])){             $Args['css']             = NULL; }
		if(!isset($Args['javascript'])){      $Args['javascript']      = NULL; }
		if(!isset($Args['delimiter'])){       $Args['delimiter']       = ":"; }

		$Disabled    = ($Args['disabled'])    ? "disabled"                    : NULL;
		$Required    = ($Args['required'])    ? "required"                    : NULL;
		$MultiSelect = ($Args['multiselect']) ? "multiple='multiple'"         : NULL;
		$Multisize   = ($Args['multiselect'] && $Args['multisize']) ? "size='{$Args['multisize']}'" : NULL;
		
		if($Args['use_table']){
			print "<tr>\n";
			print "<td align='right'>{$Args['title']}{$Args['delimiter']}";
			if($Args['required']){ form_required(); }
			print "</td>\n";
			print "<td align='{$Args['align']}'>\n";
		}

		print "<select name='{$Args['name']}' id='{$Args['id']}' $Disabled $Required {$Args['css']} {$Args['javascript']} $MultiSelect $Multisize>\n";
		
			print ($Args['select_opt']) ? "<option value=''>" . $Args['select_opt_text'] . "</option>\n" : NULL;
			
			if($Args['all_opt']){
				if(is_array($Args['value'])){
					$Selected = (in_array("all", $Args['value'])) ? "selected" : NULL;
				}else{
					$Selected = ($Args['value'] == "all") ? "selected" : NULL;
				}
				
				print "<option value='all' $Selected>All</option>\n";
			}
			
			if($Args['items']){
				foreach($Args['items'] as $Value => $Label){

					$TextColor = ($Args['color']) ? "style='background-color: $Label'" : NULL;
		
					if(is_array($Args['value'])){
						$Selected = (in_array($Value, $Args['value'])) ? "selected" : NULL;				
					}else{
						$Selected = ($Value == $Args['value']) ? "selected" : NULL;
					}
					
					print "<option $TextColor $Selected value='$Value'>$Label</option>\n";
				}
			}
			
			if($Args['na_opt']){
				if(is_array($Args['value'])){
					$Selected = (in_array("N/A", $Args['value'])) ? "selected" : NULL;
				}else{
					$Selected = ($Args['value'] == "N/A") ? "selected" : NULL;
				}
				
				print "<option value='N/A' $Selected>N/A</option>\n";
			}
		
		print "</select>\n";
		
		if($Args['use_table']){				
			print "</td>\n";
			print "</tr>\n";
		}
	}	
	
	########################################################
	##                   FORM BUTTONS                     ##
	########################################################
	
	// Insert a default submit button or a custom button created from an image
	
	function form_submit($Args = NULL){
	
		if(!isset($Args['value'])){       $Args['value']       = "Submit"; }
		if(!isset($Args['name'])){        $Args['name']        = "submit"; }
		
		if(!isset($Args['id'])){          $Args['id']          = $Args['name']; }
		if(!isset($Args['img_file'])){    $Args['img_file']    = NULL; }
		if(!isset($Args['align'])){       $Args['align']       = "center"; }
		if(!isset($Args['css'])){         $Args['css']         = NULL; }
		if(!isset($Args['javascript'])){  $Args['javascript']  = NULL; }
		if(!isset($Args['use_table'])){   $Args['use_table']   = TRUE; }
	
		if($Args['use_table']){
			print "<tr>\n";
				if($Args['img_file']){
					print "<td colspan='2' align='{$Args['align']}'><input type='image' name='{$Args['name']}' id='{$Args['id']}' value='{$Args['value']}' src='{$Args['img_file']}' {$Args['css']} {$Args['javascript']} /></td>\n";
				} else {
					print "<td colspan='2' align='{$Args['align']}'><input type='submit' name='{$Args['name']}' id='{$Args['id']}' value='{$Args['value']}' {$Args['css']} {$Args['javascript']} /></td>\n";
				}
			print "</tr>\n";
		}else{
			if($Args['img_file']){
				print "<input type='image' name='{$Args['name']}' id='{$Args['id']}' value='{$Args['value']}' src='{$Args['img_file']}' {$Args['css']} {$Args['javascript']} />\n";
			} else {
				print "<input type='submit' name='{$Args['name']}' id='{$Args['id']}' value='{$Args['value']}' {$Args['css']} {$Args['javascript']} />\n";
			}
		}
	}
	
	// Inserts two default buttons or two custom buttons created from an image
	
	function form_two_buttons($Args = NULL){
	
		if(!isset($Args['value1'])){       $Args['value1']       = "Submit 1"; }
		if(!isset($Args['name1'])){        $Args['name1']        = "submit1"; }
		if(!isset($Args['type1'])){        $Args['type1']        = "submit"; }
		if(!isset($Args['id1'])){          $Args['id1']          = $Args['name1']; }
		if(!isset($Args['img_file1'])){    $Args['img_file1']    = NULL; }
		if(!isset($Args['javascript1'])){  $Args['javascript1']  = NULL; }
		
		if(!isset($Args['value2'])){       $Args['value2']       = "Submit 2"; }
		if(!isset($Args['name2'])){        $Args['name2']        = "submit2"; }
		if(!isset($Args['type2'])){        $Args['type2']        = "submit"; }	
		if(!isset($Args['id2'])){          $Args['id2']          = $Args['name2']; }		
		if(!isset($Args['img_file2'])){    $Args['img_file2']    = NULL; }
		if(!isset($Args['javascript2'])){  $Args['javascript2']  = NULL; }
		
		if(!isset($Args['align'])){        $Args['align']        = "center"; }
		if(!isset($Args['css'])){          $Args['css']          = NULL; }		
	
		print "<tr>\n";
			print "<td colspan='2' align='{$Args['align']}'>";
			if($Args['img_file1']){
				print "<input value='{$Args['value1']}' type='image' name='{$Args['name1']}' id='{$Args['id1']}' src='{$Args['img_file1']}' {$Args['css']} {$Args['javascript1']} /> &nbsp;\n";
			} else {
				print "<input value='{$Args['value1']}' type='{$Args['type1']}' name='{$Args['name1']}' id='{$Args['id1']}' {$Args['css']} {$Args['javascript1']} /> &nbsp;\n";
			}
			if($Args['img_file2']){
				print "<input value='{$Args['value2']}' type='image' name='{$Args['name2']}' id='{$Args['id2']}' src='{$Args['img_file2']}' {$Args['css']} {$Args['javascript2']} /> &nbsp;\n";
			} else {
				print "<input value='{$Args['value2']}' type='{$Args['type2']}' name='{$Args['name2']}' id='{$Args['id2']}' {$Args['css']} {$Args['javascript2']} /> &nbsp;\n";
			}
		print "<td>\n</tr>\n";
	}
	
	// Inserts three default buttons
	
	function form_three_buttons($Args = NULL){
	
		if(!isset($Args['value1'])){       $Args['value1']       = "Submit 1"; }
		if(!isset($Args['name1'])){        $Args['name1']        = "submit1"; }
		if(!isset($Args['type1'])){        $Args['type1']        = "submit"; }
		if(!isset($Args['id1'])){          $Args['id1']          = $Args['name1']; }
		if(!isset($Args['javascript1'])){  $Args['javascript1']  = NULL; }
		
		if(!isset($Args['value2'])){       $Args['value2']       = "Submit 2"; }
		if(!isset($Args['name2'])){        $Args['name2']        = "submit2"; }
		if(!isset($Args['type2'])){        $Args['type2']        = "submit"; }	
		if(!isset($Args['id2'])){          $Args['id2']          = $Args['name2']; }		
		if(!isset($Args['javascript2'])){  $Args['javascript2']  = NULL; }
		
		if(!isset($Args['value3'])){       $Args['value3']       = "Submit 3"; }
		if(!isset($Args['name3'])){        $Args['name3']        = "submit3"; }
		if(!isset($Args['type3'])){        $Args['type3']        = "submit"; }	
		if(!isset($Args['id3'])){          $Args['id3']          = $Args['name3']; }		
		if(!isset($Args['javascript3'])){  $Args['javascript3']  = NULL; }
		
		if(!isset($Args['align'])){        $Args['align']        = "center"; }
		if(!isset($Args['css'])){          $Args['css']          = NULL; }		
	
		print "<tr>\n";
			print "<td colspan='2' align='{$Args['align']}'>";
				print "<input value='{$Args['value1']}' type='{$Args['type1']}' name='{$Args['name1']}' id='{$Args['id1']}' {$Args['css']} {$Args['javascript1']} /> &nbsp;\n";
				print "<input value='{$Args['value2']}' type='{$Args['type2']}' name='{$Args['name2']}' id='{$Args['id2']}' {$Args['css']} {$Args['javascript2']} /> &nbsp;\n";
				print "<input value='{$Args['value3']}' type='{$Args['type3']}' name='{$Args['name3']}' id='{$Args['id3']}' {$Args['css']} {$Args['javascript3']} /> &nbsp;\n";
		print "<td>\n</tr>\n";
	}
	
	// Inserts four default buttons
	
	function form_four_buttons($Args = NULL){
	
		if(!isset($Args['value1'])){       $Args['value1']       = "Submit 1"; }
		if(!isset($Args['name1'])){        $Args['name1']        = "submit1"; }
		if(!isset($Args['type1'])){        $Args['type1']        = "submit"; }
		if(!isset($Args['id1'])){          $Args['id1']          = $Args['name1']; }
		if(!isset($Args['javascript1'])){  $Args['javascript1']  = NULL; }
		
		if(!isset($Args['value2'])){       $Args['value2']       = "Submit 2"; }
		if(!isset($Args['name2'])){        $Args['name2']        = "submit2"; }
		if(!isset($Args['type2'])){        $Args['type2']        = "submit"; }	
		if(!isset($Args['id2'])){          $Args['id2']          = $Args['name2']; }		
		if(!isset($Args['javascript2'])){  $Args['javascript2']  = NULL; }
		
		if(!isset($Args['value3'])){       $Args['value3']       = "Submit 3"; }
		if(!isset($Args['name3'])){        $Args['name3']        = "submit3"; }
		if(!isset($Args['type3'])){        $Args['type3']        = "submit"; }	
		if(!isset($Args['id3'])){          $Args['id3']          = $Args['name3']; }		
		if(!isset($Args['javascript3'])){  $Args['javascript3']  = NULL; }
		
		if(!isset($Args['value4'])){       $Args['value4']       = "Submit 4"; }
		if(!isset($Args['name4'])){        $Args['name4']        = "submit4"; }
		if(!isset($Args['type4'])){        $Args['type4']        = "submit"; }	
		if(!isset($Args['id4'])){          $Args['id4']          = $Args['name4']; }		
		if(!isset($Args['javascript4'])){  $Args['javascript4']  = NULL; }
		
		if(!isset($Args['align'])){        $Args['align']        = "center"; }
		if(!isset($Args['css'])){          $Args['css']          = NULL; }		
	
		print "<tr>\n";
			print "<td colspan='2' align='{$Args['align']}'>";
				print "<input value='{$Args['value1']}' type='{$Args['type1']}' name='{$Args['name1']}' id='{$Args['id1']}' {$Args['css']} {$Args['javascript1']} /> &nbsp;\n";
				print "<input value='{$Args['value2']}' type='{$Args['type2']}' name='{$Args['name2']}' id='{$Args['id2']}' {$Args['css']} {$Args['javascript2']} /> &nbsp;\n";
				print "<input value='{$Args['value3']}' type='{$Args['type3']}' name='{$Args['name3']}' id='{$Args['id3']}' {$Args['css']} {$Args['javascript3']} /> &nbsp;\n";
				print "<input value='{$Args['value4']}' type='{$Args['type4']}' name='{$Args['name4']}' id='{$Args['id4']}' {$Args['css']} {$Args['javascript4']} /> &nbsp;\n";
		print "<td>\n</tr>\n";
	}
	
	########################################################
	##               DATE & TIME FORM FIELDS              ##
	########################################################

	// Insert a jQuery UI calendar to pick a date and time

	function form_date_time($Args = NULL){
	
		if(!isset($Args['title'])){              $Args['title']              = NULL; }
		if(!isset($Args['name'])){               $Args['name']               = "date_time"; }

		if(!isset($Args['id'])){                 $Args['id']                 = $Args['name']; }
		if(!isset($Args['value'])){              $Args['value']              = NULL; }
		
		if(!isset($Args['use_table'])){          $Args['use_table']          = TRUE; }
		if(!isset($Args['size'])){               $Args['size']               = 17; }
		if(!isset($Args['required'])){           $Args['required']           = FALSE; }
		if(!isset($Args['disabled'])){           $Args['disabled']           = FALSE; }
		if(!isset($Args['css'])){                $Args['css']                = NULL; }
		if(!isset($Args['add_text'])){           $Args['add_text']           = NULL; }		
		if(!isset($Args['javascript'])){         $Args['javascript']         = NULL; }
		if(!isset($Args['delimiter'])){          $Args['delimiter']          = ":"; }
		
		$Disabled = ($Args['disabled']) ? "disabled" : NULL;
		$Required = ($Args['required']) ? "required" : NULL;
	
		if($Args['use_table']){
			print "<tr>\n";
				print "<td align='right'>{$Args['title']}{$Args['delimiter']}";
				if($Args['required']){ form_required(); }
				print "</td>\n";
				print "<td align='left'>";
		}
				print "<input  type='text' id='{$Args['id']}' size='{$Args['size']}' name='{$Args['name']}' value='{$Args['value']}' $Disabled $Required {$Args['css']} {$Args['javascript']} />\n";
				if($Args['add_text']){ print "&nbsp;&nbsp;" . $Args['add_text']; }
		
		if($Args['use_table']){
				print "</td>\n";
			print "</tr>\n";
		}

	}
	
	########################################################
	##                 SPECIAL FORM FIELDS                ##
	########################################################
	
	// Insert a blank row in a form

	function form_break($Args = NULL){
		
		if(!isset($Args['text'])){ $Args['text'] = "&nbsp;"; }

		print "<tr>\n";
			print "<td colspan='2'>{$Args['text']}</td>\n";
		print "</tr>\n";
	}
	
	// Inserts a required "star" on a specified field
	
	function form_required($Return = FALSE){
		if($Return){
			return " <img src='" . PATH_IMAGES . "/required.png' width='7' alt='Required form field' />";
		}else{
			echo " <img src='" . PATH_IMAGES . "/required.png' width='7' alt='Required form field' />";
		}
	}
	
?>