<?php

	function header_start($Title){
		
		header("Content-Type: text/html; charset=utf-8");
		
		if(!preg_match("/ldap_login\.php/", @$_SERVER['PHP_SELF'])){	// Don't validate a user on the login page (else user is stuck in endless loop)
			validate_user();		
		}
		
		echo "<!DOCTYPE html>\n";
		echo "<html>\n";
			echo "<head>\n";
				echo "<title>" . HTML_SITE_NAME . " - $Title</title>\n";
				echo "<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />\n";
				echo "<link href='" . PATH_CSS . "/layout.css' type='text/css' rel='stylesheet' />\n";
				echo "<link href='" . PATH_CSS . "/styles.css' type='text/css' rel='stylesheet' />\n";
				echo "<link href='" . PATH_CSS . "/messaging.css' type='text/css' rel='stylesheet' />\n";
				
				load_jquery(TRUE, TRUE);
				
				// Allow the user to remove messages from the DOM
				
				echo "<script type='text/javascript'>";
					echo "$(document).ready(function(){
								$('.close').live('click', function(){
									$(this).parent('div.notification').fadeOut('normal', function(){ 
										$(this).remove();		// Remove the message from the DOM
									});
								});						
							});";
				echo "</script>";
				
				// Skin the buttons
			
				echo "<script type='text/javascript'>";
					echo "$(document).ready(function(){
							   $('input:submit, input:button, button').button();
						  });";
				echo "</script>";
	}
	
	function load_jquery($AddjQuery, $AddUI = FALSE){
	
		// Loading the jQuery library more than once on the same page can cause issues
		
		if($AddjQuery || $AddUI){
			if($AddjQuery){ 
				echo "<script type='text/javascript' src='" . PATH_JS_JQUERY . "/" . JQUERY_VERSION . "'></script>\n"; 
			}			
			if($AddUI){    
				echo "<script type='text/javascript' src='" . PATH_JS_JQUERY . "/" . JQUERY_VERSION_UI . "'></script>\n"; 
				echo "<link href='" . PATH_JS_JQUERY . "/jquery-ui-1.8.23.custom.css' type='text/css' rel='stylesheet' />\n";			
			}
		}else{
			return FALSE;
		}
	}
	
	function datetime_picker_headers($AddjQuery = FALSE){
		load_jquery($AddjQuery);
		
		echo "<link rel='stylesheet' type='text/css' href='" . PATH_JS_ANYTIME  . "/anytime.css' />";
		echo "<script type='text/javascript' src='" . PATH_JS_ANYTIME  . "/anytime.js'></script>";
	}
	
	function multiselect_headers($AddjQuery = FALSE, $AddjQueryUI = FALSE){
		load_jquery($AddjQuery, $AddjQueryUI);
		
		echo "<link rel='stylesheet' type='text/css' href='" . PATH_JS_MULTISELECT  . "/jquery.multiselect.css' />\n";
		echo "<link rel='stylesheet' type='text/css' href='" . PATH_JS_MULTISELECT  . "/jquery.multiselect.filter.css' />\n";
		echo "<script type='text/javascript' src='" . PATH_JS_MULTISELECT  . "/jquery.multiselect.js'></script>\n";
		echo "<script type='text/javascript' src='" . PATH_JS_MULTISELECT  . "/jquery.multiselect.filter.js'></script>\n";
	}
	
	function custom_jquery_alert_boxes($AddjQuery = FALSE){
		load_jquery($AddjQuery);
		echo "<script type='text/javascript' src='" . PATH_JS_ALERTS . "/jquery.alerts.js" . "'></script>\n";
		echo "<link rel='stylesheet' media='screen,projection' type='text/css' href='" . PATH_JS_ALERTS . "/jquery.alerts.css" . "' />\n";
	}
	
	function tablesorter_headers($AddjQuery = FALSE){
		load_jquery($AddjQuery);
		echo "<script type='text/javascript' src='" . PATH_JS_TABLE_SORTER . "/jquery.tablesorter.min.js'></script>\n";
	}
	
	function special_symbol_replacement_headers($AddjQuery = FALSE){
		load_jquery($AddjQuery);
		echo "<script type='text/javascript' src='" . PATH_JS . "/replace_special_symbols.js'></script>\n";
	}	
	
	function tooltip_popup_headers($AddjQuery = FALSE){
		load_jquery($AddjQuery);
		
		echo "<script type='text/javascript' src='" . PATH_JS_TOOLTIP  . "/tooltip-1.2.5.js'></script>\n";
		echo "<script type='text/javascript' src='" . PATH_JS_TOOLTIP  . "/tooltip-slide-effect-1.2.5.js'></script>\n";
		echo "<script type='text/javascript' src='" . PATH_JS_TOOLTIP  . "/tooltip-dynamic-positioning-1.2.5.js'></script>\n";	
		echo "<link rel='stylesheet' media='screen,projection' type='text/css' href='" . PATH_JS_TOOLTIP . "/tooltips.css" . "' />\n";
	}
	
	function date_parser_headers(){
		echo "<script type='text/javascript' src='" . PATH_JS  . "/date.js'></script>\n";
	}
	
	function fancybox_headers($AddjQuery = FALSE){
		load_jquery($AddjQuery);
		
		echo "<script src='" . PATH_JS_FANCYBOX . "/jquery.fancybox.pack.js?v=2.0.6'></script>\n";	
		echo "<link href='" . PATH_JS_FANCYBOX . "/jquery.fancybox.css?v=2.0.6' media='screen' rel='stylesheet' />\n";
	}
	
	function uploadify_headers(){		
		echo "<script language='javascript' type='text/javascript' src='" . PATH_JS_UPLOADIFY . "/jquery.uploadify.v2.1.4.min.js'></script>";
		echo "<script language='javascript' type='text/javascript' src='" . PATH_JS_UPLOADIFY . "/swfobject.js'></script>";		
		echo "<link rel='stylesheet' type='text/css' href='" . PATH_JS_UPLOADIFY . "/uploadify.css' />";		
	}
	
	function scrollTo_headers($AddjQuery = FALSE){
		load_jquery($AddjQuery);
		
		echo "<script src='" . PATH_JS . "/jquery.scrollTo-1.4.3.1.js'></script>\n";	
	}
	
	function body_start($BodyOptions = NULL){
			echo "</head>\n";
			echo "<body $BodyOptions>\n";
				echo "<div id='wrapper'>\n";
					echo "<div id='header'>\n";
						echo "<a href='.'><img src='" . PATH_IMAGES . "/logo.png' alt='Verisign' class='logo' /></a>\n";
	}
	
	function navigation_start($Current = "home"){
						echo "<div id='topNav'>\n";
							echo "<span>\n";
								echo "<ul class='navigation'>\n";
								
									// Display the appropriate tabs
									
									if(!preg_match("/ldap_login\.php/", @$_SERVER['PHP_SELF']) && @$_COOKIE['username']){
									
										echo "<li class='navigation'><a class='divider " . ($Current == "home" ? "current" : NULL) . "' href='.'>Form Manager</a></li>\n";
										echo "<li class='navigation'><a class='divider " . ($Current == "audit" ? "current" : NULL) . "' href='audit_trail.php'>Audit Tracker</a></li>\n";
										echo "<li class='navigation'><a class='divider " . ($Current == "file" ? "current" : NULL) . "' href='file_viewer.php'>File Viewer</a></li>\n";
										echo "<li class='navigation'><a class='divider " . ($Current == "report" ? "current" : NULL) . "' href='reporting.php'>Reporting</a></li>\n";
										echo "<li class='navigation'><a class='divider " . ($Current == "template" ? "current" : NULL) . "' href='templates.php'>Templates</a></li>\n";
										echo "<li class='navigation'><a class='divider " . ($Current == "calendar" ? "current" : NULL) . "' href='calendar.php'>Calendar</a></li>\n";
										echo "<li class='navigation'><a class='divider " . ($Current == "security" ? "current" : NULL) . "' href='security_notification.php'>Security Notices</a></li>\n";

										if(is_admin(clean_sql_value($_COOKIE['user_id']))){
											echo "<li class='navigation'><a class='divider " . ($Current == "admin" ? "current" : NULL) . "' href='admin_menu.php'>Administrative Tools</a></li>\n";
											echo "<li class='navigation'><a class='divider " . ($Current == "form" ? "current" : NULL) . "' href='admin_form_manager.php'>Form Configuration</a></li>\n";
										}
										
										echo "<li class='navigation'><a class='" . ($Current == "logout" ? "current" : NULL) . "' href='logout.php'>Logout</a></li>\n";
										
									}else{
									
										echo "<li class='navigation'><a class='divider " . ($Current == "login" ? "current" : NULL) . "' href='.'>Login</a></li>\n";
										
									}
									
								echo "</ul>\n";			
							echo "</span>\n";
						echo "</div>\n";	// End topNav
					echo "</div>\n";	// End header
				
					echo "<div id='main_content'>\n";
					
					print_messages();
	}
	
	function footer_start(){						
					echo "</div>\n";	// End main_content
							
					echo "<div id='footer'>\n";
						echo "<div>&copy; <script type='text/javascript'>var d=new Date();document.write(d.getFullYear());</script> Verisign. All Rights Reserved.</div>\n";
					echo "</div>\n";	
					
				echo "</div>\n";	// End wrapper
				
			echo "</body>\n";
		echo "</html>\n";
	}
