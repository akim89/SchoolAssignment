<?php

	####################################################
	##                 ERROR HANDLING                 ##
	####################################################
		
	// Display on screen messages using SESSION data (requires CSS formatting)
	
	function print_messages($PreventLogWrite = FALSE){	
	
		$Types = array("success", "info", "tip", "warning", "error");
		
		foreach($Types as $Type){
			if(isset($_SESSION[$Type]) && !empty($_SESSION[$Type]) && is_array($_SESSION[$Type])){
				foreach($_SESSION[$Type] as $Message){	

					if($Type == "error"){
						$Color = "red";
					}elseif($Type == "warning"){
						$Color = "orange";
					}elseif($Type == "tip"){
						$Color = "orange";
					}elseif($Type == "info"){
						$Color = "blue";
					}elseif($Type == "success"){
						$Color = "green";
					}
					
					echo "<div class='notification $Type'><strong>" . strtoupper($Type) . "!</strong> $Message <img class='close' src='" . PATH_IMAGES . "/delete-$Color.png' /></div>";

					// Write message to the log file
					
					if(preg_match("/warning|error/", $Type) && !$PreventLogWrite){
						write_to_log(strtoupper($Type), $Message);
					}
				}			
				unset($_SESSION[$Type]);
			}			
		}
	}
	
	// Prints out a message now (does not add it to the SESSION array)
	
	function display_message($Type, $Message){
		if($Type == "error"){
			   $Color = "red";
		}elseif($Type == "warning"){
				$Color = "orange";
		}elseif($Type == "tip"){
				$Color = "orange";
		}elseif($Type == "info"){
				$Color = "blue";
		}elseif($Type == "success"){
				$Color = "green";
		}

		echo "<div class='notification $Type'><strong>" . strtoupper($Type) . "!</strong> $Message</div>";
	}
	
	// Add a message to the SESSION array
	
	function add_message($Type, $Message){
		$Types = array("success", "info", "tip", "warning", "error");
		if(in_array($Type, $Types)){
			$_SESSION[$Type][] = $Message;
		}else{
			$_SESSION['error'][] = "<strong>'$Type'</strong> is not a valid message type.";
		}
	}
	
	// Check to see if any messages exist (does not print out messages)
	
	function check_messages(){
		$Types = array("success", "info", "tip", "warning", "error");
		$Messages = 0;
		
		foreach($Types as $Type){
			if(@$_SESSION[$Type]){
				$Messages++;
			}
		}
		
		if($Messages == 0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	// Add a new message, substituing a value into the static message (Message must contain "[[place_holder]]")
	
	function message_substitution($MessageType, $Message, $ReplacementText, $Bold = FALSE){
		$ReplacementText = ($Bold) ? "<strong>" . $ReplacementText . "</strong>" : $ReplacementText;		
		add_message($MessageType, preg_replace('/\[.*\]/', $ReplacementText, $Message));
	}
	
	// Write application and SQL errors to a log file
	
	function write_to_log($MessageType, $Message){
		$Filename = DEFAULT_ERROR_LOG_FILE;

		$Date        = date('Y-m-d');
		$ScriptName  = basename($_SERVER['PHP_SELF']);
		$Timestamp   = date('Y-m-d H:i:s');
				
		if($FileHandle = @fopen($Filename . '_' . $Date, 'ab')){
			$Result = fwrite($FileHandle, $Timestamp . "\t" . ((@$_COOKIE['username']) ? $_COOKIE['username'] : "unknown_user") . "\t" . $MessageType . "\t(" . $ScriptName . ")\t" . preg_replace("/[\n\r]|\t/", " ", strip_tags($Message)) . "\r\n");
			fclose($FileHandle);
		}else{			
			add_message("error", "Can't open <i>" . $Filename . '_' . $Date . "</i>.");
			print_messages(TRUE);	// Avoid endless loop if can't open file	
		}
		
		// Cleanup old log files
		
		cleanup_log_files();
		
		return (@$Result) ? TRUE : FALSE;		
	}
	
	// Delete log files older than 7 days
	
	function cleanup_log_files(){
		$Directory  = PATH_LOGS;
	 
		if(!$DirHandle = @opendir($Directory)){
			return;
		}
	 
		while(FALSE !== ($Filename = readdir($DirHandle))){
			if($Filename != "." && $Filename != ".."){
				$Filename = $Directory . "/" . $Filename;

				if(@filemtime($Filename) < (time() - DEFAULT_LOG_RETENTION)){
					@unlink($Filename);
				}
			}
		}
	}
	
	####################################################
	##                 TIME RELATED                   ##
	####################################################
		
	// Verify a start date and time is before an end date and time
	// Timestamps must be in the format of YYYY-MM-DD HH:MM:SS

	function timeframe_check($StartTimestamp, $EndTimestamp){
		list($StartYear, $StartMonth, $StartDay, $StartHour, $StartMin) = sscanf($StartTimestamp, "%4d-%2d-%2d %2d:%2d");
		list($EndYear, $EndMonth, $EndDay, $EndHour, $EndMin)           = sscanf($EndTimestamp,   "%4d-%2d-%2d %2d:%2d");

		$Start = mktime($StartHour, $StartMin, 00, $StartMonth, $StartDay, $StartYear);
		$End   = mktime($EndHour, $EndMin, 00, $EndMonth, $EndDay, $EndYear);

		if($Start > $End){
			return FALSE;
		}else{
			return TRUE;
		}
	}
	
	// Return an array of time parts given a MySQL timestamp

	function timestamp_breakdown($Duration){
		if($Duration){
			$Duration = explode(" ", $Duration);

			$TimestampPieces['date'] = $Duration[0];
			$TimestampPieces['time'] = $Duration[1];

			$DateParts = explode("-", $TimestampPieces['date']);
			$TimeParts = explode(":", $TimestampPieces['time']);

			$TimestampPieces['year']  = $DateParts[0];
			$TimestampPieces['month'] = $DateParts[1];
			$TimestampPieces['day']   = $DateParts[2];

			$TimestampPieces['hour']  = $TimeParts[0];
			$TimestampPieces['min']   = $TimeParts[1];
			$TimestampPieces['sec']   = $TimeParts[2];
			return $TimestampPieces;
		}else{
			return FALSE;
		}
    }
	
	// Converts a UTC timestamp to an EST timestamp
	
	function convert_utc_to_est($UTCTimestamp){
		$Timestamp = new DateTime($UTCTimestamp, new DateTimeZone('UTC'));
		$Timestamp->setTimezone(new DateTimeZone('EST'));

		return $Timestamp->format('Y-m-d H:i:s');
	}
	
	// Converts a EST timestamp to an UTC timestamp
	
	function convert_est_to_utc($ESTTimestamp){
		$Timestamp = new DateTime($ESTTimestamp, new DateTimeZone('EST'));
		$Timestamp->setTimezone(new DateTimeZone('UTC'));

		return $Timestamp->format('Y-m-d H:i:s');
	}
	
	####################################################
	##               PAGE MANIPULATION                ##
	####################################################
	
	// Redirect to a given page
	
	function redirect($Page = "."){
		header("Location: $Page"); 
	}
	
	####################################################
	##                 MISCELLANEOUS                  ##
	####################################################
	
	// Convert an array to csv
	
	function array_to_csv($Array = NULL){
		if(is_array($Array)){
			@$CSV = implode(",", $Array);
			return $CSV;
		}else{
			return NULL;
		}
	}
	
	// Returns a shortened string with an ellipsis
	
	function shorten_string($String, $DesiredLength = 200, $Ellipsis = '...') {
		$Length = strlen($String);
		if ($Length > $DesiredLength) {
			$ShortString = substr($String, 0, strrpos(substr($String, 0, $DesiredLength), ' '));
			return rtrim($ShortString) . $Ellipsis;
		}else{
			return $String;
		}
	}
	
	// Print array's in an easy to read format
	
	function print_array($Array){
        echo "<pre style='font-size: 14px; font-family: arial,sans-serif;'>";
			print_r($Array);
        echo  "</pre>\n";
	}
	
	// Recusrively remove a directory contents (and optionally, the directory itself)

	function recursive_remove_directory($Directory, $Empty = FALSE){
		
		// If the path has a slash at the end we remove it here
		
		if(substr($Directory,-1) == '/'){
			$Directory = substr($Directory,0,-1);
		}

		// If the path is not valid or is not a directory
		
		if(!file_exists($Directory) || !is_dir($Directory)){			
			return FALSE;

		// If the path is not readable
		
		}elseif(!is_readable($Directory)){
			return FALSE;

		// If the path is readable
		
		}else{

			// Open the directory
			
			$Handle = opendir($Directory);

			// Scan through the items inside
			
			while(FALSE !== ($Item = readdir($Handle))){
				
				// If the filepointer is not the current directory or the parent directory
				
				if($Item != '.' && $Item != '..'){
					
					// Build the new path to delete
					
					$Path = $Directory . '/' . $Item;

					// If the new path is a directory call this function with the new path
					
					if(is_dir($Path)){

						recursive_remove_directory($Path);

					// If the new path is a file remove the file
					
					}else{
						unlink($Path);
					}
				}
			}
			
			// Close the directory
			
			closedir($Handle);

			// If the option to remove the directory is not set to true
			
			if($Empty == FALSE){
				
				// Try to delete the now empty directory
				
				if(!rmdir($Directory)){
					
					// Return false if not possible
					
					return FALSE;
				}
			}
			
			// Return success
			
			return TRUE;
		}
	}
	
	####################################################
	##                   CBO FORMS                    ##
	####################################################
	
	// Generate a list of possible field types
	
	function field_types(){
		$Types['date'] = "Date";
		$Types['dropdown'] = "Dropdown Menu";
		$Types['text'] = "Text Box";
		$Types['text_area'] = "Text Area";
		
		return $Types;
	}
	
	// Generate a list of possible auto-populate choices
	
	function auto_populate_choices(){
		$Options['used_bag'] = "Used Bag";
		$Options['label'] = "Label";
		$Options['site'] = "Site";
		$Options['shareholder'] = "Shareholder";
		$Options['vendor'] = "Vendor";
		$Options['function'] = "Function";
		$Options['model_number'] = "Model Number";
		$Options['box'] = "Box";
		$Options['function_type'] = "Function Type";
		$Options['escrow_location'] = "Escrow Location";
		$Options['serial'] = "Serial Number";
		$Options['rack_location'] = "Rack Location";
		
		
		asort($Options);
		return $Options;
	}
	
	// Unzip a .docx file
	
	function unzip_docx($Filename){
		$RootDirectory   = PATH_ROOT_DIR . "/" . PATH_WWW;
		$SourceDirectory = $RootDirectory . "/" . PATH_FORMS;
		$TempDirectory   = $RootDirectory . "/" . PATH_FORMS_TEMP;
		
		// Verify that the form exists
		
		if(file_exists($SourceDirectory . "/" . $Filename) && filesize($SourceDirectory . "/" . $Filename) > 0){
		
			// Make a temp directory to unzip things into (or cleanup the existing directory)

			(!is_dir($TempDirectory)) ? mkdir($TempDirectory) : recursive_remove_directory($TempDirectory, TRUE);
			
			// Unzip everything

			return (shell_exec("unzip $SourceDirectory/$Filename -d $TempDirectory") ? TRUE : FALSE);
			
		}else{
			return FALSE;
		}		
	}
	
	// Zip up an uncompressed .docx file
	
	function zip_docx($Filename){
		$RootDirectory   = PATH_ROOT_DIR . "/" . PATH_WWW;
		$OutputDirectory = PATH_ROOT_DIR . "/" . PATH_WWW . "/" . PATH_FORMS_COMPLETED; 	
		$TempDirectory   = $RootDirectory . "/" . PATH_FORMS_TEMP;		
		
		$FilesToZip = array("_rels", "docProps", "word", "[Content_Types].xml");
		$Command = "cd $TempDirectory && zip -r $OutputDirectory/$Filename " . implode(" ", $FilesToZip);

		if(shell_exec($Command) !== NULL){   // "echo" this line to see command line output
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	// Generate a list of avaliable picklists
	
	function dropdown_options(){		
		$Options[DB_TABLE_ACCESS_POOL_TYPE] = "Access Pool Type";
		$Options[DB_TABLE_BOXES] = "Boxes";
		$Options[DB_TABLE_CABINETS] = "Cabinets";
		$Options[DB_TABLE_DESTRUCTION_METHODS] = "Destruction Methods";
		$Options[DB_TABLE_ENVIRONMENTS] = "Environments";
		$Options[DB_TABLE_ESCROW_LOCATIONS] = "Escrow Locations";
		$Options[DB_TABLE_ESCROW_LOCATIONS . "_traka"] = "Escrow Locations (Traka)";
		$Options[DB_TABLE_ESCROW_LOCATIONS . "_not_traka"] = "Escrow Locations (Not Traka)";
		$Options[DB_TABLE_ESCROW_LOCATION_TYPES] = "Escrow Location Types";
		$Options[DB_TABLE_PRODUCTS] = "Products";		
		$Options[DB_TABLE_SHAREHOLDERS] = "Shareholders (All)";
		$Options[DB_TABLE_SHAREHOLDERS . "_not_sysadmin"] = "Shareholders (Not Sysadmin)";
		$Options[DB_TABLE_SHAREHOLDERS . "_function"] = "Shareholders (w/ Function)";
		$Options[DB_TABLE_SHAREHOLDERS . "_access"] = "Shareholders (Access)";
		$Options[DB_TABLE_SHAREHOLDERS . "_physical_key"] = "Shareholders (Physical Key)";
		$Options[DB_TABLE_SHAREHOLDERS . "_cbo"] = "Shareholders (CBO)";
		$Options[DB_TABLE_SHAREHOLDERS . "_sysadmin"] = "Shareholders (Sysadmin)";
		$Options[DB_TABLE_SITES] = "Sites";
		$Options[DB_TABLE_VENDORS] = "Vendors";		
		$Options[DB_TABLE_EQUIP_TYPES] = "Equipment Types";
		$Options[DB_TABLE_FUNCTIONS] = "Functions (All)";
		$Options[DB_TABLE_FUNCTIONS . "_access"] = "Functions (Access)";
		$Options[DB_TABLE_FUNCTIONS . "_physical_key"] = "Functions (Physical Key)";
		$Options[DB_TABLE_FUNCTION_TYPES] = "Function Type";
		$Options[DB_TABLE_KEY_TYPES] = "Key Types";
		$Options[DB_TABLE_MEDIA_TYPES] = "Media Types";
		$Options[DB_TABLE_KEYS] = "Physical Keys";
		$Options[DB_TABLE_KEYS . "_distributed"] = "Physical Keys (Distributed)";
		$Options[DB_TABLE_KEYS . "_escrowed"] = "Physical Keys (Escrowed)";
		$Options[DB_TABLE_KEYS . "_traka"] = "Physical Keys (Traka)";
		$Options[DB_TABLE_KEYS . "_traka_distributed"] = "Physical Keys (Traka - Distributed)";
		$Options[DB_TABLE_KEYS . "_traka_escrowed"] = "Physical Keys (Traka - Escrowed)";
		$Options[DB_TABLE_KEYS . "_not_traka"] = "Physical Keys (Not Traka)";
		$Options[DB_TABLE_KEYS . "_not_traka_distributed"] = "Physical Keys (Not Traka - Distributed)";
		$Options[DB_TABLE_KEYS . "_not_traka_escrowed"] = "Physical Keys (Not Traka - Escrowed)";
		$Options[DB_TABLE_PHYSICAL_KEY_TYPES] = "Physical Key Types";
		$Options[DB_TABLE_TAMPER_EVIDENT_BAGS] = "Tamper Evident Bags";		// Can be "new" OR "used" (depends if auto-populate value is set to "Used Bag")
		$Options[DB_TABLE_EQUIP] = "Equipment";
		$Options[DB_TABLE_EQUIP . "_escrowed"] = "Equipment (Escrowed)";
		$Options[DB_TABLE_EQUIP . "_non_escrowed"] = "Equipment (Non-Escrowed)";
		$Options[DB_TABLE_SUPPORT_CONTRACTS] = "Support Contracts";
		$Options[DB_TABLE_SHARE_TYPES] = "Share Types";
		$Options[DB_TABLE_SHARES] = "Shares (All)";
		$Options[DB_TABLE_SHARES . "_distributed"] = "Shares (Distributed)";
		$Options[DB_TABLE_SHARES . "_escrowed"] = "Shares (Escrowed)";
		$Options['password'] = "Passwords";
		$Options[DB_TABLE_TAMPER_EVIDENT_BAGS . "_all"] = "Tamper Evident Bags (All)";	// Contains both "new" AND "used" (used primarily with "outer bag" fields)
		$Options[DB_TABLE_EQUIP . "_hsm"] = "HSMs";
		$Options[DB_TABLE_EQUIP . "_hsm_escrowed"] = "HSMs (Escrowed)";
		$Options[DB_TABLE_EQUIP . "_hsm_non_escrowed"] = "HSMs (Non-Escrowed)";
		$Options[DB_TABLE_QUARTERS] = "Quarters";
		$Options['numbers'] = "Number Range";
		$Options[DB_TABLE_EQUIP_VERSIONS] = "Equipment Versions";
		$Options[DB_TABLE_MODEL_TYPES] = "Model Types";
		
		asort($Options);
		return $Options;
	}
	
	// Convert a "dropdown option" into an array of values
	
	function lookup_dropdown_menu($Menu, $Option = NULL){	
		if($Menu == DB_TABLE_BOXES){
			return list_boxes();
		}elseif($Menu == DB_TABLE_DESTRUCTION_METHODS){
			return list_destruction_methods();
		}elseif($Menu == DB_TABLE_ACCESS_POOL_TYPE){
			return list_access_pool_types();
		}elseif($Menu == DB_TABLE_CABINETS){
			return list_cabinets();
		}elseif($Menu == DB_TABLE_ENVIRONMENTS){
			return list_environments();
		}elseif($Menu == DB_TABLE_ESCROW_LOCATIONS){
			return list_escrow_locations();	
		}elseif($Menu == DB_TABLE_ESCROW_LOCATIONS . "_traka"){
			return list_escrow_locations_traka();	
		}elseif($Menu == DB_TABLE_ESCROW_LOCATIONS . "_not_traka"){
			return list_escrow_locations_not_traka();
		}elseif($Menu == DB_TABLE_ESCROW_LOCATION_TYPES){
			return list_escrow_location_types();
		}elseif($Menu == DB_TABLE_SHARES){
			return list_shares();
		}elseif($Menu == DB_TABLE_SHAREHOLDERS){
			return list_shareholders();
		}elseif($Menu == DB_TABLE_SHAREHOLDERS . "_not_sysadmin"){
			return list_non_sysadmin_shareholders();
		}elseif($Menu == DB_TABLE_SHAREHOLDERS . "_physical_key"){	
			return list_physical_key_shareholders();
		}elseif($Menu == DB_TABLE_SHAREHOLDERS . "_access"){	
			return list_access_shareholders();
		}elseif($Menu == DB_TABLE_SHAREHOLDERS . "_cbo"){	
			return list_cbo_shareholders();
		}elseif($Menu == DB_TABLE_SHAREHOLDERS . "_function"){
			return list_shareholders_with_function();
		}elseif($Menu == DB_TABLE_SHAREHOLDERS . "_sysadmin"){
			return list_sysadmin_shareholders();
		}elseif($Menu == DB_TABLE_SITES){
			return list_sites();
		}elseif($Menu == DB_TABLE_VENDORS){
			return list_vendors();
		}elseif($Menu == DB_TABLE_USERS){
			return list_users();
		}elseif($Menu == DB_TABLE_EQUIP_TYPES){
			return list_equipment_types();
		}elseif($Menu == "equipment_status"){
			return array("Online" => "Online", "Offline" => "Offline", "Destroyed" => "Destroyed");	
		}elseif($Menu == DB_TABLE_FUNCTIONS){
			return list_functions();
		}elseif($Menu == DB_TABLE_FUNCTIONS . "_access"){
			return list_access_functions();
		}elseif($Menu == DB_TABLE_FUNCTIONS . "_physical_key"){
			return list_physical_key_functions();
		}elseif($Menu == DB_TABLE_FUNCTION_TYPES){
			return list_function_types();
		}elseif($Menu == DB_TABLE_KEY_TYPES){
			return list_key_types();
		}elseif($Menu == DB_TABLE_MEDIA_TYPES){
			return list_media_types();
		}elseif($Menu == "password"){
			return list_passwords();	
		}elseif($Menu == DB_TABLE_KEYS){
			return list_physical_keys();
		}elseif($Menu == DB_TABLE_KEYS . "_distributed"){
			return list_distributed_physical_keys();
		}elseif($Menu == DB_TABLE_KEYS . "_escrowed"){
			return list_escrowed_physical_keys();
		}elseif($Menu == DB_TABLE_KEYS . "_traka"){
			return list_physical_keys_traka();
		}elseif($Menu == DB_TABLE_KEYS . "_traka_distributed"){
			return list_distributed_physical_keys_traka();
		}elseif($Menu == DB_TABLE_KEYS . "_traka_escrowed"){
			return list_escrowed_physical_keys_traka();
		}elseif($Menu == DB_TABLE_KEYS . "_not_traka"){
			return list_physical_keys_not_traka();
		}elseif($Menu == DB_TABLE_KEYS . "_not_traka_distributed"){
			return list_distributed_physical_keys_not_traka();
		}elseif($Menu == DB_TABLE_KEYS . "_not_traka_escrowed"){
			return list_escrowed_physical_keys_not_traka();
		}elseif($Menu == DB_TABLE_PHYSICAL_KEY_TYPES){
			return list_physical_key_types();
		}elseif($Menu == DB_TABLE_PRODUCTS){
			return list_products();
		}elseif($Menu == DB_TABLE_TAMPER_EVIDENT_BAGS){
			if($Option == "used_bag"){
				return list_used_tamper_evident_bags();	// used_bags = 1
			}else{
				return list_tamper_evident_bags();	// used_bags = 0
			}
		}elseif($Menu == DB_TABLE_TAMPER_EVIDENT_BAGS . "_all"){
			return list_all_tamper_evident_bags();	// used_bags = 0|1
		}elseif($Menu == DB_TABLE_EQUIP){
			return list_equipment();
		}elseif($Menu == DB_TABLE_EQUIP . "_escrowed"){
			return list_escrowed_equipment();
		}elseif($Menu == DB_TABLE_EQUIP . "_non_escrowed"){
			return list_non_escrowed_equipment();			
		}elseif($Menu == DB_TABLE_EQUIP . "_hsm"){
			return list_hsms();
		}elseif($Menu == DB_TABLE_EQUIP . "_hsm_escrowed"){
			return list_escrowed_hsms();
		}elseif($Menu == DB_TABLE_EQUIP . "_hsm_non_escrowed"){
			return list_non_escrowed_hsms();			
		}elseif($Menu == DB_TABLE_SHARE_TYPES){
			return list_share_types();
		}elseif($Menu == DB_TABLE_SUPPORT_CONTRACTS){
			return list_support_contracts();
		}elseif($Menu == DB_TABLE_ROLES){
			return list_roles();
		}elseif($Menu == DB_TABLE_SHARES . "_distributed"){
			return list_distributed_shares();
		}elseif($Menu == DB_TABLE_SHARES . "_escrowed"){			
			return list_shares_in_escrow();
		}elseif($Menu == DB_TABLE_QUARTERS){
			return list_quarters();
		}elseif($Menu == DB_TABLE_EQUIP_VERSIONS){
			return list_equipment_versions();
		}elseif($Menu == DB_TABLE_MODEL_TYPES){
			return list_model_types();
		}elseif($Menu == 'numbers'){
			$Numbers = range(1, 50);
			array_unshift($Numbers, "phoney");	// Re-key array starting at 1
			unset($Numbers[0]);
			return $Numbers;
		}else{
			return FALSE;
		}
	}
	
	// Lookup the value of a dropdown menu given an ID
	
	function find_dropdown_value($DropdownMenu, $ID){
		if($DropdownMenu == DB_TABLE_BOXES){
			return lookup_box($ID);
		}elseif($DropdownMenu == DB_TABLE_ACCESS_POOL_TYPE){
			return lookup_access_pool_type($ID);
		}elseif($DropdownMenu == DB_TABLE_CABINETS){
			return lookup_cabinet($ID);
		}elseif($DropdownMenu == DB_TABLE_DESTRUCTION_METHODS){
			return lookup_destruction_method($ID);
		}elseif($DropdownMenu == DB_TABLE_ENVIRONMENTS){
			return lookup_environment($ID);			
		}elseif($DropdownMenu == DB_TABLE_FUNCTION_TYPES){
			return lookup_function_type($ID);
		}elseif(preg_match('/^(' . DB_TABLE_ESCROW_LOCATIONS . '|' . DB_TABLE_ESCROW_LOCATIONS . '_traka|' . DB_TABLE_ESCROW_LOCATIONS . '_not_traka)$/', $DropdownMenu)){
			return lookup_escrow_location($ID);
		}elseif($DropdownMenu == DB_TABLE_ESCROW_LOCATION_TYPES){
			return lookup_escrow_location_types($ID);
		}elseif(preg_match('/^(' . DB_TABLE_SHARES . '|password|' . DB_TABLE_SHARES . '_distributed|' . DB_TABLE_SHARES . '_escrowed)$/', $DropdownMenu)){ 
			return lookup_share($ID);
		}elseif(preg_match('/^(' . DB_TABLE_SHAREHOLDERS . '|' . DB_TABLE_SHAREHOLDERS . '_physical_key|' . DB_TABLE_SHAREHOLDERS . '_access|' . DB_TABLE_SHAREHOLDERS . '_cbo|' . DB_TABLE_SHAREHOLDERS . '_function|' . DB_TABLE_SHAREHOLDERS . '_sysadmin|' . DB_TABLE_SHAREHOLDERS . '_not_sysadmin)$/', $DropdownMenu)){
			return lookup_shareholder($ID);
		}elseif($DropdownMenu == DB_TABLE_SITES){
			return lookup_site($ID);
		}elseif($DropdownMenu == DB_TABLE_VENDORS){
			return lookup_vendor($ID);
		}elseif($DropdownMenu == DB_TABLE_USERS){
			return lookup_user($ID);			
		}elseif($DropdownMenu == DB_TABLE_EQUIP_TYPES){
			return lookup_equipment_type($ID);	
		}elseif(preg_match('/^(' . DB_TABLE_FUNCTIONS . '|' . DB_TABLE_FUNCTIONS . '_physical_key|' . DB_TABLE_FUNCTIONS . '_access)$/', $DropdownMenu)){
			return lookup_function($ID);
		}elseif($DropdownMenu == DB_TABLE_KEY_TYPES){
			return lookup_key_type($ID);
		}elseif($DropdownMenu == DB_TABLE_MEDIA_TYPES){
			return lookup_media_type($ID);
		}elseif(preg_match('/^(' . DB_TABLE_KEYS . '|' . DB_TABLE_KEYS . '_escrowed|' . DB_TABLE_KEYS . '_distributed|' . DB_TABLE_KEYS . '_traka|' . DB_TABLE_KEYS . '_traka_distributed|' . DB_TABLE_KEYS . '_traka_escrowed|' . DB_TABLE_KEYS . '_not_traka|' . DB_TABLE_KEYS . '_not_traka_distributed|' . DB_TABLE_KEYS . '_not_traka_escrowed)$/', $DropdownMenu)){
			return lookup_physical_key($ID);
		}elseif($DropdownMenu == DB_TABLE_PHYSICAL_KEY_TYPES){
			return lookup_physical_key_type($ID);
		}elseif($DropdownMenu == DB_TABLE_PRODUCTS){
			return lookup_product($ID);
		}elseif($DropdownMenu == DB_TABLE_TAMPER_EVIDENT_BAGS || $DropdownMenu == DB_TABLE_TAMPER_EVIDENT_BAGS . "_all"){
			return lookup_tamper_evident_bag($ID);
		}elseif(preg_match('/^(' . DB_TABLE_EQUIP . '|' . DB_TABLE_EQUIP . '_escrowed|' . DB_TABLE_EQUIP . '_non_escrowed|' . DB_TABLE_EQUIP . '_hsm|' . DB_TABLE_EQUIP . '_hsm_escrowed|' . DB_TABLE_EQUIP . '_hsm_non_escrowed)$/', $DropdownMenu)){
			return lookup_equipment($ID);
		}elseif($DropdownMenu == DB_TABLE_SHARE_TYPES){
			return lookup_share_type($ID);
		}elseif($DropdownMenu == DB_TABLE_SUPPORT_CONTRACTS){
			return lookup_support_contract($ID);
		}elseif($DropdownMenu == DB_TABLE_QUARTERS){	
			return lookup_quarter($ID);
		}elseif($DropdownMenu == DB_TABLE_EQUIP_VERSIONS){	
			return lookup_equipment_version($ID);
		}elseif($DropdownMenu == DB_TABLE_MODEL_TYPES){	
			return lookup_model_type($ID);
		}elseif($DropdownMenu == 'numbers'){
			return $ID;
		}else{
			return FALSE;
		}	
	}	
	
	####################################################
	##                 MISCELLANEOUS                  ##
	####################################################
	
	// Function to pad serial numbers with leading zeros 
	
	function pad_serial($Value, $Length, $PadString = '0', $Type = STR_PAD_LEFT){
		return str_pad($Value, $Length, $PadString, $Type);
	}
	
	// Function to determine the MIME type of a given file
	
	function returnMIMEType($Filename){

		$FileParts = pathinfo($Filename);
		$Extension = strtolower($FileParts['extension']);

		switch(strtolower($Extension)){
			case "js" :
				return "application/x-javascript";

			case "json" :
				return "application/json";

			case "jpg" :
			case "jpeg" :
			case "jpe" :
				return "image/jpg";

			case "png" :
			case "gif" :
			case "bmp" :
			case "tiff" :
				return "image/" . $Extension;

			case "css" :
				return "text/css";

			case "xml" :
				return "application/xml";

			case "doc" :
			case "docx" :
				return "application/msword";

			case "xls" :
			case "xlt" :
			case "xlm" :
			case "xld" :
			case "xla" :
			case "xlc" :
			case "xlw" :
			case "xll" :
				return "application/vnd.ms-excel";

			case "ppt" :
			case "pps" :
				return "application/vnd.ms-powerpoint";

			case "rtf" :
				return "application/rtf";

			case "pdf" :
				return "application/pdf";

			case "html" :
			case "htm" :
			case "php" :
				return "text/html";

			case "txt" :
				return "text/plain";

			case "mpeg" :
			case "mpg" :
			case "mpe" :
				return "video/mpeg";

			case "mp3" :
				return "audio/mpeg3";

			case "wav" :
				return "audio/wav";

			case "aiff" :
			case "aif" :
				return "audio/aiff";

			case "avi" :
				return "video/msvideo";

			case "wmv" :
				return "video/x-ms-wmv";

			case "mov" :
				return "video/quicktime";

			case "zip" :
				return "application/zip";

			case "tar" :
				return "application/x-tar";

			case "swf" :
				return "application/x-shockwave-flash";

			default :
				if(function_exists("mime_content_type")){
					$Extension = mime_content_type($Filename);
				}

				return "unknown/" . $Extension;
		}
	}

	// Sort a multi-dimensional array by a given key

	function multidimensional_array_sort(array &$aArray, $sSortKey){
		$sorter = array();
		$return = array();
		reset($aArray);

		foreach($aArray as $key => $value){
			$sorter[$key] = $value[$sSortKey];
		}

		asort($sorter);
		foreach($sorter as $key => $value){
			$return[$key] = $aArray[$key];
		}

		$aArray = $return;
	}

	// Create an array of time ranges between hours
	
	function time_range($MinHour = 0, $MaxHour = 86400, $Step = 3600, $DisplayFormat = "g:i A", $KeyFormat = "H:i:s"){
		$Times = array();
		foreach(range($MinHour, $MaxHour, $Step) as $Increment){
			$Increment = gmdate($KeyFormat, $Increment);
			list($hour, $minutes) = explode(':', $Increment);
			$Date = new DateTime($hour . ':' . $minutes);
			$Times[(string) $Increment] = $Date->format($DisplayFormat);
		}
		return $Times;
	}

	// Autoload classes
	
	function autoload_classes(){
		spl_autoload_register(function($Class){	
			$Filename = $Class . '.php';
			$BasePath = PATH_FRAMEWORK_CLASSES;
			
			// For scripts in root directory
			
			if(file_exists($BasePath . '/' . $Filename)){
				require_once($BasePath . '/' . $Filename);	
			}
			if(file_exists($BasePath . '/third-party/' . $Filename)){
				require_once($BasePath . '/third-party/' . $Filename);	
			}
			if(file_exists($BasePath . '/calendar/' . $Filename)){
				require_once($BasePath . '/calendar/' . $Filename);	
			}
			
			// For scripts in sub-directories (AJAX)
			
			if(file_exists('../' . $BasePath . '/' . $Filename)){
				require_once('../' . $BasePath . '/' . $Filename);	
			}
			if(file_exists('../' . $BasePath . '/third-party/' . $Filename)){
				require_once('../' . $BasePath . '/third-party/' . $Filename);	
			}
			if(file_exists('../' . $BasePath . '/calendar/' . $Filename)){
				require_once('../' . $BasePath . '/calendar/' . $Filename);	
			}
		});
	}

?>
