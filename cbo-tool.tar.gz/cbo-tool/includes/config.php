<?php

	// Include the credentials

	include('.secrets.php');

	// Server path constatns
	
	define('PATH_ROOT_DIR',                      '/app/http/html');								// EDIT //
	define('PATH_SERVER',                        'http://' . @$_SERVER['HTTP_HOST']);				// EDIT //		
	define('PATH_WWW',                           'cbo');										// EDIT //
	define('PATH_LOGS',                          PATH_ROOT_DIR . '/' . PATH_WWW . '/logs');
	define('PATH_INCLUDE',                       'includes');
	define('PATH_JS',                            'js');
	define('PATH_CSS',                           'css');
	define('PATH_IMAGES',                        'images');
	define('PATH_FILE_TYPE_ICONS',               PATH_IMAGES . '/file_type_icons');
	define('PATH_AJAX',                          'ajax');
	define('PATH_UPLOADS',                       'uploads');
	define('PATH_TEMPLATES',                     'templates');
	define('PATH_FORMS',                         'forms');
        define('PATH_AUTOFORMS',                     'autoforms');
	define('PATH_FORMS_TEMP',                    PATH_FORMS . '/temp');
	define('PATH_FORMS_DELETED',                 PATH_FORMS . '/deleted');
	define('PATH_FORMS_COMPLETED',               PATH_FORMS . '/completed');
	define('PATH_FORMS_SIGNED',                  PATH_FORMS . '/signed');
	define('PATH_FORMS_SIGNED_UNMAPPED',         PATH_FORMS_SIGNED . '/unmapped');
	define('PATH_JS_JQUERY',                     PATH_JS . '/jquery');
	define('PATH_JS_ANYTIME',                    PATH_JS . '/anytime');
	define('PATH_JS_MULTISELECT',                PATH_JS . '/multiselect');
	define('PATH_JS_ALERTS',                     PATH_JS . '/jquery_alerts');
	define('PATH_JS_TABLE_SORTER',               PATH_JS . '/tablesorter');
	define('PATH_JS_TOOLTIP',                    PATH_JS . '/tooltip');
	define('PATH_JS_FANCYBOX',                   PATH_JS . '/fancyBox/source');
	define('PATH_JS_UPLOADIFY',                  PATH_JS . '/uploadify');	
	define('PATH_DB_INSTALL_SCRIPTS',            'db_install_scripts');	
	define('PATH_DB_INSTALL_SCRIPTS_RUN_LAST',   PATH_DB_INSTALL_SCRIPTS . '/run_last');	
	define('PATH_FRAMEWORK',                     '../framework');	
	define('PATH_FRAMEWORK_CLASSES',             PATH_FRAMEWORK . '/classes');	
	define('PATH_FRAMEWORK_CALENDAR_CSS',        PATH_FRAMEWORK . '/css/calendar');	
	define('PATH_FRAMEWORK_LANGUAGE',            PATH_FRAMEWORK . '/lang');	

	// Uploadify settings
	
	define('UPLOADIFY_FILESIZE',               5 * 1048576);					// 5 MBs
	
	// Error hanlding
	
	define('ERRORS_SQL',                        1);		// 1 = DB errors on screen, 2 = Generic DB errors on screen (Actual DB errors logged to file)
	define('DEFAULT_LOG_RETENTION',             60 * 60 * 24 * 7);		// Retain logs for 7 days
	define('DEFAULT_ERROR_LOG_FILE',            PATH_LOGS . '/error.log');
		
	// Database info
	
	define('DB_HOST',                           'localhost');
	define('DB_BASE',                           'cbo');
	define('DB_USER',                           $GLOBAL_DB_USERNAME);
	define('DB_PASS',                           $GLOBAL_DB_PASSWORD);
	
	// Database tables
	
	define('DB_TABLE_ACCESS_POOL_TYPE',                   'access_pool_type');
	define('DB_TABLE_ATTACHMENTS',                        'attachment');
	define('DB_TABLE_AUDIT_BOXES',                        'audit_box');
	define('DB_TABLE_AUDIT_EQUIP',                        'audit_equipment');
	define('DB_TABLE_AUDIT_KEYS',                         'audit_physical_key');
	define('DB_TABLE_AUDIT_SHARES',                       'audit_share');
	define('DB_TABLE_AUDIT_SHAREHOLDERS',                 'audit_shareholder');
	define('DB_TABLE_BOXES',                              'box');
	define('DB_TABLE_BOX_SNAPSHOT',                       'box_snapshot');
	define('DB_TABLE_BOX_SNAPSHOT_CONTENTS',              'box_snapshot_contents');
	define('DB_TABLE_CABINETS',                           'cabinet');
	define('DB_TABLE_DBLOG',                              'dblog');
	define('DB_TABLE_DESTRUCTION_METHODS',                'destruction_method');
	define('DB_TABLE_ENVIRONMENTS',                       'environment');
	define('DB_TABLE_EMAIL_TEMPLATES',                    'email_template');
	define('DB_TABLE_EQUIP',                              'equipment');
	define('DB_TABLE_EQUIP_ATTACHMENTS',                  'equipment_attachment');
	define('DB_TABLE_EQUIP_RESTARTS',                     'equipment_restart');
	define('DB_TABLE_EQUIP_TYPES',                        'equipment_type');
	define('DB_TABLE_EQUIP_VERSIONS',                     'equipment_version');
	define('DB_TABLE_ESCROW_LOCATIONS',                   'escrow_location');
	define('DB_TABLE_ESCROW_LOCATION_TYPES',              'escrow_location_type');
	define('DB_TABLE_EVENTS',                             'event');
	define('DB_TABLE_EVENT_PRODUCTS',                     'event_product');
	define('DB_TABLE_EVENT_SCHEDULE',                     'event_email_schedule');
	define('DB_TABLE_EVENT_SHAREHOLDERS',                 'event_shareholder');
	define('DB_TABLE_FORMS',                              'form');
	define('DB_TABLE_FORM_LAYOUT',                        'form_layout');
	define('DB_TABLE_FORM_ROLES',                         'form_roles');
	define('DB_TABLE_FORM_STATUSES',                      'form_statuses');
	define('DB_TABLE_FUNCTIONS',                          'function');
	define('DB_TABLE_FUNCTION_TYPES',                     'function_type');
	define('DB_TABLE_KEY_TYPES',                          'key_type');
	define('DB_TABLE_MEDIA_TYPES',                        'media_type');
	define('DB_TABLE_MODEL_TYPES',                        'model_type');
	define('DB_TABLE_KEYS',                               'physical_key');
	define('DB_TABLE_PHYSICAL_KEY_TYPES',                 'physical_key_type');
	define('DB_TABLE_PRODUCTS',                           'product');
	define('DB_TABLE_QUARTERS',                           'quarter');
	define('DB_TABLE_ROLES',                              'role');
	define('DB_TABLE_SECURITY_NOTIFICATIONS',             'security_notification');
	define('DB_TABLE_SECURITY_NOTIFICATION_TYPES',        'security_notification_type');
	define('DB_TABLE_SHARES',                             'share');
	define('DB_TABLE_SHARE_TYPES',                        'share_type');
	define('DB_TABLE_SHAREHOLDERS',                       'shareholder');
	define('DB_TABLE_SHAREHOLDER_BLACKLIST',              'shareholder_blacklist');
	define('DB_TABLE_SITES',                              'site');
	define('DB_TABLE_SUPPORT_CONTRACTS',                  'support_contract');
	define('DB_TABLE_TAMPER_EVIDENT_BAGS',                'tamper_evident_bag');
	define('DB_TABLE_TOKENS',                             'token');
	define('DB_TABLE_USERS',                              'user');	
	define('DB_TABLE_USER_ACL',                           'user_acl');	
	define('DB_TABLE_VENDORS',                            'vendor');
	define('DB_TABLE_VENDOR_ATTACHMENTS',                 'vendor_attachment');
	define('DB_TABLE_VENDOR_CONTACTS',                    'vendor_contact');
	define('DB_TABLE_WORK_LOCATIONS',                     'work_location');
	
	define('DB_TABLE_FORM_EQUIP_COURIER',                      'form_equip_courier_attestation');
	define('DB_TABLE_FORM_EQUIP_COURIER_ITEMS',                'form_equip_courier_attestation_items');
	define('DB_TABLE_FORM_EQUIP_ESCROW',                       'form_equip_escrow_attestation');
	define('DB_TABLE_FORM_EQUIP_OUT_OF_BAND',                  'form_equip_out_of_band_verification_attestation');
	define('DB_TABLE_FORM_EQUIP_REBAG',                        'form_equip_rebag_attestation');
	define('DB_TABLE_FORM_EQUIP_RELOCATION',                   'form_equip_relocation_attestation');
	define('DB_TABLE_FORM_HSM_ACCEPTANCE_TEST',                'form_hsm_acceptance_test_attestation');
	define('DB_TABLE_FORM_HSM_ACTIVATION',                     'form_hsm_activation_attestation');
	define('DB_TABLE_FORM_HSM_COURIER',                        'form_hsm_courier_attestation');
	define('DB_TABLE_FORM_HSM_COURIER_ITEMS',                  'form_hsm_courier_attestation_items');
	define('DB_TABLE_FORM_HSM_DEACTIVATION',                   'form_hsm_deactivation_attestation');
	define('DB_TABLE_FORM_HSM_DESTRUCTION',                    'form_hsm_destruction_attestation');
	define('DB_TABLE_FORM_HSM_OUT_OF_BAND',                    'form_hsm_out_of_band_verification_attestation');
	define('DB_TABLE_FORM_HSM_OUT_OF_BAND_ITEMS',              'form_hsm_out_of_band_verification_attestation_items');
	define('DB_TABLE_FORM_HSM_ESCROW',                         'form_hsm_escrow_attestation');
	define('DB_TABLE_FORM_HSM_REACTIVATION',                   'form_hsm_reactivation_attestation');
	define('DB_TABLE_FORM_HSM_REBAG',                          'form_hsm_rebag_attestation');
	define('DB_TABLE_FORM_HSM_RELABEL',                        'form_hsm_relabel_attestation');
	define('DB_TABLE_FORM_HSM_RELOCATION',                     'form_hsm_relocation_attestation');
	define('DB_TABLE_FORM_KSR_RECEIPT',                        'form_ksr_receipt_attestation');
	define('DB_TABLE_FORM_LOCK_REPAIR',                        'form_lock_repair_attestation');
	define('DB_TABLE_FORM_PARTITION_PASSWORD_CREATION',        'form_partition_password_creation_attestation');
	define('DB_TABLE_FORM_KEY_COURIER',                        'form_physical_key_courier_attestation');
	define('DB_TABLE_FORM_KEY_COURIER_ITEMS',                  'form_physical_key_courier_attestation_items');
	define('DB_TABLE_FORM_KEY_DISTRIBUTION',                   'form_physical_key_distribution_attestation');
	define('DB_TABLE_FORM_KEY_ESCROW',                         'form_physical_key_escrow_attestation');
	define('DB_TABLE_FORM_KEY_REBAG',                          'form_physical_key_rebag_attestation');
	define('DB_TABLE_FORM_KEY_RELOCATION',                     'form_physical_key_relocation_attestation');
	define('DB_TABLE_FORM_KEY_TRANSFER',                       'form_physical_key_transfer_attestation');
	define('DB_TABLE_FORM_KEY_TRAKA_ASSIGNMENT',               'form_physical_key_traka_access_assignment_attestation');
	define('DB_TABLE_FORM_KEY_TRAKA_REVOCATION',               'form_physical_key_traka_access_revocation_attestation');
	define('DB_TABLE_FORM_ROOT_KEY_SIGNING',                   'form_root_key_signing_ceremony_attestation');
	define('DB_TABLE_FORM_SAFE_CHANGE',                        'form_safe_combo_change_attestation');
	define('DB_TABLE_FORM_SAFE_COMBO_DISTRIBUTION',            'form_safe_combo_distribution_attestation');
	define('DB_TABLE_FORM_SAFE_DEPOSIT_BOX_AUDIT',             'form_safe_deposit_box_audit_attestation');
	define('DB_TABLE_FORM_SAFE_DEPOSIT_BOX_AUDIT_CONTENTS',    'form_safe_deposit_box_audit_contents');	
	define('DB_TABLE_FORM_SHARE_COURIER',                      'form_share_courier_attestation');
	define('DB_TABLE_FORM_SHARE_COURIER_ITEMS',                'form_share_courier_attestation_items');
	define('DB_TABLE_FORM_SHARE_DESTRUCTION',                  'form_share_destruction_attestation');
	define('DB_TABLE_FORM_SHARE_DISTRIBUTION',                 'form_share_distribution_attestation');	
	define('DB_TABLE_FORM_SHARE_CREATION',                     'form_share_creation_attestation');	
	define('DB_TABLE_FORM_SHARE_ESCROW',                       'form_share_escrow_attestation');
	define('DB_TABLE_FORM_SHARE_REBAG',                        'form_share_rebag_attestation');
	define('DB_TABLE_FORM_SHARE_RELABEL',                      'form_share_relabel_attestation');
	define('DB_TABLE_FORM_SHARE_RELOCATION',                   'form_share_relocation_attestation');
	define('DB_TABLE_FORM_SHARE_TRANSFER',                     'form_share_transfer_attestation');
	define('DB_TABLE_FORM_SHAREHOLDER_FUNCTION_CHANGE',        'form_shareholder_function_change_attestation');	// Form renamed to Personnel Intra Role Change
	define('DB_TABLE_FORM_SHAREHOLDER_ROLE_CHANGE',            'form_shareholder_role_change_attestation');		// Form renamed to Personnel Inter Role Change
	define('DB_TABLE_FORM_SKR_RECEIPT_INSTALL',                'form_skr_receipt_install_attestation');

	// Cookie constants
	
	define('COOKIE_AUTH_EXP_DAYS',     			14);
	
	// LDAP constants
		
	#define('LDAP_SERVER', 		'ldaps://dul1wndc02.vcorp.ad.vrsn.com/');	// BRN
	#define('LDAP_SERVER', 		'ldaps://ipa01.shared-bo.brn1.vrsn.com/');	// BRN-IPA
	# define('LDAP_SERVER', 		'ldaps://10.19.12.20/');					// FRI
	# define('LDAP_SERVER', 		'ldaps://10.19.12.24/');					// FRI
	define('LDAP_SERVER', 			'ldaps://10.170.12.56/');					// ILG	
	define('LDAP_BASEDN', 			'dc=vcorp,dc=ad,dc=vrsn,dc=com');
	define('LDAP_DOMAIN', 			'vcorp.ad.vrsn.com');
	define('LDAP_USER',			$GLOBAL_LDAP_USERNAME);
	define('LDAP_PASS',			$GLOBAL_LDAP_PASSWORD);
	
	// Email settings
	
	define('EMAIL_CC',                            'bglinkerman@verisign.com');
	define('EMAIL_BCC',                           'bglinkerman@verisign.com');
	define('EMAIL_FROM',                          'naming-cbo@verisign.com');

	define('EMAIL_MANAGER_CHANGE_TO',             EMAIL_CC . ',naming-cbo@verisign.com');	
	define('EMAIL_MANAGER_CHANGE_SUBJECT',        'Shareholder Manager Change');
	
	define('EMAIL_DESK_CHANGE_TO',                EMAIL_MANAGER_CHANGE_TO);
	define('EMAIL_DESK_CHANGE_SUBJECT',           'Shareholder Location Change');

	define('EMAIL_TITLE_CHANGE_TO',                EMAIL_MANAGER_CHANGE_TO);
	define('EMAIL_TITLE_CHANGE_SUBJECT',           'Job Title Change');
	
        define('EMAIL_END_OF_LIFE_TO',               EMAIL_CC . ',naming-cbo@verisign.com');
        define('EMAIL_END_OF_LIFE_SUBJECT',         'Equipment End-of-Life Notice');

	// Function & box definitions
	
	define('REGEX_BOXES_MOFN', 	               '/^((BRN|ILG)(0[1-9]|1[0-6]))$/');
	define('REGEX_BOXES_DSO', 	               '/^((BRN|ILG)(1[7-9]|2[0-2]))$/');
	define('REGEX_BOXES_HSM', 	               '/^((BRN|ILG)23)$/');
	define('REGEX_BOXES_PASSWORDS', 	       '/^((BRN|ILG)2[4-5])$/');
	
	define('REGEX_CBO_FUNCTIONS', 	           '/^(4|9|10|11|24|25|26|27)$/');
	define('REGEX_DCA_FUNCTIONS', 	           '/^(4|22|23)$/');
	define('REGEX_POOL_BRN_FUNCTIONS', 	       '/^(24|26)$/');
	define('REGEX_POOL_ILG_FUNCTIONS', 	       '/^(25|27)$/');
	define('REGEX_POOL_ALL_FUNCTIONS', 	       '/^(24|26|25|27)$/');

	// Misc
	
	define('JQUERY_VERSION',                    'jquery-1.8.0.min.js');
	define('JQUERY_VERSION_UI',                 'jquery-ui-1.8.23.custom.min.js');
	define('DEFAULT_PAGE',                      'home.php');
	define('DEFAULT_EMAIL_DOMAIN',              'verisign.com');
	define('HTML_SITE_NAME',                    'CBO');
	define('FROMS_FILE_EXTENSION',              '.docx');
	define('ICAL_FROM',                         'naming-cbo@verisign.com');
	
	// Number of days prior to an event that email reminders should be sent out
		
	$_GLOBALS['email_reminders'] = array(14, 7, 1);

?>
