<?php

	// Authenticate a user against AD
	
	function authenticate_user($Username, $Password){		
		$AD = ldap_connect(LDAP_SERVER);			
		ldap_set_option($AD, LDAP_OPT_PROTOCOL_VERSION, 3);
		ldap_set_option($AD, LDAP_OPT_REFERRALS, 0); 
		$Bind = @ldap_bind($AD, "$Username@" . LDAP_DOMAIN, $Password);
		
		if($Bind){
			$Result   = ldap_search($AD, LDAP_BASEDN, "sAMAccountName=$Username");
			$LDAPInfo = ldap_get_entries($AD, $Result);
			if($Result) {
				return $LDAPInfo[0];
			}
		}else{
			return FALSE;
		}
	}
	
	// Create a cookie after a user sucessfully logs in
	
	function create_cookie($Username){
		$UserID = user_id_lookup($Username);
		$Number = mt_rand() . mt_rand() . mt_rand() . mt_rand();
		$Token  = md5($Number);

		$ExpiryTime = 60 * 60 * 24 * COOKIE_AUTH_EXP_DAYS;
		
		setcookie("username", $Username, time() + $ExpiryTime);		
		setcookie("token", $Token, time() + $ExpiryTime);
		setcookie("user_id", $UserID, time() + $ExpiryTime);

		$Info['user_id'] = $UserID;
		$Info['token']   = $Token;
		$Info['date']    = "NOW()";
		
		$Result = db_query(create_sql_insert($Info, DB_TABLE_TOKENS), FALSE);

		if(!$Result){ return 0; }else{ return 1; }		
	}

	// Remove old tokens (Default is +14 days)
	
	function token_cleanup() {
		$Days   = COOKIE_AUTH_EXP_DAYS;
		$Where  = "(date + INTERVAL $Days DAY) < NOW()";
		$Result = db_query(create_sql_delete($Where , DB_TABLE_TOKENS), FALSE);	
	} 
	
	// Validate a users credentials using the randomly generated tokens
	
	function validate_user(){	
		if(isset($_COOKIE['username'])){ $Username = clean_sql_value($_COOKIE['username']); }
		if(isset($_COOKIE['token'])){    $Token    = clean_sql_value($_COOKIE['token']); }		
		if(isset($_COOKIE['user_id'])){  $UserID   = clean_sql_value($_COOKIE['user_id']); }

		$NumberOfRows = 0;
		if(isset($Username, $Token, $UserID)){
			$Query = "SELECT token, username, t.user_id FROM " . DB_TABLE_USERS . " u LEFT JOIN " . DB_TABLE_TOKENS . " t ON u.user_id=t.user_id WHERE token='$Token' AND username='$Username' AND t.user_id='$UserID'";
			$Result = db_query($Query);
			$NumberOfRows = row_count($Result);	
		}

		if($NumberOfRows == 1){
			return TRUE;
		} else {
		
			// If the user is trying to access a page via an external link (ex: email) and they are not logged in, add their destination link to the URL
		
			$URL = urlencode($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']);
			redirect('ldap_login.php?url=' . $URL);
		}
	}
	
	// Verify that a user is in the ACL
	
	function check_user_acl($Username){
		$Query = "SELECT DISTINCT(username) FROM " . DB_TABLE_USER_ACL . " WHERE username='$Username' AND deleted=0";
		$Result = db_query($Query);
		$NumberOfRows = row_count($Result);
		
		return ($NumberOfRows == 1 ? TRUE : FALSE);
	}
	
	// Check to see if a user is an admin
	
	function is_admin($UserID){
		$Query = "SELECT is_admin FROM " . DB_TABLE_USERS . " WHERE user_id='$UserID' AND disabled=0";
		$Result = db_query($Query);
		$NumberOfRows = row_count($Result);
		
		if($NumberOfRows == 1){
			$Data = row_fetch($Result);
			return ($Data[0] == 1 ? TRUE : FALSE);
		}else{
			return FALSE;
		}
	}
		
?>
